﻿(function(){
  const normalizeKey = (value)=>{
    let text = String(value == null ? '' : value).trim().toLowerCase();
    try{ text = text.normalize('NFD').replace(/[\u0300-\u036f]/g, ''); }catch(_){ }
    return text
      .replace(/[^a-z0-9]+/g, '_')
      .replace(/^_+|_+$/g, '')
      .replace(/_+/g, '_');
  };

  const normalizeTable = (table, index)=>{
    if(!table || typeof table !== 'object') return null;
    const columns = Array.isArray(table.columnas) ? table.columnas.map((cell)=> String(cell == null ? '' : cell)) : [];
    const rows = Array.isArray(table.filas)
      ? table.filas.map((row)=> Array.isArray(row) ? row.map((cell)=> String(cell == null ? '' : cell)) : [String(row == null ? '' : row)])
      : [];
    if(!columns.length && !rows.length) return null;
    return {
      title: String(table.titulo == null ? '' : table.titulo),
      columns,
      rows,
      id: 'tabla_' + String(index + 1)
    };
  };

  const source = [
    {
        "nombre":  "Acción",
        "descripcion":  "En tu turno, puedes llevar a cabo una acción. Elige qué acción quieres realizar entre las que aparecen a continuación o entre las acciones especiales que te otorgan tus rasgos. Estas acciones se definen en otras partes del glosario:",
        "notas":  [
                      "Atacar",
                      "Ayudar",
                      "Buscar",
                      "Correr",
                      "Destrabarse",
                      "Esconderse",
                      "Esquivar",
                      "Estudiar",
                      "Influir",
                      "Magia",
                      "Preparar una acción",
                      "Utilizar"
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Acciones"
                             ]
    },
    {
        "nombre":  "Acción adicional",
        "descripcion":  "Una acción adicional es una acción especial que puedes hacer en el mismo turno en que llevas a cabo una acción. No puedes realizar más de una acción adicional en un turno y solo tienes acciones adicionales a tu disposición si una regla lo indica de forma explícita.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Acciones"
                             ]
    },
    {
        "nombre":  "Actitud",
        "descripcion":  "Los monstruos tienen una actitud inicial hacia un personaje de un jugador, la cual puede ser amistosa, hostil o indiferente.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Amistosa",
                                 "Hostil",
                                 "Indiferente",
                                 "Influir"
                             ]
    },
    {
        "nombre":  "Agarrado [estado]",
        "descripcion":  "Mientras tengas el estado de agarrado, experimentarás los siguientes efectos:",
        "notas":  [
                      "Velocidad 0. Tu velocidad es 0 y no puede aumentar.",
                      "Ataques afectados. Tienes desventaja en las tiradas de ataque contra cualquier objetivo que no sea quien te agarra.",
                      "Desplazable. Quien te agarra puede arrastrarte o transportarte al moverse, pero cada pie de movimiento le cuesta 1 pie adicional, salvo que seas Diminuto o tu tamaño sea dos o más categorías inferior al suyo."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Agarrar",
        "descripcion":  "Una criatura puede agarrar a otra. Por lo general, los personajes realizan agarres usando un ataque sin armas. Muchos monstruos poseen ataques especiales que les permiten agarrar a sus presas rápidamente. Cuando se inicia un agarre, este sigue las siguientes reglas.",
        "notas":  [
                      "Estado de agarrada. Agarrar a una criatura le impone el estado de agarrada.",
                      "Un agarre por mano. Una criatura debe tener una mano libre para agarrar a otra criatura. Algunos perfiles y efectos del juego permiten que una criatura agarre a otra usando un tentáculo, sus fauces u otra parte del cuerpo. Independientemente de la parte del cuerpo que emplee, podrá agarrar solo a una criatura a la vez con esa parte y no podrá usar esa parte para hacer objetivo a otra criatura salvo que ponga fin al agarre.",
                      "Poner fin a un agarre. Una criatura agarrada puede emplear su acción para hacer una prueba de Fuerza (Atletismo) o Destreza (Acrobacias) contra la CD para escapar del agarre; si la supera, pondrá fin a su estado. El estado también termina si quien agarra tiene el estado de incapacitado o si la distancia entre el objetivo agarrado y quien lo agarra supera el alcance del agarre. Además, quien agarra puede soltar al objetivo en cualquier momento (no requiere acción)."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Agarrado",
                                 "Ataque sin armas"
                             ]
    },
    {
        "nombre":  "Al día",
        "descripcion":  "Si una regla indica que puedes utilizar algo una cantidad determinada de veces al día, significa que debes finalizar un descanso largo para emplearlo de nuevo tras consumir todos los usos.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Alcance",
        "descripcion":  "Una criatura tiene un alcance de 5 pies a menos que una regla indique algo distinto.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Aliado",
        "descripcion":  "Una criatura es tu aliada si es un miembro de tu grupo de aventureros, si es tu amiga, si combate en tu bando o si las reglas o tu GM determinan que sea tu aliada.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Alineamiento",
        "descripcion":  "El alineamiento de una criatura describe en términos generales su actitud e ideales éticos. El alineamiento es una combinación de dos factores: por una parte, la moralidad (bueno, malvado o neutral) y, por otra, la actitud hacia el orden (legal, caótico o neutral). Estos factores dan pie a nueve combinaciones posibles, como las de legal bueno y neutral malvado.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Creación de personajes \u003e Crear tu personaje"
                             ]
    },
    {
        "nombre":  "Amistosa [actitud]",
        "descripcion":  "Una criatura amistosa te verá con buenos ojos. Tienes ventaja en las pruebas de característica para influir en una criatura amistosa.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Influir"
                             ]
    },
    {
        "nombre":  "Apresado [estado]",
        "descripcion":  "Mientras tengas el estado de apresado, experimentarás los siguientes efectos:",
        "notas":  [
                      "Velocidad 0. Tu velocidad es 0 y no puede aumentar.",
                      "Ataques afectados. Las tiradas de ataque contra ti tienen ventaja y tus tiradas de ataque tienen desventaja.",
                      "Tiradas de salvación afectadas. Tienes desventaja en las tiradas de salvación de Destreza."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Área de efecto",
        "descripcion":  "Las descripciones de muchos conjuros y otros rasgos especifican que tienen un área de efecto, que suele tener una de seis formas posibles. Estas formas se definen en otras partes del glosario:",
        "notas":  [
                      "Cilindro",
                      "Cono",
                      "Cubo",
                      "Emanación",
                      "Esfera",
                      "Línea",
                      "Las áreas de efecto poseen un punto de origen, un lugar desde el que surge la energía del efecto. Las reglas de cada forma especifican cuál es el punto de origen. Si todas las líneas rectas que se extienden desde el punto de origen hasta un lugar del área de efecto están bloqueadas, ese lugar no estará incluido en el área de efecto. Para bloquear una línea, un obstáculo debe proporcionar cobertura completa. Si el creador de un área de efecto la sitúa en un punto que no vea y una obstrucción (como un muro) está entre dicho punto y el creador, el origen se moverá hasta el lado de la obstrucción más cercano a él."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cobertura"
                             ]
    },
    {
        "nombre":  "Arma",
        "descripcion":  "Un arma es un objeto que pertenece a la categoría de armas sencillas o marciales.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Equipo \u003e Armas"
                             ]
    },
    {
        "nombre":  "Armas improvisadas",
        "descripcion":  "Un arma improvisada es cualquier objeto que utilices como arma provisional, como una botella rota, la pata de una mesa o una sartén. Un arma sencilla o marcial también cuenta como arma improvisada si se emplea de un modo contrario a su diseño: por ejemplo, si utilizas un arma a distancia para realizar un ataque cuerpo a cuerpo o lanzas un arma cuerpo a cuerpo sin la propiedad “arrojadiza”, contará como un arma improvisada. Un arma improvisada sigue estas reglas:",
        "notas":  [
                      "Competencia. No sumas tu bonificador por competencia a las tiradas de ataque con un arma improvisada.",
                      "Daño. Si acierta, el arma inflige 1d4 de daño de un tipo que tu GM considere apropiado para el objeto.",
                      "Alcance. Si arrojas el arma, tendrá un alcance normal de 20 pies y un alcance largo de 60 pies.",
                      "Equivalentes del arma. Si un arma improvisada se parece a un arma sencilla o marcial, tu GM puede decidir que funcione como ella y emplear las reglas que se le aplican. Por ejemplo, tu GM podría tratar la pata de una mesa como un garrote."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Arrastrarse",
        "descripcion":  "Cuando te arrastras, cada pie de movimiento te cuesta 1 pie adicional (2 pies adicionales en terreno difícil).",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Velocidad"
                             ]
    },
    {
        "nombre":  "Asfixia [peligro]",
        "descripcion":  "Una criatura puede aguantar la respiración durante una cantidad de minutos igual a 1 más su modificador por Constitución (mínimo de 30 segundos) antes de que empiece a asfixiarse. Cuando una criatura se quede sin aire o se esté ahogando, sumará 1 nivel de cansancio al final de cada uno de sus turnos. Cuando recupere el aliento, perderá todos los niveles de cansancio sumados por la asfixia.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Asustado [estado]",
        "descripcion":  "Mientras tengas el estado de asustado, experimentarás los siguientes efectos: Pruebas de característica y ataques afectados. Tienes desventaja en las pruebas de característica y las tiradas de ataque mientras la fuente de tu miedo esté en tu línea de visión.",
        "notas":  [
                      "No puedes acercarte. No puedes acercarte voluntariamente a la fuente de tu miedo."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Atacar [acción]",
        "descripcion":  "Cuando llevas a cabo la acción de atacar, puedes hacer una tirada de ataque con un arma o un ataque sin armas. Equiparse con armas y desequiparse de ellas. Como parte de la acción de atacar, puedes equiparte con un arma o desequiparte de ella. Puedes hacerlo antes o después del ataque. Si te equipas con un arma antes de un ataque, no tienes por qué usarla en él. Equiparse con un arma incluye desenvainarla o recogerla. Desequiparse de un arma incluye envainarla, guardarla o soltarla.",
        "notas":  [
                      "Moverse entre ataques. Si te mueves en tu turno y tienes un rasgo, como Ataque adicional, que te permite hacer más de un ataque como parte de la acción de atacar, puedes usar parte del movimiento o todo él para moverte entre esos ataques."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Ataque con arma",
        "descripcion":  "Un ataque con arma es una tirada de ataque realizada con un arma.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Arma"
                             ]
    },
    {
        "nombre":  "Ataque de conjuro",
        "descripcion":  "Un ataque de conjuro es una tirada de ataque que se hace como parte de un conjuro u otro efecto mágico.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Conjuros \u003e Lanzar conjuros"
                             ]
    },
    {
        "nombre":  "Ataques de oportunidad",
        "descripcion":  "Puedes hacer un ataque de oportunidad cuando una criatura que puedas ver salga de tu alcance usando su acción, acción adicional, reacción o una de sus velocidades. Para ello, usa una reacción para hacer un ataque cuerpo a cuerpo con un arma o un ataque sin armas contra la criatura que lo provoque. Este ataque sucede justo antes de que la criatura se mueva fuera de tu alcance.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Combate"
                             ]
    },
    {
        "nombre":  "Ataque sin armas",
        "descripcion":  "En lugar de utilizar un arma para realizar un ataque cuerpo a cuerpo, puedes dar un puñetazo, una patada, un cabezazo o cualquier otro golpe enérgico. En la terminología del juego, esto se denomina un ataque sin armas: un ataque cuerpo a cuerpo en el que usas tu cuerpo para dañar, agarrar o empujar a un objetivo a 5 pies o menos de ti. Cuando uses tu ataque sin armas, elige una de las siguientes opciones para su efecto.",
        "notas":  [
                      "Daño. Haces una tirada de ataque contra el objetivo. Tu bonificador a la tirada es igual a tu modificador por Fuerza más tu bonificador por competencia. Si acierta, el objetivo sufre una cantidad de daño contundente igual a 1 más tu modificador por Fuerza.",
                      "Agarre. El objetivo deberá superar una tirada de salvación de Fuerza o Destreza (a su elección) o tendrá el estado de agarrado. La CD para la tirada de salvación y cualquier intento de escapar será igual a 8 más tu modificador por Fuerza y tu bonificador por competencia. Solo se puede ejecutar este agarre si el tamaño del objetivo está, como mucho, una categoría por encima de la tuya y si tienes una mano libre para agarrarlo.",
                      "Empujón. El objetivo deberá superar una tirada de salvación de Fuerza o Destreza (a su elección); de lo contrario, lo empujarás 5 pies respecto a ti o harás que tenga el estado de derribado. La CD para la tirada de salvación será igual a 8 más tu modificador por Fuerza y tu bonificador por competencia. Solo se puede dar este empujón si el tamaño del objetivo está, como mucho, una categoría por encima de la tuya."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Agarrar"
                             ]
    },
    {
        "nombre":  "Aturdido [estado]",
        "descripcion":  "Mientras tengas el estado de aturdido, experimentarás los siguientes efectos:",
        "notas":  [
                      "Incapacitado. Tienes el estado de incapacitado.",
                      "Tiradas de salvación afectadas. Fallas automáticamente las tiradas de salvación de Fuerza y Destreza.",
                      "Ataques afectados. Las tiradas de ataque contra ti tienen ventaja."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Aventura",
        "descripcion":  "Una aventura es una serie de encuentros. La historia surge al ir interpretándolos.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Encuentro"
                             ]
    },
    {
        "nombre":  "Ayudar [acción]",
        "descripcion":  "Cuando llevas a cabo la acción de ayudar, tienes estas opciones:",
        "notas":  [
                      "Ayudar en una prueba de característica. Elige una de tus competencias en habilidades o con herramientas y un aliado que esté lo bastante cerca como para ayudarle verbal o físicamente cuando haga una prueba de característica. Ese aliado tendrá ventaja en la siguiente prueba de característica que haga con la habilidad o herramienta elegidas. Este beneficio concluye si el aliado no lo usa antes del principio de tu siguiente turno. Tu GM tiene la última palabra sobre si puedes o no prestar esta ayuda.",
                      "Ayudar en una tirada de ataque. Distraes por un momento a un enemigo que esté a 5 pies o menos de ti, lo que da ventaja a la siguiente tirada de ataque que uno de tus aliados haga contra ese enemigo. Este beneficio concluye al principio de tu siguiente turno."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Buscar [acción]",
        "descripcion":  "Cuando llevas a cabo la acción de buscar, realizas una prueba de Sabiduría para distinguir algo que no resulta evidente. La tabla “Búsqueda” indica las habilidades que se pueden aplicar al usar esta acción, en función de lo que trates de detectar.",
        "notas":  [

                  ],
        "tablas":  [
                       {
                           "titulo":  "Búsqueda",
                           "columnas":  [
                                            "Habilidad",
                                            "Objeto de detección"
                                        ],
                           "filas":  [
                                         [
                                             "Medicina",
                                             "Dolencia o causa de la muerte de una criatura"
                                         ],
                                         [
                                             "Percepción",
                                             "Criatura u objeto ocultos"
                                         ],
                                         [
                                             "Perspicacia",
                                             "Estado mental de una criatura"
                                         ],
                                         [
                                             "Supervivencia",
                                             "Huellas o alimentos"
                                         ]
                                     ]
                       }
                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Caídas [peligro]",
        "descripcion":  "Una criatura que sufra una caída recibirá 1d6 de daño contundente por cada 10 pies que haya caído antes de golpearse contra el suelo, hasta un máximo de 20d6. La criatura caerá de bruces y tendrá el estado de derribada salvo que, de alguna forma, evite recibir daño de la caída. Toda criatura que caiga al agua u otro líquido podrá usar su reacción y hacer una prueba de Fuerza (Atletismo) o Destreza (Acrobacias) con CD 15 para entrar al agua de cabeza o de pie. Si la supera, cualquier daño que reciba por la caída se reducirá a la mitad.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Cambio de forma",
        "descripcion":  "Si un efecto, como el rasgo Forma salvaje o el conjuro polimorfar, te permite cambiar de forma, su descripción especifica lo que te ocurre. Salvo que se indique lo contrario, cualquier efecto que te esté afectando (estados, conjuros, maldiciones y similares) se conserva de una forma a otra. Si mueres, recuperas tu forma verdadera.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Campaña",
        "descripcion":  "Una campaña es una serie de aventuras.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Aventura"
                             ]
    },
    {
        "nombre":  "Canalizador mágico",
        "descripcion":  "Un canalizador mágico es un objeto que pueden usar determinadas criaturas en lugar de los componentes materiales de un conjuro si este no los consume y los materiales no tienen un coste especificado. Algunas clases permiten a sus miembros utilizar ciertos tipos de canalizadores mágicos.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Conjuros \u003e Lanzar conjuros"
                             ]
    },
    {
        "nombre":  "Cansancio [estado]",
        "descripcion":  "Mientras tengas el estado de cansancio, experimentarás los siguientes efectos:",
        "notas":  [
                      "Niveles de cansancio. Este estado es acumulativo. Cada vez que lo recibas, sumas 1 nivel de cansancio. Morirás si tu nivel de cansancio es 6.",
                      "Pruebas con d20 afectadas. Cuando hagas una prueba con d20, el resultado se reduce en 2 × tu nivel de cansancio.",
                      "Velocidad reducida. Tu velocidad se reduce en 5 pies × tu nivel de cansancio.",
                      "Eliminar niveles de cansancio. Tras finalizar un descanso largo, resta 1 nivel de cansancio. Cuando tus niveles de cansancio se reduzcan a 0, el estado terminará."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Capacidad de carga",
        "descripcion":  "Tu tamaño y tu puntuación de Fuerza determinan el peso máximo en libras que puedes transportar, como se muestra en la tabla “Capacidad de carga”. La tabla indica también el peso máximo que puedes arrastrar, levantar o empujar. Si arrastras, levantas o empujas un peso que supere el máximo que puedes cargar, tu velocidad no superará los 5 pies.",
        "notas":  [

                  ],
        "tablas":  [
                       {
                           "titulo":  "Capacidad de carga",
                           "columnas":  [
                                            "Tamaño de la criatura",
                                            "Máximo",
                                            "Arrastrar, levantar o empujar"
                                        ],
                           "filas":  [
                                         [
                                             "Diminuto",
                                             "Fue × 7,5 libras",
                                             "Fue × 15 libras"
                                         ],
                                         [
                                             "Pequeño/Mediano",
                                             "Fue × 15 libras",
                                             "Fue × 30 libras"
                                         ],
                                         [
                                             "Grande",
                                             "Fue × 30 libras",
                                             "Fue × 60 libras"
                                         ],
                                         [
                                             "Enorme",
                                             "Fue × 60 libras",
                                             "Fue × 120 libras"
                                         ],
                                         [
                                             "Gargantuesco",
                                             "Fue × 120 libras",
                                             "Fue × 240 libras"
                                         ]
                                     ]
                       }
                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Cegado [estado]",
        "descripcion":  "Mientras tengas el estado de cegado, experimentarás los siguientes efectos:",
        "notas":  [
                      "No puedes ver. No puedes ver y fallas automáticamente todas las pruebas de característica que requieran la vista.",
                      "Ataques afectados. Las tiradas de ataque contra ti tienen ventaja y tus tiradas de ataque tienen desventaja."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Cilindro [área de efecto]",
        "descripcion":  "Un cilindro es un área de efecto que se extiende en líneas rectas desde un punto de origen situado en el centro de la parte superior o inferior circular del cilindro. El efecto que crea un cilindro especifica el radio de la base y la altura del cilindro. El punto de origen de un cilindro está incluido en el área de efecto.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Clase de armadura",
        "descripcion":  "Una clase de armadura (CA) es el número objetivo de una tirada de ataque. La CA representa la dificultad de acertar a un objetivo. El cálculo de tu CA base es 10 + tu modificador por Destreza. Si una regla otorga otro cálculo de tu CA base, elige qué cálculo quieres usar, ya que no puedes usar más de uno.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Tirada de ataque"
                             ]
    },
    {
        "nombre":  "Clase de dificultad",
        "descripcion":  "Una clase de dificultad (CD) es el número objetivo de una prueba de característica o de una tirada de salvación.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Las pruebas con d20"
                             ]
    },
    {
        "nombre":  "Cobertura",
        "descripcion":  "La cobertura proporciona un grado de protección a un objetivo situado tras ella. Hay tres niveles de cobertura, cada uno de los cuales otorga un beneficio diferente al objetivo: cobertura media (bonificador de +2 a la CA y las tiradas de salvación de Destreza), cobertura tres cuartos (bonificador de +5 a la CA y las tiradas de salvación de Destreza) y cobertura completa (no puede ser el objetivo directo). Si un objetivo está detrás de más de un grado de cobertura, solo se beneficia del que le proporciona más protección.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Combate"
                             ]
    },
    {
        "nombre":  "Competencia",
        "descripcion":  "Si tienes competencia en algo o con algo, puedes sumar tu bonificador por competencia a cualquier prueba con d20 que hagas con ese elemento. Una criatura puede tener competencia en una habilidad o tirada de salvación, o con un arma o herramienta.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Competencia"
                             ]
    },
    {
        "nombre":  "Concentración",
        "descripcion":  "Algunos conjuros y otros efectos requieren concentración para permanecer activos, según se especifique en sus descripciones. Si el creador del efecto pierde la concentración, el efecto concluye. Si el efecto tiene una duración máxima, la descripción detalla cuánto tiempo puede concentrarse el creador en él: hasta 1 minuto, 1 hora u otra duración. El creador puede dejar de concentrarse en cualquier momento (no requiere acción). Los siguientes factores rompen la concentración:",
        "notas":  [
                      "Otro efecto de concentración. Pierdes la concentración en un efecto en cuanto comienzas a lanzar un conjuro que también requiere concentración o activas otro efecto que requiere concentración.",
                      "Daño. Si sufres daño, debes superar una tirada de salvación de Constitución para mantener la concentración. La CD es de 10 o la mitad del daño sufrido (redondeando hacia abajo), lo que sea mayor, hasta un máximo de 30.",
                      "Incapacitado o muerto. Tu concentración acaba si tienes el estado de incapacitado o mueres."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Conjuro",
        "descripcion":  "Un conjuro es un efecto mágico que tiene las características descritas en el capítulo “Conjuros”.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Cono [área de efecto]",
        "descripcion":  "Un cono es un área de efecto que se extiende en líneas rectas desde un punto de origen en la dirección que elija su creador. El ancho del cono en un punto cualquiera a lo largo de su extensión es igual a la distancia entre dicho punto y el origen. Por ejemplo, un cono tiene un ancho de 15 pies en un punto a lo largo de su extensión que esté a 15 pies del punto de origen. El efecto que crea un cono especifica su extensión máxima. El punto de origen de un cono no está incluido en el área de efecto, salvo que su creador decida lo contrario.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Correr [acción]",
        "descripcion":  "Cuando llevas a cabo la acción de correr, consigues movimiento adicional para ese turno. Este aumento es igual a tu velocidad tras aplicar cualquier modificador pertinente. Así, si tu velocidad fuera de 30 pies, podrías moverte hasta 60 pies en un turno en el que corras. Si tu velocidad de 30 pies se redujera a 15 pies, podrías moverte hasta 30 pies en un turno en el que realizaras la acción de correr. Si tienes una velocidad especial, como una velocidad nadando o una velocidad volando, puedes emplearla en lugar de tu velocidad normal cuando llevas a cabo esta acción. Eliges la velocidad que vas a emplear cada vez que realizas la acción.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Velocidad"
                             ]
    },
    {
        "nombre":  "Criatura",
        "descripcion":  "Cualquier ser que aparece en el juego, incluidos los personajes de los jugadores, se considera una criatura.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Tipo de criatura"
                             ]
    },
    {
        "nombre":  "Crítico",
        "descripcion":  "Si sacas un 20 en el d20 al hacer una tirada de ataque, causarás un crítico y el ataque acertará sin tener en cuenta los modificadores ni la CA del objetivo. Un crítico te permite tirar dados de daño adicionales contra el objetivo: tira todos los dados de daño del ataque dos veces, suma los resultados y luego añade los modificadores pertinentes.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Daño y curación"
                             ]
    },
    {
        "nombre":  "Cubo [área de efecto]",
        "descripcion":  "Un cubo es un área de efecto que se extiende en líneas rectas desde un punto de origen situado en cualquier parte de una cara del cubo. El efecto que crea un cubo especifica su tamaño, que es la longitud de cada lado. El punto de origen de un cubo no está incluido en el área de efecto, salvo que su creador decida lo contrario.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Curación",
        "descripcion":  "La curación es el medio para recuperar puntos de golpe.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Daño y curación"
                             ]
    },
    {
        "nombre":  "Dados de puntos de golpe",
        "descripcion":  "Los dados de puntos de golpe (o “dados de golpe” para abreviar) ayudan a determinar los puntos de golpe máximos de un personaje jugador, como se explica en el capítulo “Creación de personajes”. La mayoría de monstruos tienen también dados de golpe. Durante un descanso corto, una criatura puede gastar dados de golpe para recuperar puntos de golpe.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Descanso corto"
                             ]
    },
    {
        "nombre":  "Daño",
        "descripcion":  "Recibir daño hace que una criatura o un objeto pierda puntos de golpe.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Derribado [estado]",
        "descripcion":  "Mientras tengas el estado de derribado, experimentarás los siguientes efectos:",
        "notas":  [
                      "Movimiento restringido. Tus únicas opciones de movimiento son arrastrarte o gastar una cantidad de movimiento igual a la mitad de tu velocidad (redondeando hacia abajo) para levantarte y, por tanto, poner fin a este estado. Si tu velocidad es 0, no puedes levantarte.",
                      "Ataques afectados. Tienes desventaja en las tiradas de ataque. Las tiradas de ataque contra ti tienen ventaja si el atacante está a 5 pies o menos de ti. De lo contrario, las tiradas de ataque tienen desventaja."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Descanso corto",
        "descripcion":  "Un descanso corto es un periodo de inactividad de 1 hora en el que una criatura no hace nada más extenuante que leer, charlar, comer o montar guardia. Para comenzar un descanso corto, debes tener al menos 1 punto de golpe.",
        "notas":  [
                      "Beneficios del descanso. Tras finalizar el descanso obtendrás los siguientes beneficios:",
                      "Gastar dados de puntos de golpe. Puedes gastar uno o más dados de puntos de golpe para recuperar puntos de golpe. Por cada dado de puntos de golpe que gastes de esta forma, tira el dado y suma tu modificador por Constitución al resultado. Recuperas una cantidad de puntos de golpe equivalente al total obtenido (con un mínimo de 1). Puedes decidir si gastas otro dado de puntos de golpe tras cada tirada.",
                      "Rasgo especial. Algunos rasgos se recargan con un descanso corto. Si tienes uno de estos rasgos, se recargará de la forma que indique su descripción.",
                      "Interrumpir el descanso. Un descanso corto se puede interrumpir de las siguientes formas: • si se tira iniciativa; • si se lanza un conjuro que no sea un truco; • si se sufre daño. Un descanso corto interrumpido no otorga ningún beneficio."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Descanso largo",
        "descripcion":  "Un descanso largo es un periodo de inactividad prolongado (al menos 8 horas) a disposición de cualquier criatura. Durante un descanso largo, duermes durante al menos 6 horas y realizas como máximo 2 horas de actividades ligeras, como leer, hablar, comer o montar guardia. Mientras duermes, tienes el estado de inconsciente. Tras finalizar un descanso largo, deberás esperar al menos 16 horas para comenzar otro.",
        "notas":  [
                      "Beneficios del descanso. Para comenzar un descanso largo, debes tener al menos 1 punto de golpe. Tras finalizar el descanso obtendrás los siguientes beneficios:",
                      "Puntos de golpe al máximo. Recuperas todos los puntos de golpe perdidos y todos los dados de puntos de golpe gastados. Si tus puntos de golpe máximos se habían reducido, vuelven a la normalidad. Puntuaciones de característica restablecidas. Si alguna de tus puntuaciones de característica se había reducido, vuelve a la normalidad.",
                      "Cansancio reducido. Si tienes el estado de cansancio, su nivel se reduce en 1.",
                      "Rasgo especial. Algunos rasgos se recargan con un descanso largo. Si tienes uno de estos rasgos, se recargará de la forma que indique su descripción.",
                      "Interrumpir el descanso. Un descanso largo se puede interrumpir de las siguientes formas: • si se tira iniciativa; • si se lanza un conjuro que no sea un truco; • si se sufre daño; • si se camina o se hace algún otro ejercicio físico durante 1 hora. Si logras descansar al menos 1 hora antes de la interrupción, obtienes los beneficios de un descanso corto. Puedes reanudar un descanso largo inmediatamente después de una interrupción. Si lo haces, el descanso requerirá 1 hora adicional por cada interrupción para finalizarlo."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Descanso corto"
                             ]
    },
    {
        "nombre":  "Deshidratación [peligro]",
        "descripcion":  "Las criaturas requieren cierta cantidad de agua al día en función de su tamaño, como se muestra en la tabla “Consumo de agua al día”. Si una criatura bebe menos de la mitad del agua que necesita al día, sumará 1 nivel de cansancio al final del día. El cansancio causado por la deshidratación no puede eliminarse hasta que la criatura beba la cantidad completa de agua necesaria al día.",
        "notas":  [

                  ],
        "tablas":  [
                       {
                           "titulo":  "Consumo de agua al día",
                           "columnas":  [
                                            "Tamaño",
                                            "Agua"
                                        ],
                           "filas":  [
                                         [
                                             "Diminuto",
                                             "1/4 de galón"
                                         ],
                                         [
                                             "Pequeño",
                                             "1 galón"
                                         ],
                                         [
                                             "Mediano",
                                             "1 galón"
                                         ],
                                         [
                                             "Grande",
                                             "4 galones"
                                         ],
                                         [
                                             "Enorme",
                                             "16 galones"
                                         ],
                                         [
                                             "Gargantuesco",
                                             "64 galones"
                                         ]
                                     ]
                       }
                   ],
        "consulta_tambien":  [
                                 "Cansancio"
                             ]
    },
    {
        "nombre":  "Desnutrición [peligro]",
        "descripcion":  "Las criaturas necesitan cierta cantidad de alimentos al día en función de su tamaño, como se muestra en la tabla “Consumo de alimentos al día”. Si una criatura come, pero ingiere menos de la mitad de los alimentos que necesita al día, deberá superar una tirada de salvación de Constitución con CD 10 o sumará 1 nivel de cansancio al final del día. Si una criatura no come nada durante 5 días, sumará automáticamente 1 nivel de cansancio al final del quinto día y un nivel adicional al final de cada día posterior sin comer. El cansancio causado por la desnutrición no puede eliminarse hasta que la criatura coma la cantidad completa de alimentos necesarios al día.",
        "notas":  [

                  ],
        "tablas":  [
                       {
                           "titulo":  "Consumo de alimentos al día",
                           "columnas":  [
                                            "Tamaño",
                                            "Alimentos"
                                        ],
                           "filas":  [
                                         [
                                             "Diminuto",
                                             "4 onzas"
                                         ],
                                         [
                                             "Pequeño",
                                             "1 libra"
                                         ],
                                         [
                                             "Mediano",
                                             "1 libra"
                                         ],
                                         [
                                             "Grande",
                                             "4 libras"
                                         ],
                                         [
                                             "Enorme",
                                             "16 libras"
                                         ],
                                         [
                                             "Gargantuesco",
                                             "64 libras"
                                         ]
                                     ]
                       }
                   ],
        "consulta_tambien":  [
                                 "Cansancio"
                             ]
    },
    {
        "nombre":  "Destrabarse [acción]",
        "descripcion":  "Si llevas a cabo la acción de destrabarse, tu movimiento no provocará ataques de oportunidad durante el resto del turno actual.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Desventaja",
        "descripcion":  "Si tienes desventaja en una prueba con d20, tira 2d20 y utiliza el resultado más bajo. Una tirada no puede verse afectada por más de una desventaja, y una ventaja y una desventaja en la misma tirada se anulan entre sí.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Las pruebas con d20"
                             ]
    },
    {
        "nombre":  "Efecto mágico",
        "descripcion":  "Un efecto es mágico si lo crea un conjuro, un objeto mágico o un fenómeno que una regla etiquete como mágico.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Efectos simultáneos",
        "descripcion":  "Si ocurren dos o más cosas a la vez en un turno, la persona (jugador o GM) de la partida cuyo turno esté en marcha decidirá el orden en el que ocurren esas cosas. Por ejemplo, si dos efectos ocurren al principio del turno del personaje de un jugador, el jugador decidirá qué efecto ocurre primero.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Emanación [área de efecto]",
        "descripcion":  "Una emanación es un área de efecto que se extiende en líneas rectas desde una criatura o un objeto en todas las direcciones. El efecto que crea una emanación especifica la distancia que abarca. Una emanación se mueve con la criatura o el objeto que sea su origen, salvo que se trate de un efecto instantáneo o estático. El origen de una emanación (criatura u objeto) no se incluye en el área de efecto, salvo que su creador decida lo contrario.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Encuentro",
        "descripcion":  "Un encuentro es una escena de una aventura que forma parte de al menos uno de los tres pilares del juego: interacciones sociales, exploración o combate.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar",
                                 "Interacciones sociales",
                                 "Exploración",
                                 "Combate"
                             ]
    },
    {
        "nombre":  "Enemigo",
        "descripcion":  "Una criatura es tu enemiga si se opone a ti en combate, si tiene intención de perjudicarte o si las reglas o tu GM la designan como tal.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Ensordecido [estado]",
        "descripcion":  "Mientras tengas el estado de ensordecido, experimentarás el siguiente efecto:",
        "notas":  [
                      "No puedes oír. No puedes oír y fallas automáticamente las pruebas de característica que requieran el oído."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Entrenamiento con armaduras",
        "descripcion":  "El entrenamiento con armaduras te permite utilizar una armadura de una determinada categoría sin los siguientes inconvenientes. Si llevas una armadura ligera, media o pesada, pero no te has entrenado con ella, tendrás desventaja en cualquier prueba con d20 que implique la Fuerza o la Destreza y no podrás lanzar conjuros. Si embrazas un escudo, pero no te has entrenado con él, no obtendrás su bonificador a la CA.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Desventaja",
                                 "Equipo",
                                 "Armaduras"
                             ]
    },
    {
        "nombre":  "Envenenado [estado]",
        "descripcion":  "Mientras tengas el estado de envenenado, experimentarás el siguiente efecto: Pruebas de característica y ataques afectados. Tienes desventaja en las tiradas de ataque y las pruebas de característica.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Esconderse [acción]",
        "descripcion":  "Con la acción de esconderse, tratas de ocultarte. Para ello, debes superar una prueba de Destreza (Sigilo) con CD 15 mientras estás en una zona muy oscura o detrás de una cobertura tres cuartos o completa, y deberás estar fuera de la línea de visión de cualquier enemigo; si puedes ver a una criatura, sabrás si te puede ver o no. Si la superas, tendrás el estado de invisible mientras permanezcas oculto. Anota el resultado de tu prueba, que es la CD para que una criatura te detecte con una prueba de Sabiduría (Percepción). Dejas de estar oculto inmediatamente después de que ocurra algo de lo siguiente: haces un ruido más alto que un susurro, un enemigo te detecta, haces una tirada de ataque o lanzas un conjuro con un componente verbal.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Esfera [área de efecto]",
        "descripcion":  "Una esfera es un área de efecto que se extiende en líneas rectas desde un punto de origen hacia fuera en todas las direcciones. El efecto que crea una esfera especifica la distancia que se extiende como el radio de la esfera. El punto de origen de una esfera está incluido en su área de efecto.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Espacio ocupado",
        "descripcion":  "Un espacio se considera ocupado si una criatura se encuentra en él o si está completamente lleno de objetos.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Espacio sin ocupar",
        "descripcion":  "Un espacio está sin ocupar si no hay criaturas en él y si no está completamente lleno de objetos.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Esquivar [acción]",
        "descripcion":  "Si llevas a cabo la acción de esquivar, obtienes los siguientes beneficios: hasta el principio de tu siguiente turno, las tiradas de ataque contra ti tendrán desventaja si puedes ver al atacante y tendrás ventaja en las tiradas de salvación de Destreza. Perderás estos beneficios si tienes el estado de incapacitado o si tu velocidad es 0.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Estable",
        "descripcion":  "Una criatura está estable si tiene 0 puntos de golpe pero no debe hacer tiradas de salvación contra muerte.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Daño y curación"
                             ]
    },
    {
        "nombre":  "Estado",
        "descripcion":  "Un estado es una situación temporal que experimenta una criatura en la partida. La definición de un estado indica cómo afecta a su destinatario y diversas reglas explican cómo poner fin a un estado. El glosario define los siguientes estados:",
        "notas":  [
                      "Agarrado",
                      "Apresado",
                      "Asustado",
                      "Aturdido",
                      "Cansancio",
                      "Cegado",
                      "Derribado",
                      "Ensordecido",
                      "Envenenado",
                      "Hechizado",
                      "Incapacitado",
                      "Inconsciente",
                      "Invisible",
                      "Paralizado",
                      "Petrificado",
                      "Un estado no se acumula: el destinatario lo tiene o no lo tiene. El estado de cansancio es una excepción a esta regla."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Estudiar [acción]",
        "descripcion":  "Cuando llevas a cabo la acción de estudiar, haces una prueba de Inteligencia para explorar tus recuerdos o examinar un libro, una pista u otra fuente de conocimiento y recordar algún dato importante. La tabla “Áreas de conocimiento” sugiere qué habilidades se pueden aplicar a diversos ámbitos.",
        "notas":  [

                  ],
        "tablas":  [
                       {
                           "titulo":  "Áreas de conocimiento",
                           "columnas":  [
                                            "Habilidad",
                                            "Áreas"
                                        ],
                           "filas":  [
                                         [
                                             "Conocimiento arcano",
                                             "Conjuros, objetos mágicos, símbolos sobrenaturales, tradiciones mágicas, planos de existencia y determinadas criaturas (aberraciones, autómatas, elementales, feéricos y monstruosidades)"
                                         ],
                                         [
                                             "Historia",
                                             "Acontecimientos y personajes históricos, civilizaciones antiguas, guerras y determinadas criaturas (gigantes y humanoides)"
                                         ],
                                         [
                                             "Investigación",
                                             "Trampas, códigos, enigmas y artilugios"
                                         ],
                                         [
                                             "Naturaleza",
                                             "Terreno, flora, clima y determinadas criaturas (bestias, cienos, dragones y plantas)"
                                         ],
                                         [
                                             "Religión",
                                             "Deidades, jerarquías religiosas y ritos, símbolos sagrados, sectas y determinadas criaturas (celestiales, infernales y muertos vivientes)"
                                         ]
                                     ]
                       }
                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Fuego [peligro]",
        "descripcion":  "Una criatura u objeto que arda sufre 1d4 de daño de fuego al principio de cada uno de sus turnos. Como acción, puedes apagar el fuego que te afecta adoptando el estado de derribado y rodando por el suelo. El fuego también se extingue si se empapa, se sumerge o se ahoga.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Habilidad",
        "descripcion":  "Una habilidad es un área de especialización asociada a una prueba de característica. Si eres competente en una habilidad, puedes sumar tu bonificador por competencia cuando hagas una prueba de característica asociada a esa habilidad.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Competencia"
                             ]
    },
    {
        "nombre":  "Hechizado [estado]",
        "descripcion":  "Mientras tengas el estado de hechizado, experimentarás los siguientes efectos: No puedes dañar a quien te haya hechizado. No puedes atacar ni elegir como objetivo de efectos dañinos o mágicos a quien te haya hechizado.",
        "notas":  [
                      "Ventaja social. Quien te haya hechizado tiene ventaja en las pruebas de característica para interactuar socialmente contigo."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Hoja de personaje",
        "descripcion":  "Una hoja de personaje es un registro en papel o digital en el que apuntas la información sobre tu personaje.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Creación de personajes"
                             ]
    },
    {
        "nombre":  "Hostil [actitud]",
        "descripcion":  "Una criatura hostil te ve con malos ojos. Tienes desventaja en las pruebas de característica para influir en una criatura hostil.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Influir"
                             ]
    },
    {
        "nombre":  "Ilusiones",
        "descripcion":  "Los conjuros y otros efectos a veces crean ilusiones mágicas. Estos efectos definen lo que hace la ilusión y con qué sentidos o facultades mentales juega. Si una ilusión se manifiesta en un lugar, será insustancial e ingrávida, aunque parecerá que le afecta el entorno como si la ilusión fuera real, salvo que el efecto que la haya creado especifique algo distinto. Por ejemplo, una ilusión visual de una criatura proyecta sombras y reflejos, y el viento parece afectar a la criatura ilusoria. De manera similar, una ilusión audible resuena en un lugar con eco.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Incapacitado [estado]",
        "descripcion":  "Mientras tengas el estado de incapacitado, experimentarás los siguientes efectos:",
        "notas":  [
                      "Inactivo. No puedes llevar a cabo ninguna acción, acción adicional o reacción.",
                      "Pérdida de concentración. Pierdes la concentración.",
                      "Mudo. No puedes hablar.",
                      "Sorprendido. Si tienes el estado de incapacitado cuando tiras iniciativa, tendrás desventaja en la tirada."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Inconsciente [estado]",
        "descripcion":  "Mientras tengas el estado de inconsciente, experimentarás los siguientes efectos:",
        "notas":  [
                      "Inerte. Tienes los estados de derribado e incapacitado y sueltas lo que estés sujetando. Cuando concluya este estado, permanecerás derribado.",
                      "Velocidad 0. Tu velocidad es 0 y no puede aumentar.",
                      "Ataques afectados. Las tiradas de ataque contra ti tienen ventaja.",
                      "Tiradas de salvación afectadas. Fallas automáticamente las tiradas de salvación de Fuerza y Destreza.",
                      "Críticos automáticos. Cualquier tirada de ataque que te acierte es un crítico si el atacante está a 5 pies o menos de ti.",
                      "Ignorante. No eres consciente de tu entorno."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Indiferente [actitud]",
        "descripcion":  "Una criatura indiferente no tiene interés ni en ayudarte ni en obstaculizarte. Esta es la actitud por defecto de un monstruo.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Influir"
                             ]
    },
    {
        "nombre":  "Influir [acción]",
        "descripcion":  "Con la acción de influir, instas a un monstruo a que haga algo. Describe o interpreta cómo te comunicas con ese monstruo. ¿Tratas de engañarlo, intimidarlo, entretenerlo o persuadirlo disimuladamente? Tu GM determinará si el monstruo muestra disposición (voluntario) o no (no voluntario), o si está indeciso por tu interacción; conforme a esto, establecerá si se necesita o no hacer una prueba de característica, como se explica a continuación.",
        "notas":  [
                      "Voluntario. Si tu afán concuerda con los deseos del monstruo, no será necesaria ninguna prueba de característica: el monstruo cumplirá con lo que le pidas de la forma que estime pertinente.",
                      "No voluntario. Si tu deseo resulta aversivo para el monstruo u opuesto a su alineamiento, no será necesaria ninguna prueba de característica: no lo aceptará.",
                      "Indeciso. Si instas al monstruo a que haga algo sobre lo que siente dudas, deberás realizar una prueba de característica, en la que influirá la actitud del monstruo: indiferente, amistosa u hostil, todas ellas definidas en este glosario. La tabla “Pruebas de influencia” sugiere qué prueba de característica se debe hacer en función de cómo interactúas con el monstruo. Tu GM elegirá la prueba, que tendrá por defecto una CD igual a 15 o la puntuación de Inteligencia del monstruo, la que sea más alta. Si la superas, el monstruo hará lo que le pides. Si la fallas, deberás esperar 24 horas (o el plazo que establezca tu GM) antes de volver a insistir."
                  ],
        "tablas":  [
                       {
                           "titulo":  "Pruebas de influencia",
                           "columnas":  [
                                            "Prueba de característica",
                                            "Interacción"
                                        ],
                           "filas":  [
                                         [
                                             "Carisma (Engaño)",
                                             "Engañar a un monstruo que te entienda."
                                         ],
                                         [
                                             "Carisma (Interpretación)",
                                             "Entretener a un monstruo."
                                         ],
                                         [
                                             "Carisma (Intimidación)",
                                             "Intimidar a un monstruo."
                                         ],
                                         [
                                             "Carisma (Persuasión)",
                                             "Persuadir a un monstruo que te entienda."
                                         ],
                                         [
                                             "Sabiduría (Trato con animales)",
                                             "Convencer poco a poco a una bestia o monstruosidad."
                                         ]
                                     ]
                       }
                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Iniciativa",
        "descripcion":  "La iniciativa determina el orden de los turnos durante el combate. Las reglas del combate del capítulo “Cómo jugar” explican cómo tirar iniciativa. A veces, los GM pueden hacer que los combatientes utilicen sus puntuaciones de iniciativa en vez de tirar iniciativa. Tu puntuación de iniciativa es igual a 10 + tu modificador por Destreza. Si tienes ventaja en las tiradas de iniciativa, aumenta tu puntuación de iniciativa en 5. Si, por el contrario, tienes desventaja en estas tiradas, reduce esa puntuación en 5.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Combate"
                             ]
    },
    {
        "nombre":  "Inmunidad",
        "descripcion":  "Si tienes inmunidad a un tipo de daño o un estado, no te afectará de ningún modo.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Inspiración heroica",
        "descripcion":  "Si tienes inspiración heroica (como personaje jugador), puedes gastarla para volver a tirar cualquier dado inmediatamente después de lanzarlo; si lo haces, deberás utilizar el nuevo resultado. Si obtienes inspiración heroica y ya tenías, se desperdiciará salvo que se la concedas a un personaje jugador que carezca de ella.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Invisible [estado]",
        "descripcion":  "Mientras tengas el estado de invisible, experimentarás los siguientes efectos:",
        "notas":  [
                      "Sorpresa. Si tienes el estado de invisible cuando tiras iniciativa, tendrás ventaja en la tirada.",
                      "Oculto. No te afecta ningún efecto que requiera ver a su objetivo, salvo que el creador del efecto pueda verte de alguna forma. Cualquier equipo que vistas o lleves contigo también se oculta.",
                      "Ataques afectados. Las tiradas de ataque contra ti tienen desventaja y tus tiradas de ataque tienen ventaja. Si una criatura puede verte de alguna forma, no obtienes este beneficio contra esa criatura."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Levitar",
        "descripcion":  "Algunas criaturas pueden levitar, como se indica en sus perfiles, y algunos conjuros y otros efectos otorgan la capacidad de levitar. Si levitas al volar, evitarás caerte en determinadas circunstancias.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Volar"
                             ]
    },
    {
        "nombre":  "Ligeramente oscuro",
        "descripcion":  "Tienes desventaja en las pruebas de Sabiduría (Percepción) para ver algo en un espacio ligeramente oscuro.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Luz tenue",
                                 "Cómo jugar",
                                 "Exploración"
                             ]
    },
    {
        "nombre":  "Línea [área de efecto]",
        "descripcion":  "Una línea es un área de efecto que se extiende desde un punto de origen en una trayectoria recta a lo largo de su extensión y cubre un área delimitada por su ancho. El efecto que crea una línea especifica su longitud y anchura. El punto de origen de una línea no está incluido en el área de efecto, salvo que su creador decida lo contrario.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Luz brillante",
        "descripcion":  "La luz brillante es la iluminación normal.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Exploración"
                             ]
    },
    {
        "nombre":  "Luz tenue",
        "descripcion":  "Una zona con luz tenue está ligeramente oscura.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Ligeramente oscuro",
                                 "Cómo jugar",
                                 "Exploración"
                             ]
    },
    {
        "nombre":  "Magia [acción]",
        "descripcion":  "Cuando llevas a cabo la acción de magia, puedes lanzar un conjuro que tenga un tiempo de lanzamiento de una acción o usar un rasgo u objeto mágico que requiera una acción de magia para activarlo. Si lanzas un conjuro que tiene un tiempo de lanzamiento de 1 minuto o superior, deberás realizar la acción de magia en cada turno de ese lanzamiento y mantener la concentración mientras lo haces. Si pierdes la concentración, el conjuro fallará, pero no gastarás un espacio de conjuro.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Concentración"
                             ]
    },
    {
        "nombre":  "Maldiciones",
        "descripcion":  "Algunos efectos del juego maldicen a una criatura o un objeto. El efecto que impone la maldición define lo que esta hace. Las maldiciones se pueden eliminar con los conjuros levantar maldición y restablecimiento mayor u otros efectos mágicos que especifiquen esa capacidad.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Maltrecho",
        "descripcion":  "Una criatura está maltrecha cuando le quedan la mitad de sus puntos de golpe o menos.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Monstruo",
        "descripcion":  "Un monstruo es una criatura que controla el GM, aunque dicha criatura sea bondadosa.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Criatura",
                                 "PNJ"
                             ]
    },
    {
        "nombre":  "Muerto",
        "descripcion":  "Una criatura muerta no tiene puntos de golpe ni puede recuperarlos salvo que antes la revivan con magia, como los conjuros alzar a los muertos o revivir. Cuando se lanza un conjuro de ese estilo, el espíritu sabe quién lo lanza y puede rechazarlo. El espíritu de una criatura muerta abandona su cuerpo y parte a los Planos Exteriores, por lo que revivir a la criatura requiere llamar a su espíritu para que regrese. Si la criatura vuelve a la vida, el efecto que la revive determina sus puntos de golpe actuales. Salvo que indique lo contrario, la criatura vuelve a la vida con cualquier estado, enfermedad mágica o maldición que la afectara en el momento de su muerte si las duraciones de esos efectos no han concluido. Si la criatura murió con algún nivel de cansancio, regresará con 1 nivel menos. Si la criatura estaba sintonizada con uno o varios objetos mágicos, dejará de estarlo.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Muy oscuro",
        "descripcion":  "Cuando tratas de ver algo en un espacio muy oscuro, tienes el estado de cegado.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cegado",
                                 "Oscuridad",
                                 "Cómo jugar",
                                 "Exploración"
                             ]
    },
    {
        "nombre":  "Nadar",
        "descripcion":  "Cuando nadas, cada pie de movimiento te cuesta 1 pie adicional (2 pies adicionales en terreno difícil). Ignoras este coste adicional si tienes una velocidad nadando y la usas para nadar. Si tu GM lo cree conveniente, para recorrer cualquier distancia por aguas revueltas podría tener que superarse una prueba de Fuerza (Atletismo) con CD 15.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Noquear a una criatura",
        "descripcion":  "Si fueses a reducir a 0 los puntos de golpe de una criatura con un ataque cuerpo a cuerpo, puedes optar por dejarla con 1 punto de golpe. En tal caso, la criatura tendrá el estado de inconsciente y comenzará un descanso corto. La criatura permanecerá inconsciente hasta que recupere algún punto de golpe o hasta que alguien utilice una acción para administrarle primeros auxilios, para lo que deberá superar una prueba de Sabiduría (Medicina) con CD 10.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Objetivo",
        "descripcion":  "Un objetivo es la criatura o el objeto al que una tirada de ataque hace objetivo, al que un efecto obliga a hacer una tirada de salvación o al que se selecciona para recibir los efectos de un conjuro u otro fenómeno.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Objeto",
        "descripcion":  "Un objeto es una cosa individual y sin vida. Las cosas compuestas, como los edificios, constan de más de un objeto.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Romper objetos"
                             ]
    },
    {
        "nombre":  "Oscuridad",
        "descripcion":  "Una zona de oscuridad está muy oscura.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Muy oscuro",
                                 "Cómo jugar",
                                 "Exploración"
                             ]
    },
    {
        "nombre":  "Paralizado [estado]",
        "descripcion":  "Mientras tengas el estado de paralizado, experimentarás los siguientes efectos:",
        "notas":  [
                      "Incapacitado. Tienes el estado de incapacitado.",
                      "Velocidad 0. Tu velocidad es 0 y no puede aumentar.",
                      "Tiradas de salvación afectadas. Fallas automáticamente las tiradas de salvación de Fuerza y Destreza.",
                      "Ataques afectados. Las tiradas de ataque contra ti tienen ventaja.",
                      "Críticos automáticos. Cualquier tirada de ataque que te acierte es un crítico si el atacante está a 5 pies o menos de ti."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Peligro",
        "descripcion":  "Un peligro es una situación contextual comprometida.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Asfixia",
                                 "Caídas, “Deshidratación",
                                 "Desnutrición",
                                 "Fuego"
                             ]
    },
    {
        "nombre":  "Percepción pasiva",
        "descripcion":  "La Percepción pasiva es una puntuación que refleja la atención general de una criatura al entorno. El GM usa esta puntuación para determinar si una criatura se percata de algo sin tener que realizar adrede una prueba de Sabiduría (Percepción). La Percepción pasiva de una criatura es igual a 10 + su bonificador a las pruebas de Sabiduría (Percepción). Si la criatura tiene ventaja en estas pruebas, aumenta la puntuación en 5. Si la criatura tiene desventaja en ellas, reduce la puntuación en 5. Por ejemplo, un personaje de nivel 1 con una Sabiduría de 15 y competencia en Percepción tiene una Percepción pasiva de 14 (10 + 2 + 2). Si ese personaje tiene ventaja en las pruebas de Sabiduría (Percepción), la puntuación será de 19.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Perfil",
        "descripcion":  "Un perfil contiene las estadísticas de juego de un monstruo. Cada perfil incluye la siguiente información tras el nombre del monstruo.",
        "notas":  [
                      "Tamaño. Un monstruo puede ser Diminuto, Pequeño, Mediano, Grande, Enorme o Gargantuesco.",
                      "Tipo de criatura. Este apartado indica la familia de seres a la que pertenece un monstruo, junto con cualquier etiqueta descriptiva.",
                      "Alineamiento. Se sugiere un alineamiento para el monstruo, aunque cada GM determina su alineamiento real.",
                      "CA, iniciativa y PG. Estos apartados muestran la clase de armadura, la iniciativa y los puntos de golpe del monstruo, que se explican en el capítulo “Cómo jugar”. Después de los puntos de golpe aparecen los dados de puntos de golpe del monstruo entre paréntesis, junto con la contribución de su Constitución a sus puntos de golpe, si corresponde. Tras el modificador a la iniciativa se encuentra la puntuación de iniciativa. Algunas criaturas creadas mediante magia no tienen información sobre los dados de golpe y la iniciativa.",
                      "Velocidad. Aquí se indica la velocidad del monstruo, junto con cualquier velocidad especial que tenga.",
                      "Puntuaciones de característica. Una tabla muestra las puntuaciones de característica, los modificadores y los modificadores a las tiradas de salvación del monstruo, todos ellos explicados en el capítulo “Cómo jugar”.",
                      "Habilidades. Este apartado indica las competencias en habilidades del monstruo, si es que tiene alguna.",
                      "Resistencias y vulnerabilidades. Estos apartados recogen las resistencias y vulnerabilidades del monstruo si es que tiene alguna.",
                      "Inmunidades. Este apartado recoge las inmunidades a daños y a estados del monstruo si es que tiene alguna.",
                      "Equipo. Si el monstruo tiene algún equipo que se puede entregar o recuperar, aparecerá en este apartado.",
                      "Sentidos. Este apartado incluye los sentidos especiales (como la visión en la oscuridad) y la",
                      "Percepción pasiva del monstruo.",
                      "Idiomas. En este apartado aparecen los idiomas que sabe el monstruo.",
                      "VD. El valor de desafío resume la amenaza que supone un monstruo y se explica en el capítulo “Monstruos”. Luego se muestran los puntos de experiencia que los personajes reciben por derrotar a un monstruo y su bonificador por competencia. Algunas criaturas creadas mediante magia no tienen VD.",
                      "Atributos. Los atributos del monstruo (si tiene) son capacidades que están activas todo el tiempo o en determinadas situaciones.",
                      "Acciones. El monstruo puede llevar a cabo estas acciones además de las detalladas en este glosario.",
                      "Acciones adicionales. Si el monstruo tiene opciones como acción adicional, aparecerán en este apartado.",
                      "Reacciones. Si el monstruo puede llevar a cabo alguna reacción especial, aparecerá en esta sección.",
                      "Notación de ataques. Los apartados de los ataques de un monstruo comienzan identificando si el ataque es cuerpo a cuerpo o a distancia. Luego indican el bonificador a la tirada de ataque, su alcance y lo que ocurre si acierta. Un ataque se lleva a cabo contra un objetivo salvo que este apartado diga lo contrario.",
                      "Notación de tiradas de salvación. Si un efecto obliga a realizar una tirada de salvación, el apartado del efecto comienza identificando el tipo de tirada de salvación necesaria. Luego indica la CD de la tirada de salvación y describe qué criaturas deben realizar la tirada y lo que ocurre si la fallan o la superan.",
                      "Notación del daño. Los perfiles suelen proporcionar un número estático y la tirada de dados usada con cada efecto de daño. Por ejemplo, un ataque podría causar 4 (1d4 +2) de daño si acierta. Cada GM determina si se emplea el número estático o la tirada de dados que aparece entre paréntesis: no se usan los dos."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Tamaño",
                                 "Tipo de criatura",
                                 "Alineamiento",
                                 "Velocidad excavando,",
                                 "Velocidad nadando",
                                 "Velocidad trepando",
                                 "Velocidad volando",
                                 "Cómo jugar \u003e Competencia",
                                 "Resistencia",
                                 "Vulnerabilidad",
                                 "Inmunidad",
                                 "Percepción pasiva",
                                 "Puntos de experiencia",
                                 "Valor de desafío",
                                 "Cómo jugar \u003e Acciones"
                             ]
    },
    {
        "nombre":  "Pericia",
        "descripcion":  "La pericia es un rasgo que mejora el uso de tu competencia en una habilidad. Cuando hagas una prueba de característica con una competencia en una habilidad en la que tengas pericia, tu bonificador por competencia se duplica en esa prueba salvo que otro rasgo lo duplique. Si ganas pericia, la ganas en una habilidad en la que tengas competencia. No puedes tener pericia más de una vez en la misma habilidad.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Competencia"
                             ]
    },
    {
        "nombre":  "Personaje jugador",
        "descripcion":  "Un personaje jugador (también llamado personaje de un jugador) es un personaje que controla un jugador.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Creación de personajes"
                             ]
    },
    {
        "nombre":  "Personaje no jugador",
        "descripcion":  "Un personaje no jugador (PNJ) es un monstruo que tiene un nombre propio y una personalidad particular.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Monstruo"
                             ]
    },
    {
        "nombre":  "Petrificado [estado]",
        "descripcion":  "Mientras tengas el estado de petrificado, experimentarás los siguientes efectos:",
        "notas":  [
                      "Transformación en sustancia inanimada. Te transformas, junto con cualquier objeto no mágico que vistas o lleves contigo, en una sustancia sólida e inanimada (normalmente piedra). Tu peso se multiplica por diez y dejas de envejecer.",
                      "Incapacitado. Tienes el estado de incapacitado.",
                      "Velocidad 0. Tu velocidad es 0 y no puede aumentar.",
                      "Ataques afectados. Las tiradas de ataque contra ti tienen ventaja.",
                      "Tiradas de salvación afectadas. Fallas automáticamente las tiradas de salvación de Fuerza y Destreza.",
                      "Resistencia al daño. Tienes resistencia a todo el daño.",
                      "Inmunidad al veneno. Tienes inmunidad al estado de envenenado."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Posesión",
        "descripcion":  "Algunos efectos hacen que una criatura sea poseída por otra criatura o entidad. Un efecto de posesión define cómo funciona la misma. Una posesión se puede prevenir con el conjuro protección contra el bien y el mal y deshacer con el conjuro disipar el bien y el mal.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Preparar una acción [acción]",
        "descripcion":  "Preparas una acción para esperar a que ocurra algo concreto antes de actuar. Para ello, llevas a cabo esta acción en tu turno, lo que te permitirá actuar usando tu reacción antes del principio de tu siguiente turno. En primer lugar, decide qué circunstancia (que puedas percibir) activará tu reacción. A continuación, elige la acción que realizarás en respuesta a dicha circunstancia. Como alternativa, en vez de una acción puedes decidir moverte hasta tu velocidad. Por ejemplo: “Si los sectarios pisan la trampilla, tiraré de la palanca que la abre” o “si el zombi se acerca, me alejaré de él”. Cuando se produzca la circunstancia de activación, podrás elegir entre usar tu reacción cuando dicha circunstancia termine o ignorarla. Cuando te preparas para lanzar un conjuro, lo lanzas con normalidad (gastando cualquier recurso empleado para lanzarlo), pero retienes su energía y la liberas usando tu reacción cuando se produzca la circunstancia que la desencadene. Solo los conjuros cuyo tiempo de lanzamiento sea de una acción pueden formar parte de una acción preparada. Además, el esfuerzo que implica contener las energías mágicas exige concentración, que podrás mantener hasta el principio de tu siguiente turno. Si pierdes la concentración, el conjuro se disipará sin causar efecto alguno.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Prueba con d20",
        "descripcion":  "Las pruebas con d20 abarcan las tres principales tiradas con el d20 en el juego: las pruebas de característica, las tiradas de ataque y las tiradas de salvación. Si algo en el juego afecta a las pruebas con d20, afecta a estas tres tiradas. Cada GM decide si una prueba con d20 está justificada en una circunstancia determinada.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Las pruebas con d20"
                             ]
    },
    {
        "nombre":  "Prueba de característica",
        "descripcion":  "Una prueba de característica es una prueba con d20 que representa el uso de una de las seis características (o de una habilidad asociada a una característica) para superar un desafío.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar",
                                 "Las pruebas con d20",
                                 "Competencia"
                             ]
    },
    {
        "nombre":  "Puntos de experiencia",
        "descripcion":  "A medida que los personajes superan desafíos y completan aventuras, ganan puntos de experiencia (PX) otorgados por su Game Master. Cuando el total de PX de un personaje supera ciertos umbrales, el personaje sube de nivel.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Progresión de niveles"
                             ]
    },
    {
        "nombre":  "Puntos de golpe",
        "descripcion":  "Los puntos de golpe (pg) miden lo difícil que resulta matar o destruir a una criatura u objeto. El daño reduce los puntos de golpe y la curación los restaura. No puedes tener más puntos de golpe que tus puntos de golpe máximos ni puedes tener menos de 0.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Romper objetos",
                                 "Cómo jugar",
                                 "Daño y curación"
                             ]
    },
    {
        "nombre":  "Puntos de golpe temporales",
        "descripcion":  "Algunos efectos otorgan puntos de golpe temporales, que evitan la pérdida de puntos de golpe reales.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Daño y curación"
                             ]
    },
    {
        "nombre":  "Puntuación de característica y modificador",
        "descripcion":  "Las criaturas tienen seis puntuaciones de característica: Fuerza, Destreza, Constitución, Inteligencia, Sabiduría y Carisma, que tienen su modificador correspondiente. Suma el modificador cuando hagas una prueba con d20 con la característica que corresponda o cuando una regla te lo pida.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Las seis características"
                             ]
    },
    {
        "nombre":  "Reacción",
        "descripcion":  "Una reacción es una acción especial que se realiza en respuesta a un suceso definido en su descripción. Puedes llevar a cabo una reacción en el turno de otra criatura, y si es en tu turno, puedes hacerlo incluso si también realizas una acción, una acción adicional o ambas. Cuando lleves a cabo una reacción, ya no podrás volver a hacerlo hasta el principio de tu siguiente turno. El ataque de oportunidad es una reacción disponible para todas las criaturas.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Ataques de oportunidad",
                                 "Cómo jugar",
                                 "Acciones"
                             ]
    },
    {
        "nombre":  "Redondear hacia abajo",
        "descripcion":  "Siempre que tengas que dividir o multiplicar un número en la partida, redondéalo hacia abajo si no es entero, incluso cuando la parte decimal sea 5 o más. Algunas reglas plantean excepciones e indican que redondees hacia arriba.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Resistencia",
        "descripcion":  "Si tienes resistencia a un tipo de daño, el daño de ese tipo se reduce a la mitad contra ti (redondeando hacia abajo). La resistencia se aplica solo una vez a un efecto de daño.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Daño y curación"
                             ]
    },
    {
        "nombre":  "Ritual",
        "descripcion":  "Si tienes preparado un conjuro marcado como “ritual”, puedes lanzarlo como un ritual. Lanzar un conjuro de forma ritual requiere 10 piesinutos más del tiempo normal, pero, a cambio, no se gasta ningún espacio de conjuro. Por tanto, no se puede lanzar la versión ritual de un conjuro a un nivel superior al de este.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Conjuros"
                             ]
    },
    {
        "nombre":  "Romper objetos",
        "descripcion":  "Los objetos pueden dañarse con ataques y algunos conjuros, conforme a las siguientes reglas. Si un objeto es extremadamente frágil, tu GM puede permitir que una criatura lo rompa automáticamente con las acciones de atacar o utilizar.",
        "notas":  [
                      "Clase de armadura. La tabla “Clase de armadura de objetos” muestra las CA de varias sustancias.",
                      "Puntos de golpe. Un objeto se destruye cuando sus puntos de golpe se reducen a 0. La tabla “Puntos de golpe de objetos” sugiere puntos de golpe para objetos frágiles y resistentes de tamaño Grande o más pequeño. Para asignar puntos de golpe a un objeto Enorme o Gargantuesco, divídelo en secciones Grandes o más pequeñas y lleva la cuenta de cada una por separado. Cada GM determina si destruir parte de un objeto hará que se desmorone por completo.",
                      "Tipos de daño y objetos. Los objetos tienen inmunidad al daño psíquico y de veneno. Cada GM puede decidir que determinados tipos de daño sean más o menos efectivos contra un objeto. Por ejemplo, el daño contundente sirve para destrozar cosas a golpes, pero no para cortar. Los objetos de papel o tela pueden ser vulnerables al daño de fuego.",
                      "Umbral de daño. Los objetos de gran tamaño, como los muros de un castillo, suelen tener una resistencia mayor, lo que se representa mediante un umbral de daño.",
                      "Sin puntuaciones de característica. Los objetos no tienen puntuaciones de característica, salvo que una regla les asigne puntuaciones. Al no tener puntuaciones de característica, los objetos no pueden hacer pruebas de característica y fallan todas las tiradas de salvación."
                  ],
        "tablas":  [
                       {
                           "titulo":  "Clase de armadura de objetos",
                           "columnas":  [
                                            "CA",
                                            "Sustancia"
                                        ],
                           "filas":  [
                                         [
                                             "11",
                                             "Tela, papel, cuerda"
                                         ],
                                         [
                                             "13",
                                             "Cristal, vidrio, hielo"
                                         ],
                                         [
                                             "15",
                                             "Madera"
                                         ],
                                         [
                                             "17",
                                             "Piedra"
                                         ],
                                         [
                                             "19",
                                             "Hierro, acero"
                                         ],
                                         [
                                             "21",
                                             "Mithral"
                                         ],
                                         [
                                             "23",
                                             "Adamantina"
                                         ]
                                     ]
                       },
                       {
                           "titulo":  "Puntos de golpe de objetos",
                           "columnas":  [
                                            "Tamaño",
                                            "Frágil",
                                            "Resistente"
                                        ],
                           "filas":  [
                                         [
                                             "Diminuto (botella, cerradura)",
                                             "2 (1d4)",
                                             "5 (2d4)"
                                         ],
                                         [
                                             "Pequeño (cofre, laúd)",
                                             "3 (1d6)",
                                             "10 (3d6)"
                                         ],
                                         [
                                             "Mediano (barril, candelabro)",
                                             "4 (1d8)",
                                             "18 (4d8)"
                                         ],
                                         [
                                             "Grande (carreta, mesa de comedor)",
                                             "5 (1d10)",
                                             "27 (5d10)"
                                         ]
                                     ]
                       }
                   ],
        "consulta_tambien":  [
                                 "Umbral de daño"
                             ]
    },
    {
        "nombre":  "Saltar",
        "descripcion":  "Cuando saltas, puedes hacer un salto de longitud (horizontal) o un salto de altura (vertical).",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Salto de altura",
                                 "Salto de longitud"
                             ]
    },
    {
        "nombre":  "Salto de altura",
        "descripcion":  "Cuando hagas un salto de altura, ascenderás una distancia de 3 pies + 1 pie × tu modificador por Fuerza (como mínimo 0 pies) si te mueves al menos 10 pies a pie antes de saltar. Si saltas sin coger carrerilla, solo podrás ascender la mitad de esa distancia. En cualquier caso, cada pie que saltes te costará 1 pie de tu movimiento.",
        "notas":  [
                      "Mientras saltas, puedes estirar los brazos una distancia equivalente a la mitad de tu altura por encima de ti. De esta forma, podrás alcanzar con las manos una distancia igual a la de la altura del salto más una vez y media tu altura."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Saltar"
                             ]
    },
    {
        "nombre":  "Salto de longitud",
        "descripcion":  "Cuando hagas un salto de longitud, avanzarás horizontalmente una distancia de hasta 1 pie × tu puntuación de Fuerza si recorres al menos 10 pies antes de saltar. Si saltas sin coger carrerilla, solo podrás recorrer la mitad de esa distancia. En cualquier caso, cada pie que saltes te costará 1 pie de tu movimiento.",
        "notas":  [
                      "Si aterrizas en terreno difícil, deberás superar una prueba de Destreza (Acrobacias) con CD 10 o tendrás el estado de derribado.",
                      "La regla de los saltos de longitud da por supuesto que la altura del salto no influye, como cuando se salta para cruzar un río o una grieta. Si tu GM lo cree conveniente, deberás superar una prueba de Fuerza (Atletismo) con CD 10 para superar un obstáculo de una altura no superior a la cuarta parte de la distancia del salto, como puede ser un seto o un muro bajo. De lo contrario, chocarás contra el obstáculo."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Saltar",
                                 "Terreno difícil",
                                 "Derribado [estado]"
                             ]
    },
    {
        "nombre":  "Salvación",
        "descripcion":  "Salvación es otro nombre para referirse a una tirada de salvación.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Tirada de salvación"
                             ]
    },
    {
        "nombre":  "Sentir vibraciones",
        "descripcion":  "Una criatura con la capacidad de sentir vibraciones puede localizar criaturas y objetos en movimiento dentro de un alcance determinado, siempre y cuando la criatura que pueda sentir vibraciones y cualquier cosa que detecte estén en contacto con la misma superficie (como el suelo, una pared o un techo) o con el mismo líquido. Sentir vibraciones no sirve para detectar criaturas u objetos en el aire y no cuenta como una forma de visión.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Sintonización",
        "descripcion":  "Algunos objetos mágicos requieren que una criatura forme un vínculo llamado sintonización antes de usar sus propiedades mágicas. Una criatura no puede sintonizarse con más de tres objetos mágicos a la vez.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Equipo \u003e Objetos mágicos"
                             ]
    },
    {
        "nombre":  "Sorpresa",
        "descripcion":  "Si el comienzo de un combate pilla desprevenida a una criatura, estará sorprendida, lo que le hará tener desventaja en su tirada de iniciativa.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Combate"
                             ]
    },
    {
        "nombre":  "Tamaño",
        "descripcion":  "Cada criatura u objeto pertenece a una categoría de tamaño: Diminuto, Pequeño, Mediano, Grande,",
        "notas":  [
                      "Enorme o Gargantuesco. El tamaño de una criatura determina el espacio que ocupa en combate. El tamaño de un objeto afecta a sus puntos de golpe."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Romper objetos",
                                 "Cómo jugar",
                                 "Combate"
                             ]
    },
    {
        "nombre":  "Telepatía",
        "descripcion":  "La telepatía es una facultad mágica que permite a una criatura comunicarse mentalmente con otra criatura que esté dentro del alcance indicado. Salvo que una regla indique algo distinto, no es necesario que la criatura contactada tenga un idioma en común con el telépata para entender esta comunicación, pero deberá poder entender al menos un idioma o ejercer ella misma la telepatía para poder entenderse. Un telépata no necesita ver a la criatura contactada y puede comenzar o terminar la conexión telepática cuando quiera (no requiere acción). La conexión telepática no puede iniciarse y se interrumpe de inmediato si el telépata o la otra criatura tiene el estado de incapacitado. La conexión telepática se interrumpe también si la criatura contactada deja de estar al alcance del telépata o si el telépata contacta con otra criatura a su alcance. Las criaturas sin telepatía pueden recibir mensajes telepáticos, pero no pueden iniciar una conversación telepática. En cuanto comienza una conversación telepática, la criatura que no sea telépata podrá comunicarse mentalmente con el telépata hasta que se interrumpa la conexión.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Teletransporte",
        "descripcion":  "El teletransporte es un tipo especial de transporte mágico. Si te teletransportas, desapareces y reapareces en otra parte al instante, sin atravesar el espacio entre medias. Este transporte no gasta movimiento, salvo que una regla diga lo contrario, y nunca provoca ataques de oportunidad. Cuando te teletransportas, todo el equipo que vistas o lleves se teletransporta contigo. Si estás tocando a otra criatura en el momento en el que te teletransportes, la criatura no se teletransportará contigo salvo que el efecto de teletransporte diga lo contrario. Si el lugar de destino del teletransporte está ocupado por otra criatura o bloqueado por un obstáculo sólido, aparecerás en el espacio sin ocupar más cercano que elijas. La descripción de un efecto de teletransporte indica si debes ver el destino del teletransporte.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Terreno difícil",
        "descripcion":  "Si un espacio es terreno difícil, cada pie de movimiento en ese espacio cuesta 1 pie adicional. Por ejemplo, si te mueves 5 pies por terreno difícil, te cuesta 10 pies de movimiento. El terreno difícil no es acumulativo; un espacio es terreno difícil o no lo es. Un espacio es terreno difícil si contiene algo de lo siguiente u otro elemento similar: • una criatura que no sea Diminuta o aliada tuya; • un mueble diseñado para criaturas de tu tamaño o superior; • escombros, hielo, maleza o nieve espesa; • líquido que llegue entre las espinillas y la cintura; • una abertura estrecha en la que quepa una criatura cuyo tamaño sea una categoría inferior al tuyo; • una pendiente de 20 grados o más.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Tipo de criatura",
        "descripcion":  "Todas las criaturas, incluidos los personajes de los jugadores, tienen una etiqueta en las reglas que identifica su tipo de criatura. La mayoría de los personajes de los jugadores son de tipo humanoide. Estos son los tipos de criaturas del juego:",
        "notas":  [
                      "Aberración",
                      "Autómata",
                      "Bestia",
                      "Celestial",
                      "Cieno",
                      "Dragón",
                      "Elemental",
                      "Feérico",
                      "Gigante",
                      "Humanoide",
                      "Infernal",
                      "Monstruosidad",
                      "Muerto viviente",
                      "Planta",
                      "Estos tipos no tienen reglas en sí mismos, pero hay reglas del juego que afectan de manera distinta a criaturas de ciertos tipos."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Tipos de daño",
        "descripcion":  "Los ataques y otros efectos dañinos causan diferentes tipos de daño. Los tipos de daño no tienen reglas propias, pero otras reglas, como la resistencia, dependen de ellos. La tabla “Tipos de daño” plantea ejemplos para que cada GM sepa qué tipo puede asignar a los efectos nuevos.",
        "notas":  [

                  ],
        "tablas":  [
                       {
                           "titulo":  "Tipos de daño",
                           "columnas":  [
                                            "Tipo",
                                            "Ejemplos"
                                        ],
                           "filas":  [
                                         [
                                             "Ácido",
                                             "Enzimas digestivas, líquidos corrosivos"
                                         ],
                                         [
                                             "Contundente",
                                             "Aplastamientos, caídas, objetos romos"
                                         ],
                                         [
                                             "Cortante",
                                             "Garras, objetos cortantes"
                                         ],
                                         [
                                             "Frío",
                                             "Agua gélida, ráfagas heladas"
                                         ],
                                         [
                                             "Fuego",
                                             "Calor insoportable, llamas"
                                         ],
                                         [
                                             "Fuerza",
                                             "Energía mágica pura"
                                         ],
                                         [
                                             "Necrótico",
                                             "Energía que absorbe la vida"
                                         ],
                                         [
                                             "Perforante",
                                             "Colmillos, objetos punzantes"
                                         ],
                                         [
                                             "Psíquico",
                                             "Energía que desgarra la mente"
                                         ],
                                         [
                                             "Radiante",
                                             "Energía sagrada, radiación abrasadora"
                                         ],
                                         [
                                             "Relámpago",
                                             "Electricidad"
                                         ],
                                         [
                                             "Trueno",
                                             "Sonido conmocionador"
                                         ],
                                         [
                                             "Veneno",
                                             "Gas tóxico, veneno"
                                         ]
                                     ]
                       }
                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Tirada de ataque",
        "descripcion":  "Una tirada de ataque es una prueba con d20 que representa hacer un ataque con un arma, un ataque sin armas o un conjuro.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Las pruebas con d20"
                             ]
    },
    {
        "nombre":  "Tirada de daño",
        "descripcion":  "Una tirada de daño es una tirada de dados a la que se le aplican los modificadores que correspondan y que causa daño a un objetivo.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Daño y curación"
                             ]
    },
    {
        "nombre":  "Tirada de salvación",
        "descripcion":  "Una tirada de salvación, o simplemente salvación, representa un intento de evitar o resistir una amenaza. Por lo general, las tiradas de salvación solo se hacen cuando una regla lo requiere, pero puedes optar por no hacer la tirada para fallarla. El resultado de una tirada de salvación se describe en el efecto que la ha provocado. Si un objetivo debe hacer una tirada de salvación y carece de la puntuación de característica empleada en ella, la fallará automáticamente.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Las pruebas con d20"
                             ]
    },
    {
        "nombre":  "Tirada de salvación contra muerte",
        "descripcion":  "Si un personaje jugador comienza su turno con 0 puntos de golpe, deberá realizar una tirada de salvación contra muerte (también llamada salvación contra muerte).",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Daño y curación"
                             ]
    },
    {
        "nombre":  "Trepar",
        "descripcion":  "Cuando trepas, cada pie de movimiento te cuesta 1 pie adicional (2 pies adicionales en terreno difícil). Ignoras este coste adicional si tienes una velocidad trepando y la usas para trepar. A discreción de cada GM, trepar por una superficie resbaladiza o con pocos agarres podría requerir superar una prueba de Fuerza (Atletismo) con CD 15.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Truco",
        "descripcion":  "Un truco es un conjuro de nivel 0 que se lanza sin un espacio de conjuro.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Conjuros"
                             ]
    },
    {
        "nombre":  "Umbral de daño",
        "descripcion":  "Una criatura u objeto que posea un umbral de daño tendrá inmunidad a todo el daño excepto si recibe una cantidad de daño procedente de un único ataque o efecto igual o mayor que su umbral de daño, en cuyo caso sufrirá todo ese daño. Cualquier daño que no iguale o supere el umbral de daño se considera superficial y no reduce los puntos de golpe. Por ejemplo, si un objeto tiene un umbral de daño de 10, no sufrirá daño si se le causa 9 de daño, ya que no supera el umbral. Si ese mismo objeto recibe 11 de daño, sufrirá todo ese daño.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Utilizar [acción]",
        "descripcion":  "Normalmente, interactúas con un objeto mientras haces otra cosa, como cuando desenvainas una espada como parte de una acción de atacar. Si quieres utilizar un objeto que requiera una acción para ello, tendrás que llevar a cabo la acción de utilizar.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Valor de desafío",
        "descripcion":  "El valor de desafío (VD) resume la amenaza que supone un monstruo para un grupo de cuatro personajes jugadores. Compara el VD del monstruo con el nivel de los personajes. Si el VD es superior, el monstruo seguramente suponga un peligro. Si el VD es inferior, el monstruo probablemente no sea una gran amenaza. No obstante, las circunstancias y la cantidad de personajes jugadores pueden alterar considerablemente lo peligroso que puede ser un monstruo en realidad. En el capítulo “Herramientas del juego” (“Encuentros de combate”) se explica cómo usar el VD al planear posibles encuentros de combate.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Perfil"
                             ]
    },
    {
        "nombre":  "Velocidad",
        "descripcion":  "Las criaturas tienen una velocidad, que es la distancia en pies que pueden recorrer cuando se mueven en su turno.",
        "notas":  [
                      "Velocidades especiales. Algunas criaturas tienen velocidades especiales, como una velocidad excavando, velocidad nadando, velocidad trepando o velocidad volando, todas ellas definidas en este glosario. Si tienes más de una velocidad, elige cuál vas a usar al moverte. Podrás alternar entre las velocidades durante el movimiento. Cada vez que lo hagas, resta la distancia que ya te hayas movido a la nueva velocidad. Lo que quede será lo que aún te puedas mover. Si te quedan 0 pies o menos, no podrás usar la nueva velocidad durante el movimiento actual. Por ejemplo, si tienes una velocidad caminando de 30 pies y una velocidad volando de 40 pies, entonces podrías volar 10 pies, caminar 10 pies y levantar el vuelo para recorrer otros 20 pies más.",
                      "Cambios en tus velocidades. Si un efecto aumenta o reduce tu velocidad durante un tiempo, cualquier velocidad especial que tengas aumentará o se reducirá en la misma cantidad durante el mismo periodo de tiempo. Por ejemplo, si tu velocidad se reduce a 0 y tienes una velocidad trepando, tu velocidad trepando también se reducirá a 0. De igual forma, si tu velocidad se reduce a la mitad y tienes una velocidad volando, tu velocidad volando también se reducirá a la mitad."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Arrastrarse",
                                 "Nadar",
                                 "Trepar",
                                 "Saltar",
                                 "Volar",
                                 "Cómo jugar",
                                 "Combate"
                             ]
    },
    {
        "nombre":  "Velocidad excavando",
        "descripcion":  "Si una criatura tiene una velocidad excavando, puede usar esa velocidad para desplazarse a través de arena, tierra, lodo o hielo. No puede excavar a través de roca sólida a menos que tenga un atributo que se lo permita.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Velocidad"
                             ]
    },
    {
        "nombre":  "Velocidad nadando",
        "descripcion":  "Una velocidad nadando sirve para nadar sin gastar el movimiento adicional que normalmente se asocia a nadar.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Nadar",
                                 "Velocidad"
                             ]
    },
    {
        "nombre":  "Velocidad trepando",
        "descripcion":  "Una velocidad trepando se puede utilizar en lugar de la velocidad para recorrer una superficie vertical sin gastar el movimiento adicional que normalmente se asocia a trepar.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Trepar",
                                 "Velocidad"
                             ]
    },
    {
        "nombre":  "Velocidad volando",
        "descripcion":  "Una velocidad volando sirve para viajar por el aire. Mientras tengas una velocidad volando, podrás permanecer en el aire hasta que aterrices, caigas o mueras.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Velocidad",
                                 "Volar"
                             ]
    },
    {
        "nombre":  "Ventaja",
        "descripcion":  "Si tienes ventaja en una prueba con d20, tira 2d20 y utiliza el resultado más alto. Una tirada no puede verse afectada por más de una ventaja, y una ventaja y una desventaja en la misma tirada se anulan entre sí.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Las pruebas con d20"
                             ]
    },
    {
        "nombre":  "Visión ciega",
        "descripcion":  "Si tienes visión ciega, puedes ver dentro de un alcance determinado sin recurrir a la vista. Dentro de ese alcance, puedes ver cualquier cosa que no esté tras una cobertura completa, incluso si tienes el estado de cegado o te encuentras en la oscuridad. Asimismo, en ese alcance puedes ver cosas que tengan el estado de invisibles.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Visión en la oscuridad",
        "descripcion":  "Si tienes visión en la oscuridad dentro de un alcance específico, puedes ver con luz tenue como si hubiera luz brillante y, en la oscuridad, como si hubiera luz tenue. En esa oscuridad, solo disciernes los colores como tonos de gris.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Exploración"
                             ]
    },
    {
        "nombre":  "Visión verdadera",
        "descripcion":  "Si tienes visión verdadera, tu visión mejora dentro de un alcance especificado. En él, tu visión es capaz de atravesar lo siguiente:",
        "notas":  [
                      "Oscuridad. Puedes ver en la oscuridad normal y mágica.",
                      "Invisibilidad. Puedes ver criaturas y objetos que tengan el estado de invisibles.",
                      "Ilusiones visuales. Las ilusiones visuales te parecen transparentes y superas automáticamente las tiradas de salvación contra ellas.",
                      "Transformaciones. Distingues la forma verdadera de cualquier criatura u objeto que veas y que esté transformado por un efecto mágico.",
                      "Plano Etéreo. Puedes ver en el Plano Etéreo."
                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [

                             ]
    },
    {
        "nombre":  "Volar",
        "descripcion":  "Diversos efectos permiten que las criaturas vuelen. Cuando vueles, te caerás si tienes los estados de derribado o incapacitado o si tu velocidad volando se reduce a 0. Puedes permanecer en el aire en esas circunstancias si tienes la capacidad de levitar.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Caídas",
                                 "Velocidad volando"
                             ]
    },
    {
        "nombre":  "Vulnerabilidad",
        "descripcion":  "Si tienes vulnerabilidad a un tipo de daño, el daño de ese tipo se duplica contra ti. La vulnerabilidad se aplica solo una vez a un efecto de daño.",
        "notas":  [

                  ],
        "tablas":  [

                   ],
        "consulta_tambien":  [
                                 "Cómo jugar \u003e Daño y curación"
                             ]
    }
];
  window.RULES_GLOSSARY_DATA = (Array.isArray(source) ? source : []).map((entry, index)=>({
    id: String(entry?.id || '') || ('glosario_' + (normalizeKey(entry?.nombre || ('entrada_' + String(index + 1))) || ('entrada_' + String(index + 1)))),
    name: String(entry?.nombre == null ? '' : entry.nombre),
    description: String(entry?.descripcion == null ? '' : entry.descripcion),
    notes: Array.isArray(entry?.notas) ? entry.notas.map((item)=> String(item == null ? '' : item)).filter(Boolean) : [],
    tables: Array.isArray(entry?.tablas) ? entry.tablas.map((table, tableIndex)=> normalizeTable(table, tableIndex)).filter(Boolean) : [],
    seeAlso: Array.isArray(entry?.consulta_tambien) ? entry.consulta_tambien.map((item)=> String(item == null ? '' : item)).filter(Boolean) : []
  }));
})();
