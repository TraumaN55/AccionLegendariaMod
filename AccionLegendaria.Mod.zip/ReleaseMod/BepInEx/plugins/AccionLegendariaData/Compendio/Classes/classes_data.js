window.INTEGRATED_CLASS_DATA = {
  "barbaro": {
    "id": "barbaro",
    "name": "Bárbaro",
    "primaryAbility": [
      "Fuerza"
    ],
    "hitDie": "1d12",
    "savingThrows": [
      "Fuerza",
      "Constitución"
    ],
    "skillChoices": {
      "choose": 2,
      "from": [
        "Atletismo",
        "Intimidación",
        "Naturaleza",
        "Percepción",
        "Supervivencia",
        "Trato con animales"
      ]
    },
    "weaponProficiencies": [
      "Armas sencillas",
      "Armas marciales"
    ],
    "armorTraining": [
      "Armaduras ligeras",
      "Armaduras medias",
      "Escudos"
    ],
    "startingEquipment": {
      "options": [
        {
          "id": "a",
          "label": "Equipo estándar",
          "items": [
            "hacha_a_dos_manos",
            "4_hachas_de_mano",
            "paquete_explorador"
          ],
          "gold": 15
        },
        {
          "id": "b",
          "label": "Oro inicial",
          "items": [],
          "gold": 75
        }
      ]
    },
    "levels": {
      "1": {
        "proficiencyBonus": "+2",
        "rageUses": 2,
        "rageDamage": 2,
        "weaponMasteryCount": 2,
        "features": [
          "defensa_sin_armadura",
          "furia",
          "maestria_con_armas"
        ]
      },
      "2": {
        "proficiencyBonus": "+2",
        "rageUses": 2,
        "rageDamage": 2,
        "weaponMasteryCount": 2,
        "features": [
          "ataque_temerario",
          "sentir_el_peligro"
        ]
      },
      "3": {
        "proficiencyBonus": "+2",
        "rageUses": 3,
        "rageDamage": 2,
        "weaponMasteryCount": 2,
        "features": [
          "conocimiento_primigenio",
          "subclase_barbaro"
        ]
      },
      "4": {
        "proficiencyBonus": "+2",
        "rageUses": 3,
        "rageDamage": 2,
        "weaponMasteryCount": 2,
        "features": [
          "mejora_de_caracteristica"
        ]
      },
      "5": {
        "proficiencyBonus": "+3",
        "rageUses": 3,
        "rageDamage": 2,
        "weaponMasteryCount": 3,
        "features": [
          "ataque_adicional",
          "movimiento_rapido"
        ]
      },
      "6": {
        "proficiencyBonus": "+3",
        "rageUses": 4,
        "rageDamage": 2,
        "weaponMasteryCount": 3,
        "features": [],
        "subclassFeatures": true
      },
      "7": {
        "proficiencyBonus": "+3",
        "rageUses": 4,
        "rageDamage": 2,
        "weaponMasteryCount": 3,
        "features": [
          "instinto_salvaje",
          "salto_instintivo"
        ]
      },
      "8": {
        "proficiencyBonus": "+3",
        "rageUses": 4,
        "rageDamage": 2,
        "weaponMasteryCount": 3,
        "features": [
          "mejora_de_caracteristica"
        ]
      },
      "9": {
        "proficiencyBonus": "+4",
        "rageUses": 4,
        "rageDamage": 3,
        "weaponMasteryCount": 3,
        "features": [
          "golpe_brutal"
        ]
      },
      "10": {
        "proficiencyBonus": "+4",
        "rageUses": 4,
        "rageDamage": 3,
        "weaponMasteryCount": 4,
        "features": [],
        "subclassFeatures": true
      },
      "11": {
        "proficiencyBonus": "+4",
        "rageUses": 4,
        "rageDamage": 3,
        "weaponMasteryCount": 4,
        "features": [
          "furia_implacable"
        ]
      },
      "12": {
        "proficiencyBonus": "+4",
        "rageUses": 5,
        "rageDamage": 3,
        "weaponMasteryCount": 4,
        "features": [
          "mejora_de_caracteristica"
        ]
      },
      "13": {
        "proficiencyBonus": "+5",
        "rageUses": 5,
        "rageDamage": 3,
        "weaponMasteryCount": 4,
        "features": [
          "golpe_brutal_mejorado"
        ]
      },
      "14": {
        "proficiencyBonus": "+5",
        "rageUses": 5,
        "rageDamage": 3,
        "weaponMasteryCount": 4,
        "features": [],
        "subclassFeatures": true
      },
      "15": {
        "proficiencyBonus": "+5",
        "rageUses": 5,
        "rageDamage": 3,
        "weaponMasteryCount": 4,
        "features": [
          "furia_persistente"
        ]
      },
      "16": {
        "proficiencyBonus": "+5",
        "rageUses": 5,
        "rageDamage": 4,
        "weaponMasteryCount": 4,
        "features": [
          "mejora_de_caracteristica"
        ]
      },
      "17": {
        "proficiencyBonus": "+6",
        "rageUses": 6,
        "rageDamage": 4,
        "weaponMasteryCount": 4,
        "features": [
          "golpe_brutal_mejorado_2"
        ]
      },
      "18": {
        "proficiencyBonus": "+6",
        "rageUses": 6,
        "rageDamage": 4,
        "weaponMasteryCount": 4,
        "features": [
          "poderio_indomito"
        ]
      },
      "19": {
        "proficiencyBonus": "+6",
        "rageUses": 6,
        "rageDamage": 4,
        "weaponMasteryCount": 4,
        "features": [
          "don_epico"
        ]
      },
      "20": {
        "proficiencyBonus": "+6",
        "rageUses": 6,
        "rageDamage": 4,
        "weaponMasteryCount": 4,
        "features": [
          "campeon_primordial"
        ]
      }
    },
    "features": {
      "defensa_sin_armadura": {
        "name": "Defensa sin armadura",
        "level": 1,
        "description": "Mientras no lleves armadura alguna, tu clase de armadura base será igual a 10 más tus modificadores por Destreza y Constitución.\nObtienes este beneficio aunque lleves un escudo."
      },
      "furia": {
        "name": "Furia",
        "level": 1,
        "description": "Puedes imbuirte de un poder primigenio llamado furia, que te otorga una fuerza y resistencia extraordinarias.\nPuedes dejarte llevar por ella como acción adicional si no llevas puesta una armadura pesada.\nPuedes dejarte llevar por la furia tantas veces como se indica para tu nivel de bárbaro en la columna “N.º de furias” de la tabla “Rasgos de bárbaro”. Recuperas uno de los usos gastados tras finalizar un descanso corto y todos tras finalizar un descanso largo.\n\nMientras estés enfurecido, usa las siguientes reglas.\n\nResistencia al daño. Tienes resistencia al daño contundente, cortante y perforante.\nDaño por furia. Cuando llevas a cabo un ataque que use la Fuerza (ya sea con un arma o un ataque sin armas) y causas daño al objetivo, obtienes un bonificador al daño que aumenta conforme subes de nivel de bárbaro, como se muestra en la columna “Daño por furia” de la tabla “Rasgos de bárbaro”.\nVentaja en Fuerza. Tienes ventaja en las pruebas de Fuerza y en las tiradas de salvación de Fuerza.\nSin concentración ni conjuros. No puedes mantener la concentración ni lanzar conjuros.\nDuración. La furia dura hasta el final de tu siguiente turno y termina antes si te pones una armadura pesada o recibes el estado de incapacitado.\nSi la furia sigue activa en tu siguiente turno, puedes prolongarla otro asalto de una de las siguientes formas:\n- Haces una tirada de ataque contra un enemigo.\n- Obligas a un enemigo a hacer una tirada de salvación.\n- Empleas una acción adicional para prolongar tu furia.\nCada vez que prolongues la furia, durará hasta el final de tu siguiente turno.\nPuedes mantener una furia hasta 10 minutos."
      },
      "maestria_con_armas": {
        "name": "Maestría con armas",
        "level": 1,
        "description": "Tu entrenamiento con armas te permite utilizar las propiedades de maestría con dos tipos de armas cuerpo a cuerpo sencillas o marciales de tu elección, como las hachas a dos manos y las hachas de mano.\nTras finalizar un descanso largo, puedes llevar a cabo ejercicios con armas y cambiar una de dichas elecciones.\nCuando alcances ciertos niveles de bárbaro, adquirirás la capacidad de usar las propiedades de maestría con más tipos de armas, como se muestra en la columna “Maestría con armas” de la tabla “Rasgos de bárbaro”."
      },
      "ataque_temerario": {
        "name": "Ataque temerario",
        "level": 2,
        "description": "Puedes abandonar por completo tu defensa para atacar con una mayor fiereza.\nCuando vayas a realizar la primera tirada de ataque de tu turno, puedes decidir atacar temerariamente.\nSi lo haces, tendrás ventaja en las tiradas de ataque que utilicen la Fuerza hasta el principio de tu siguiente turno, pero las tiradas de ataque contra ti también tendrán ventaja durante ese tiempo."
      },
      "sentir_el_peligro": {
        "name": "Sentir el peligro",
        "level": 2,
        "description": "Eres capaz de percibir de forma casi sobrenatural cuándo las cosas no son como deberían. Gracias a ello, se te da bien evitar el peligro.\nTienes ventaja en las tiradas de salvación de Destreza salvo que tengas el estado de incapacitado."
      },
      "conocimiento_primigenio": {
        "name": "Conocimiento primigenio",
        "level": 3,
        "description": "Ganas competencia en otra habilidad de tu elección de la lista de habilidades disponibles para los bárbaros en el nivel 1.\nAdemás, mientras estés enfurecido, puedes canalizar el poder primigenio cuando intentes determinadas tareas.\nSiempre que hagas una prueba de característica con una de las siguientes habilidades, podrás hacerla como una prueba de Fuerza incluso si normalmente utiliza otra característica: Acrobacias, Intimidación, Percepción, Sigilo o Supervivencia.\nCuando utilizas esta capacidad, tu Fuerza representa el poder primigenio que fluye por ti y agudiza tu agilidad, porte y sentidos."
      },
      "subclase_barbaro": {
        "name": "Subclase de bárbaro",
        "level": 3,
        "description": "Consigues una subclase de bárbaro de tu elección.\nLas subclases de la senda del Árbol del Mundo, la senda del berserker, la senda del corazón salvaje y la senda del fanático se detallan tras la descripción de esta clase.\nUna subclase es una especialización que te proporciona rasgos cuando alcanzas ciertos niveles de bárbaro. De aquí en adelante, obtienes todos los rasgos de tu subclase que sean de tu nivel de bárbaro e inferiores."
      },
      "mejora_de_caracteristica": {
        "name": "Mejora de característica",
        "level": 4,
        "description": "Obtienes la dote Mejora de característica (consulta el capítulo 5) u otra dote de tu elección para la que cumplas las condiciones.\nVuelves a obtener este rasgo en los niveles de bárbaro 8, 12 y 16."
      },
      "ataque_adicional": {
        "name": "Ataque adicional",
        "level": 5,
        "description": "Cuando lleves a cabo la acción de atacar en tu turno, podrás hacer dos ataques en lugar de uno."
      },
      "movimiento_rapido": {
        "name": "Movimiento rápido",
        "level": 5,
        "description": "Tu velocidad aumenta en 10 pies si no llevas armadura pesada."
      },
      "instinto_salvaje": {
        "name": "Instinto salvaje",
        "level": 7,
        "description": "Tus instintos están tan afinados que tienes ventaja en las tiradas de iniciativa."
      },
      "salto_instintivo": {
        "name": "Salto instintivo",
        "level": 7,
        "description": "Como parte de la acción adicional para dejarte llevar por la furia, puedes moverte hasta la mitad de tu velocidad."
      },
      "golpe_brutal": {
        "name": "Golpe brutal",
        "level": 9,
        "description": "Si utilizas Ataque temerario, puedes renunciar a cualquier ventaja en una tirada de ataque de tu elección basada en la Fuerza en tu turno. La tirada de ataque elegida no debe tener desventaja.\nSi la tirada de ataque elegida acierta, el objetivo sufre 1d10 de daño adicional del mismo tipo que inflija el arma o el ataque sin armas y puedes causar un efecto de Golpe brutal de tu elección.\n\nTienes las siguientes opciones de efectos:\n\nGolpe enérgico. El objetivo es empujado 15 pies respecto a ti en línea recta. Luego puedes moverte hasta la mitad de tu velocidad directamente hacia el objetivo sin provocar ataques de oportunidad.\nGolpe ralentizador. La velocidad del objetivo se reduce en 15 pies hasta el principio de tu siguiente turno. Un objetivo solo puede sufrir un golpe ralentizador cada vez: el más reciente."
      },
      "furia_implacable": {
        "name": "Furia implacable",
        "level": 11,
        "description": "Tu furia te permite seguir luchando incluso tras sufrir heridas graves.\nSi tus puntos de golpe se reducen a 0 mientras estás enfurecido, pero no mueres inmediatamente, puedes hacer una tirada de salvación de Constitución con CD 10. Si la superas, tus puntos de golpe pasarán a ser una cantidad igual al doble de tu nivel de bárbaro.\nSiempre que uses este rasgo después de la primera vez, la CD aumenta en 5.\nTras finalizar un descanso corto o largo, la CD vuelve a ser 10."
      },
      "golpe_brutal_mejorado": {
        "name": "Golpe brutal mejorado",
        "level": 13,
        "description": "Has perfeccionado tus formas de atacar con fiereza.\nEntre las opciones de Golpe brutal se encuentran ahora los siguientes efectos:\n\nGolpe abrumador. El objetivo tiene desventaja en la siguiente tirada de salvación que haga y no puede llevar a cabo ataques de oportunidad hasta el principio de tu siguiente turno.\nGolpe desgarrador. Antes del principio de tu siguiente turno, la próxima tirada de ataque realizada por otra criatura contra el objetivo obtiene un bonificador de +5. Una tirada de ataque puede obtener solo un bonificador de un golpe desgarrador."
      },
      "furia_persistente": {
        "name": "Furia persistente",
        "level": 15,
        "description": "Cuando tires iniciativa, puedes recuperar todos los usos gastados de la furia. Tras recuperar los usos de la furia de esta manera, no podrás volver a hacerlo hasta que finalices un descanso largo.\nAdemás, tu furia es tan intensa que ahora dura 10 minutos sin necesidad de hacer nada para prolongarla de un asalto a otro. Tu furia termina antes si recibes el estado de inconsciente o te pones una armadura pesada."
      },
      "golpe_brutal_mejorado_2": {
        "name": "Golpe brutal mejorado",
        "level": 17,
        "description": "El daño adicional de tu Golpe brutal aumenta a 2d10.\nAdemás, puedes utilizar dos efectos diferentes de Golpe brutal siempre que uses tu rasgo Golpe brutal."
      },
      "poderio_indomito": {
        "name": "Poderío indómito",
        "level": 18,
        "description": "Si tu resultado en una prueba de Fuerza o una tirada de salvación de Fuerza es inferior a tu puntuación de Fuerza, puedes usar esa puntuación en lugar del resultado."
      },
      "don_epico": {
        "name": "Don épico",
        "level": 19,
        "description": "Obtienes una dote de don épico (consulta el capítulo 5) u otra dote de tu elección para la que cumplas las condiciones.\nSe recomienda Don del ataque imparable."
      },
      "campeon_primordial": {
        "name": "Campeón primordial",
        "level": 20,
        "description": "Encarnas un poder primigenio.\nTus puntuaciones de Fuerza y Constitución aumentan en 4, hasta un máximo de 25."
      }
    },
    "subclasses": {
      "senda_del_arbol_del_mundo": {
        "name": "Senda del Árbol del Mundo",
        "levels": {
          "3": [
            "vitalidad_del_arbol"
          ],
          "6": [
            "ramas_del_arbol"
          ],
          "10": [
            "raices_apaleadoras"
          ],
          "14": [
            "viajar_por_el_arbol"
          ]
        },
        "features": {
          "vitalidad_del_arbol": {
            "name": "Vitalidad del Árbol",
            "level": 3,
            "description": "Tu furia se nutre de la fuerza vital del Árbol del Mundo.\nObtienes los siguientes beneficios:\n\nOleada de vitalidad. Cuando te enfurezcas, obtendrás una cantidad de puntos de golpe temporales igual a tu nivel de bárbaro.\nFuerza revitalizante. Al principio de cada uno de tus turnos mientras estés enfurecido, puedes elegir a otra criatura a 10 pies o menos de ti para que obtenga puntos de golpe temporales. Para determinarlos, tira una cantidad de d6 igual a tu bonificación de daño por furia y suma los resultados.\nSi algunos de estos puntos de golpe temporales permanecen cuando dejes de estar enfurecido, se desvanecerán."
          },
          "ramas_del_arbol": {
            "name": "Ramas del Árbol",
            "level": 6,
            "description": "Cuando una criatura que puedas ver comience su turno a 30 pies o menos de ti mientras estás enfurecido, podrás llevar a cabo una reacción para invocar unas ramas espectrales del Árbol del Mundo a su alrededor.\nEl objetivo deberá superar una tirada de salvación de Fuerza (CD 8 más tu modificador por Fuerza y tu bonificador por competencia) o se teletransportará a un espacio sin ocupar que puedas ver a 5 pies de ti o al espacio sin ocupar más cercano que puedas ver.\nDespués de que el objetivo se teletransporte, puedes reducir su velocidad a 0 hasta el final del turno actual."
          },
          "raices_apaleadoras": {
            "name": "Raíces apaleadoras",
            "level": 10,
            "description": "Durante tu turno, tu alcance es 10 pies superior con cualquier arma cuerpo a cuerpo que tenga la propiedad de pesada o versátil, ya que los zarcillos del Árbol del Mundo se prolongan desde tu cuerpo.\nCuando aciertes con un arma así en tu turno, podrás activar la propiedad de maestría de derribar o empujar, además de otra propiedad de maestría diferente que utilices con ese arma."
          },
          "viajar_por_el_arbol": {
            "name": "Viajar por el Árbol",
            "level": 14,
            "description": "Cuando te enfureces y como acción adicional mientras estés enfurecido, puedes teletransportarte hasta 60 pies a un espacio sin ocupar que puedas ver.\nAsimismo, una vez por furia, puedes aumentar el alcance del teletransporte a 150 pies. Si lo haces, también puedes transportar hasta seis criaturas voluntarias que estén a 10 pies o menos de ti.\nCada criatura se teletransportará a un espacio sin ocupar de tu elección a 10 pies o menos de tu espacio de destino."
          }
        }
      },
      "senda_del_berserker": {
        "name": "Senda del berserker",
        "levels": {
          "3": [
            "frenesi"
          ],
          "6": [
            "furia_irracional"
          ],
          "10": [
            "represalia"
          ],
          "14": [
            "presencia_intimidante"
          ]
        },
        "features": {
          "frenesi": {
            "name": "Frenesí",
            "level": 3,
            "description": "Si utilizas Ataque temerario mientras estás enfurecido, causarás daño adicional al primer objetivo al que aciertes en tu turno con un ataque basado en la Fuerza.\nPara determinar el daño adicional, tira una cantidad de d6 igual a tu bonificación de daño por furia y suma los resultados.\nEl daño será del mismo tipo que el del arma o ataque sin armas utilizado para el ataque."
          },
          "furia_irracional": {
            "name": "Furia irracional",
            "level": 6,
            "description": "Tienes inmunidad a los estados de asustado y hechizado mientras estés enfurecido.\nSi estás asustado o hechizado cuando te dejes llevar por la furia, el estado terminará para ti."
          },
          "represalia": {
            "name": "Represalia",
            "level": 10,
            "description": "Cuando recibas daño de una criatura que esté a 5 pies o menos de ti, puedes llevar a cabo una reacción para hacer un ataque cuerpo a cuerpo contra esa criatura usando un arma o un ataque sin armas."
          },
          "presencia_intimidante": {
            "name": "Presencia intimidante",
            "level": 14,
            "description": "Como acción adicional, puedes sembrar el terror en los demás con tu mera presencia amenazadora y tu poder primigenio.\nCuando lo hagas, todas las criaturas de tu elección situadas en una emanación de 30 pies originada en ti deberán hacer una tirada de salvación de Sabiduría (CD 8 más tu modificador por Fuerza y tu bonificador por competencia). Si la fallan, tendrán el estado de asustadas durante 1 minuto.\nAl final de cada uno de sus turnos, las criaturas asustadas repiten la tirada de salvación y, si tienen éxito, se librarán del efecto.\nCuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo, a menos que gastes un uso de tu furia (no requiere acción) para restablecer su uso."
          }
        }
      },
      "senda_del_corazon_salvaje": {
        "name": "Senda del corazón salvaje",
        "levels": {
          "3": [
            "furia_de_lo_salvaje",
            "portavoz_de_los_animales"
          ],
          "6": [
            "aspecto_de_lo_salvaje"
          ],
          "10": [
            "hablante_de_la_naturaleza"
          ],
          "14": [
            "poder_de_lo_salvaje"
          ]
        },
        "features": {
          "furia_de_lo_salvaje": {
            "name": "Furia de lo salvaje",
            "level": 3,
            "description": "Tu furia se sirve del poder primigenio de los animales.\nCuando te enfurezcas, obtendrás una de las siguientes opciones, a tu elección.\n\nÁguila. Cuando te enfurezcas, podrás llevar a cabo las acciones de destrabarse y correr como parte de esa acción adicional. Mientras estés enfurecido, puedes usar una acción adicional para llevar a cabo ambas acciones.\nLobo. Mientras estés enfurecido, tus aliados tendrán ventaja en las tiradas de ataque contra cualquiera de tus enemigos que se encuentre a 5 pies o menos de ti.\nOso. Mientras estés enfurecido, tendrás resistencia a todos los tipos de daño salvo de fuerza, necrótico, psíquico y radiante."
          },
          "portavoz_de_los_animales": {
            "name": "Portavoz de los animales",
            "level": 3,
            "description": "Puedes lanzar los conjuros hablar con los animales y sentidos de la bestia, pero solo como rituales.\nLa Sabiduría es tu aptitud mágica para lanzarlos."
          },
          "aspecto_de_lo_salvaje": {
            "name": "Aspecto de lo salvaje",
            "level": 6,
            "description": "Obtienes una de las siguientes opciones, a tu elección.\nTras finalizar un descanso largo, puedes cambiar de opción.\n\nBúho. Tienes visión en la oscuridad hasta 60 pies. Si ya posees visión en la oscuridad, su alcance aumenta en 60 pies.\nPantera. Tienes una velocidad trepando igual a tu velocidad.\nSalmón. Tienes una velocidad nadando igual a tu velocidad."
          },
          "hablante_de_la_naturaleza": {
            "name": "Hablante de la naturaleza",
            "level": 10,
            "description": "Puedes lanzar el conjuro comunión con la naturaleza, pero solo como ritual.\nLa Sabiduría es tu aptitud mágica para lanzarlo."
          },
          "poder_de_lo_salvaje": {
            "name": "Poder de lo salvaje",
            "level": 14,
            "description": "Cuando te enfurezcas, obtendrás una de las siguientes opciones, a tu elección.\n\nCarnero. Mientras estés enfurecido, podrás hacer que una criatura Grande o más pequeña sufra el estado de derribada si la aciertas con un ataque cuerpo a cuerpo.\nHalcón. Mientras estés enfurecido, tendrás una velocidad volando igual a tu velocidad si no llevas ninguna armadura.\nLeón. Mientras estés enfurecido, cualquier enemigo que esté a 5 pies o menos de ti tendrá desventaja en las tiradas de ataque contra otros objetivos que no seáis tú u otro bárbaro que tenga esta opción activa."
          }
        }
      },
      "senda_del_fanatico": {
        "name": "Senda del fanático",
        "levels": {
          "3": [
            "furia_divina",
            "guerrero_de_los_dioses"
          ],
          "6": [
            "foco_fanatico"
          ],
          "10": [
            "presencia_ferviente"
          ],
          "14": [
            "furia_de_los_dioses"
          ]
        },
        "features": {
          "furia_divina": {
            "name": "Furia divina",
            "level": 3,
            "description": "Puedes canalizar el poder divino hacia tus ataques.\nEn cada uno de tus turnos mientras estés enfurecido, la primera criatura a la que aciertes con un arma o un ataque sin armas sufrirá una cantidad de daño adicional igual a 1d20 piesás la mitad de tu nivel de bárbaro (redondeando hacia abajo).\nEl daño adicional es necrótico o radiante, que eliges cada vez que lo causas."
          },
          "guerrero_de_los_dioses": {
            "name": "Guerrero de los dioses",
            "level": 3,
            "description": "Una entidad divina ayuda a garantizar que continúes la batalla. Cuentas con una reserva de cuatro d12 que puedes gastar para curarte.\nComo acción adicional, puedes gastar dados de la reserva, tirarlos y recuperar una cantidad de puntos de golpe igual al resultado total de la tirada.\nTu reserva recupera todos los dados gastados tras finalizar un descanso largo.\nEl número máximo de dados de la reserva aumenta en uno cuando alcanzas los niveles 6 (5 dados), 12 (6 dados) y 17 (7 dados) de bárbaro."
          },
          "foco_fanatico": {
            "name": "Foco fanático",
            "level": 6,
            "description": "Una vez por furia, si fallas una tirada de salvación, podrás repetirla con un bonificador igual a tu bonificación de daño por furia y deberás utilizar el nuevo resultado."
          },
          "presencia_ferviente": {
            "name": "Presencia ferviente",
            "level": 10,
            "description": "Como acción adicional, profieres un grito de guerra imbuido de energía divina.\nHasta diez criaturas de tu elección que estén a 60 pies o menos de ti obtendrán ventaja en las tiradas de ataque y tiradas de salvación hasta el principio de tu siguiente turno.\nCuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo, a menos que gastes un uso de tu furia (no requiere acción) para restablecer su uso."
          },
          "furia_de_los_dioses": {
            "name": "Furia de los dioses",
            "level": 14,
            "description": "Cuando te enfureces, puedes adoptar la forma de un guerrero divino. Esta forma dura 1 minuto o hasta que tus puntos de golpe se reduzcan a 0. Cuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo.\n\nMientras tengas esta forma, obtendrás los siguientes beneficios:\n\nResistencia. Tienes resistencia al daño necrótico, psíquico y radiante.\nRevitalización. Cuando los puntos de golpe de una criatura que esté a 30 pies o menos de ti fueran a reducirse a 0, puedes llevar a cabo una reacción para gastar un uso de tu furia y hacer que los puntos de golpe del objetivo cambien a una cantidad igual a tu nivel de bárbaro.\nVuelo. Tienes una velocidad volando igual a tu velocidad y puedes levitar."
          }
        }
      }
    },
    "tables": {
      "progression": {
        "title": "Rasgos de Bárbaro",
        "columns": [
          "Nivel",
          "Bonificador por competencia",
          "Usos de furia",
          "Daño de furia",
          "Maestría con armas",
          "Rasgos de clase"
        ],
        "rows": [
          [
            "1",
            "+2",
            "2",
            "2",
            "2",
            "Defensa sin armadura, Furia, Maestría con armas"
          ],
          [
            "2",
            "+2",
            "2",
            "2",
            "2",
            "Ataque temerario, Sentir el peligro"
          ],
          [
            "3",
            "+2",
            "3",
            "2",
            "2",
            "Conocimiento primigenio, Subclase de bárbaro"
          ],
          [
            "4",
            "+2",
            "3",
            "2",
            "2",
            "Mejora de característica"
          ],
          [
            "5",
            "+3",
            "3",
            "2",
            "3",
            "Ataque adicional, Movimiento rápido"
          ],
          [
            "6",
            "+3",
            "4",
            "2",
            "3",
            "Rasgo de subclase"
          ],
          [
            "7",
            "+3",
            "4",
            "2",
            "3",
            "Instinto salvaje, Salto instintivo"
          ],
          [
            "8",
            "+3",
            "4",
            "2",
            "3",
            "Mejora de característica"
          ],
          [
            "9",
            "+4",
            "4",
            "3",
            "3",
            "Golpe brutal"
          ],
          [
            "10",
            "+4",
            "4",
            "3",
            "4",
            "Rasgo de subclase"
          ],
          [
            "11",
            "+4",
            "4",
            "3",
            "4",
            "Furia implacable"
          ],
          [
            "12",
            "+4",
            "5",
            "3",
            "4",
            "Mejora de característica"
          ],
          [
            "13",
            "+5",
            "5",
            "3",
            "4",
            "Golpe brutal mejorado"
          ],
          [
            "14",
            "+5",
            "5",
            "3",
            "4",
            "Rasgo de subclase"
          ],
          [
            "15",
            "+5",
            "5",
            "3",
            "4",
            "Furia persistente"
          ],
          [
            "16",
            "+5",
            "5",
            "4",
            "4",
            "Mejora de característica"
          ],
          [
            "17",
            "+6",
            "6",
            "4",
            "4",
            "Golpe brutal mejorado"
          ],
          [
            "18",
            "+6",
            "6",
            "4",
            "4",
            "Poderío indómito"
          ],
          [
            "19",
            "+6",
            "6",
            "4",
            "4",
            "Don épico"
          ],
          [
            "20",
            "+6",
            "6",
            "4",
            "4",
            "Campeón primordial"
          ]
        ]
      }
    }
  },
  "bardo": {
    "id": "bardo",
    "name": "Bardo",
    "primaryAbility": [
      "Carisma"
    ],
    "hitDie": "1d8",
    "savingThrows": [
      "Destreza",
      "Carisma"
    ],
    "skillChoices": {
      "choose": 3,
      "from": "Cualquiera"
    },
    "weaponProficiencies": [
      "Armas sencillas"
    ],
    "toolProficiencies": {
      "choose": 3,
      "from": "Instrumentos musicales"
    },
    "armorTraining": [
      "Armaduras ligeras"
    ],
    "startingEquipment": {
      "options": [
        {
          "id": "a",
          "label": "Equipo estándar",
          "items": [
            "armadura_de_cuero",
            "2_dagas",
            "instrumento_musical",
            "paquete_de_artista"
          ],
          "gold": 19
        },
        {
          "id": "b",
          "label": "Oro inicial",
          "items": [],
          "gold": 90
        }
      ]
    },
    "levels": {
      "1": {
        "proficiencyBonus": "+2",
        "bardicDie": "d6",
        "features": [
          "inspiracion_bardica",
          "lanzamiento_de_conjuros"
        ]
      },
      "2": {
        "proficiencyBonus": "+2",
        "bardicDie": "d6",
        "features": [
          "aprendiz_de_mucho",
          "pericia"
        ]
      },
      "3": {
        "proficiencyBonus": "+2",
        "bardicDie": "d6",
        "features": [
          "subclase_bardo"
        ]
      },
      "4": {
        "proficiencyBonus": "+2",
        "bardicDie": "d6",
        "features": [
          "mejora_de_caracteristica"
        ]
      },
      "5": {
        "proficiencyBonus": "+3",
        "bardicDie": "d8",
        "features": [
          "fuente_de_inspiracion"
        ]
      },
      "6": {
        "proficiencyBonus": "+3",
        "bardicDie": "d8",
        "features": [],
        "subclassFeatures": true
      },
      "7": {
        "proficiencyBonus": "+3",
        "bardicDie": "d8",
        "features": [
          "contraencantamiento"
        ]
      },
      "8": {
        "proficiencyBonus": "+3",
        "bardicDie": "d8",
        "features": [
          "mejora_de_caracteristica"
        ]
      },
      "9": {
        "proficiencyBonus": "+4",
        "bardicDie": "d8",
        "features": [
          "pericia"
        ]
      },
      "10": {
        "proficiencyBonus": "+4",
        "bardicDie": "d10",
        "features": [
          "secretos_magicos"
        ]
      },
      "11": {
        "proficiencyBonus": "+4",
        "bardicDie": "d10",
        "features": []
      },
      "12": {
        "proficiencyBonus": "+4",
        "bardicDie": "d10",
        "features": [
          "mejora_de_caracteristica"
        ]
      },
      "13": {
        "proficiencyBonus": "+5",
        "bardicDie": "d10",
        "features": []
      },
      "14": {
        "proficiencyBonus": "+5",
        "bardicDie": "d10",
        "features": [],
        "subclassFeatures": true
      },
      "15": {
        "proficiencyBonus": "+5",
        "bardicDie": "d12",
        "features": []
      },
      "16": {
        "proficiencyBonus": "+5",
        "bardicDie": "d12",
        "features": [
          "mejora_de_caracteristica"
        ]
      },
      "17": {
        "proficiencyBonus": "+6",
        "bardicDie": "d12",
        "features": []
      },
      "18": {
        "proficiencyBonus": "+6",
        "bardicDie": "d12",
        "features": [
          "inspiracion_superior"
        ]
      },
      "19": {
        "proficiencyBonus": "+6",
        "bardicDie": "d12",
        "features": [
          "don_epico"
        ]
      },
      "20": {
        "proficiencyBonus": "+6",
        "bardicDie": "d12",
        "features": [
          "palabras_de_creacion"
        ]
      }
    },
    "features": {
      "inspiracion_bardica": {
        "name": "Inspiración bárdica",
        "level": 1,
        "description": "Puedes recurrir a tus palabras, música o danza para inspirar de forma sobrenatural a los demás. Esta inspiración se representa con tu dado de Inspiración bárdica, que es un d6.\n\nUtilizar la Inspiración bárdica. Como acción adicional, puedes inspirar a otra criatura que esté a 60 pies o menos de ti y que te pueda ver u oír. Esa criatura obtiene uno de tus dados de Inspiración bárdica. Cada criatura no puede tener más de un dado de Inspiración bárdica.\n\nUna sola vez durante la siguiente hora, cuando la criatura falle una prueba con d20, podrá tirar el dado de Inspiración bárdica y sumar el resultado al d20, lo que podría hacerle superar la prueba. Un dado de Inspiración bárdica se gasta al tirarlo.\n\nNúmero de usos. Puedes conceder un dado de Inspiración bárdica una cantidad de veces igual a tu modificador por Carisma (mínimo una vez) y recuperas todos sus usos tras finalizar un descanso largo.\n\nA niveles superiores. Tu dado de Inspiración bárdica cambia cuando alcanzas ciertos niveles de bardo, como se muestra en la columna “Dado bárdico” de la tabla “Rasgos de bardo”. El dado se convierte en un d8 en el nivel 5, un d10 en el nivel 10 y un d12 en el nivel 15."
      },
      "lanzamiento_de_conjuros": {
        "name": "Lanzamiento de conjuros",
        "level": 1,
        "description": "Has aprendido a lanzar conjuros mediante tus artes bárdicas. Consulta el capítulo 7 para ver las reglas sobre el lanzamiento de conjuros. La información presentada a continuación detalla cómo usar esas reglas con los conjuros de bardo.\n\nTrucos. Conoces dos trucos de tu elección escogidos de entre los de la lista de conjuros de bardo. Se recomiendan burla dañina y luces danzantes.\nCada vez que subas un nivel de bardo, puedes sustituir uno de tus trucos por otro truco de tu elección de la lista de conjuros de bardo.\nCuando alcances los niveles 4 y 10 de bardo, aprenderás otro truco de tu elección de la lista de conjuros de bardo.\n\nEspacios de conjuro. La tabla “Rasgos de bardo” muestra cuántos espacios de conjuro tienes para lanzar tus conjuros de nivel 1 y superiores. Recuperas todos los espacios utilizados tras finalizar un descanso largo.\n\nConjuros preparados de nivel 1 y superiores. Preparas una serie de conjuros de nivel 1 y superiores, que son los que podrás lanzar con este rasgo. Para empezar, elige cuatro conjuros de nivel 1 de la lista de conjuros de bardo. Se recomiendan hechizar persona, palabra de curación, rociada de color y susurros discordantes.\nEl número de conjuros de tu lista aumenta conforme subes de nivel de bardo, como se muestra en la columna “Conjuros preparados” de la tabla “Rasgos de bardo”.\nCuando ese número aumente, elige conjuros adicionales de la lista de conjuros de bardo hasta que el número de conjuros de tu lista coincida con el número de la tabla.\nEstos conjuros deben ser de un nivel para el que tengas espacios de conjuro. Por ejemplo, si eres un bardo de nivel 3, podrías preparar cualquier combinación de seis conjuros de nivel 1 o 2.\n\nSi otro rasgo de bardo te proporciona conjuros que siempre tienes preparados, esos conjuros no cuentan para el total que puedes preparar con este rasgo, pero sí que cuentan como conjuros de bardo para ti.\n\nCambiar los conjuros preparados. Cada vez que subas un nivel de bardo, puedes sustituir un conjuro de tu lista por otro conjuro de bardo para el que tengas espacios de conjuro.\n\nAptitud mágica. El Carisma es tu aptitud mágica en lo que respecta a tus conjuros de bardo.\n\nCanalizador mágico. Puedes utilizar un instrumento musical como canalizador mágico para tus conjuros de bardo."
      },
      "aprendiz_de_mucho": {
        "name": "Aprendiz de mucho",
        "level": 2,
        "description": "Puedes sumar la mitad de tu bonificador por competencia (redondeando hacia abajo) a cualquier prueba de característica que hagas que utilice una habilidad en la que no seas competente y que no use de otro modo tu bonificador por competencia.\nPor ejemplo, si haces una prueba de Fuerza (Atletismo) y no eres competente en Atletismo, puedes sumar la mitad de tu bonificador por competencia a la prueba."
      },
      "pericia": {
        "name": "Pericia",
        "level": 2,
        "description": "Ganas pericia (consulta el glosario de reglas) en dos de tus competencias en habilidades de tu elección.\nSe recomiendan Interpretación y Persuasión si eres competente en ellas.\n\nEn el nivel 9 de bardo ganas pericia en otras dos competencias de tu elección."
      },
      "subclase_bardo": {
        "name": "Subclase de bardo",
        "level": 3,
        "description": "Consigues una subclase de bardo de tu elección.\nLas subclases del colegio de la danza, el colegio del conocimiento, el colegio del glamour y el colegio del valor se detallan tras la descripción de esta clase.\nUna subclase es una especialización que te proporciona rasgos cuando alcanzas ciertos niveles de bardo.\nDe aquí en adelante, obtienes todos los rasgos de tu subclase que sean de tu nivel de bardo e inferiores."
      },
      "mejora_de_caracteristica": {
        "name": "Mejora de característica",
        "level": 4,
        "description": "Obtienes la dote Mejora de característica (consulta el capítulo 5) u otra dote de tu elección para la que cumplas las condiciones.\nVuelves a obtener este rasgo en los niveles 8, 12 y 16 de bardo."
      },
      "fuente_de_inspiracion": {
        "name": "Fuente de inspiración",
        "level": 5,
        "description": "Ahora recuperas todos los usos de Inspiración bárdica tras finalizar un descanso corto o largo.\nAdemás, puedes gastar un espacio de conjuro (no requiere acción) para recuperar un uso gastado de Inspiración bárdica."
      },
      "contraencantamiento": {
        "name": "Contraencantamiento",
        "level": 7,
        "description": "Puedes emplear notas musicales o palabras de poder para interrumpir los efectos que afectan a la mente.\nSi tú o una criatura que esté a 30 pies o menos de ti falláis una tirada de salvación contra un efecto que aplique el estado de asustado o hechizado, puedes llevar a cabo una reacción para que se repita la tirada de salvación, y la nueva tirada tendrá ventaja."
      },
      "secretos_magicos": {
        "name": "Secretos mágicos",
        "level": 10,
        "description": "Has aprendido secretos de diversas tradiciones mágicas.\nCada vez que alcances un nivel de bardo (incluido este) y aumente la cantidad de conjuros preparados de la tabla “Rasgos de bardo”, podrás elegir cualquiera de los nuevos conjuros preparados de entre las listas de conjuros de bardo, clérigo, druida y mago.\nLos conjuros elegidos contarán como conjuros de bardo para ti.\nAdemás, cuando sustituyas un conjuro preparado para esta clase, podrás hacerlo con un conjuro de esas listas."
      },
      "inspiracion_superior": {
        "name": "Inspiración superior",
        "level": 18,
        "description": "Cuando tires iniciativa, recuperarás usos gastados de Inspiración bárdica hasta que tengas dos, si tuvieras menos de esta cifra."
      },
      "don_epico": {
        "name": "Don épico",
        "level": 19,
        "description": "Obtienes una dote de don épico (consulta el capítulo 5) u otra dote de tu elección para la que cumplas las condiciones.\nSe recomienda Don del recuerdo de conjuros."
      },
      "palabras_de_creacion": {
        "name": "Palabras de creación",
        "level": 20,
        "description": "Ahora dominas dos de las palabras de creación: las palabras de la vida y de la muerte.\nPor tanto, siempre tienes preparados los conjuros palabra de poder: sanar y palabra de poder: matar.\nCuando lances uno de estos conjuros, podrás hacer objetivo a una segunda criatura si esta se encuentra a 10 pies o menos del primer objetivo."
      }
    },
    "subclasses": {
      "colegio_de_la_danza": {
        "name": "Colegio de la danza",
        "levels": {
          "3": [
            "juego_de_pies_deslumbrante"
          ],
          "6": [
            "juego_de_pies_conjunto",
            "movimiento_inspirador"
          ],
          "14": [
            "evasion_dirigida"
          ]
        },
        "features": {
          "juego_de_pies_deslumbrante": {
            "name": "Juego de pies deslumbrante",
            "level": 3,
            "description": "Mientras no lleves armadura ni portes un escudo, obtienes los siguientes beneficios.\n\nVirtuoso de la danza. Tienes ventaja en cualquier prueba de Carisma (Interpretación) que hagas que implique bailar.\n\nDefensa sin armadura. Tu clase de armadura base es igual a 10 más tus modificadores por Destreza y Carisma.\n\nAtaques ágiles. Cuando gastes un uso de tu Inspiración bárdica como parte de una acción, una acción adicional o una reacción, puedes realizar un ataque sin armas como parte de esa acción, acción adicional o reacción.\n\nDaño bárdico. Puedes usar tu Destreza en lugar de tu Fuerza para las tiradas de ataque de tus ataques sin armas. Cuando causas daño con un ataque sin armas, puedes infligir una cantidad de daño contundente igual al resultado de una tirada con tu dado de Inspiración bárdica más tu modificador por Destreza, en lugar del daño normal del ataque. No gastas el dado con esta tirada."
          },
          "juego_de_pies_conjunto": {
            "name": "Juego de pies conjunto",
            "level": 6,
            "description": "Cuando tires iniciativa, puedes gastar un uso de tu Inspiración bárdica si no tienes el estado de incapacitado.\nCuando lo hagas, tira tu dado de Inspiración bárdica; tú y todos los aliados que estén a 30 pies o menos de ti que puedan verte u oírte ganaréis un bonificador a la iniciativa igual al resultado."
          },
          "movimiento_inspirador": {
            "name": "Movimiento inspirador",
            "level": 6,
            "description": "Cuando un enemigo que puedas ver termine su turno a 5 pies o menos de ti, puedes llevar a cabo una reacción y gastar un uso de tu Inspiración bárdica para moverte hasta la mitad de tu velocidad.\nDespués, un aliado que elijas que esté a 30 pies o menos de ti también podrá moverse hasta la mitad de su velocidad usando su reacción.\nLos movimientos realizados con este rasgo no provocan ataques de oportunidad."
          },
          "evasion_dirigida": {
            "name": "Evasión dirigida",
            "level": 14,
            "description": "Cuando sufras un efecto que te permita hacer una tirada de salvación de Destreza para sufrir solo la mitad de daño, no recibes daño alguno si la superas y solo sufres la mitad si la fallas.\nSi cualquier criatura que esté a 5 pies de ti hace la misma tirada de salvación de Destreza, puedes compartir este beneficio con ella para la tirada.\nNo puedes usar este rasgo si tienes el estado de incapacitado."
          }
        }
      },
      "colegio_del_conocimiento": {
        "name": "Colegio del conocimiento",
        "levels": {
          "3": [
            "competencias_adicionales",
            "palabras_cortantes"
          ],
          "6": [
            "descubrimientos_magicos"
          ],
          "14": [
            "habilidad_sin_parangon"
          ]
        },
        "features": {
          "competencias_adicionales": {
            "name": "Competencias adicionales",
            "level": 3,
            "description": "Ganas competencia en tres habilidades de tu elección."
          },
          "palabras_cortantes": {
            "name": "Palabras cortantes",
            "level": 3,
            "description": "Aprendes a usar tu astucia para distraer, confundir y minar la confianza y las aptitudes de los demás de manera sobrenatural.\nCuando una criatura que puedas ver a 60 pies o menos de ti haga una tirada de daño o tenga éxito en una prueba de característica o una tirada de ataque, puedes llevar a cabo una reacción para gastar un uso de tu Inspiración bárdica.\nTira tu dado de Inspiración bárdica y resta el número obtenido al resultado de la tirada de la criatura, lo que reducirá el daño o quizá convierta el éxito en un fallo."
          },
          "descubrimientos_magicos": {
            "name": "Descubrimientos mágicos",
            "level": 6,
            "description": "Aprendes dos conjuros de tu elección.\nEstos conjuros pueden proceder de las listas de conjuros de clérigo, druida o mago, o de cualquier combinación de estas.\nLos conjuros que elijas deben ser trucos o conjuros para los que tengas espacios de conjuro.\n\nSiempre tienes preparados los conjuros elegidos y, cada vez que subas un nivel de bardo, podrás reemplazar uno de los conjuros por otro conjuro que cumpla estos requisitos."
          },
          "habilidad_sin_parangon": {
            "name": "Habilidad sin parangón",
            "level": 14,
            "description": "Cuando hagas una prueba de característica o una tirada de ataque y falles, podrás gastar un uso de Inspiración bárdica.\nTira el dado de Inspiración bárdica y suma el resultado al d20, lo que podría convertir un fallo en un éxito.\nSi fallas la tirada, la Inspiración bárdica no se gasta."
          }
        }
      },
      "colegio_del_glamour": {
        "name": "Colegio del glamour",
        "levels": {
          "3": [
            "magia_cautivadora",
            "manto_de_inspiracion"
          ],
          "6": [
            "manto_de_majestad"
          ],
          "14": [
            "majestad_inquebrantable"
          ]
        },
        "features": {
          "magia_cautivadora": {
            "name": "Magia cautivadora",
            "level": 3,
            "description": "Siempre tienes los conjuros hechizar persona e imagen múltiple preparados.\n\nAsimismo, inmediatamente después de que lances un conjuro de encantamiento o ilusionismo mediante un espacio de conjuro, podrás hacer que una criatura que puedas ver a 60 pies o menos de ti realice una tirada de salvación de Sabiduría contra tu CD de salvación de conjuros.\nSi la falla, el objetivo tendrá el estado de asustado o hechizado (a tu elección) durante 1 minuto.\nEl objetivo repetirá la tirada de salvación al final de cada uno de sus turnos y, si tiene éxito, se librará del efecto.\n\nCuando uses este beneficio, no podrás volver a hacerlo hasta que finalices un descanso largo.\nTambién puedes restablecer su uso gastando un uso de tu Inspiración bárdica (no requiere acción)."
          },
          "manto_de_inspiracion": {
            "name": "Manto de inspiración",
            "level": 3,
            "description": "Puedes urdir la magia feérica en una canción o danza que insufle energía a los demás.\nComo acción adicional, puedes gastar un uso de tu Inspiración Bárdica y tirar un dado de Inspiración bárdica.\nCuando lo hagas, elige una cantidad de otras criaturas a 60 pies o menos de ti, hasta un máximo igual a tu modificador por Carisma (mínimo una criatura).\nCada una de esas criaturas obtendrá una cantidad de puntos de golpe temporales igual al doble del resultado del dado de Inspiración bárdica y luego podrá usar su reacción para moverse hasta su velocidad sin provocar ataques de oportunidad."
          },
          "manto_de_majestad": {
            "name": "Manto de majestad",
            "level": 6,
            "description": "Siempre tienes el conjuro orden imperiosa preparado.\n\nComo acción adicional, puedes lanzar orden imperiosa sin gastar un espacio de conjuro y adoptar una apariencia sobrenatural durante 1 minuto o hasta que pierdas la concentración.\nDurante este tiempo, puedes lanzar orden imperiosa como acción adicional sin gastar un espacio de conjuro.\n\nCualquier criatura a la que hayas hechizado fallará automáticamente su tirada de salvación contra la orden imperiosa que lances con este rasgo.\n\nCuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo.\nTambién puedes restablecer su uso gastando un espacio de conjuro de nivel 3 o superior (no requiere acción)."
          },
          "majestad_inquebrantable": {
            "name": "Majestad inquebrantable",
            "level": 14,
            "description": "Como acción adicional, puedes adoptar un aspecto majestuoso mágico durante 1 minuto o hasta que tengas el estado de incapacitado.\nDurante ese tiempo, cuando una criatura te acierte con una tirada de ataque por primera vez en un turno, el atacante deberá superar una tirada de salvación de Carisma contra tu CD de salvación de conjuros o el ataque fallará, puesto que la criatura se amedrentará por tu majestuosidad.\n\nCuando adoptes este aspecto majestuoso, no podrás volver a hacerlo hasta que finalices un descanso corto o largo."
          }
        }
      },
      "colegio_del_valor": {
        "name": "Colegio del valor",
        "levels": {
          "3": [
            "entrenamiento_marcial",
            "inspiracion_en_combate"
          ],
          "6": [
            "ataque_adicional"
          ],
          "14": [
            "magia_de_batalla"
          ]
        },
        "features": {
          "entrenamiento_marcial": {
            "name": "Entrenamiento marcial",
            "level": 3,
            "description": "Ganas competencia con armas marciales y entrenamiento con armaduras medias y escudos.\nAdemás, puedes utilizar un arma sencilla o marcial como canalizador mágico para lanzar tus conjuros de bardo."
          },
          "inspiracion_en_combate": {
            "name": "Inspiración en combate",
            "level": 3,
            "description": "Puedes emplear tu ingenio para cambiar las tornas de la batalla.\nUna criatura que tenga uno de tus dados de Inspiración bárdica podrá usarlo para lograr uno de los siguientes efectos.\n\nDefensa.\nCuando una tirada de ataque acierte a la criatura, esta podrá usar su reacción para tirar el dado de Inspiración bárdica y sumar el resultado a su CA contra ese ataque, lo que podría hacer que falle.\n\nOfensiva.\nInmediatamente después de que la criatura acierte a un objetivo con una tirada de ataque, podrá tirar el dado de Inspiración bárdica y sumar el resultado al daño del ataque contra el objetivo."
          },
          "ataque_adicional": {
            "name": "Ataque adicional",
            "level": 6,
            "description": "Cuando lleves a cabo la acción de atacar en tu turno, podrás hacer dos ataques en lugar de uno.\nAdemás, podrás lanzar uno de tus trucos que tenga un tiempo de lanzamiento de una acción en vez de realizar uno de esos ataques."
          },
          "magia_de_batalla": {
            "name": "Magia de batalla",
            "level": 14,
            "description": "Tras lanzar un conjuro que tenga un tiempo de lanzamiento de una acción, podrás hacer un ataque con un arma como acción adicional."
          }
        }
      },
      "colegio_de_la_luna": {
        "name": "Colegio de la Luna",
        "source": "Forgotten Realms: Heroes of Faerûn / Unearthed Arcana 2025",
        "levels": {
          "3": {
            "features": [
              "moonshae_folktales",
              "primal_lorist"
            ]
          },
          "6": {
            "features": [
              "blessing_of_the_moonwells"
            ]
          },
          "14": {
            "features": [
              "bolstered_folktales"
            ]
          }
        },
        "features": {
          "moonshae_folktales": {
            "name": "Cuentos de Moonshae",
            "level": 3,
            "description": "Como acción de Magia, puedes invocar el poder de un cuento folklórico e imbuirte de magia primordial hasta que vuelvas a usar este rasgo. Cuando uses este rasgo, elige cuál de los siguientes cuentos invocas; tu elección te otorga ciertos beneficios mientras esta magia esté activa.\n\nCuento de la vida. Invocas un relato de vitalidad y de tierra floreciente. Cuando restaures puntos de golpe a una criatura con un conjuro, puedes gastar un dado de Inspiración Bárdica y aumentar la cantidad de puntos de golpe restaurados en una cantidad igual a una tirada del dado de Inspiración Bárdica. Solo puedes hacerlo una vez por turno.\n\nCuento del crepúsculo. Invocas un relato de misterio y secretos. Cuando uses una acción adicional para dar a una criatura un dado de Inspiración Bárdica, puedes realizar la acción de Destrabarse o Esconderse como parte de esa misma acción adicional.\n\nCuento de la dicha. Invocas un relato de alegría y astucia feérica. Cuando un enemigo que puedas ver a 60 pies o menos de ti tenga éxito en una tirada de salvación, puedes usar tu reacción para gastar un dado de Inspiración Bárdica. Esa criatura debe tirar el dado de Inspiración Bárdica y restar el número obtenido del total de su salvación, pudiendo provocar que falle."
          },
          "primal_lorist": {
            "name": "Sabio primordial",
            "level": 3,
            "description": "Aprendes druídico y un truco de la lista de conjuros de druida. Cuenta como un conjuro de bardo para ti, pero no cuenta para el número de trucos que conoces.\n\nAdemás, elige una de las siguientes habilidades: Trato con animales, Perspicacia, Medicina, Naturaleza, Percepción o Supervivencia. Ganas competencia en esa habilidad."
          },
          "blessing_of_the_moonwells": {
            "name": "Bendición de los pozos lunares",
            "level": 6,
            "description": "Siempre tienes preparado el conjuro Rayo de luna.\n\nComo acción adicional, puedes lanzar Rayo de luna sin gastar un espacio de conjuro. Cuando lo lanzas usando este rasgo, emites un tenue resplandor mientras mantengas la concentración en el conjuro. Mientras resplandeces, proyectas luz tenue en un radio de 5 pies y, siempre que una criatura falle su tirada de salvación contra los efectos de este Rayo de luna, otra criatura de tu elección que puedas ver a 60 pies o menos de ti recupera 2d4 puntos de golpe.\n\nUna vez que uses este rasgo, no podrás volver a usarlo hasta terminar un descanso largo. También puedes recuperar su uso gastando un espacio de conjuro de nivel 3 o superior, sin requerir acción."
          },
          "bolstered_folktales": {
            "name": "Cuentos reforzados",
            "level": 14,
            "description": "El poder de tus Cuentos folklóricos de Moonshae mejora. Cuando uses tu Cuento de la vida o tu Cuento de la dicha, puedes tirar 1d6 y usar el número obtenido en lugar de gastar un dado de Inspiración Bárdica. Además, cuando uses tu Cuento del crepúsculo, también puedes teletransportarte hasta 30 pies a un espacio desocupado que puedas ver como parte de esa misma acción adicional."
          }
        }
      }
    },
    "tables": {
      "progression": {
        "title": "Rasgos de Bardo",
        "columns": [
          "Nivel",
          "Bonificador por competencia",
          "Dado de inspiración",
          "Rasgos de clase"
        ],
        "rows": [
          [
            "1",
            "+2",
            "d6",
            "Inspiración bárdica, Lanzamiento de conjuros"
          ],
          [
            "2",
            "+2",
            "d6",
            "Aprendiz de mucho, Pericia"
          ],
          [
            "3",
            "+2",
            "d6",
            "Subclase de bardo"
          ],
          [
            "4",
            "+2",
            "d6",
            "Mejora de característica"
          ],
          [
            "5",
            "+3",
            "d8",
            "Fuente de inspiración"
          ],
          [
            "6",
            "+3",
            "d8",
            "Rasgo de subclase"
          ],
          [
            "7",
            "+3",
            "d8",
            "Contraencantamiento"
          ],
          [
            "8",
            "+3",
            "d8",
            "Mejora de característica"
          ],
          [
            "9",
            "+4",
            "d8",
            "Pericia"
          ],
          [
            "10",
            "+4",
            "d10",
            "Secretos mágicos"
          ],
          [
            "11",
            "+4",
            "d10",
            ""
          ],
          [
            "12",
            "+4",
            "d10",
            "Mejora de característica"
          ],
          [
            "13",
            "+5",
            "d10",
            ""
          ],
          [
            "14",
            "+5",
            "d10",
            "Rasgo de subclase"
          ],
          [
            "15",
            "+5",
            "d12",
            ""
          ],
          [
            "16",
            "+5",
            "d12",
            "Mejora de característica"
          ],
          [
            "17",
            "+6",
            "d12",
            ""
          ],
          [
            "18",
            "+6",
            "d12",
            "Inspiración superior"
          ],
          [
            "19",
            "+6",
            "d12",
            "Don épico"
          ],
          [
            "20",
            "+6",
            "d12",
            "Palabras de creación"
          ]
        ]
      }
    }
  },
  "brujo": {
    "id": "brujo",
    "name": "Brujo",
    "primaryAbility": "Carisma",
    "hitDie": "1d8",
    "savingThrows": [
      "Sabiduría",
      "Carisma"
    ],
    "skillChoices": {
      "choose": 2,
      "from": [
        "conocimiento_arcano",
        "engano",
        "historia",
        "intimidacion",
        "investigacion",
        "naturaleza",
        "religion"
      ]
    },
    "weaponProficiencies": [
      "Armas sencillas"
    ],
    "startingEquipment": {
      "options": [
        {
          "id": "a",
          "label": "Equipo estándar",
          "items": [
            "armadura_de_cuero",
            "hoz",
            "2_dagas",
            "canalizador_arcano_orbe",
            "libro_de_conocimiento_oculto",
            "paquete_de_erudito"
          ],
          "gold": 15
        },
        {
          "id": "b",
          "label": "Oro inicial",
          "items": [],
          "gold": 100
        }
      ]
    },
    "levels": {
      "1": {
        "proficiencyBonus": "+2",
        "spellsKnown": 2,
        "invocationsKnown": 1,
        "features": [
          "invocaciones_sobrenaturales",
          "magia_del_pacto"
        ]
      },
      "2": {
        "proficiencyBonus": "+2",
        "spellsKnown": 3,
        "invocationsKnown": 2,
        "features": [
          "astucia_magica"
        ]
      },
      "3": {
        "proficiencyBonus": "+2",
        "spellsKnown": 4,
        "invocationsKnown": 2,
        "features": [
          "subclase_brujo"
        ]
      },
      "4": {
        "proficiencyBonus": "+2",
        "spellsKnown": 5,
        "invocationsKnown": 2,
        "features": [
          "mejora_de_caracteristica"
        ]
      },
      "5": {
        "proficiencyBonus": "+3",
        "spellsKnown": 6,
        "invocationsKnown": 3,
        "features": []
      },
      "6": {
        "proficiencyBonus": "+3",
        "spellsKnown": 7,
        "invocationsKnown": 3,
        "features": [
          "subclass_feature"
        ]
      },
      "7": {
        "proficiencyBonus": "+3",
        "spellsKnown": 8,
        "invocationsKnown": 4,
        "features": []
      },
      "8": {
        "proficiencyBonus": "+3",
        "spellsKnown": 9,
        "invocationsKnown": 4,
        "features": [
          "mejora_de_caracteristica"
        ]
      },
      "9": {
        "proficiencyBonus": "+4",
        "spellsKnown": 10,
        "invocationsKnown": 5,
        "features": [
          "contactar_patron"
        ]
      },
      "10": {
        "proficiencyBonus": "+4",
        "spellsKnown": 10,
        "invocationsKnown": 5,
        "features": [
          "subclass_feature"
        ]
      },
      "11": {
        "proficiencyBonus": "+4",
        "spellsKnown": 11,
        "invocationsKnown": 5,
        "features": [
          "arcanum_mistico"
        ]
      },
      "12": {
        "proficiencyBonus": "+4",
        "spellsKnown": 11,
        "invocationsKnown": 6,
        "features": [
          "mejora_de_caracteristica"
        ]
      },
      "13": {
        "proficiencyBonus": "+5",
        "spellsKnown": 12,
        "invocationsKnown": 6,
        "features": [
          "arcanum_mistico"
        ]
      },
      "14": {
        "proficiencyBonus": "+5",
        "spellsKnown": 12,
        "invocationsKnown": 6,
        "features": [
          "subclass_feature"
        ]
      },
      "15": {
        "proficiencyBonus": "+5",
        "spellsKnown": 13,
        "invocationsKnown": 7,
        "features": [
          "arcanum_mistico"
        ]
      },
      "16": {
        "proficiencyBonus": "+5",
        "spellsKnown": 13,
        "invocationsKnown": 7,
        "features": [
          "mejora_de_caracteristica"
        ]
      },
      "17": {
        "proficiencyBonus": "+6",
        "spellsKnown": 14,
        "invocationsKnown": 7,
        "features": [
          "arcanum_mistico"
        ]
      },
      "18": {
        "proficiencyBonus": "+6",
        "spellsKnown": 14,
        "invocationsKnown": 8,
        "features": []
      },
      "19": {
        "proficiencyBonus": "+6",
        "spellsKnown": 15,
        "invocationsKnown": 8,
        "features": [
          "don_epico"
        ]
      },
      "20": {
        "proficiencyBonus": "+6",
        "spellsKnown": 15,
        "invocationsKnown": 8,
        "features": [
          "maestro_sobrenatural"
        ]
      }
    },
    "features": {
      "invocaciones_sobrenaturales": {
        "name": "Invocaciones sobrenaturales",
        "level": 1,
        "description": "Has desenterrado invocaciones sobrenaturales, fragmentos de conocimiento prohibido que te imbuyen de una capacidad mágica perpetua o de otros saberes.\nObtienes una invocación de tu elección, como Pacto del grimorio. Las invocaciones se detallan más adelante en la descripción de esta clase, en el apartado “Opciones de invocación sobrenatural”.\n\nRequisitos.\nSi una invocación tiene un requisito, debes cumplirlo para poder aprenderla. Por ejemplo, si una invocación te pide un nivel 5 o superior de brujo, podrás seleccionar esa invocación cuando alcances ese nivel de brujo.\n\nSustituir y conseguir invocaciones.\nCada vez que subas un nivel de brujo, puedes sustituir una de tus invocaciones por otra para la que cumplas las condiciones. No puedes sustituir una invocación si es un requisito de otra invocación que tengas.\nObtienes más invocaciones de tu elección cuando alcanzas ciertos niveles de brujo, como se muestra en la columna “Invocaciones” de la tabla “Rasgos de brujo”.\nNo puedes elegir la misma invocación más de una vez salvo que la descripción indique algo diferente."
      },
      "magia_del_pacto": {
        "name": "Magia del pacto",
        "level": 1,
        "description": "Has sellado un pacto con una entidad misteriosa mediante una ceremonia ocultista para obtener poderes mágicos.\nEse ente es una voz en las sombras y no tienes clara su identidad, pero el don que te ofrece sí que lo conoces: te ha dado la capacidad de lanzar conjuros.\n\nTrucos.\nConoces dos trucos de brujo de tu elección. Se recomiendan descarga sobrenatural y prestidigitación.\nCada vez que subas un nivel de brujo, puedes sustituir uno de tus trucos de este rasgo por otro truco de brujo de tu elección.\nCuando alcanzas los niveles 4 y 10 de brujo, aprendes otro truco de brujo de tu elección.\n\nEspacios de conjuro.\nLa tabla “Rasgos de brujo” muestra cuántos espacios de conjuro tienes para lanzar tus conjuros de brujo de los niveles 1 a 5. La tabla también te indica de qué nivel son dichos espacios, todos los cuales son del mismo nivel.\nRecuperas todos los espacios utilizados de Magia del pacto tras finalizar un descanso corto o largo.\nPor ejemplo, en el nivel 5 de brujo tienes dos espacios de conjuro de nivel 3. Para lanzar el conjuro de nivel 1 rayo de hechicería, deberás gastar uno de esos espacios y lo lanzarás como un conjuro de nivel 3.\n\nConjuros preparados de nivel 1 y superiores.\nPreparas una serie de conjuros de nivel 1 y superiores, que son los que podrás lanzar con este rasgo. Para empezar, elige dos conjuros de brujo de nivel 1. Se recomiendan hechizar persona y maleficio.\nEl número de conjuros de tu lista aumenta conforme subes de nivel de brujo, como se muestra en la columna “Conjuros preparados” de la tabla “Rasgos de brujo”.\nCuando ese número aumente, elige conjuros de brujo adicionales hasta que el número de conjuros de tu lista coincida con el número de la tabla. Los conjuros que elijas deben ser de un nivel igual o inferior al que aparece en la columna “Nivel de los espacios” para tu nivel.\nSi otro rasgo de brujo te proporciona conjuros que siempre tienes preparados, esos conjuros no cuentan para el total que puedes preparar con este rasgo, pero sí que cuentan como conjuros de brujo para ti.\n\nCambiar los conjuros preparados.\nCada vez que subas un nivel de brujo, puedes sustituir un conjuro de tu lista por otro conjuro de brujo de un nivel adecuado.\n\nAptitud mágica.\nEl Carisma es tu aptitud mágica en lo que respecta a tus conjuros de brujo.\n\nCanalizador mágico.\nPuedes utilizar un canalizador arcano como canalizador mágico para tus conjuros de brujo."
      },
      "astucia_magica": {
        "name": "Astucia mágica",
        "level": 2,
        "description": "Puedes llevar a cabo un rito esotérico durante 1 minuto.\nAl terminarlo, recuperas una cantidad de espacios de conjuro utilizados de Magia del pacto igual o inferior a la mitad de tu máximo (redondeando hacia arriba).\nCuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo."
      },
      "subclase_brujo": {
        "name": "Subclase de brujo",
        "level": 3,
        "description": "Consigues una subclase de brujo de tu elección.\nLas subclases del patrón celestial, el patrón feérico, el patrón infernal y el patrón primigenio se detallan tras la descripción de esta clase. Una subclase es una especialización que te proporciona rasgos cuando alcanzas ciertos niveles de brujo.\nDe aquí en adelante, obtienes todos los rasgos de tu subclase que sean de tu nivel de brujo e inferiores."
      },
      "mejora_de_caracteristica": {
        "name": "Mejora de característica",
        "level": 4,
        "description": "Obtienes la dote Mejora de característica (consulta el capítulo 5) u otra dote de tu elección para la que cumplas las condiciones.\nVuelves a obtener este rasgo en los niveles 8, 12 y 16 de brujo."
      },
      "contactar_patron": {
        "name": "Contactar patrón",
        "level": 9,
        "description": "Antes solías ponerte en contacto con tu patrón a través de intermediarios. Ahora puedes comunicarte directamente, ya que siempre tienes el conjuro contactar con otro plano preparado.\nCon este rasgo, puedes lanzar el conjuro sin gastar un espacio de conjuro para contactar con tu patrón y superas automáticamente la tirada de salvación del conjuro.\nCuando lances el conjuro con este rasgo, no podrás volver a hacerlo de esta forma hasta que finalices un descanso largo."
      },
      "arcanum_mistico": {
        "name": "Arcanum místico",
        "level": 11,
        "description": "Tu patrón te recompensa con un secreto mágico denominado arcanum. Escoge uno de los conjuros de brujo de nivel 6 como este arcanum.\nPuedes lanzar tu conjuro de arcanum una vez sin gastar un espacio de conjuro y debes finalizar un descanso largo antes de poder volver a lanzarlo de este modo.\nObtendrás más conjuros de brujo de tu elección que podrás lanzar de esta forma cuando alcances los niveles 13 (conjuro de nivel 7), 15 (conjuro de nivel 8) y 17 (conjuro de nivel 9) de brujo.\nRecuperas todos los usos de tu Arcanum místico tras finalizar un descanso largo.\nSiempre que subas un nivel de brujo, puedes sustituir uno de tus conjuros de arcanum por otro conjuro de brujo del mismo nivel."
      },
      "don_epico": {
        "name": "Don épico",
        "level": 19,
        "description": "Obtienes una dote de don épico (consulta el capítulo 5) u otra dote de tu elección para la que cumplas las condiciones.\nSe recomienda Don del destino."
      },
      "maestro_sobrenatural": {
        "name": "Maestro sobrenatural",
        "level": 20,
        "description": "Cuando empleas tu rasgo Astucia mágica, recuperas todos los espacios de conjuro utilizados de Magia del pacto."
      },
      "subclass_feature": {
        "name": "Rasgo de subclase",
        "level": 6,
        "description": "Obtienes un rasgo adicional de tu subclase de brujo en este nivel."
      }
    },
    "invocations": {
      "descarga_agonica": {
        "name": "Descarga agónica",
        "requirements": "Brujo de nivel 2 o superior, un truco de brujo que cause daño.",
        "description": "Elige uno de tus trucos de brujo que conozcas y cause daño.\nPuedes sumar tu modificador por Carisma a las tiradas de daño del conjuro.\n\nRepetible. Puedes obtener esta invocación más de una vez. Cada vez que lo hagas, elige un truco distinto que cumpla las condiciones."
      },
      "descarga_ahuyentadora": {
        "name": "Descarga ahuyentadora",
        "requirements": "Brujo de nivel 2 o superior, un truco de brujo que cause daño mediante una tirada de ataque.",
        "description": "Elige uno de tus trucos de brujo que conozcas y requiera una tirada de ataque.\nCuando aciertes a una criatura Grande o más pequeña con ese truco, puedes empujarla hasta 10 pies respecto a ti en línea recta.\n\nRepetible. Puedes obtener esta invocación más de una vez. Cada vez que lo hagas, elige un truco distinto que cumpla las condiciones."
      },
      "devorador_de_vida": {
        "name": "Devorador de vida",
        "requirements": "Brujo de nivel 9 o superior, invocación Pacto del filo.",
        "description": "Una vez por turno, cuando aciertes a una criatura con tu arma de pacto, puedes causarle 1d6 de daño necrótico, psíquico o radiante adicional (a tu elección) a esa criatura y gastar uno de tus dados de puntos de golpe para tirarlo y recuperar una cantidad de puntos de golpe igual al resultado más tu modificador por Constitución (mínimo 1 punto de golpe)."
      },
      "don_de_las_profundidades": {
        "name": "Don de las profundidades",
        "requirements": "Brujo de nivel 5 o superior.",
        "description": "Puedes respirar bajo el agua y obtienes una velocidad nadando igual a tu velocidad.\nTambién puedes lanzar respirar bajo el agua una vez sin gastar un espacio de conjuro. Recuperas la capacidad de lanzarlo de este modo tras finalizar un descanso largo."
      },
      "don_de_los_protectores": {
        "name": "Don de los protectores",
        "requirements": "Brujo de nivel 9 o superior, invocación Pacto del grimorio.",
        "description": "Aparece una nueva página en el Libro de las sombras cuando lo conjuras. Con tu permiso, una criatura puede usar una acción para escribir su nombre en esa página, que puede contener una cantidad de nombres igual a tu modificador por Carisma (mínimo un nombre).\nCuando los puntos de golpe de cualquier criatura cuyo nombre esté en la página se reduzcan a 0, pero no muera, en vez de eso pasará a tener 1 punto de golpe mágicamente. Cuando esta magia se active, ninguna criatura podrá beneficiarse de ella hasta que finalices un descanso largo.\nComo acción de magia, puedes borrar un nombre de la página tocándolo."
      },
      "filo_sediento": {
        "name": "Filo sediento",
        "requirements": "Brujo de nivel 5 o superior, invocación Pacto del filo.",
        "description": "Obtienes el rasgo Ataque adicional, pero solo para tu arma de pacto. Este rasgo te permite hacer dos ataques con esa arma en lugar de uno cuando lleves a cabo la acción de atacar en tu turno."
      },
      "hoja_devoradora": {
        "name": "Hoja devoradora",
        "requirements": "Brujo de nivel 12 o superior, invocación Filo sediento.",
        "description": "El rasgo Ataque adicional de tu invocación Filo sediento otorga dos ataques adicionales en vez de uno."
      },
      "inversion_del_amo_de_las_cadenas": {
        "name": "Inversión del amo de las cadenas",
        "requirements": "Brujo de nivel 5 o superior, invocación Pacto de la cadena.",
        "description": "Cuando lanzas encontrar familiar, imbuyes al familiar invocado de una cierta cantidad de tu poder sobrenatural, lo que le otorga a la criatura los siguientes beneficios.\n\nAcuático o aéreo. El familiar obtiene una velocidad nadando o una velocidad volando (a tu elección) de 40 pies.\nAtaque rápido. Como acción adicional, puedes ordenar al familiar que realice la acción de atacar.\nDaño necrótico o radiante. Siempre que el familiar haga daño contundente, cortante o perforante, puedes hacer que cause daño necrótico o radiante en su lugar.\nTu CD de salvación. Si el familiar obliga a una criatura a realizar una tirada de salvación, esta utiliza tu CD de salvación de conjuros.\nResistencia. Cuando el familiar recibe daño, puedes usar una reacción para otorgarle resistencia contra ese daño."
      },
      "lanza_sobrenatural": {
        "name": "Lanza sobrenatural",
        "requirements": "Brujo de nivel 2 o superior, un truco de brujo que cause daño.",
        "description": "Elige uno de tus trucos de brujo que conozcas, cause daño y tenga un alcance de 10 pies o más.\nCuando lances ese conjuro, su alcance aumenta una cantidad de pies igual a 30 veces tu nivel de brujo.\n\nRepetible. Puedes obtener esta invocación más de una vez. Cada vez que lo hagas, elige un truco distinto que cumpla las condiciones."
      },
      "lecciones_de_los_primeros": {
        "name": "Lecciones de los primeros",
        "requirements": "Brujo de nivel 2 o superior.",
        "description": "Has obtenido conocimientos de un ente anciano del multiverso, lo que te permite obtener una dote de origen de tu elección.\n\nRepetible. Puedes obtener esta invocación más de una vez. Cada vez que lo hagas, elige una dote de origen distinta."
      },
      "maestro_de_las_formas_innumerables": {
        "name": "Maestro de las formas innumerables",
        "requirements": "Brujo de nivel 5 o superior.",
        "description": "Puedes lanzar alterar el propio aspecto sin gastar un espacio de conjuro."
      },
      "mascara_de_los_mil_rostros": {
        "name": "Máscara de los mil rostros",
        "requirements": "Brujo de nivel 2 o superior.",
        "description": "Puedes lanzar disfrazarse sin gastar un espacio de conjuro."
      },
      "mente_sobrenatural": {
        "name": "Mente sobrenatural",
        "requirements": "",
        "description": "Tienes ventaja en las tiradas de salvación de Constitución que realices para mantener la concentración."
      },
      "mirada_de_las_dos_mentes": {
        "name": "Mirada de las dos mentes",
        "requirements": "Brujo de nivel 5 o superior.",
        "description": "Puedes usar una acción adicional para tocar a una criatura voluntaria y percibir el mundo a través de sus sentidos hasta el final de tu siguiente turno. Mientras la criatura permanezca en el mismo plano de existencia que tú, podrás utilizar una acción adicional en cada uno de los turnos posteriores para mantener esta conexión y alargar la duración de este efecto hasta el final de tu siguiente turno. La conexión termina si no la mantienes de esta forma.\nMientras percibes el mundo a través de los ojos de la otra criatura, te beneficias de cualquier sentido especial que tenga y puedes lanzar conjuros como si estuvieras en tu espacio o en el espacio de la otra criatura si estáis a 60 pies o menos de distancia."
      },
      "pacto_de_la_cadena": {
        "name": "Pacto de la cadena",
        "requirements": "",
        "description": "Aprendes el conjuro encontrar familiar y puedes lanzarlo como acción de magia sin gastar un espacio de conjuro.\nCuando lo lances, escoge entre una de las formas habituales para tu familiar o una de las siguientes formas especiales: diablillo, duende, esfinge de las maravillas, esqueleto, pseudodragón, quasit, renacuajo slaad o serpiente venenosa.\nAsimismo, cuando realizas la acción de atacar, puedes renunciar a uno de tus propios ataques para que el familiar realice un ataque propio con su reacción."
      },
      "pacto_del_filo": {
        "name": "Pacto del filo",
        "requirements": "",
        "description": "Como acción adicional, puedes conjurar en tu mano un arma de pacto, un arma cuerpo a cuerpo sencilla o marcial de tu elección con la que estableces un vínculo.\nComo alternativa, puedes vincularte con un arma mágica que toques, pero no podrás hacerlo si otra criatura está sintonizada con ella o si otro brujo está vinculado con ella.\nHasta que termine el vínculo, tendrás competencia con esa arma y podrás usarla como canalizador mágico.\nSiempre que ataques con el arma vinculada, puedes usar tu modificador por Carisma para las tiradas de ataque y de daño en lugar del modificador por Fuerza o Destreza.\nAdemás, puedes hacer que cause daño necrótico, psíquico o radiante en lugar de su tipo de daño normal.\nTu vínculo con el arma se rompe si vuelves a usar la acción adicional de este rasgo, si el arma está a más de 5 pies de ti durante 1 minuto o más o si mueres. Un arma conjurada desaparece cuando termina el vínculo."
      },
      "pacto_del_grimorio": {
        "name": "Pacto del grimorio",
        "requirements": "",
        "description": "Uniendo hebras de sombras, conjuras un libro en tu mano al terminar un descanso corto o largo. Este Libro de las sombras (tú eliges su aspecto) contiene magia sobrenatural a la que solo tú puedes acceder y que te proporciona los beneficios presentados a continuación. El libro desaparece si conjuras otro con este rasgo o si mueres.\n\nTrucos y rituales. Cuando aparezca el libro, elige tres trucos y dos conjuros de nivel 1 que estén marcados como “ritual”. Los conjuros pueden ser de la lista de cualquier clase y deben ser conjuros que no tengas ya preparados. Mientras lleves el libro contigo, tendrás preparados los conjuros elegidos y funcionarán como conjuros de brujo para ti.\n\nCanalizador mágico. Puedes usar el libro como canalizador mágico."
      },
      "paso_ascendente": {
        "name": "Paso ascendente",
        "requirements": "Brujo de nivel 5 o superior.",
        "description": "Puedes lanzar levitar sobre ti sin gastar un espacio de conjuro."
      },
      "salto_sobrenatural": {
        "name": "Salto sobrenatural",
        "requirements": "Brujo de nivel 2 o superior.",
        "description": "Puedes lanzar salto sobre ti sin gastar un espacio de conjuro."
      },
      "susurros_del_sepulcro": {
        "name": "Susurros del sepulcro",
        "requirements": "Brujo de nivel 7 o superior.",
        "description": "Puedes lanzar hablar con los muertos sin gastar un espacio de conjuro."
      },
      "uno_con_las_sombras": {
        "name": "Uno con las sombras",
        "requirements": "Brujo de nivel 5 o superior.",
        "description": "Mientras estés en una zona de luz tenue u oscuridad, puedes lanzar invisibilidad sobre ti sin gastar un espacio de conjuro."
      },
      "vigor_infernal": {
        "name": "Vigor infernal",
        "requirements": "Brujo de nivel 2 o superior.",
        "description": "Puedes lanzar falsa vida sobre ti sin gastar un espacio de conjuro. Si lanzas el conjuro con este rasgo, no tiras el dado para los puntos de golpe temporales; en su lugar, obtienes automáticamente el número más alto en el dado."
      },
      "vision_bruja": {
        "name": "Visión bruja",
        "requirements": "Brujo de nivel 15 o superior.",
        "description": "Tienes visión verdadera hasta 30 pies."
      },
      "visiones_brumosas": {
        "name": "Visiones brumosas",
        "requirements": "Brujo de nivel 2 o superior.",
        "description": "Puedes lanzar imagen silenciosa sin gastar un espacio de conjuro."
      },
      "visiones_de_reinos_remotos": {
        "name": "Visiones de reinos remotos",
        "requirements": "Brujo de nivel 9 o superior.",
        "description": "Puedes lanzar ojo arcano sin gastar un espacio de conjuro."
      },
      "vista_del_diablo": {
        "name": "Vista del diablo",
        "requirements": "Brujo de nivel 2 o superior.",
        "description": "Puedes ver con normalidad en luz tenue y en la oscuridad, tanto si son mágicas como si no, a una distancia de 120 pies o menos de ti."
      }
    },
    "subclasses": {
      "patron_celestial": {
        "name": "Patrón celestial",
        "levels": {
          "3": [
            "conjuros_del_patron_celestial",
            "luz_sanadora"
          ],
          "6": [
            "alma_radiante"
          ],
          "10": [
            "resiliencia_celestial"
          ],
          "14": [
            "venganza_ardiente"
          ]
        },
        "features": {
          "conjuros_del_patron_celestial": {
            "name": "Conjuros del celestial",
            "level": 3,
            "description": "La magia de tu patrón garantiza que siempre tengas ciertos conjuros preparados. Cuando alcances un nivel de brujo especificado en la tabla “Conjuros del celestial”, a partir de entonces siempre tendrás preparados los conjuros que se indican.",
            "table": {
              "title": "Conjuros del celestial",
              "columns": [
                "Nivel de brujo",
                "Conjuros"
              ],
              "rows": [
                [
                  "3",
                  "Auxilio, curar heridas, llama sagrada, luz, restablecimiento menor, saeta guía"
                ],
                [
                  "5",
                  "Luz del día, revivir"
                ],
                [
                  "7",
                  "Guardián de la fe, muro de fuego"
                ],
                [
                  "9",
                  "Invocar celestial, restablecimiento mayor"
                ]
              ]
            }
          },
          "luz_sanadora": {
            "name": "Luz sanadora",
            "level": 3,
            "description": "Obtienes la facultad de canalizar energía celestial para curar heridas. Tienes una reserva de d6 para alimentar esta sanación. La cantidad de dados de tu reserva es de 1 más tu nivel de brujo.\nComo acción adicional, puedes gastar dados de tu reserva para curarte a ti mismo o a una criatura que puedas ver a 60 pies o menos de ti. La cantidad máxima de dados que puedes usar a la vez es igual a tu modificador por Carisma (un dado como mínimo). Tira los dados que gastes y restablece una cantidad de puntos de golpe igual al resultado total de la tirada. Tu reserva recupera todos los dados gastados tras finalizar un descanso largo."
          },
          "alma_radiante": {
            "name": "Alma radiante",
            "level": 6,
            "description": "Tu vínculo con tu patrón te permite servir de canalizador de energía radiante. Tienes resistencia al daño radiante.\nUna vez por turno, si causas daño radiante o de fuego con un conjuro, puedes sumar tu modificador por Carisma al daño del conjuro contra uno de sus objetivos."
          },
          "resiliencia_celestial": {
            "name": "Resiliencia celestial",
            "level": 10,
            "description": "Obtienes puntos de golpe temporales siempre que uses el rasgo Astucia mágica o finalices un descanso corto o largo. La cantidad obtenida es igual a tu nivel de brujo más tu modificador por Carisma.\nAdemás, eliges hasta cinco criaturas que puedas ver cuando obtengas los puntos. Cada una de ellas obtiene una cantidad de puntos de golpe temporales igual a la mitad de tu nivel de brujo más tu modificador por Carisma."
          },
          "venganza_ardiente": {
            "name": "Venganza ardiente",
            "level": 14,
            "description": "Cuando tú o un aliado a 60 pies o menos de ti vayáis a hacer una tirada de salvación contra muerte, puedes emitir energía radiante para salvar a esa criatura. La criatura recupera una cantidad de puntos de golpe igual a la mitad de sus puntos de golpe máximos y puede poner fin a su estado de derribada. Todas las criaturas de tu elección que se encuentren a 30 pies o menos de la criatura sufren una cantidad de daño radiante igual a 2d8 más tu modificador por Carisma y tienen el estado de cegadas hasta el final del turno actual.\nCuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo."
          },
          "subclass_spells": {
            "name": "Conjuros de Subclase",
            "level": 1,
            "description": "Obtienes conjuros adicionales según tu nivel."
          }
        },
        "tables": {
          "subclass_spells_table": {
            "title": "Conjuros de Subclase",
            "columns": [
              "Nivel",
              "Conjuros"
            ],
            "rows": [
              [
                "3",
                [
                  "Auxilio",
                  "Curar heridas",
                  "Llama sagrada",
                  "Luz",
                  "Restablecimiento menor",
                  "Saeta guía"
                ]
              ],
              [
                "5",
                [
                  "Luz del día",
                  "Revivir"
                ]
              ],
              [
                "7",
                [
                  "Guardián de la fe",
                  "Muro de fuego"
                ]
              ],
              [
                "9",
                [
                  "Invocar celestial",
                  "Restablecimiento mayor"
                ]
              ]
            ]
          }
        }
      },
      "patron_feerico": {
        "name": "Patrón feérico",
        "levels": {
          "3": [
            "conjuros_del_patron_feerico",
            "pasos_feericos"
          ],
          "6": [
            "escape_brumoso"
          ],
          "10": [
            "defensas_seductoras"
          ],
          "14": [
            "magia_embrujadora"
          ]
        },
        "features": {
          "conjuros_del_patron_feerico": {
            "name": "Conjuros del señor feérico",
            "level": 3,
            "description": "La magia de tu patrón garantiza que siempre tengas ciertos conjuros preparados. Cuando alcances un nivel de brujo especificado en la tabla “Conjuros del señor feérico”, a partir de entonces siempre tendrás preparados los conjuros que se indican.",
            "table": {
              "title": "Conjuros del señor feérico",
              "columns": [
                "Nivel de brujo",
                "Conjuros"
              ],
              "rows": [
                [
                  "3",
                  "Calmar emociones, dormir, fuego feérico, fuerza fantasmal, paso brumoso"
                ],
                [
                  "5",
                  "Crecimiento vegetal, desplazamiento"
                ],
                [
                  "7",
                  "Dominar bestia, invisibilidad mejorada"
                ],
                [
                  "9",
                  "Apariencia, dominar persona"
                ]
              ]
            }
          },
          "pasos_feericos": {
            "name": "Pasos feéricos",
            "level": 3,
            "description": "Tu patrón te otorga la capacidad de desplazarte entre los límites de los planos. Puedes lanzar paso brumoso sin gastar un espacio de conjuro una cantidad de veces igual a tu modificador por Carisma (mínimo una vez) y recuperas todos los usos tras finalizar un descanso largo.\nAdemás, siempre que lances el conjuro, puedes elegir uno de los siguientes efectos adicionales.\n\nPaso burlón. Las criaturas a 5 pies o menos del espacio que hayas abandonado deberán superar una tirada de salvación de Sabiduría contra tu CD de salvación de conjuros o tendrán desventaja en las tiradas de ataque contra criaturas que no seas tú hasta el principio de tu siguiente turno.\n\nPaso refrescante. Inmediatamente después de teletransportarte, tú o una criatura que puedas ver a 10 pies o menos de ti obtenéis 1d10 puntos de golpe temporales."
          },
          "escape_brumoso": {
            "name": "Escape brumoso",
            "level": 6,
            "description": "Puedes lanzar paso brumoso como reacción en respuesta a recibir daño.\nAdemás, ahora cuentas con los siguientes efectos entre tus opciones de Pasos feéricos.\n\nPaso aterrador. Las criaturas a 5 pies o menos del espacio que hayas abandonado o del espacio en el que aparezcas (a tu elección) deberán superar una tirada de salvación de Sabiduría contra tu CD de salvación de conjuros o sufrirán 2d10 de daño psíquico.\n\nPaso desvanecedor. Tienes el estado de invisible hasta el principio de tu siguiente turno o hasta justo después de que hagas una tirada de ataque, causes daño o lances un conjuro."
          },
          "defensas_seductoras": {
            "name": "Defensas seductoras",
            "level": 10,
            "description": "Tu patrón te enseña a proteger tu mente y cuerpo.\nEres inmune al estado de hechizado.\nAdemás, inmediatamente después de que una criatura que puedas ver te acierte con una tirada de ataque, puedes usar una reacción para reducir a la mitad el daño que recibes (redondeando hacia abajo) y obligar al atacante a hacer una tirada de salvación de Sabiduría contra tu CD de salvación de conjuros. Si la falla, sufrirá una cantidad de daño psíquico igual al daño que tú recibas.\nCuando uses esta reacción, no podrás volver a hacerlo hasta que finalices un descanso largo, a menos que gastes un espacio de conjuro de Magia del pacto (no requiere acción) para restablecer su uso."
          },
          "magia_embrujadora": {
            "name": "Magia embrujadora",
            "level": 14,
            "description": "Tu patrón te otorga la capacidad de entrelazar tu magia con la teletransportación.\nInmediatamente después de lanzar un conjuro de encantamiento o ilusionismo usando una acción y un espacio de conjuro, puedes lanzar paso brumoso como parte de la misma acción y sin gastar otro espacio de conjuro."
          },
          "subclass_spells": {
            "name": "Conjuros de Subclase",
            "level": 1,
            "description": "Obtienes conjuros adicionales según tu nivel."
          }
        },
        "tables": {
          "subclass_spells_table": {
            "title": "Conjuros de Subclase",
            "columns": [
              "Nivel",
              "Conjuros"
            ],
            "rows": [
              [
                "3",
                [
                  "Calmar emociones",
                  "Dormir",
                  "Fuego feérico",
                  "Fuerza fantasmal",
                  "Paso brumoso"
                ]
              ],
              [
                "5",
                [
                  "Crecimiento vegetal",
                  "Desplazamiento"
                ]
              ],
              [
                "7",
                [
                  "Dominar bestia",
                  "Invisibilidad mejorada"
                ]
              ],
              [
                "9",
                [
                  "Apariencia",
                  "Dominar persona"
                ]
              ]
            ]
          }
        }
      },
      "patron_infernal": {
        "name": "Patrón infernal",
        "levels": {
          "3": [
            "conjuros_del_patron_infernal",
            "bendicion_del_oscuro"
          ],
          "6": [
            "la_suerte_del_oscuro"
          ],
          "10": [
            "resistencia_infernal"
          ],
          "14": [
            "arrastrar_por_el_infierno"
          ]
        },
        "features": {
          "conjuros_del_patron_infernal": {
            "name": "Conjuros del infernal",
            "level": 3,
            "description": "La magia de tu patrón garantiza que siempre tengas ciertos conjuros preparados. Cuando alcances un nivel de brujo especificado en la tabla “Conjuros del infernal”, a partir de entonces siempre tendrás preparados los conjuros que se indican.",
            "table": {
              "title": "Conjuros del infernal",
              "columns": [
                "Nivel de brujo",
                "Conjuros"
              ],
              "rows": [
                [
                  "3",
                  "Manos ardientes, orden imperiosa, rayo abrasador, sugestión"
                ],
                [
                  "5",
                  "Bola de fuego, nube apestosa"
                ],
                [
                  "7",
                  "Escudo de fuego, muro de fuego"
                ],
                [
                  "9",
                  "Geas, plaga de insectos"
                ]
              ]
            }
          },
          "bendicion_del_oscuro": {
            "name": "Bendición del oscuro",
            "level": 3,
            "description": "Cuando reduzcas a 0 los puntos de golpe de un enemigo, obtienes una cantidad de puntos de golpe temporales igual a tu modificador por Carisma más tu nivel de brujo (mínimo de 1 punto de golpe temporal).\nTambién obtienes este beneficio si otra criatura reduce a 0 los puntos de golpe de un enemigo a 10 pies o menos de ti."
          },
          "la_suerte_del_oscuro": {
            "name": "La suerte del oscuro",
            "level": 6,
            "description": "Puedes invocar a tu patrón infernal para alterar el destino a tu favor.\nCuando hagas una prueba de característica o una tirada de salvación, puedes utilizar este rasgo para sumar 1d10 a tu tirada.\nPuedes hacerlo después de ver el resultado de la tirada, pero antes de que ocurran sus efectos.\n\nPuedes usar este rasgo una cantidad de veces igual a tu modificador por Carisma (mínimo una vez), pero no más de una vez por tirada.\nRecuperas todos los usos tras finalizar un descanso largo."
          },
          "resistencia_infernal": {
            "name": "Resistencia infernal",
            "level": 10,
            "description": "Tras finalizar un descanso corto o largo, elige un tipo de daño que no sea el de fuerza.\nTienes resistencia a ese tipo de daño hasta que elijas uno distinto con este rasgo."
          },
          "arrastrar_por_el_infierno": {
            "name": "Arrastrar por el infierno",
            "level": 14,
            "description": "Una vez por turno, cuando aciertas a una criatura con una tirada de ataque, puedes intentar teletransportar instantáneamente al objetivo a los Planos Inferiores.\nEl objetivo deberá superar una tirada de salvación de Carisma contra tu CD de salvación de conjuros o desaparecerá y se precipitará a través de un paisaje de pesadilla.\nSi el objetivo no es un infernal, sufrirá 8d10 de daño psíquico y tendrá el estado de incapacitado hasta el final de tu siguiente turno, momento en el que volverá al espacio que ocupaba anteriormente o al espacio sin ocupar más cercano.\n\nCuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo, a menos que gastes un espacio de conjuro de Magia del pacto (no requiere acción) para restablecer su uso."
          },
          "subclass_spells": {
            "name": "Conjuros de Subclase",
            "level": 1,
            "description": "Obtienes conjuros adicionales según tu nivel."
          }
        },
        "tables": {
          "subclass_spells_table": {
            "title": "Conjuros de Subclase",
            "columns": [
              "Nivel",
              "Conjuros"
            ],
            "rows": [
              [
                "3",
                [
                  "Manos ardientes",
                  "Orden imperiosa",
                  "Rayo abrasador",
                  "Sugestión"
                ]
              ],
              [
                "5",
                [
                  "Bola de fuego",
                  "Nube apestosa"
                ]
              ],
              [
                "7",
                [
                  "Escudo de fuego",
                  "Muro de fuego"
                ]
              ],
              [
                "9",
                [
                  "Geas",
                  "Plaga de insectos"
                ]
              ]
            ]
          }
        }
      },
      "patron_primigenio": {
        "name": "Patrón primigenio",
        "levels": {
          "3": [
            "conjuros_del_primigenio",
            "conjuros_psiquicos",
            "mente_iluminada"
          ],
          "6": [
            "combatiente_clarividente"
          ],
          "10": [
            "escudo_mental",
            "maleficio_sobrenatural"
          ],
          "14": [
            "crear_siervo"
          ]
        },
        "features": {
          "conjuros_del_primigenio": {
            "name": "Conjuros del primigenio",
            "level": 3,
            "description": "La magia de tu patrón garantiza que siempre tengas ciertos conjuros preparados. Cuando alcances un nivel de brujo especificado en la tabla “Conjuros del primigenio”, a partir de entonces siempre tendrás preparados los conjuros que se indican.",
            "table": {
              "title": "Conjuros del primigenio",
              "columns": [
                "Nivel de brujo",
                "Conjuros"
              ],
              "rows": [
                [
                  "3",
                  "Detectar pensamientos, fuerza fantasmal, risa horrible de Tasha, susurros discordantes"
                ],
                [
                  "5",
                  "Clarividencia, hambre de Hadar"
                ],
                [
                  "7",
                  "Confusión, invocar aberración"
                ],
                [
                  "9",
                  "Alterar los recuerdos, telequinesis"
                ]
              ]
            }
          },
          "conjuros_psiquicos": {
            "name": "Conjuros psíquicos",
            "level": 3,
            "description": "Cuando lances un conjuro de brujo que cause daño, puedes cambiar su tipo de daño a psíquico.\nAdemás, cuando lances un conjuro de brujo de encantamiento o ilusionismo, puedes hacerlo sin componentes verbales ni somáticos."
          },
          "mente_iluminada": {
            "name": "Mente iluminada",
            "level": 3,
            "description": "Puedes establecer una conexión telepática con la mente de otra criatura.\nComo acción adicional, elige una criatura que puedas ver a 30 pies o menos de ti. La criatura elegida y tú podréis comunicaros telepáticamente mientras estéis a una distancia máxima igual a 1 milla × tu modificador por Carisma (mínimo de 1 milla).\nPara entenderos, debéis emplear mentalmente un idioma que ambos conozcáis.\nLa conexión telepática dura un número de minutos igual a tu nivel de brujo.\nTermina antes de tiempo si usas este rasgo para conectarte con otra criatura."
          },
          "combatiente_clarividente": {
            "name": "Combatiente clarividente",
            "level": 6,
            "description": "Cuando formas un enlace telepático con una criatura usando Mente iluminada, puedes obligar a esa criatura a hacer una tirada de salvación de Sabiduría contra tu CD de salvación de conjuros.\nSi la falla, la criatura tendrá desventaja en las tiradas de ataque contra ti y tú tendrás ventaja en las tiradas de ataque contra ella hasta que acabe el enlace.\n\nCuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso corto o largo, a menos que gastes un espacio de conjuro de Magia del pacto (no requiere acción) para restablecer su uso."
          },
          "escudo_mental": {
            "name": "Escudo mental",
            "level": 10,
            "description": "Tus pensamientos no se pueden leer mediante telepatía o cualquier otro medio sin que tú lo permitas.\nAdemás, tienes resistencia al daño psíquico y, siempre que una criatura te cause daño psíquico, ella recibirá la misma cantidad de daño que tú."
          },
          "maleficio_sobrenatural": {
            "name": "Maleficio sobrenatural",
            "level": 10,
            "description": "Tu patrón extraterrenal te concede una poderosa maldición.\nSiempre tienes el conjuro maleficio preparado.\nCuando lanzas maleficio y eliges una característica, el objetivo también tendrá desventaja en las tiradas de salvación de la característica elegida hasta que termine el conjuro."
          },
          "crear_siervo": {
            "name": "Crear siervo",
            "level": 14,
            "description": "Cuando lanzas invocar aberración, puedes modificarlo para que no requiera concentración.\nSi lo haces, la duración del conjuro pasa a ser de 1 minuto para ese lanzamiento y, cuando la invoques, la aberración tendrá una cantidad de puntos de golpe temporales igual a tu nivel de brujo más tu modificador por Carisma.\n\nAdemás, la primera vez en cada turno que la aberración acierte a una criatura bajo el efecto de tu maleficio, le infligirá una cantidad de daño psíquico extra igual al daño adicional del conjuro."
          },
          "subclass_spells": {
            "name": "Conjuros de Subclase",
            "level": 1,
            "description": "Obtienes conjuros adicionales según tu nivel."
          }
        },
        "tables": {
          "subclass_spells_table": {
            "title": "Conjuros de Subclase",
            "columns": [
              "Nivel",
              "Conjuros"
            ],
            "rows": [
              [
                "3",
                [
                  "Detectar pensamientos",
                  "Fuerza fantasmal",
                  "Risa horrible de Tasha",
                  "Susurros discordantes"
                ]
              ],
              [
                "5",
                [
                  "Clarividencia",
                  "Hambre de Hadar"
                ]
              ],
              [
                "7",
                [
                  "Confusión",
                  "Invocar aberración"
                ]
              ],
              [
                "9",
                [
                  "Alterar los recuerdos",
                  "Telequinesis"
                ]
              ]
            ]
          }
        }
      }
    },
    "armorTraining": [
      "Armaduras ligeras"
    ],
    "tables": {
      "warlock_progression": {
        "title": "Rasgos de Brujo",
        "columns": [
          "Nivel",
          "Bonif. competencia",
          "Rasgos de clase",
          "Invocaciones\nsobrenaturales",
          "Trucos",
          "Conjuros\npreparados",
          "Espacios\nde conjuro",
          "Nivel de los\nespacios"
        ],
        "rows": [
          [
            "1",
            "+2",
            "Invocaciones sobrenaturales, Magia del pacto",
            "1",
            "2",
            "2",
            "1",
            "1"
          ],
          [
            "2",
            "+2",
            "Astucia mágica",
            "3",
            "2",
            "3",
            "2",
            "1"
          ],
          [
            "3",
            "+2",
            "Subclase de brujo",
            "3",
            "2",
            "4",
            "2",
            "2"
          ],
          [
            "4",
            "+2",
            "Mejora de característica",
            "3",
            "3",
            "5",
            "2",
            "2"
          ],
          [
            "5",
            "+3",
            "—",
            "5",
            "3",
            "6",
            "2",
            "3"
          ],
          [
            "6",
            "+3",
            "Rasgo de subclase",
            "5",
            "3",
            "7",
            "2",
            "3"
          ],
          [
            "7",
            "+3",
            "—",
            "6",
            "3",
            "8",
            "2",
            "4"
          ],
          [
            "8",
            "+3",
            "Mejora de característica",
            "6",
            "3",
            "9",
            "2",
            "4"
          ],
          [
            "9",
            "+4",
            "Contactar patrón",
            "7",
            "3",
            "10",
            "2",
            "5"
          ],
          [
            "10",
            "+4",
            "Rasgo de subclase",
            "7",
            "4",
            "10",
            "2",
            "5"
          ],
          [
            "11",
            "+4",
            "Arcanum místico",
            "7",
            "4",
            "11",
            "3",
            "5"
          ],
          [
            "12",
            "+4",
            "Mejora de característica",
            "8",
            "4",
            "11",
            "3",
            "5"
          ],
          [
            "13",
            "+5",
            "Arcanum místico",
            "8",
            "4",
            "12",
            "3",
            "5"
          ],
          [
            "14",
            "+5",
            "Rasgo de subclase",
            "8",
            "4",
            "12",
            "3",
            "5"
          ],
          [
            "15",
            "+5",
            "Arcanum místico",
            "9",
            "4",
            "13",
            "3",
            "5"
          ],
          [
            "16",
            "+5",
            "Mejora de característica",
            "9",
            "4",
            "13",
            "3",
            "5"
          ],
          [
            "17",
            "+6",
            "Arcanum místico",
            "9",
            "4",
            "14",
            "4",
            "5"
          ],
          [
            "18",
            "+6",
            "—",
            "10",
            "4",
            "14",
            "4",
            "5"
          ],
          [
            "19",
            "+6",
            "Don épico",
            "10",
            "4",
            "15",
            "4",
            "5"
          ],
          [
            "20",
            "+6",
            "Maestro sobrenatural",
            "10",
            "4",
            "15",
            "4",
            "5"
          ]
        ]
      }
    }
  },
  "clerigo": {
    "id": "clerigo",
    "name": "Clérigo",
    "primaryAbility": "Sabiduría",
    "hitDie": "1d8",
    "savingThrows": [
      "Sabiduría",
      "Carisma"
    ],
    "skillChoices": {
      "choose": 2,
      "from": [
        "Historia",
        "Medicina",
        "Perspicacia",
        "Persuasión",
        "Religión"
      ]
    },
    "weaponProficiencies": [
      "Armas sencillas"
    ],
    "startingEquipment": {
      "options": [
        {
          "label": "A",
          "items": [
            "Camisa de malla",
            "Escudo",
            "Maza",
            "Paquete de sacerdote",
            "Símbolo sagrado",
            "7 po"
          ]
        },
        {
          "label": "B",
          "items": [
            "110 po"
          ]
        }
      ]
    },
    "features": {
      "lanzamiento_de_conjuros": {
        "level": 1,
        "description": "Has aprendido a lanzar conjuros gracias a la oración y la meditación. Consulta el capítulo 7 para ver las reglas sobre el lanzamiento de conjuros. La información presentada a continuación detalla cómo usar esas reglas con los conjuros de clérigo.\n\nTrucos. Conoces tres trucos de tu elección escogidos de entre los de la lista de conjuros de clérigo. Se recomiendan guía, llama sagrada y taumaturgia.\nCada vez que subas un nivel de clérigo, puedes sustituir uno de tus trucos por otro truco de tu elección de la lista de conjuros de clérigo.\nCuando alcances los niveles 4 y 10 de clérigo, aprenderás otro truco de tu elección de la lista de conjuros de clérigo.\n\nEspacios de conjuro. La tabla “Rasgos de clérigo” muestra cuántos espacios de conjuro tienes para lanzar tus conjuros de nivel 1 y superiores. Recuperas todos los espacios utilizados tras finalizar un descanso largo.\n\nConjuros preparados de nivel 1 y superiores. Preparas una serie de conjuros de nivel 1 y superiores, que son los que podrás lanzar con este rasgo. Para empezar, elige cuatro conjuros de nivel 1 de la lista de conjuros de clérigo. Se recomiendan bendición, curar heridas, escudo de fe y saeta guía.\nEl número de conjuros de tu lista aumenta conforme subes de nivel de clérigo, como se muestra en la columna “Conjuros preparados” de la tabla “Rasgos de clérigo”.\nCuando ese número aumente, elige conjuros adicionales de la lista de conjuros de clérigo hasta que el número de conjuros de tu lista coincida con el número de la tabla.\nEstos conjuros deben ser de un nivel para el que tengas espacios de conjuro. Por ejemplo, si eres una clériga de nivel 3, podrías preparar cualquier combinación de seis conjuros de nivel 1 o 2.\nSi otro rasgo de clérigo te proporciona conjuros que siempre tienes preparados, esos conjuros no cuentan para el total que puedes preparar con este rasgo, pero sí que cuentan como conjuros de clérigo para ti.\n\nCambiar los conjuros preparados. Tras finalizar un descanso largo, puedes cambiar los conjuros que tienes preparados sustituyendo los que quieras por otros conjuros de clérigo para los que tengas espacios de conjuro.\n\nAptitud mágica. La Sabiduría es tu aptitud mágica en lo que respecta a tus conjuros de clérigo.\n\nCanalizador mágico. Puedes utilizar un símbolo sagrado como canalizador mágico para tus conjuros de clérigo.",
        "name": "Lanzamiento de Conjuros"
      },
      "orden_divina": {
        "level": 1,
        "description": "Te has consagrado a una de las siguientes funciones sacras, a tu elección.\n\nProtector. Te has entrenado para el combate y ganas competencia con armas marciales y entrenamiento con armaduras pesadas.\n\nTaumaturgo. Conoces un truco adicional de la lista de conjuros de clérigo. Además, tu conexión mística con lo divino te proporciona un bonificador a tus pruebas de Inteligencia (Conocimiento arcano y Religión). El bonificador es igual a tu modificador por Sabiduría (mínimo de +1).",
        "name": "Orden Divina"
      },
      "canalizar_divinidad": {
        "level": 2,
        "description": "Puedes canalizar energía divina directamente de los Planos Exteriores para alimentar varios efectos mágicos. Empiezas con dos de estos efectos: Chispa divina y Expulsar muertos vivientes.\nPuedes usar el rasgo Canalizar divinidad dos veces. Recuperas uno de los usos gastados tras finalizar un descanso corto y todos tras finalizar un descanso largo. Obtienes usos adicionales cuando alcanzas ciertos niveles de clérigo.\nSi un efecto de Canalizar divinidad requiere una tirada de salvación, la CD será igual a la CD de salvación de conjuros del rasgo Lanzamiento de conjuros de esta clase.\n\nChispa divina. Como acción de magia, diriges tu símbolo sagrado hacia otra criatura que puedas ver a 30 pies o menos de ti y concentras energía divina en ella. Tira 1d8 y suma tu modificador por Sabiduría. Puedes hacer que la criatura recupere una cantidad de puntos de golpe igual al resultado u obligar a la criatura a hacer una tirada de salvación de Constitución. Si la falla, sufrirá una cantidad de daño necrótico o radiante (a tu elección) igual a ese resultado. Si la supera, sufrirá la mitad de daño (redondeando hacia abajo).\nTira 1d8 adicional cuando alcances los niveles 7 (2d8), 13 (3d8) y 18 (4d8) de clérigo.\n\nExpulsar muertos vivientes. Como acción de magia, muestras tu símbolo sagrado y rechazas a los muertos vivientes. Cada muerto viviente de tu elección a 30 pies o menos de ti deberá hacer una tirada de salvación de Sabiduría. Si la falla, tendrá los estados de asustado e incapacitado durante 1 minuto. Durante ese tiempo, tratará de alejarse de ti todo lo que pueda en sus turnos. Este efecto termina antes de tiempo si la criatura sufre daño, si tienes el estado de incapacitado o si mueres.",
        "name": "Canalizar Divinidad"
      },
      "subclase_de_clerigo": {
        "level": 3,
        "description": "Consigues una subclase de clérigo de tu elección. Las subclases del dominio de la guerra, el dominio de la luz, el dominio de la vida y el dominio del engaño se detallan tras la descripción de esta clase. Una subclase es una especialización que te proporciona rasgos cuando alcanzas ciertos niveles de clérigo. De aquí en adelante, obtienes todos los rasgos de tu subclase que sean de tu nivel de clérigo e inferiores.",
        "name": "Subclase de Clérigo"
      },
      "mejora_de_caracteristica": {
        "level": 4,
        "description": "Obtienes la dote Mejora de característica (consulta el capítulo 5) u otra dote de tu elección para la que cumplas las condiciones. Vuelves a obtener este rasgo en los niveles 8, 12 y 16 de clérigo.",
        "name": "Mejora de Característica"
      },
      "abrasar_muertos_vivientes": {
        "level": 5,
        "description": "Cuando utilices Expulsar muertos vivientes, puedes tirar una cantidad de d8 igual a tu modificador por Sabiduría (mínimo 1d8) y sumar los resultados. Todos los muertos vivientes que fallen su tirada de salvación contra ese uso de Expulsar muertos vivientes sufrirán una cantidad de daño radiante igual al resultado total de las tiradas. Este daño no pone fin al efecto de expulsión.",
        "name": "Abrasar Muertos Vivientes"
      },
      "golpes_benditos": {
        "level": 7,
        "description": "Te imbuyes de poder divino en la batalla. Obtienes una de las siguientes opciones, a tu elección.\n\nGolpe divino. Una vez en cada uno de tus turnos, cuando aciertes a una criatura con una tirada de ataque usando un arma, podrás hacer que el objetivo sufra 1d8 de daño necrótico o radiante adicional (a tu elección).\n\nLanzamiento potente. Sumas tu modificador por Sabiduría al daño que causas con cualquier truco de clérigo.",
        "name": "Golpes Benditos"
      },
      "intercesion_divina": {
        "level": 10,
        "description": "Puedes recurrir a tu deidad o panteón para que intervenga en tu nombre. Como acción de magia, elige cualquier conjuro de clérigo de nivel 5 o inferior que no requiera una reacción para lanzarlo. Como parte de la misma acción, lanzas ese conjuro sin gastar un espacio de conjuro o sin necesidad de componentes materiales.\nNo podrás volver a utilizar este rasgo hasta que finalices un descanso largo.",
        "name": "Intercesión Divina"
      },
      "golpes_benditos_mejorados": {
        "level": 14,
        "description": "La opción elegida para Golpes benditos se vuelve más poderosa.\n\nGolpe divino. El daño adicional de tu Golpe divino aumenta a 2d8.\n\nLanzamiento potente. Cuando lances un truco de clérigo y causes daño a una criatura con él, podrás transmitir vitalidad a ti o a otra criatura que esté a 60 pies o menos de ti; se concederá una cantidad de puntos de golpe temporales igual al doble de tu modificador por Sabiduría.",
        "name": "Golpes Benditos Mejorados"
      },
      "don_epico": {
        "level": 19,
        "description": "Obtienes una dote de don épico (consulta el capítulo 5) u otra dote de tu elección para la que cumplas las condiciones. Se recomienda Don del destino.",
        "name": "Don Épico"
      },
      "intercesion_divina_mayor": {
        "level": 20,
        "description": "Puedes solicitar una intercesión divina todavía más poderosa. Cuando uses tu rasgo Intercesión divina, puedes elegir deseo al seleccionar un conjuro. Si lo haces, no podrás volver a usar Intercesión divina hasta que finalices 2d4 descansos largos.",
        "name": "Intercesión Divina Mayor"
      }
    },
    "subclasses": {
      "dominio_guerra": {
        "name": "Dominio de la Guerra",
        "features": {
          "golpe_guiado": {
            "level": 3,
            "description": "Cuando tú o una criatura a 30 pies o menos de ti falléis una tirada de ataque, podrás gastar un uso de Canalizar divinidad y conceder un bonificador de +10 a la tirada, lo que podría hacer que acierte. Cuando utilices este rasgo para mejorar la tirada de ataque de otra criatura, deberás llevar a cabo una reacción para ello.",
            "name": "Golpe Guiado"
          },
          "sacerdote_guerrero": {
            "level": 3,
            "description": "Como acción adicional, puedes realizar un ataque con un arma o un ataque sin armas. Puedes utilizar esta acción adicional una cantidad de veces igual a tu modificador por Sabiduría (mínimo una vez). Recuperas todos los usos tras finalizar un descanso corto o largo.",
            "name": "Sacerdote Guerrero"
          },
          "bendicion_del_dios_de_la_guerra": {
            "level": 6,
            "description": "Puedes gastar un uso de Canalizar divinidad para lanzar arma espiritual o escudo de fe en vez de gastar un espacio de conjuro. Cuando lances cualquiera de esos conjuros de esta forma, no requerirá concentración. En su lugar, el conjuro durará 1 minuto, pero terminará antes de tiempo si lanzas el conjuro de nuevo, si tienes el estado incapacitado o si mueres.",
            "name": "Bendición del Dios de la Guerra"
          },
          "avatar_de_la_batalla": {
            "level": 17,
            "description": "Ganas resistencia al daño contundente, cortante y perforante.",
            "name": "Avatar de la Batalla"
          },
          "domain_spells": {
            "name": "Conjuros del Dominio de la Guerra",
            "level": 3,
            "description": "Cuando alcances un nivel de clérigo especificado en la tabla correspondiente, a partir de entonces siempre tendrás preparados los conjuros que se indican."
          }
        },
        "levels": {
          "3": [
            "domain_spells",
            "golpe_guiado",
            "sacerdote_guerrero"
          ],
          "6": [
            "bendicion_del_dios_de_la_guerra"
          ],
          "17": [
            "avatar_de_la_batalla"
          ]
        },
        "tables": {
          "domain_spells_table": {
            "title": "Conjuros del Dominio de la Guerra",
            "columns": [
              "Nivel de clérigo",
              "Conjuros preparados"
            ],
            "rows": [
              [
                "3",
                "Arma espiritual, arma mágica, escudo de fe, saeta guía"
              ],
              [
                "5",
                "Espíritus guardianes, manto del cruzado"
              ],
              [
                "7",
                "Escudo de fuego, libertad del movimiento"
              ],
              [
                "9",
                "Golpe de viento acerado, inmovilizar monstruo"
              ]
            ]
          }
        }
      },
      "dominio_luz": {
        "name": "Dominio de la Luz",
        "features": {
          "fulgor_protector": {
            "level": 3,
            "description": "Cuando una criatura que puedas ver a 30 pies o menos de ti haga una tirada de ataque, puedes llevar a cabo una reacción para imponer desventaja a su tirada de ataque haciendo que una luz resplandezca ante ella antes de que acierte o falle.\nPuedes utilizar este rasgo una cantidad de veces igual a tu modificador por Sabiduría (mínimo una vez). Recuperas todos los usos tras finalizar un descanso largo.",
            "name": "Fulgor Protector"
          },
          "resplandor_del_amanecer": {
            "level": 3,
            "description": "Como acción de magia, muestras tu símbolo sagrado y gastas un uso de Canalizar divinidad para emitir un destello luminoso en una emanación de 30 pies originada en ti. Cualquier oscuridad mágica, como la que crea el conjuro oscuridad, se disipa en esa zona. Asimismo, todas las criaturas de tu elección situadas en esa zona deberán hacer una tirada de salvación de Constitución; sufrirán una cantidad de daño radiante igual a 2d10 más tu nivel de clérigo si la fallan o la mitad del daño si la superan.",
            "name": "Resplandor del Amanecer"
          },
          "fulgor_protector_mejorado": {
            "level": 6,
            "description": "Recuperas todos los usos de tu Fulgor protector tras finalizar un descanso corto o largo.\nAdemás, cuando uses tu Fulgor protector, puedes conceder al objetivo del ataque al que reaccionas una cantidad de puntos de golpe temporales igual a 2d20 piesás tu modificador por Sabiduría.",
            "name": "Fulgor Protector Mejorado"
          },
          "halo_de_luz": {
            "level": 17,
            "description": "Como acción de magia, puedes emitir un aura de luz solar que dura 1 minuto o hasta que la disipes (no requiere acción). Emitirás luz brillante en un radio de 60 pies y luz tenue 30 pies más allá. Los enemigos situados en la zona de luz brillante tendrán desventaja en las tiradas de salvación contra tu rasgo Resplandor del amanecer o contra cualquier conjuro que cause daño de fuego o radiante.\nPuedes usar este rasgo una cantidad de veces igual a tu modificador por Sabiduría (mínimo una vez) y recuperas todos los usos tras finalizar un descanso largo.",
            "name": "Halo de Luz"
          },
          "domain_spells": {
            "name": "Conjuros del Dominio de la Luz",
            "level": 3,
            "description": "Cuando alcances un nivel de clérigo especificado en la tabla correspondiente, a partir de entonces siempre tendrás preparados los conjuros que se indican."
          }
        },
        "levels": {
          "3": [
            "domain_spells",
            "fulgor_protector",
            "resplandor_del_amanecer"
          ],
          "6": [
            "fulgor_protector_mejorado"
          ],
          "17": [
            "halo_de_luz"
          ]
        },
        "tables": {
          "domain_spells_table": {
            "title": "Conjuros del Dominio de la Luz",
            "columns": [
              "Nivel de clérigo",
              "Conjuros preparados"
            ],
            "rows": [
              [
                "3",
                "Fuego feérico, manos ardientes, rayo abrasador, ver invisibilidad"
              ],
              [
                "5",
                "Bola de fuego, luz del día"
              ],
              [
                "7",
                "Muro de fuego, ojo arcano"
              ],
              [
                "9",
                "Escudriñar, golpe flamígero"
              ]
            ]
          }
        }
      },
      "dominio_vida": {
        "name": "Dominio de la Vida",
        "features": {
          "discipulo_de_la_vida": {
            "level": 3,
            "description": "Cuando uses un espacio de conjuro para lanzar un conjuro que haga recuperar puntos de golpe a una criatura, esa criatura recuperará puntos de golpe adicionales en el turno en que lances el conjuro. La cantidad de puntos de golpe adicionales es igual a 2 más el nivel del espacio de conjuro.",
            "name": "Discípulo de la Vida"
          },
          "preservar_vida": {
            "level": 3,
            "description": "Como acción de magia, muestras tu símbolo sagrado y gastas un uso de Canalizar divinidad para generar una energía curativa capaz de restaurar una cantidad de puntos de golpe igual a cinco veces tu nivel de clérigo. Elige criaturas maltrechas a 30 pies o menos de ti (lo que puede incluirte a ti) y divide estos puntos de golpe entre ellas. Este rasgo no puede hacer que una criatura pase a tener más de la mitad de sus puntos de golpe máximos.",
            "name": "Preservar Vida"
          },
          "sanador_bendito": {
            "level": 6,
            "description": "Los conjuros de curación que lances sobre otros también te sanan a ti. Inmediatamente después de usar un espacio de conjuro para lanzar un conjuro que haga recuperar puntos de golpe a una o varias criaturas que no seas tú, recuperarás una cantidad de puntos de golpe igual a 2 más el nivel del espacio de conjuro.",
            "name": "Sanador Bendito"
          },
          "sanacion_suprema": {
            "level": 17,
            "description": "En vez de tirar uno o más dados para hacer que una criatura recupere puntos de golpe con un conjuro o con Canalizar divinidad, no tirarás estos dados para la curación, sino que utilizarás el número más alto de cada dado. Por ejemplo, en lugar de hacer que una criatura recupere 2d6 puntos de golpe, harás que recupere 12.",
            "name": "Sanación Suprema"
          },
          "domain_spells": {
            "name": "Conjuros del Dominio de la Vida",
            "level": 3,
            "description": "Cuando alcances un nivel de clérigo especificado en la tabla correspondiente, a partir de entonces siempre tendrás preparados los conjuros que se indican."
          }
        },
        "levels": {
          "3": [
            "domain_spells",
            "discipulo_de_la_vida",
            "preservar_vida"
          ],
          "6": [
            "sanador_bendito"
          ],
          "17": [
            "sanacion_suprema"
          ]
        },
        "tables": {
          "domain_spells_table": {
            "title": "Conjuros del Dominio de la Vida",
            "columns": [
              "Nivel de clérigo",
              "Conjuros preparados"
            ],
            "rows": [
              [
                "3",
                "Auxilio, bendición, curar heridas, restablecimiento menor"
              ],
              [
                "5",
                "Palabra de curación en masa, revivir"
              ],
              [
                "7",
                "Aura de vida, guarda contra la muerte"
              ],
              [
                "9",
                "Curar heridas en masa, restablecimiento mayor"
              ]
            ]
          }
        }
      },
      "dominio_engano": {
        "name": "Dominio del Engaño",
        "features": {
          "bendicion_del_embaucador": {
            "level": 3,
            "description": "Como acción de magia, puedes escogerte a ti o a una criatura voluntaria a 30 pies o menos de ti para que tenga ventaja en las pruebas de Destreza (Sigilo). Esta bendición dura hasta que finalices un descanso largo o hasta que vuelvas a usar este rasgo.",
            "name": "Bendición del Embaucador"
          },
          "invocar_duplicidad": {
            "level": 3,
            "description": "Como acción adicional, puedes gastar un uso de Canalizar divinidad para crear un duplicado ilusorio perfecto de ti en un espacio sin ocupar que puedas ver a 30 pies o menos de ti. La ilusión no es tangible ni ocupa el espacio en el que se encuentra. Dura 1 minuto, pero termina antes de tiempo si la disipas (no requiere acción) o si tienes el estado de incapacitado. La ilusión está animada e imita tus expresiones y gestos. Mientras persista, obtienes los siguientes beneficios:\n\nDistraer. Cuando tanto tu ilusión como tú estéis a 5 pies o menos de una criatura que pueda ver la ilusión, tendrás ventaja en las tiradas de ataque contra esa criatura, ya que la ilusión distrae al objetivo.\n\nLanzar conjuros. Puedes lanzar conjuros como si estuvieras en el espacio de la ilusión, pero debes utilizar tus propios sentidos.\n\nMover. Como acción adicional, puedes mover la ilusión hasta 30 pies a un espacio sin ocupar que puedas ver a 120 pies o menos de ti.",
            "name": "Invocar Duplicidad"
          },
          "transposicion_del_embaucador": {
            "level": 6,
            "description": "Siempre que utilices una acción adicional para crear o mover la ilusión de Invocar duplicidad, podrás teletransportarte y cambiarle el lugar a la ilusión.",
            "name": "Transposición del Embaucador"
          },
          "duplicidad_mejorada": {
            "level": 17,
            "description": "La ilusión de Invocar duplicidad se vuelve más poderosa de las siguientes formas:\n\nDistracción compartida. Cuando tus aliados y tú hagáis tiradas de ataque contra una criatura que se encuentre a 5 pies o menos de la ilusión, esas tiradas de ataque tendrán ventaja.\n\nIlusión sanadora. Cuando la ilusión desaparezca, tú o una criatura de tu elección a 5 pies o menos de ella recuperaréis una cantidad de puntos de golpe igual a tu nivel de clérigo.",
            "name": "Duplicidad Mejorada"
          },
          "domain_spells": {
            "name": "Conjuros del Dominio del Engaño",
            "level": 3,
            "description": "Cuando alcances un nivel de clérigo especificado en la tabla correspondiente, a partir de entonces siempre tendrás preparados los conjuros que se indican."
          }
        },
        "levels": {
          "3": [
            "domain_spells",
            "bendicion_del_embaucador",
            "invocar_duplicidad"
          ],
          "6": [
            "transposicion_del_embaucador"
          ],
          "17": [
            "duplicidad_mejorada"
          ]
        },
        "tables": {
          "domain_spells_table": {
            "title": "Conjuros del Dominio del Engaño",
            "columns": [
              "Nivel de clérigo",
              "Conjuros preparados"
            ],
            "rows": [
              [
                "3",
                "Disfrazarse, hechizar persona, invisibilidad, pasar sin rastro"
              ],
              [
                "5",
                "Indetectable, patrón hipnótico"
              ],
              [
                "7",
                "Confusión, puerta dimensional"
              ],
              [
                "9",
                "Alterar los recuerdos, dominar persona"
              ]
            ]
          }
        }
      },
      "dominio_del_conocimiento": {
        "name": "Dominio del Conocimiento",
        "source": "Forgotten Realms: Heroes of Faerûn / Unearthed Arcana 2025",
        "levels": {
          "3": {
            "features": [
              "blessings_of_knowledge",
              "knowledge_domain_spells",
              "mind_magic"
            ]
          },
          "6": {
            "features": [
              "unfettered_mind"
            ]
          },
          "17": {
            "features": [
              "divine_foreknowledge"
            ]
          }
        },
        "features": {
          "blessings_of_knowledge": {
            "name": "Bendiciones del conocimiento",
            "level": 3,
            "description": "Ganas competencia con un tipo de herramientas de artesano de tu elección y en dos de las siguientes habilidades de tu elección: Arcano, Historia, Naturaleza o Religión. Tu bonificador por competencia se duplica para cualquier prueba que hagas usando esas dos habilidades."
          },
          "knowledge_domain_spells": {
            "name": "Conjuros del dominio del conocimiento",
            "level": 3,
            "description": "Cuando alcances un nivel de clérigo especificado en la tabla «Conjuros del dominio del conocimiento», siempre tendrás preparados los conjuros indicados.",
            "table": {
              "title": "Conjuros del Dominio del Conocimiento",
              "columns": [
                "Nivel de clérigo",
                "Conjuros preparados"
              ],
              "rows": [
                [
                  "3",
                  "Orden imperiosa, Entender idiomas, Detectar magia, Detectar pensamientos, Identificar, Clavo mental"
                ],
                [
                  "5",
                  "Disipar magia, Indetectable, Don de lenguas"
                ],
                [
                  "7",
                  "Ojo arcano, Destierro, Confusión"
                ],
                [
                  "9",
                  "Conocer las leyendas, Escudriñar, Estática sináptica"
                ]
              ]
            }
          },
          "mind_magic": {
            "name": "Magia mental",
            "level": 3,
            "description": "Como acción de Magia, puedes gastar un uso de tu Canalizar Divinidad para manifestar tu conocimiento mágico. Elige un conjuro de la tabla Conjuros del dominio del conocimiento que tengas preparado. Como parte de esa acción, lanzas ese conjuro sin gastar un espacio de conjuro ni necesitar componentes materiales."
          },
          "unfettered_mind": {
            "name": "Mente liberada",
            "level": 6,
            "description": "Ganas telepatía con un alcance de 60 pies. Cuando uses esta telepatía, puedes contactar simultáneamente con un número de criaturas igual a tu modificador por Sabiduría, con un mínimo de una.\n\nAdemás, si el total de una prueba de Inteligencia que haces es inferior a tu puntuación de Sabiduría, puedes usar esa puntuación en lugar del total."
          },
          "divine_foreknowledge": {
            "name": "Presciencia divina",
            "level": 17,
            "description": "Como acción adicional, expandes mágicamente tu mente a las posibilidades del futuro. Durante 1 hora, tienes ventaja en las pruebas de d20. Una vez que uses este rasgo, no podrás volver a usarlo hasta terminar un descanso largo. También puedes recuperar su uso gastando un espacio de conjuro de nivel 6 o superior, sin requerir acción."
          }
        },
        "tables": {
          "knowledge_domain_spells_table": {
            "title": "Conjuros del Dominio del Conocimiento",
            "columns": [
              "Nivel de clérigo",
              "Conjuros preparados"
            ],
            "rows": [
              [
                "3",
                "Orden imperiosa, Entender idiomas, Detectar magia, Detectar pensamientos, Identificar, Clavo mental"
              ],
              [
                "5",
                "Disipar magia, Indetectable, Don de lenguas"
              ],
              [
                "7",
                "Ojo arcano, Destierro, Confusión"
              ],
              [
                "9",
                "Conocer las leyendas, Escudriñar, Estática sináptica"
              ]
            ]
          }
        }
      }
    },
    "armorTraining": [
      "Armaduras ligeras",
      "Armaduras medias",
      "Escudos"
    ],
    "levels": {
      "1": {
        "features": [
          "lanzamiento_de_conjuros",
          "orden_divina"
        ],
        "cantripsKnown": 3,
        "preparedSpells": 4,
        "proficiencyBonus": "+2"
      },
      "2": {
        "features": [
          "canalizar_divinidad"
        ],
        "channelDivinityUses": 2,
        "preparedSpells": 5,
        "proficiencyBonus": "+2"
      },
      "3": {
        "features": [
          "subclase_de_clerigo"
        ],
        "preparedSpells": 6,
        "proficiencyBonus": "+2"
      },
      "4": {
        "features": [
          "mejora_de_caracteristica"
        ],
        "cantripsKnown": 4,
        "preparedSpells": 7,
        "proficiencyBonus": "+2"
      },
      "5": {
        "features": [
          "abrasar_muertos_vivientes"
        ],
        "preparedSpells": 9,
        "proficiencyBonus": "+3"
      },
      "6": {
        "channelDivinityUses": 3,
        "preparedSpells": 10,
        "proficiencyBonus": "+3"
      },
      "7": {
        "features": [
          "golpes_benditos"
        ],
        "preparedSpells": 11,
        "proficiencyBonus": "+3"
      },
      "8": {
        "features": [
          "mejora_de_caracteristica"
        ],
        "preparedSpells": 12,
        "proficiencyBonus": "+3"
      },
      "9": {
        "preparedSpells": 14,
        "proficiencyBonus": "+4"
      },
      "10": {
        "features": [
          "intercesion_divina"
        ],
        "cantripsKnown": 5,
        "preparedSpells": 15,
        "proficiencyBonus": "+4"
      },
      "11": {
        "preparedSpells": 16,
        "proficiencyBonus": "+4"
      },
      "12": {
        "features": [
          "mejora_de_caracteristica"
        ],
        "preparedSpells": 16,
        "proficiencyBonus": "+4"
      },
      "13": {
        "preparedSpells": 17,
        "proficiencyBonus": "+5"
      },
      "14": {
        "features": [
          "golpes_benditos_mejorados"
        ],
        "preparedSpells": 18,
        "proficiencyBonus": "+5"
      },
      "15": {
        "preparedSpells": 19,
        "proficiencyBonus": "+5"
      },
      "16": {
        "features": [
          "mejora_de_caracteristica"
        ],
        "preparedSpells": 19,
        "proficiencyBonus": "+5"
      },
      "17": {
        "preparedSpells": 20,
        "proficiencyBonus": "+6"
      },
      "18": {
        "channelDivinityUses": 4,
        "preparedSpells": 21,
        "proficiencyBonus": "+6"
      },
      "19": {
        "features": [
          "don_epico"
        ],
        "preparedSpells": 22,
        "proficiencyBonus": "+6"
      },
      "20": {
        "features": [
          "intercesion_divina_mayor"
        ],
        "preparedSpells": 22,
        "proficiencyBonus": "+6"
      }
    },
    "tables": {
      "spell_progression": {
        "title": "Progresión de Clérigo",
        "columns": [
          "Nivel",
          "Bonif. competencia",
          "Trucos",
          "Conjuros preparados",
          "1",
          "2",
          "3",
          "4",
          "5",
          "6",
          "7",
          "8",
          "9"
        ],
        "rows": [
          [
            "1",
            "+2",
            "3",
            "4",
            "2",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "2",
            "+2",
            "3",
            "5",
            "3",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "3",
            "+2",
            "3",
            "6",
            "4",
            "2",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "4",
            "+2",
            "4",
            "7",
            "4",
            "3",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "5",
            "+3",
            "4",
            "9",
            "4",
            "3",
            "2",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "6",
            "+3",
            "4",
            "10",
            "4",
            "3",
            "3",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "7",
            "+3",
            "4",
            "11",
            "4",
            "3",
            "3",
            "1",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "8",
            "+3",
            "4",
            "12",
            "4",
            "3",
            "3",
            "2",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "9",
            "+4",
            "4",
            "14",
            "4",
            "3",
            "3",
            "3",
            "1",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "10",
            "+4",
            "5",
            "15",
            "4",
            "3",
            "3",
            "3",
            "2",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "11",
            "+4",
            "5",
            "16",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "-",
            "-",
            "-"
          ],
          [
            "12",
            "+4",
            "5",
            "16",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "-",
            "-",
            "-"
          ],
          [
            "13",
            "+5",
            "5",
            "17",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "-",
            "-"
          ],
          [
            "14",
            "+5",
            "5",
            "18",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "-",
            "-"
          ],
          [
            "15",
            "+5",
            "5",
            "19",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "1",
            "-"
          ],
          [
            "16",
            "+5",
            "5",
            "19",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "1",
            "-"
          ],
          [
            "17",
            "+6",
            "5",
            "20",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "1",
            "1"
          ],
          [
            "18",
            "+6",
            "5",
            "21",
            "4",
            "3",
            "3",
            "3",
            "3",
            "1",
            "1",
            "1",
            "1"
          ],
          [
            "19",
            "+6",
            "5",
            "22",
            "4",
            "3",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "1"
          ],
          [
            "20",
            "+6",
            "5",
            "22",
            "4",
            "3",
            "3",
            "3",
            "3",
            "2",
            "2",
            "1",
            "1"
          ]
        ]
      },
      "channel_divinity_progression": {
        "title": "Canalizar Divinidad",
        "columns": [
          "Nivel de clérigo",
          "Usos"
        ],
        "rows": [
          [
            "2",
            "2"
          ],
          [
            "6",
            "3"
          ],
          [
            "18",
            "4"
          ]
        ]
      },
      "cleric_progression": {
        "title": "Rasgos de Clérigo",
        "columns": [
          "Nivel",
          "Bonif. competencia",
          "Rasgos",
          "Trucos",
          "Canalizar\nDivinidad",
          "Conjuros\npreparados",
          "1",
          "2",
          "3",
          "4",
          "5",
          "6",
          "7",
          "8",
          "9"
        ],
        "rows": [
          [
            "1",
            "+2",
            "Lanzamiento de Conjuros, Orden Divina",
            "3",
            "—",
            "4",
            "2",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "2",
            "+2",
            "Canalizar Divinidad",
            "3",
            "2",
            "5",
            "3",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "3",
            "+2",
            "Subclase de Clérigo",
            "3",
            "2",
            "6",
            "4",
            "2",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "4",
            "+2",
            "Mejora de Característica",
            "4",
            "2",
            "7",
            "4",
            "3",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "5",
            "+3",
            "Abrasar Muertos Vivientes",
            "4",
            "2",
            "9",
            "4",
            "3",
            "2",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "6",
            "+3",
            "Rasgo de subclase",
            "4",
            "3",
            "10",
            "4",
            "3",
            "3",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "7",
            "+3",
            "Golpes Benditos",
            "4",
            "3",
            "11",
            "4",
            "3",
            "3",
            "1",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "8",
            "+3",
            "Mejora de Característica",
            "4",
            "3",
            "12",
            "4",
            "3",
            "3",
            "2",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "9",
            "+4",
            "—",
            "4",
            "3",
            "14",
            "4",
            "3",
            "3",
            "3",
            "1",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "10",
            "+4",
            "Intercesión Divina",
            "5",
            "3",
            "15",
            "4",
            "3",
            "3",
            "3",
            "2",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "11",
            "+4",
            "—",
            "5",
            "3",
            "16",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "-",
            "-",
            "-"
          ],
          [
            "12",
            "+4",
            "Mejora de Característica",
            "5",
            "3",
            "16",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "-",
            "-",
            "-"
          ],
          [
            "13",
            "+5",
            "—",
            "5",
            "3",
            "17",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "-",
            "-"
          ],
          [
            "14",
            "+5",
            "Golpes Benditos Mejorados",
            "5",
            "3",
            "18",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "-",
            "-"
          ],
          [
            "15",
            "+5",
            "—",
            "5",
            "3",
            "19",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "1",
            "-"
          ],
          [
            "16",
            "+5",
            "Mejora de Característica",
            "5",
            "3",
            "19",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "1",
            "-"
          ],
          [
            "17",
            "+6",
            "Rasgo de subclase",
            "5",
            "3",
            "20",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "1",
            "1"
          ],
          [
            "18",
            "+6",
            "—",
            "5",
            "4",
            "21",
            "4",
            "3",
            "3",
            "3",
            "3",
            "1",
            "1",
            "1",
            "1"
          ],
          [
            "19",
            "+6",
            "Don Épico",
            "5",
            "4",
            "22",
            "4",
            "3",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "1"
          ],
          [
            "20",
            "+6",
            "Intercesión Divina Mayor",
            "5",
            "4",
            "22",
            "4",
            "3",
            "3",
            "3",
            "3",
            "2",
            "2",
            "1",
            "1"
          ]
        ]
      }
    }
  },
  "druida": {
    "id": "druida",
    "name": "Druida",
    "primaryAbility": "Sabiduría",
    "hitDie": "1d8",
    "savingThrows": [
      "Inteligencia",
      "Sabiduría"
    ],
    "skillChoices": {
      "choose": 2,
      "from": [
        "Arcano",
        "Medicina",
        "Naturaleza",
        "Percepción",
        "Perspicacia",
        "Religión",
        "Supervivencia",
        "Trato con Animales"
      ]
    },
    "weaponProficiencies": [
      "Armas sencillas"
    ],
    "toolProficiencies": [
      "Útiles de herborista"
    ],
    "armorTraining": [
      "Armaduras ligeras",
      "Escudos"
    ],
    "startingEquipment": {
      "options": [
        {
          "label": "A",
          "items": [
            "Armadura de cuero",
            "Escudo",
            "Hoz",
            "Canalizador druídico (bastón)",
            "Paquete de explorador",
            "Útiles de herborista",
            "9 po"
          ]
        },
        {
          "label": "B",
          "items": [
            "50 po"
          ]
        }
      ]
    },
    "levels": {
      "1": {
        "features": [
          "spellcasting",
          "druidic",
          "primal_order"
        ],
        "cantripsKnown": 2,
        "preparedSpells": 4,
        "proficiencyBonus": "+2",
        "wildShapeUses": 0
      },
      "2": {
        "features": [
          "wild_companion",
          "wild_shape"
        ],
        "proficiencyBonus": "+2",
        "preparedSpells": 5,
        "wildShapeUses": 2
      },
      "3": {
        "features": [
          "druid_subclass"
        ],
        "proficiencyBonus": "+2",
        "preparedSpells": 6,
        "wildShapeUses": 2
      },
      "4": {
        "features": [
          "ability_score_improvement_druid"
        ],
        "cantripsKnown": 3,
        "proficiencyBonus": "+2",
        "preparedSpells": 7,
        "wildShapeUses": 2
      },
      "5": {
        "features": [
          "wild_resurgence"
        ],
        "proficiencyBonus": "+3",
        "preparedSpells": 9,
        "wildShapeUses": 2
      },
      "6": {
        "proficiencyBonus": "+3",
        "preparedSpells": 10,
        "wildShapeUses": 3
      },
      "7": {
        "features": [
          "elemental_fury"
        ],
        "proficiencyBonus": "+3",
        "preparedSpells": 11,
        "wildShapeUses": 3
      },
      "8": {
        "features": [
          "ability_score_improvement_druid"
        ],
        "proficiencyBonus": "+3",
        "preparedSpells": 12,
        "wildShapeUses": 3
      },
      "9": {
        "proficiencyBonus": "+4",
        "preparedSpells": 14,
        "wildShapeUses": 3
      },
      "10": {
        "cantripsKnown": 4,
        "proficiencyBonus": "+4",
        "preparedSpells": 15,
        "wildShapeUses": 3
      },
      "11": {
        "proficiencyBonus": "+4",
        "preparedSpells": 16,
        "wildShapeUses": 3
      },
      "12": {
        "features": [
          "ability_score_improvement_druid"
        ],
        "proficiencyBonus": "+4",
        "preparedSpells": 16,
        "wildShapeUses": 3
      },
      "13": {
        "proficiencyBonus": "+5",
        "preparedSpells": 17,
        "wildShapeUses": 3
      },
      "14": {
        "proficiencyBonus": "+5",
        "preparedSpells": 18,
        "wildShapeUses": 3
      },
      "15": {
        "features": [
          "improved_elemental_fury"
        ],
        "proficiencyBonus": "+5",
        "preparedSpells": 19,
        "wildShapeUses": 3
      },
      "16": {
        "features": [
          "ability_score_improvement_druid"
        ],
        "proficiencyBonus": "+5",
        "preparedSpells": 19,
        "wildShapeUses": 3
      },
      "17": {
        "proficiencyBonus": "+6",
        "preparedSpells": 20,
        "wildShapeUses": 4
      },
      "18": {
        "features": [
          "beast_spellcasting"
        ],
        "proficiencyBonus": "+6",
        "preparedSpells": 21,
        "wildShapeUses": 4
      },
      "19": {
        "features": [
          "epic_boon_druid"
        ],
        "proficiencyBonus": "+6",
        "preparedSpells": 22,
        "wildShapeUses": 4
      },
      "20": {
        "features": [
          "archdruid"
        ],
        "proficiencyBonus": "+6",
        "preparedSpells": 22,
        "wildShapeUses": 4
      }
    },
    "features": {
      "spellcasting": {
        "name": "Lanzamiento de Conjuros",
        "level": 1,
        "description": "Has aprendido a lanzar conjuros estudiando las fuerzas místicas de la naturaleza. Consulta el capítulo 7 para ver las reglas sobre el lanzamiento de conjuros. La información presentada a continuación detalla cómo usar esas reglas con los conjuros de druida.\n\nTrucos. Conoces dos trucos de tu elección escogidos de entre los de la lista de conjuros de druida. Cada vez que subas un nivel de druida, puedes sustituir uno de tus trucos por otro truco de tu elección de la lista de conjuros de druida. Cuando alcances los niveles 4 y 10 de druida, aprenderás otro truco de tu elección de la lista de conjuros de druida.\n\nEspacios de conjuro. Recuperas todos los espacios utilizados tras finalizar un descanso largo.\n\nConjuros preparados de nivel 1 y superiores. Preparas una serie de conjuros de nivel 1 y superiores, que son los que podrás lanzar con este rasgo. Para empezar, elige cuatro conjuros de nivel 1 de la lista de conjuros de druida.\n\nEl número de conjuros de tu lista aumenta conforme subes de nivel de druida, como se muestra en la columna Conjuros preparados de la tabla de progresión. Cuando ese número aumente, elige conjuros adicionales de la lista de conjuros de druida hasta que el número de conjuros de tu lista coincida con el número de la tabla. Estos conjuros deben ser de un nivel para el que tengas espacios de conjuro.\n\nSi otro rasgo de druida te proporciona conjuros que siempre tienes preparados, esos conjuros no cuentan para el total que puedes preparar con este rasgo, pero sí cuentan como conjuros de druida para ti.\n\nCambiar los conjuros preparados. Tras finalizar un descanso largo, puedes cambiar los conjuros que tienes preparados sustituyendo los que quieras por otros conjuros de druida para los que tengas espacios de conjuro.\n\nAptitud mágica. La Sabiduría es tu aptitud mágica en lo que respecta a tus conjuros de druida.\n\nCanalizador mágico. Puedes utilizar un canalizador druídico como canalizador mágico para tus conjuros de druida."
      },
      "druidic": {
        "name": "Druídico",
        "level": 1,
        "description": "Sabes druídico, el idioma secreto de los druidas. Mientras aprendías esta lengua antigua, accediste a la magia para comunicarte con los animales, por lo que siempre tienes el conjuro Hablar con los animales preparado.\n\nPuedes utilizar el druídico para dejar mensajes ocultos. Tanto tú como cualquiera que conozca este idioma os percataréis de inmediato de la presencia de estos mensajes. Los demás deberán superar una prueba de Inteligencia (Investigación) con CD 15 para detectarlos, pero no podrán descifrarlos sin recurrir a la magia."
      },
      "primal_order": {
        "name": "Orden Primigenia",
        "level": 1,
        "description": "Te has consagrado a una de las siguientes funciones sacras, a tu elección.\n\nGuardián. Te has entrenado para el combate y ganas competencia con armas marciales y entrenamiento con armaduras medias.\n\nNaturalista. Conoces un truco adicional de la lista de conjuros de druida. Además, tu conexión mística con la naturaleza te proporciona un bonificador a tus pruebas de Inteligencia (Arcano y Naturaleza). El bonificador es igual a tu modificador por Sabiduría, con un mínimo de +1."
      },
      "wild_companion": {
        "name": "Compañero Salvaje",
        "level": 2,
        "description": "Puedes invocar un espíritu de la naturaleza que adopta la forma de un animal para ayudarte. Como acción de magia, puedes gastar un espacio de conjuro o un uso de tu rasgo Forma salvaje para lanzar el conjuro Encontrar familiar sin necesidad de componentes materiales.\n\nCuando lances el conjuro de esta forma, el familiar será un feérico y desaparecerá tras finalizar un descanso largo."
      },
      "wild_shape": {
        "name": "Forma Salvaje",
        "level": 2,
        "description": "El poder de la naturaleza te permite transformarte en un animal. Como acción adicional, adoptas la forma de una bestia que hayas aprendido para este rasgo.\n\nConservas esa forma durante una cantidad de horas igual a la mitad de tu nivel de druida o hasta que vuelvas a utilizar Forma salvaje, tengas el estado de incapacitado o mueras. También puedes abandonar la forma antes de tiempo como acción adicional.\n\nNúmero de usos. Puedes utilizar el rasgo Forma salvaje dos veces. Recuperas uno de los usos gastados tras finalizar un descanso corto y todos tras finalizar un descanso largo.\n\nFormas conocidas. Conoces cuatro formas de bestia para este rasgo, escogidas de entre los perfiles de criaturas de tipo bestia que tengan un valor de desafío máximo de 1/4 y que no tengan una velocidad volando. Tras finalizar un descanso largo, podrás reemplazar una de tus formas conocidas por otra que cumpla los requisitos.\n\nCuando alcances determinados niveles de druida, la cantidad de formas conocidas y el valor de desafío máximo de estas formas aumentan. Además, a partir del nivel 8 podrás adoptar una forma que tenga una velocidad volando.\n\nReglas con forma de bestia.\n\nPuntos de golpe temporales. Cuando te transformas usando Forma salvaje, obtienes una cantidad de puntos de golpe temporales igual a tu nivel de druida.\n\nPerfil. Tu perfil se sustituye por el perfil de la bestia, pero conservas tu tipo de criatura, puntos de golpe, dados de puntos de golpe, puntuaciones de Inteligencia, Sabiduría y Carisma, rasgos de clase, idiomas y dotes. También conservas tus competencias en habilidades y tiradas de salvación y utilizas tu bonificador por competencia con ellas, además de obtener las competencias de la criatura. Si el modificador de una habilidad o tirada de salvación del perfil de la bestia es superior al tuyo, usa el de la bestia.\n\nSin lanzamiento de conjuros. No puedes lanzar conjuros, pero cambiar de forma no te hace perder la concentración ni interfiere de ningún otro modo con un conjuro que ya hayas lanzado.\n\nObjetos. Tu capacidad de manejar objetos depende de las extremidades de la bestia cuya forma hayas adoptado. Además, eliges si tu equipo cae en tu espacio, se funde con la nueva forma o lo sigues llevando puesto. El equipo que lleves puesto funcionará con normalidad, pero tu DM determinará si es factible que la nueva forma pueda llevar un objeto de equipo concreto, en función del tamaño y la forma de la criatura. Tu equipo no cambia de forma o tamaño para adaptarse a la nueva forma y cualquier objeto que esta no pueda llevar puesto deberá caer al suelo o fundirse con la nueva forma. El equipo que se funde con la forma no tendrá efecto mientras conserves esa forma."
      },
      "druid_subclass": {
        "name": "Subclase de Druida",
        "level": 3,
        "description": "Consigues una subclase de druida de tu elección. Las subclases del Círculo de la Luna, el Círculo de la Tierra, el Círculo de las Estrellas y el Círculo del Mar se detallan tras la descripción de esta clase. Una subclase es una especialización que te proporciona rasgos cuando alcanzas ciertos niveles de druida. De aquí en adelante, obtienes todos los rasgos de tu subclase que sean de tu nivel de druida e inferiores."
      },
      "ability_score_improvement_druid": {
        "name": "Mejora de Característica",
        "level": 4,
        "description": "Obtienes la dote Mejora de característica u otra dote de tu elección para la que cumplas las condiciones. Vuelves a obtener este rasgo en los niveles 8, 12 y 16 de druida."
      },
      "wild_resurgence": {
        "name": "Resurgimiento Salvaje",
        "level": 5,
        "description": "Una vez en cada uno de tus turnos, si no te quedan usos de Forma salvaje, puedes obtener un uso gastando un espacio de conjuro, sin requerir acción.\n\nAdemás, puedes gastar un uso de tu rasgo Forma salvaje, sin requerir acción, para obtener un espacio de conjuro de nivel 1, pero no podrás volver a hacerlo hasta que finalices un descanso largo."
      },
      "elemental_fury": {
        "name": "Furia Elemental",
        "level": 7,
        "description": "El poder de los elementos fluye por ti. Obtienes una de las siguientes opciones, a tu elección.\n\nGolpe primordial. Una vez en cada uno de tus turnos, cuando aciertes a una criatura con una tirada de ataque usando un arma o un ataque de una bestia en Forma salvaje, podrás hacer que el objetivo sufra 1d8 de daño de frío, fuego, relámpago o trueno adicional. Elige el tipo cuando aciertes.\n\nLanzamiento potente. Sumas tu modificador por Sabiduría al daño que causas con cualquier truco de druida."
      },
      "improved_elemental_fury": {
        "name": "Furia Elemental Mejorada",
        "level": 15,
        "description": "La opción elegida para Furia elemental se vuelve más poderosa.\n\nGolpe primordial. El daño adicional de tu Golpe primordial aumenta a 2d8.\n\nLanzamiento potente. Cuando lances un truco de druida con un alcance de 10 pies o más, el alcance del conjuro aumentará en 300 pies."
      },
      "beast_spellcasting": {
        "name": "Conjurar como Bestia",
        "level": 18,
        "description": "Mientras utilices Forma salvaje, podrás lanzar conjuros en forma de bestia, salvo cualquier conjuro que tenga un componente material que tenga un coste especificado o que se consuma como parte del conjuro."
      },
      "epic_boon_druid": {
        "name": "Don Épico",
        "level": 19,
        "description": "Obtienes una dote de don épico u otra dote de tu elección para la que cumplas las condiciones. Se recomienda Don del viaje dimensional."
      },
      "archdruid": {
        "name": "Archidruida",
        "level": 20,
        "description": "La vitalidad de la naturaleza florece en ti de manera constante, lo que te otorga los siguientes beneficios.\n\nForma salvaje perenne. Cuando tires iniciativa y no te queden usos de Forma salvaje, recuperas uno de los usos gastados.\n\nMago de la naturaleza. Puedes convertir los usos de Forma salvaje en un espacio de conjuro, sin requerir acción. Elige una cantidad de usos no gastados de Forma salvaje para convertirlos en un único espacio de conjuro. Cada uso aporta 2 niveles de conjuro. Por ejemplo, si conviertes dos usos de Forma salvaje, produces un espacio de conjuro de nivel 4. Cuando uses este beneficio, no podrás volver a hacerlo hasta que finalices un descanso largo.\n\nLongevidad. La magia primigenia que dominas ralentiza tu envejecimiento. Por cada diez años que pasen, tu cuerpo envejece solo uno."
      }
    },
    "tables": {
      "wild_shape_forms": {
        "title": "Formas de Bestia",
        "columns": [
          "Nivel",
          "Formas conocidas",
          "VD máxima",
          "Vuelo"
        ],
        "rows": [
          [
            "2",
            "4",
            "1/4",
            "No"
          ],
          [
            "4",
            "6",
            "1/2",
            "No"
          ],
          [
            "8",
            "6",
            "1",
            "Sí"
          ]
        ]
      },
      "spell_progression": {
        "title": "Rasgos de Druida",
        "columns": [
          "Nivel",
          "Bonif. competencia",
          "Rasgos",
          "Forma\nsalvaje",
          "Trucos",
          "Conjuros\npreparados",
          "1",
          "2",
          "3",
          "4",
          "5",
          "6",
          "7",
          "8",
          "9"
        ],
        "rows": [
          [
            "1",
            "+2",
            "Lanzamiento de Conjuros, Druídico, Orden Primigenia",
            "—",
            "2",
            "4",
            "2",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "2",
            "+2",
            "Compañero Salvaje, Forma Salvaje",
            "2",
            "2",
            "5",
            "3",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "3",
            "+2",
            "Subclase de Druida",
            "2",
            "2",
            "6",
            "4",
            "2",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "4",
            "+2",
            "Mejora de Característica",
            "2",
            "3",
            "7",
            "4",
            "3",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "5",
            "+3",
            "Resurgimiento Salvaje",
            "2",
            "3",
            "9",
            "4",
            "3",
            "2",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "6",
            "+3",
            "Rasgo de subclase",
            "3",
            "3",
            "10",
            "4",
            "3",
            "3",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "7",
            "+3",
            "Furia Elemental",
            "3",
            "3",
            "11",
            "4",
            "3",
            "3",
            "1",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "8",
            "+3",
            "Mejora de Característica",
            "3",
            "3",
            "12",
            "4",
            "3",
            "3",
            "2",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "9",
            "+4",
            "—",
            "3",
            "3",
            "14",
            "4",
            "3",
            "3",
            "3",
            "1",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "10",
            "+4",
            "Rasgo de subclase",
            "3",
            "4",
            "15",
            "4",
            "3",
            "3",
            "3",
            "2",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "11",
            "+4",
            "—",
            "3",
            "4",
            "16",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "-",
            "-",
            "-"
          ],
          [
            "12",
            "+4",
            "Mejora de Característica",
            "3",
            "4",
            "16",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "-",
            "-",
            "-"
          ],
          [
            "13",
            "+5",
            "—",
            "3",
            "4",
            "17",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "-",
            "-"
          ],
          [
            "14",
            "+5",
            "Rasgo de subclase",
            "3",
            "4",
            "18",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "-",
            "-"
          ],
          [
            "15",
            "+5",
            "Furia Elemental Mejorada",
            "3",
            "4",
            "19",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "1",
            "-"
          ],
          [
            "16",
            "+5",
            "Mejora de Característica",
            "3",
            "4",
            "19",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "1",
            "-"
          ],
          [
            "17",
            "+6",
            "—",
            "4",
            "4",
            "20",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "1",
            "1"
          ],
          [
            "18",
            "+6",
            "Conjurar como Bestia",
            "4",
            "4",
            "21",
            "4",
            "3",
            "3",
            "3",
            "3",
            "1",
            "1",
            "1",
            "1"
          ],
          [
            "19",
            "+6",
            "Don Épico",
            "4",
            "4",
            "22",
            "4",
            "3",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "1"
          ],
          [
            "20",
            "+6",
            "Archidruida",
            "4",
            "4",
            "22",
            "4",
            "3",
            "3",
            "3",
            "3",
            "2",
            "2",
            "1",
            "1"
          ]
        ]
      }
    },
    "subclasses": {
      "circulo_de_la_luna": {
        "name": "Círculo de la Luna",
        "levels": {
          "3": [
            "moon_circle_spells",
            "circle_forms"
          ],
          "6": [
            "improved_circle_forms"
          ],
          "10": [
            "moonlight_step"
          ],
          "14": [
            "moon_form"
          ]
        },
        "features": {
          "moon_circle_spells": {
            "name": "Conjuros del Círculo de la Luna",
            "level": 3,
            "description": "Cuando alcances un nivel de druida especificado en la tabla Conjuros del Círculo de la Luna, a partir de entonces siempre tendrás preparados los conjuros que se indican.\n\nAdemás, puedes lanzar los conjuros de este rasgo mientras utilizas tu Forma salvaje."
          },
          "circle_forms": {
            "name": "Formas del Círculo",
            "level": 3,
            "description": "Puedes canalizar la magia lunar cuando usas tu Forma salvaje, lo que te proporciona los siguientes beneficios.\n\nValor de desafío. El valor de desafío máximo de la forma es igual a tu nivel de druida dividido entre 3, redondeando hacia abajo.\n\nClase de armadura. Hasta que abandones la forma, tu CA será igual a 110 piesás tu modificador por Sabiduría si ese total es superior a la CA de la bestia.\n\nPuntos de golpe temporales. Obtienes una cantidad de puntos de golpe temporales igual al triple de tu nivel de druida."
          },
          "improved_circle_forms": {
            "name": "Formas del Círculo Mejoradas",
            "level": 6,
            "description": "Mientras utilices tu Forma salvaje, obtienes los siguientes beneficios.\n\nResplandor lunar. Todos los ataques que hagas mientras utilices tu Forma salvaje pueden causar su tipo de daño normal o daño radiante. Tomas esta decisión cada vez que aciertes con esos ataques.\n\nAguante aumentado. Puedes sumar tu modificador por Sabiduría a tus tiradas de salvación de Constitución."
          },
          "moonlight_step": {
            "name": "Paso de la Luz Lunar",
            "level": 10,
            "description": "Te transportas mágicamente y reapareces en medio de un destello de luz lunar. Como acción adicional, te teletransportas hasta 30 pies a un espacio sin ocupar que puedas ver y tienes ventaja en la siguiente tirada de ataque que hagas antes de que finalice este turno.\n\nPuedes usar este rasgo una cantidad de veces igual a tu modificador por Sabiduría, con un mínimo de una vez, y recuperas todos los usos tras finalizar un descanso largo. También puedes recuperar usos gastando un espacio de conjuro de nivel 2 o superior por cada uso que quieras recuperar, sin requerir acción."
          },
          "moon_form": {
            "name": "Forma Lunar",
            "level": 14,
            "description": "El poder de la luna te envuelve y te otorga los siguientes beneficios.\n\nLuz lunar compartida. Siempre que emplees tu Paso de la luz lunar, podrás teletransportar también a una criatura voluntaria. Esa criatura deberá encontrarse a 10 pies o menos de ti y la teletransportarás a un espacio sin ocupar que puedas ver a 10 pies o menos de tu espacio de destino."
          }
        },
        "tables": {
          "moon_circle_spells_table": {
            "title": "Conjuros del Círculo de la Luna",
            "columns": [
              "Nivel de druida",
              "Conjuros preparados"
            ],
            "rows": [
              [
                "3",
                "Curar heridas, Rayo de luna, Voluta estelar"
              ],
              [
                "5",
                "Conjurar animales"
              ],
              [
                "7",
                "Fuente de luz lunar"
              ],
              [
                "9",
                "Curar heridas en masa"
              ]
            ]
          }
        }
      },
      "circulo_de_la_tierra": {
        "name": "Círculo de la Tierra",
        "levels": {
          "3": [
            "land_aid",
            "land_circle_spells"
          ],
          "6": [
            "natural_recovery"
          ],
          "10": [
            "nature_ward"
          ],
          "14": [
            "nature_sanctuary"
          ]
        },
        "features": {
          "land_aid": {
            "name": "Ayuda de la Tierra",
            "level": 3,
            "description": "Como acción de magia, puedes gastar un uso de tu rasgo Forma salvaje y elegir un punto a 60 pies o menos de ti.\n\nUnas flores que otorgan vitalidad y espinas que la absorben aparecen por un instante en una esfera de 10 pies de radio centrada en ese punto. Todas las criaturas de tu elección situadas en la esfera deberán hacer una tirada de salvación de Constitución contra tu CD de salvación de conjuros; sufrirán 2d6 de daño necrótico si la fallan o la mitad del daño si la superan. Además, una criatura de tu elección situada en esa zona recuperará 2d6 puntos de golpe.\n\nEl daño y la curación aumentan en 1d6 cuando alcances los niveles 10 y 14 de druida."
          },
          "land_circle_spells": {
            "name": "Conjuros del Círculo de la Tierra",
            "level": 3,
            "description": "Tras finalizar un descanso largo, elige un tipo de terreno: árido, polar, templado o tropical.\n\nConsulta la tabla que se corresponda con el tipo elegido. Tendrás preparados los conjuros que se mencionan para tu nivel de druida e inferiores.",
            "tables": [
              {
                "title": "Terreno Árido",
                "columns": [
                  "Nivel de druida",
                  "Conjuros de círculo"
                ],
                "rows": [
                  [
                    "3",
                    "Contorno borroso, Descarga de fuego, Manos ardientes"
                  ],
                  [
                    "5",
                    "Bola de fuego"
                  ],
                  [
                    "7",
                    "Marchitar"
                  ],
                  [
                    "9",
                    "Muro de piedra"
                  ]
                ]
              },
              {
                "title": "Terreno Polar",
                "columns": [
                  "Nivel de druida",
                  "Conjuros de círculo"
                ],
                "rows": [
                  [
                    "3",
                    "Inmovilizar persona, Nube de oscurecimiento, Rayo de escarcha"
                  ],
                  [
                    "5",
                    "Tormenta de aguanieve"
                  ],
                  [
                    "7",
                    "Tormenta de hielo"
                  ],
                  [
                    "9",
                    "Cono de frío"
                  ]
                ]
              },
              {
                "title": "Terreno Templado",
                "columns": [
                  "Nivel de druida",
                  "Conjuros de círculo"
                ],
                "rows": [
                  [
                    "3",
                    "Agarre electrizante, Dormir, Paso brumoso"
                  ],
                  [
                    "5",
                    "Relámpago"
                  ],
                  [
                    "7",
                    "Libertad de movimiento"
                  ],
                  [
                    "9",
                    "Paso arbóreo"
                  ]
                ]
              },
              {
                "title": "Terreno Tropical",
                "columns": [
                  "Nivel de druida",
                  "Conjuros de círculo"
                ],
                "rows": [
                  [
                    "3",
                    "Rayo nauseabundo, Salpicadura ácida, Telaraña"
                  ],
                  [
                    "5",
                    "Nube apestosa"
                  ],
                  [
                    "7",
                    "Polimorfar"
                  ],
                  [
                    "9",
                    "Plaga de insectos"
                  ]
                ]
              }
            ]
          },
          "natural_recovery": {
            "name": "Recuperación Natural",
            "level": 6,
            "description": "Puedes lanzar un conjuro de nivel 1 o superior que tengas preparado por el rasgo Conjuros de círculo sin gastar un espacio de conjuro. Deberás finalizar un descanso largo antes de volver a hacerlo.\n\nAdemás, tras finalizar un descanso corto, puedes elegir espacios de conjuro gastados y recuperarlos. La suma de niveles de estos espacios de conjuro debe ser igual o inferior a la mitad de tu nivel de druida, redondeando hacia arriba, y ninguno de los espacios puede ser de nivel 6 o más. Cuando recuperes espacios de conjuro con este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo."
          },
          "nature_ward": {
            "name": "Protección de la Naturaleza",
            "level": 10,
            "description": "Eres inmune al estado de envenenado y tienes resistencia a un tipo de daño asociado con tu elección de terreno actual del rasgo Conjuros de círculo, como se muestra en la tabla Protección de la Naturaleza."
          },
          "nature_sanctuary": {
            "name": "Santuario de la Naturaleza",
            "level": 14,
            "description": "Como acción de magia, puedes gastar un uso de tu rasgo Forma salvaje y hacer que aparezcan árboles y enredaderas espectrales en un cubo de 15 pies de lado sobre el suelo a 120 pies o menos de ti. Permanecerán ahí durante 1 minuto o hasta que tengas el estado de incapacitado o mueras.\n\nTus aliados y tú tendréis cobertura media mientras estéis en esa zona y tus aliados obtendrán la resistencia actual de tu Protección de la naturaleza mientras estén ahí.\n\nComo acción adicional, puedes mover el cubo hasta 60 pies a una parte del suelo que esté a 120 pies o menos de ti."
          }
        },
        "tables": {
          "arid_land_spells": {
            "title": "Terreno Árido",
            "columns": [
              "Nivel de druida",
              "Conjuros de círculo"
            ],
            "rows": [
              [
                "3",
                "Contorno borroso, Descarga de fuego, Manos ardientes"
              ],
              [
                "5",
                "Bola de fuego"
              ],
              [
                "7",
                "Marchitar"
              ],
              [
                "9",
                "Muro de piedra"
              ]
            ]
          },
          "polar_land_spells": {
            "title": "Terreno Polar",
            "columns": [
              "Nivel de druida",
              "Conjuros de círculo"
            ],
            "rows": [
              [
                "3",
                "Inmovilizar persona, Nube de oscurecimiento, Rayo de escarcha"
              ],
              [
                "5",
                "Tormenta de aguanieve"
              ],
              [
                "7",
                "Tormenta de hielo"
              ],
              [
                "9",
                "Cono de frío"
              ]
            ]
          },
          "temperate_land_spells": {
            "title": "Terreno Templado",
            "columns": [
              "Nivel de druida",
              "Conjuros de círculo"
            ],
            "rows": [
              [
                "3",
                "Agarre electrizante, Dormir, Paso brumoso"
              ],
              [
                "5",
                "Relámpago"
              ],
              [
                "7",
                "Libertad de movimiento"
              ],
              [
                "9",
                "Paso arbóreo"
              ]
            ]
          },
          "tropical_land_spells": {
            "title": "Terreno Tropical",
            "columns": [
              "Nivel de druida",
              "Conjuros de círculo"
            ],
            "rows": [
              [
                "3",
                "Rayo nauseabundo, Salpicadura ácida, Telaraña"
              ],
              [
                "5",
                "Nube apestosa"
              ],
              [
                "7",
                "Polimorfar"
              ],
              [
                "9",
                "Plaga de insectos"
              ]
            ]
          },
          "nature_ward_table": {
            "title": "Protección de la Naturaleza",
            "columns": [
              "Tipo de terreno",
              "Resistencia"
            ],
            "rows": [
              [
                "Árido",
                "Fuego"
              ],
              [
                "Polar",
                "Frío"
              ],
              [
                "Templado",
                "Relámpago"
              ],
              [
                "Tropical",
                "Veneno"
              ]
            ]
          }
        }
      },
      "circulo_de_las_estrellas": {
        "name": "Círculo de las Estrellas",
        "levels": {
          "3": [
            "starry_form",
            "star_map"
          ],
          "6": [
            "cosmic_omen"
          ],
          "10": [
            "twinkling_constellations"
          ],
          "14": [
            "full_of_starlight"
          ]
        },
        "features": {
          "starry_form": {
            "name": "Forma Estelar",
            "level": 3,
            "description": "Como acción adicional, puedes gastar un uso de tu rasgo Forma salvaje para adoptar una forma estelar en lugar de transformarte en una bestia.\n\nMientras estés en tu forma estelar, sigues teniendo el mismo perfil, pero tu cuerpo se vuelve luminoso: tus articulaciones resplandecen como estrellas y están conectadas por líneas brillantes, como en un mapa estelar.\n\nEsta forma emite luz brillante en un radio de 10 pies y luz tenue 10 pies más allá. La forma dura 10 minutos y termina antes de tiempo si la cancelas, si tienes el estado de incapacitado, si mueres o si vuelves a usar este rasgo.\n\nSiempre que adoptes tu forma estelar, elige cuál de las siguientes constelaciones brillará en tu cuerpo.\n\nArquero. En tu cuerpo aparece una constelación con forma de arquero. Cuando activas esta forma y como acción adicional en tus turnos siguientes mientras dure, puedes realizar un ataque de conjuro a distancia con el que lanzas una flecha luminosa a una criatura a 60 pies o menos de ti. Si acierta, el ataque causará 1d8 más tu modificador por Sabiduría de daño radiante.\n\nCáliz. En tu cuerpo aparece una constelación con forma de cáliz de vida. Siempre que gastes un espacio de conjuro para lanzar un conjuro que haga recuperar puntos de golpe a una criatura, tú u otra criatura a 30 pies o menos de ti podréis recuperar una cantidad de puntos de golpe igual a 1d8 más tu modificador por Sabiduría.\n\nDragón. En tu cuerpo aparece una constelación con forma de un sabio dragón. Cuando hagas una prueba de Inteligencia o Sabiduría o una tirada de salvación de Constitución para mantener la concentración, podrás sustituir un resultado de 9 o menos en el d20 por un 10."
          },
          "star_map": {
            "name": "Mapa Estelar",
            "level": 3,
            "description": "Has creado un mapa estelar como parte de tus estudios del firmamento. Es un objeto Diminuto y puedes utilizarlo como canalizador mágico para tus conjuros de druida.\n\nEscoge su forma de entre las opciones de la tabla Mapa Estelar o tira un dado para decidirlo.\n\nMientras sostienes el mapa, tienes los conjuros Guía y Saeta guía preparados, y puedes lanzar Saeta guía sin gastar un espacio de conjuro. Puedes lanzarlo de esa forma una cantidad de veces igual a tu modificador por Sabiduría, con un mínimo de una vez, y recuperas todos los usos tras finalizar un descanso largo.\n\nSi pierdes el mapa, puedes realizar una ceremonia de 1 hora para crear un sustituto mágicamente. Esta ceremonia se puede llevar a cabo durante un descanso corto o largo y destruye el mapa anterior."
          },
          "cosmic_omen": {
            "name": "Presagio Cósmico",
            "level": 6,
            "description": "Tras finalizar un descanso largo, puedes consultar tu mapa estelar para tener un presagio y tirar un dado.\n\nHasta que finalices tu próximo descanso largo, dispondrás de una reacción especial que dependerá de si sacaste un número par o impar en la tirada.\n\nDesdicha (impar). Cuando una criatura que puedas ver a 30 pies o menos de ti vaya a hacer una prueba con d20, puedes usar tu reacción para tirar 1d6 y restar el resultado al total.\n\nFortuna (par). Cuando una criatura que puedas ver a 30 pies o menos de ti vaya a hacer una prueba con d20, puedes usar tu reacción para tirar 1d6 y sumar el resultado al total.\n\nPuedes usar esta reacción una cantidad de veces igual a tu modificador por Sabiduría, con un mínimo de una vez, y recuperas todos los usos tras finalizar un descanso largo."
          },
          "twinkling_constellations": {
            "name": "Constelaciones Centelleantes",
            "level": 10,
            "description": "Las constelaciones de tu rasgo Forma estelar mejoran.\n\nEl 1d8 del Arquero y el Cáliz se convierte en 2d8 y, mientras el Dragón está activo, tienes una velocidad volando de 20 pies y puedes levitar.\n\nAdemás, al principio de cada uno de tus turnos, mientras estés en tu forma estelar, podrás cambiar la constelación que brilla en tu cuerpo."
          },
          "full_of_starlight": {
            "name": "Colmado de Luz Estelar",
            "level": 14,
            "description": "Mientras estés en tu forma estelar, te vuelves parcialmente incorpóreo, lo que te da resistencia al daño contundente, cortante y perforante."
          }
        },
        "tables": {
          "star_map_table": {
            "title": "Mapa Estelar",
            "columns": [
              "1d6",
              "Forma del mapa"
            ],
            "rows": [
              [
                "1",
                "Un pergamino donde están representadas las constelaciones"
              ],
              [
                "2",
                "Una tablilla de piedra perforada con pequeños agujeros"
              ],
              [
                "3",
                "La piel de un oso lechuza en la que hay símbolos estelares grabados"
              ],
              [
                "4",
                "Un conjunto de mapas encuadernados con una cubierta de ébano"
              ],
              [
                "5",
                "Un cristal decorado con patrones de estrellas"
              ],
              [
                "6",
                "Un disco de cristal con grabados de constelaciones"
              ]
            ]
          }
        }
      },
      "circulo_del_mar": {
        "name": "Círculo del Mar",
        "levels": {
          "3": [
            "sea_circle_spells",
            "wrath_of_the_sea"
          ],
          "6": [
            "aquatic_affinity"
          ],
          "10": [
            "stormborn"
          ],
          "14": [
            "oceanic_gift"
          ]
        },
        "features": {
          "sea_circle_spells": {
            "name": "Conjuros del Círculo del Mar",
            "level": 3,
            "description": "Cuando alcances un nivel de druida especificado en la tabla Conjuros del Círculo del Mar, a partir de entonces siempre tendrás preparados los conjuros que se indican."
          },
          "wrath_of_the_sea": {
            "name": "Ira de los Mares",
            "level": 3,
            "description": "Como acción adicional, puedes gastar un uso de tu rasgo Forma salvaje para generar una emanación de 5 pies que adopta la forma de la espuma de mar y te rodea durante 10 minutos. Terminará antes de tiempo si la disipas, si la generas de nuevo o si tienes el estado de incapacitado.\n\nCuando generas la emanación y como acción adicional en tus siguientes turnos, puedes elegir a otra criatura que puedas ver en la emanación. El objetivo deberá superar una tirada de salvación de Constitución contra tu CD de salvación de conjuros o sufrirá daño de frío y, si la criatura es Grande o más pequeña, será empujada hasta 15 pies respecto a ti. Para determinar este daño, tira una cantidad de d6 igual a tu modificador por Sabiduría, con un mínimo de un dado."
          },
          "aquatic_affinity": {
            "name": "Afinidad Acuática",
            "level": 6,
            "description": "El tamaño de la emanación creada con tu Ira de los Mares aumenta a 10 pies.\n\nAdemás, obtienes una velocidad nadando igual a tu velocidad."
          },
          "stormborn": {
            "name": "Nacido de la Tempestad",
            "level": 10,
            "description": "Tu rasgo Ira de los Mares otorga dos beneficios más mientras está activo.\n\nResistencia. Tienes resistencia al daño de frío, relámpago y trueno.\n\nVuelo. Obtienes una velocidad volando igual a tu velocidad."
          },
          "oceanic_gift": {
            "name": "Obsequio Oceánico",
            "level": 14,
            "description": "En vez de generar la emanación del rasgo Ira de los Mares alrededor de ti, puedes generarla alrededor de una criatura voluntaria que esté a 60 pies o menos de ti. Esa criatura obtiene todos los beneficios de la emanación y utiliza tu CD de salvación de conjuros y tu modificador por Sabiduría para ella.\n\nAdemás, puedes generar la emanación alrededor de ti y de la otra criatura si gastas dos usos de Forma salvaje en vez de uno al manifestarla."
          }
        },
        "tables": {
          "sea_circle_spells_table": {
            "title": "Conjuros del Círculo del Mar",
            "columns": [
              "Nivel de druida",
              "Conjuros preparados"
            ],
            "rows": [
              [
                "3",
                "Hacer añicos, Nube de oscurecimiento, Ola atronadora, Ráfaga de viento, Rayo de escarcha"
              ],
              [
                "5",
                "Relámpago, Respirar bajo el agua"
              ],
              [
                "7",
                "Controlar agua, Tormenta de hielo"
              ],
              [
                "9",
                "Conjurar elemental, Inmovilizar monstruo"
              ]
            ]
          }
        }
      }
    }
  },
  "explorador": {
    "id": "explorador",
    "name": "Explorador",
    "primaryAbility": [
      "Destreza",
      "Sabiduría"
    ],
    "hitDie": "1d10",
    "savingThrows": [
      "Fuerza",
      "Destreza"
    ],
    "skillChoices": {
      "choose": 3,
      "from": [
        "Atletismo",
        "Investigación",
        "Naturaleza",
        "Percepción",
        "Perspicacia",
        "Sigilo",
        "Supervivencia",
        "Trato con Animales"
      ]
    },
    "weaponProficiencies": [
      "Armas sencillas",
      "Armas marciales"
    ],
    "armorTraining": [
      "Armaduras ligeras",
      "Armaduras medias",
      "Escudos"
    ],
    "startingEquipment": {
      "options": [
        {
          "label": "A",
          "items": [
            "Armadura de cuero tachonado",
            "Cimitarra",
            "Espada corta",
            "Arco largo",
            "20 flechas",
            "Aljaba",
            "Canalizador druídico (rama de muérdago)",
            "Paquete de explorador",
            "7 po"
          ]
        },
        {
          "label": "B",
          "items": [
            "150 po"
          ]
        }
      ]
    },
    "levels": {
      "1": {
        "features": [
          "spellcasting",
          "favored_enemy",
          "weapon_mastery"
        ],
        "proficiencyBonus": "+2",
        "preparedSpells": 2,
        "favoredEnemyUses": 2
      },
      "2": {
        "features": [
          "fighting_style",
          "deft_explorer"
        ],
        "proficiencyBonus": "+2",
        "preparedSpells": 3,
        "favoredEnemyUses": 2
      },
      "3": {
        "features": [
          "ranger_subclass"
        ],
        "proficiencyBonus": "+2",
        "preparedSpells": 4,
        "favoredEnemyUses": 2
      },
      "4": {
        "features": [
          "ability_score_improvement_ranger"
        ],
        "proficiencyBonus": "+2",
        "preparedSpells": 5,
        "favoredEnemyUses": 2
      },
      "5": {
        "features": [
          "extra_attack"
        ],
        "proficiencyBonus": "+3",
        "preparedSpells": 6,
        "favoredEnemyUses": 3
      },
      "6": {
        "features": [
          "roving"
        ],
        "proficiencyBonus": "+3",
        "preparedSpells": 6,
        "favoredEnemyUses": 3
      },
      "7": {
        "proficiencyBonus": "+3",
        "preparedSpells": 7,
        "favoredEnemyUses": 3
      },
      "8": {
        "features": [
          "ability_score_improvement_ranger"
        ],
        "proficiencyBonus": "+3",
        "preparedSpells": 7,
        "favoredEnemyUses": 3
      },
      "9": {
        "features": [
          "expertise_ranger"
        ],
        "proficiencyBonus": "+4",
        "preparedSpells": 9,
        "favoredEnemyUses": 4
      },
      "10": {
        "features": [
          "tireless"
        ],
        "proficiencyBonus": "+4",
        "preparedSpells": 9,
        "favoredEnemyUses": 4
      },
      "11": {
        "proficiencyBonus": "+4",
        "preparedSpells": 10,
        "favoredEnemyUses": 4
      },
      "12": {
        "features": [
          "ability_score_improvement_ranger"
        ],
        "proficiencyBonus": "+4",
        "preparedSpells": 10,
        "favoredEnemyUses": 4
      },
      "13": {
        "features": [
          "relentless_hunter"
        ],
        "proficiencyBonus": "+5",
        "preparedSpells": 11,
        "favoredEnemyUses": 5
      },
      "14": {
        "features": [
          "natures_veil"
        ],
        "proficiencyBonus": "+5",
        "preparedSpells": 11,
        "favoredEnemyUses": 5
      },
      "15": {
        "proficiencyBonus": "+5",
        "preparedSpells": 12,
        "favoredEnemyUses": 5
      },
      "16": {
        "features": [
          "ability_score_improvement_ranger"
        ],
        "proficiencyBonus": "+5",
        "preparedSpells": 12,
        "favoredEnemyUses": 5
      },
      "17": {
        "features": [
          "precise_hunter"
        ],
        "proficiencyBonus": "+6",
        "preparedSpells": 14,
        "favoredEnemyUses": 6
      },
      "18": {
        "features": [
          "feral_senses"
        ],
        "proficiencyBonus": "+6",
        "preparedSpells": 14,
        "favoredEnemyUses": 6
      },
      "19": {
        "features": [
          "epic_boon_ranger"
        ],
        "proficiencyBonus": "+6",
        "preparedSpells": 15,
        "favoredEnemyUses": 6
      },
      "20": {
        "features": [
          "foe_slayer"
        ],
        "proficiencyBonus": "+6",
        "preparedSpells": 15,
        "favoredEnemyUses": 6
      }
    },
    "features": {
      "spellcasting": {
        "name": "Lanzamiento de Conjuros",
        "level": 1,
        "description": "Has aprendido a canalizar la esencia mágica de la naturaleza para lanzar conjuros. Consulta el capítulo 7 para ver las reglas sobre el lanzamiento de conjuros. La información presentada a continuación detalla cómo usar esas reglas con los conjuros de explorador.\n\nEspacios de conjuro. Recuperas todos los espacios utilizados tras finalizar un descanso largo.\n\nConjuros preparados de nivel 1 y superiores. Preparas una serie de conjuros de nivel 1 y superiores, que son los que podrás lanzar con este rasgo. Para empezar, elige dos conjuros de explorador de nivel 1.\n\nEl número de conjuros de tu lista aumenta conforme subes de nivel de explorador, como se muestra en la columna Conjuros preparados de la tabla de progresión. Cuando ese número aumente, elige conjuros adicionales de la lista de conjuros de explorador hasta que el número de conjuros de tu lista coincida con el número de la tabla. Estos conjuros deben ser de un nivel para el que tengas espacios de conjuro.\n\nCambiar los conjuros preparados. Tras finalizar un descanso largo, puedes cambiar los conjuros que tienes preparados sustituyendo los que quieras por otros conjuros de explorador para los que tengas espacios de conjuro.\n\nAptitud mágica. La Sabiduría es tu aptitud mágica en lo que respecta a tus conjuros de explorador.\n\nCanalizador mágico. Puedes utilizar un canalizador druídico como canalizador mágico para tus conjuros de explorador."
      },
      "favored_enemy": {
        "name": "Enemigo Predilecto",
        "level": 1,
        "description": "Siempre tienes el conjuro Marca del cazador preparado.\n\nPuedes lanzarlo dos veces sin gastar un espacio de conjuro y recuperas todos los usos de esta capacidad tras finalizar un descanso largo.\n\nLa cantidad de veces que puedes lanzar el conjuro sin gastar un espacio aumenta según alcanzas ciertos niveles de explorador, como se muestra en la columna Enemigo predilecto de la tabla de progresión."
      },
      "weapon_mastery": {
        "name": "Maestría con Armas",
        "level": 1,
        "description": "Tu entrenamiento con armas te permite utilizar las propiedades de maestría con dos tipos de armas de tu elección con las que tengas competencia.\n\nTras finalizar un descanso largo, puedes cambiar los tipos de armas elegidas."
      },
      "fighting_style": {
        "name": "Estilo de Combate",
        "level": 2,
        "description": "Obtienes una dote de estilo de combate de tu elección.\n\nEn lugar de elegir una de esas dotes, puedes elegir Guerrero druídico. Aprendes dos trucos de druida de tu elección. Los trucos elegidos cuentan como conjuros de explorador para ti y la Sabiduría es tu aptitud mágica para lanzarlos. Cada vez que subas un nivel de explorador, puedes sustituir uno de estos trucos por otro truco de druida."
      },
      "deft_explorer": {
        "name": "Explorador Hábil",
        "level": 2,
        "description": "Tus viajes te proporcionan los siguientes beneficios.\n\nIdiomas. Conoces dos idiomas de tu elección de las tablas de idiomas del capítulo 2.\n\nPericia. Escoge una de tus competencias en habilidades con las que no tengas pericia. Ganas pericia en esa habilidad."
      },
      "ranger_subclass": {
        "name": "Subclase de Explorador",
        "level": 3,
        "description": "Consigues una subclase de explorador de tu elección. Las subclases de Acechador en la Penumbra, Cazador, Errante Feérico y Señor de las Bestias se detallan tras la descripción de esta clase. Una subclase es una especialización que te proporciona rasgos cuando alcanzas ciertos niveles de explorador. De aquí en adelante, obtienes todos los rasgos de tu subclase que sean de tu nivel de explorador e inferiores."
      },
      "ability_score_improvement_ranger": {
        "name": "Mejora de Característica",
        "level": 4,
        "description": "Obtienes la dote Mejora de característica u otra dote de tu elección para la que cumplas las condiciones.\n\nVuelves a obtener este rasgo en los niveles 8, 12 y 16 de explorador."
      },
      "extra_attack": {
        "name": "Ataque Adicional",
        "level": 5,
        "description": "Cuando lleves a cabo la acción de atacar en tu turno, podrás hacer dos ataques en lugar de uno."
      },
      "roving": {
        "name": "Errante",
        "level": 6,
        "description": "Tu velocidad aumenta en 10 pies si no llevas armadura pesada.\n\nTambién tienes una velocidad nadando y una velocidad trepando iguales a tu velocidad."
      },
      "expertise_ranger": {
        "name": "Pericia",
        "level": 9,
        "description": "Escoge dos de tus competencias en habilidades con las que no tengas pericia. Ganas pericia en esas habilidades."
      },
      "tireless": {
        "name": "Infatigable",
        "level": 10,
        "description": "Las fuerzas primigenias te ayudan ahora en tus viajes, lo que te otorga los siguientes beneficios.\n\nPuntos de golpe temporales. Como acción de magia, puedes concederte una cantidad de puntos de golpe temporales igual a 1d8 más tu modificador por Sabiduría, con un mínimo de 1. Puedes usar esta acción una cantidad de veces igual a tu modificador por Sabiduría, con un mínimo de una vez, y recuperas todos los usos tras finalizar un descanso largo.\n\nDisminuir cansancio. Tras finalizar un descanso corto, tu nivel de cansancio, si lo tienes, se reduce en 1."
      },
      "relentless_hunter": {
        "name": "Cazador Persistente",
        "level": 13,
        "description": "Sufrir daño no rompe tu concentración de Marca del cazador."
      },
      "natures_veil": {
        "name": "Velo de la Naturaleza",
        "level": 14,
        "description": "Invocas espíritus de la naturaleza para esconderte mágicamente. Como acción adicional, puedes otorgarte el estado de invisible hasta el final de tu siguiente turno.\n\nPuedes usar este rasgo una cantidad de veces igual a tu modificador por Sabiduría, con un mínimo de una vez, y recuperas todos los usos tras finalizar un descanso largo."
      },
      "precise_hunter": {
        "name": "Cazador Preciso",
        "level": 17,
        "description": "Tienes ventaja en las tiradas de ataque contra la criatura que tenga tu Marca del cazador sobre ella."
      },
      "feral_senses": {
        "name": "Sentidos Salvajes",
        "level": 18,
        "description": "Tu conexión con las fuerzas de la naturaleza te otorga visión ciega hasta 30 pies."
      },
      "epic_boon_ranger": {
        "name": "Don Épico",
        "level": 19,
        "description": "Obtienes una dote de don épico u otra dote de tu elección para la que cumplas las condiciones. Se recomienda Don del viaje dimensional."
      },
      "foe_slayer": {
        "name": "Azote de Enemigos",
        "level": 20,
        "description": "El dado de daño de tu Marca del cazador es un d10 en lugar de un d6."
      }
    },
    "tables": {
      "ranger_progression": {
        "title": "Rasgos de Explorador",
        "columns": [
          "Nivel",
          "Bonif. competencia",
          "Rasgos",
          "Enemigo\npredilecto",
          "Conjuros\npreparados",
          "1",
          "2",
          "3",
          "4",
          "5"
        ],
        "rows": [
          [
            "1",
            "+2",
            "Lanzamiento de Conjuros, Enemigo Predilecto, Maestría con Armas",
            "2",
            "2",
            "2",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "2",
            "+2",
            "Estilo de Combate, Explorador Hábil",
            "2",
            "3",
            "2",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "3",
            "+2",
            "Subclase de Explorador",
            "2",
            "4",
            "3",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "4",
            "+2",
            "Mejora de Característica",
            "2",
            "5",
            "3",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "5",
            "+3",
            "Ataque Adicional",
            "3",
            "6",
            "4",
            "2",
            "-",
            "-",
            "-"
          ],
          [
            "6",
            "+3",
            "Errante",
            "3",
            "6",
            "4",
            "2",
            "-",
            "-",
            "-"
          ],
          [
            "7",
            "+3",
            "Rasgo de subclase",
            "3",
            "7",
            "4",
            "3",
            "-",
            "-",
            "-"
          ],
          [
            "8",
            "+3",
            "Mejora de Característica",
            "3",
            "7",
            "4",
            "3",
            "-",
            "-",
            "-"
          ],
          [
            "9",
            "+4",
            "Pericia",
            "4",
            "9",
            "4",
            "3",
            "2",
            "-",
            "-"
          ],
          [
            "10",
            "+4",
            "Infatigable",
            "4",
            "9",
            "4",
            "3",
            "2",
            "-",
            "-"
          ],
          [
            "11",
            "+4",
            "Rasgo de subclase",
            "4",
            "10",
            "4",
            "3",
            "3",
            "-",
            "-"
          ],
          [
            "12",
            "+4",
            "Mejora de Característica",
            "4",
            "10",
            "4",
            "3",
            "3",
            "-",
            "-"
          ],
          [
            "13",
            "+5",
            "Cazador Persistente",
            "5",
            "11",
            "4",
            "3",
            "3",
            "1",
            "-"
          ],
          [
            "14",
            "+5",
            "Velo de la Naturaleza",
            "5",
            "11",
            "4",
            "3",
            "3",
            "1",
            "-"
          ],
          [
            "15",
            "+5",
            "Rasgo de subclase",
            "5",
            "12",
            "4",
            "3",
            "3",
            "2",
            "-"
          ],
          [
            "16",
            "+5",
            "Mejora de Característica",
            "5",
            "12",
            "4",
            "3",
            "3",
            "2",
            "-"
          ],
          [
            "17",
            "+6",
            "Cazador Preciso",
            "6",
            "14",
            "4",
            "3",
            "3",
            "3",
            "1"
          ],
          [
            "18",
            "+6",
            "Sentidos Salvajes",
            "6",
            "14",
            "4",
            "3",
            "3",
            "3",
            "1"
          ],
          [
            "19",
            "+6",
            "Don Épico",
            "6",
            "15",
            "4",
            "3",
            "3",
            "3",
            "2"
          ],
          [
            "20",
            "+6",
            "Azote de Enemigos",
            "6",
            "15",
            "4",
            "3",
            "3",
            "3",
            "2"
          ]
        ]
      }
    },
    "subclasses": {
      "gloom_stalker": {
        "name": "Acechador en la Penumbra",
        "levels": {
          "3": [
            "gloom_stalker_spells",
            "dread_ambusher",
            "umbral_sight"
          ],
          "7": [
            "iron_mind"
          ],
          "11": [
            "stalkers_flurry"
          ],
          "15": [
            "shadowy_dodge"
          ]
        },
        "features": {
          "gloom_stalker_spells": {
            "name": "Conjuros de Acechador en la Penumbra",
            "level": 3,
            "description": "Cuando alcances un nivel de explorador especificado en la tabla Conjuros de Acechador en la Penumbra, a partir de entonces siempre tendrás preparados los conjuros que se indican."
          },
          "dread_ambusher": {
            "name": "Emboscador Pavoroso",
            "level": 3,
            "description": "Dominas el arte de tender emboscadas temibles, lo que te otorga los siguientes beneficios.\n\nBonificador de iniciativa. Cuando tires iniciativa, puedes sumar tu modificador por Sabiduría a la tirada.\n\nGolpe pavoroso. Cuando ataques a una criatura con un arma y aciertes, puedes infligirle 2d6 de daño psíquico adicional. Puedes usar este beneficio solo una vez por turno, puedes usarlo una cantidad de veces igual a tu modificador por Sabiduría, con un mínimo de una vez, y recuperas todos los usos tras finalizar un descanso largo.\n\nSalto emboscador. Al comienzo de tu primer turno de cada combate, tu velocidad aumenta en 10 pies hasta el final de ese turno."
          },
          "umbral_sight": {
            "name": "Visión en la Umbra",
            "level": 3,
            "description": "Obtienes visión en la oscuridad hasta 60 pies. Si ya posees visión en la oscuridad cuando obtienes este rasgo, su alcance aumenta en 60 pies.\n\nAdemás, eres muy hábil evitando a criaturas que dependan de la visión en la oscuridad. Mientras estés en una oscuridad total, tendrás el estado de invisible frente a cualquier criatura que dependa de visión en la oscuridad para verte en esas tinieblas."
          },
          "iron_mind": {
            "name": "Mente de Hierro",
            "level": 7,
            "description": "Has mejorado tu habilidad para resistir los poderes que alteran la mente. Ganas competencia en las tiradas de salvación de Sabiduría. Si ya tienes esta competencia, obtienes competencia en las tiradas de salvación de Inteligencia o Carisma, a tu elección."
          },
          "stalkers_flurry": {
            "name": "Oleada del Acechador",
            "level": 11,
            "description": "El daño psíquico de tu Golpe pavoroso pasa a ser 2d8.\n\nAdemás, cuando utilizas el efecto de Golpe pavoroso del rasgo Emboscador pavoroso, puedes provocar uno de los siguientes efectos adicionales.\n\nAtaque súbito. Puedes realizar otro ataque con la misma arma contra una criatura distinta que se encuentre a 5 pies o menos del objetivo original y que esté dentro del alcance del arma.\n\nTerror masivo. El objetivo y todas las criaturas a 10 pies o menos de él deberán hacer una tirada de salvación de Sabiduría contra tu CD de salvación de conjuros. Si una criatura la falla, tendrá el estado de asustada hasta el principio de tu siguiente turno."
          },
          "shadowy_dodge": {
            "name": "Esquiva de las Sombras",
            "level": 15,
            "description": "Cuando una criatura haga una tirada de ataque contra ti, puedes usar una reacción para darle desventaja en la tirada. Tanto si el ataque acierta como si no, luego podrás teletransportarte hasta 30 pies a un espacio sin ocupar que puedas ver."
          }
        },
        "tables": {
          "gloom_stalker_spells_table": {
            "title": "Conjuros de Acechador en la Penumbra",
            "columns": [
              "Nivel de explorador",
              "Conjuros"
            ],
            "rows": [
              [
                "3",
                "Disfrazarse"
              ],
              [
                "5",
                "Truco de la cuerda"
              ],
              [
                "9",
                "Terror"
              ],
              [
                "13",
                "Invisibilidad mejorada"
              ],
              [
                "17",
                "Apariencia"
              ]
            ]
          }
        }
      },
      "hunter": {
        "name": "Cazador",
        "levels": {
          "3": [
            "hunter_prey",
            "hunter_lore"
          ],
          "7": [
            "defensive_tactics"
          ],
          "11": [
            "superior_hunters_prey"
          ],
          "15": [
            "superior_hunters_defense"
          ]
        },
        "features": {
          "hunter_prey": {
            "name": "El Cazador y la Presa",
            "level": 3,
            "description": "Obtienes una de las siguientes opciones de este rasgo, a tu elección. Tras finalizar un descanso corto o largo, puedes cambiar la opción elegida por la otra.\n\nAzote de colosos. Tu tenacidad puede agotar incluso a los enemigos más resistentes. Cuando aciertes a una criatura con un arma, esta inflige 1d8 de daño adicional si el objetivo no tiene todos sus puntos de golpe. Solo puedes infligir este daño adicional una vez por turno.\n\nDestructor de hordas. Una vez en cada uno de tus turnos, cuando hagas un ataque con un arma, puedes realizar otro con la misma arma contra una criatura distinta que se encuentre a 5 pies o menos del objetivo original si no la has atacado este turno y está dentro del alcance del arma."
          },
          "hunter_lore": {
            "name": "Sabiduría del Cazador",
            "level": 3,
            "description": "Puedes invocar a las fuerzas de la naturaleza para mostrar ciertos puntos fuertes y débiles de tu presa. Mientras una criatura tenga tu Marca del cazador sobre ella, sabrás si tiene alguna inmunidad, resistencia o vulnerabilidad y cuáles son, de ser así."
          },
          "defensive_tactics": {
            "name": "Tácticas Defensivas",
            "level": 7,
            "description": "Obtienes una de las siguientes opciones de este rasgo, a tu elección. Tras finalizar un descanso corto o largo, puedes cambiar la opción elegida por la otra.\n\nDefensa contra ataques múltiples. Cuando una criatura te acierte con una tirada de ataque, esa criatura tendrá desventaja en todas las demás tiradas de ataque contra ti este turno.\n\nEscapar de la horda. Los ataques de oportunidad tienen desventaja contra ti."
          },
          "superior_hunters_prey": {
            "name": "El Cazador Experto y la Presa",
            "level": 11,
            "description": "Una vez por turno, cuando inflijas daño a una criatura que tenga tu Marca del cazador, también puedes hacer el daño adicional del conjuro a una criatura distinta que puedas ver a 30 pies o menos de la primera criatura."
          },
          "superior_hunters_defense": {
            "name": "Defensa de Cazador Experto",
            "level": 15,
            "description": "Cuando recibes daño, puedes usar una reacción para concederte resistencia a ese daño y a cualquier otro daño del mismo tipo hasta el final de ese turno."
          }
        }
      },
      "fey_wanderer": {
        "name": "Errante Feérico",
        "levels": {
          "3": [
            "fey_wanderer_spells",
            "otherworldly_glamour",
            "dreadful_strikes"
          ],
          "7": [
            "beguiling_twist"
          ],
          "11": [
            "fey_reinforcements"
          ],
          "15": [
            "misty_wanderer"
          ]
        },
        "features": {
          "fey_wanderer_spells": {
            "name": "Conjuros de Errante Feérico",
            "level": 3,
            "description": "Cuando alcances un nivel de explorador especificado en la tabla Conjuros de Errante Feérico, a partir de entonces siempre tendrás preparados los conjuros que se indican.\n\nTambién cuentas con una bendición feérica. Elígela de la tabla Dádivas de los Parajes Feéricos o determínala al azar.",
            "tables": [
              {
                "title": "Conjuros de Errante Feérico",
                "columns": [
                  "Nivel de explorador",
                  "Conjuro"
                ],
                "rows": [
                  [
                    "3",
                    "Hechizar persona"
                  ],
                  [
                    "5",
                    "Paso brumoso"
                  ],
                  [
                    "9",
                    "Invocar feérico"
                  ],
                  [
                    "13",
                    "Puerta dimensional"
                  ],
                  [
                    "17",
                    "Engañar"
                  ]
                ]
              },
              {
                "title": "Dádivas de los Parajes Feéricos",
                "columns": [
                  "1d6",
                  "Dádiva"
                ],
                "rows": [
                  [
                    "1",
                    "Unas mariposas ilusorias revolotean a tu alrededor mientras haces un descanso corto o largo."
                  ],
                  [
                    "2",
                    "Te brotan flores en el pelo cada amanecer."
                  ],
                  [
                    "3",
                    "Emanas un ligero olor a canela, lavanda, nuez moscada u otra hierba o especia agradable."
                  ],
                  [
                    "4",
                    "Tu sombra baila cuando nadie la mira directamente."
                  ],
                  [
                    "5",
                    "De tu cabeza brotan cuernos o astas."
                  ],
                  [
                    "6",
                    "Tu piel y tu cabello cambian de color cada amanecer."
                  ]
                ]
              }
            ]
          },
          "otherworldly_glamour": {
            "name": "Glamur Sobrenatural",
            "level": 3,
            "description": "Siempre que hagas una prueba de Carisma, obtienes un bonificador igual a tu modificador por Sabiduría, con un mínimo de +1.\n\nTambién ganas competencia en una de las siguientes habilidades a tu elección: Engaño, Interpretación o Persuasión."
          },
          "dreadful_strikes": {
            "name": "Golpes Pavorosos",
            "level": 3,
            "description": "Puedes potenciar tus ataques con armas usando magia inquietante que proviene de las turbias hondonadas de los Parajes Feéricos. Cuando aciertas a una criatura con un arma, puedes infligir 1d4 de daño psíquico adicional al objetivo, que solo puede sufrir este daño adicional una vez por turno. El daño adicional aumenta a 1d6 cuando alcanzas el nivel 11 de explorador."
          },
          "beguiling_twist": {
            "name": "Giro Seductor",
            "level": 7,
            "description": "La magia de los Parajes Feéricos protege tu mente. Tienes ventaja en las tiradas de salvación para evitar o poner fin a los estados de asustado o hechizado.\n\nAdemás, siempre que tú o una criatura que puedas ver a 120 pies o menos de ti tengáis éxito en una tirada de salvación para evitar o poner fin a los estados de asustado o hechizado, puedes usar una reacción para obligar a otra criatura distinta que puedas ver a 120 pies o menos de ti a hacer una tirada de salvación de Sabiduría contra tu CD de salvación de conjuros. Si la falla, el objetivo quedará asustado o hechizado, a tu elección, durante 1 minuto. El objetivo repetirá la tirada de salvación al final de cada uno de sus turnos y, si tiene éxito, se librará del efecto."
          },
          "fey_reinforcements": {
            "name": "Refuerzos Feéricos",
            "level": 11,
            "description": "Puedes lanzar Invocar feérico sin ningún componente material.\n\nTambién puedes lanzarlo una vez sin gastar un espacio de conjuro y recuperas la capacidad de hacerlo de esta forma tras finalizar un descanso largo.\n\nCuando empieces a lanzar el conjuro, puedes modificarlo para que no requiera concentración. Si lo haces, la duración del conjuro es de 1 minuto para ese lanzamiento."
          },
          "misty_wanderer": {
            "name": "Errante Brumoso",
            "level": 15,
            "description": "Puedes lanzar Paso brumoso sin gastar un espacio de conjuro. Puedes hacerlo una cantidad de veces igual a tu modificador por Sabiduría, con un mínimo de una vez, y recuperas todos los usos tras finalizar un descanso largo.\n\nAdemás, siempre que lances Paso brumoso, podrás elegir a una criatura voluntaria que puedas ver a 5 pies o menos de ti para que te acompañe. Esa criatura se teletransportará a un espacio sin ocupar de tu elección a 5 pies de tu espacio de destino."
          }
        },
        "tables": {
          "fey_wanderer_spells_table": {
            "title": "Conjuros de Errante Feérico",
            "columns": [
              "Nivel de explorador",
              "Conjuro"
            ],
            "rows": [
              [
                "3",
                "Hechizar persona"
              ],
              [
                "5",
                "Paso brumoso"
              ],
              [
                "9",
                "Invocar feérico"
              ],
              [
                "13",
                "Puerta dimensional"
              ],
              [
                "17",
                "Engañar"
              ]
            ]
          },
          "feywild_gifts_table": {
            "title": "Dádivas de los Parajes Feéricos",
            "columns": [
              "1d6",
              "Dádiva"
            ],
            "rows": [
              [
                "1",
                "Unas mariposas ilusorias revolotean a tu alrededor mientras haces un descanso corto o largo."
              ],
              [
                "2",
                "Te brotan flores en el pelo cada amanecer."
              ],
              [
                "3",
                "Emanas un ligero olor a canela, lavanda, nuez moscada u otra hierba o especia agradable."
              ],
              [
                "4",
                "Tu sombra baila cuando nadie la mira directamente."
              ],
              [
                "5",
                "De tu cabeza brotan cuernos o astas."
              ],
              [
                "6",
                "Tu piel y tu cabello cambian de color cada amanecer."
              ]
            ]
          }
        }
      },
      "beast_master": {
        "name": "Señor de las Bestias",
        "levels": {
          "3": [
            "primal_companion"
          ],
          "7": [
            "exceptional_training"
          ],
          "11": [
            "bestial_fury"
          ],
          "15": [
            "share_spells"
          ]
        },
        "features": {
          "primal_companion": {
            "name": "Compañero Primigenio",
            "level": 3,
            "description": "Invocas mágicamente a una bestia primigenia que extrae fuerza de tu vínculo con la naturaleza. Elige un perfil para ella: bestia de los mares, bestia de tierra firme o bestia del cielo. También eliges el tipo de animal que es, siempre y cuando sea coherente con su perfil. Sea cual sea el tipo que elijas, la bestia tiene marcas primigenias que indican su origen místico.\n\nLa bestia es amistosa contigo y tus aliados, obedece tus órdenes y desaparecerá si mueres.\n\nLa bestia en combate. En combate, la bestia actúa durante tu turno. Se puede mover y usar su reacción por cuenta propia, pero la única acción que hace es la de esquivar, a menos que utilices una acción adicional para ordenarle que realice una acción que aparezca en su perfil u otra distinta. También puedes sacrificar uno de tus ataques cuando realices la acción de atacar para ordenar a la bestia que use la acción de golpe de bestia. Si tienes el estado de incapacitado, la bestia actúa por su cuenta y no está limitada a hacer la acción de esquivar.\n\nDevolver la bestia a la vida o sustituirla. Si la bestia ha muerto en la última hora, puedes usar una acción de magia para tocarla y gastar un espacio de conjuro. La bestia volverá a la vida después de 1 minuto con todos sus puntos de golpe recuperados.\n\nTras finalizar un descanso largo, puedes invocar a una bestia primigenia diferente, que aparece en un espacio sin ocupar a 5 pies de ti y eliges su perfil y aspecto. Si ya tienes una bestia por este rasgo, se desvanecerá cuando aparezca la nueva."
          },
          "exceptional_training": {
            "name": "Entrenamiento Excepcional",
            "level": 7,
            "description": "Cuando utilices una acción adicional para ordenarle a la bestia primigenia que lleve a cabo una acción, también puedes decirle que realice las acciones de ayudar, correr, destrabarse o esquivar empleando su acción adicional.\n\nAdemás, siempre que acierte con una tirada de ataque y cause daño, eliges si hace daño de fuerza o su tipo de daño normal."
          },
          "bestial_fury": {
            "name": "Furia Bestial",
            "level": 11,
            "description": "Cuando le ordenas a la bestia primigenia que realice la acción de golpe de bestia, podrá usarla dos veces.\n\nAdemás, la primera vez cada turno que acierte a una criatura bajo el efecto de tu conjuro Marca del cazador, la bestia inflige un daño de fuerza adicional igual al daño adicional de ese conjuro."
          },
          "share_spells": {
            "name": "Compartir Conjuros",
            "level": 15,
            "description": "Cuando lances un conjuro que te haga objetivo, puedes hacer que también afecte a tu bestia primigenia si se encuentra a 30 pies o menos de ti."
          }
        }
      },
      "caminante_del_invierno": {
        "name": "Caminante Invernal",
        "source": "Forgotten Realms: Heroes of Faerûn / Unearthed Arcana 2025",
        "levels": {
          "3": {
            "features": [
              "frigid_explorer",
              "hunters_rime",
              "winter_walker_spells"
            ]
          },
          "7": {
            "features": [
              "fortifying_soul"
            ]
          },
          "11": {
            "features": [
              "chilling_retribution"
            ]
          },
          "15": {
            "features": [
              "frozen_haunt"
            ]
          }
        },
        "features": {
          "frigid_explorer": {
            "name": "Explorador del hielo",
            "level": 3,
            "description": "Obtienes los siguientes beneficios.\n\nResistencia al frío. Tienes resistencia al daño de frío.\n\nGolpes polares. Cuando impactas a una criatura con un arma, puedes infligirle 1d4 de daño de frío adicional. El objetivo solo puede recibir este daño adicional una vez por turno. Este daño adicional ignora la resistencia al daño de frío. Cuando alcanzas el nivel 11 de explorador, este daño adicional aumenta a 1d6."
          },
          "hunters_rime": {
            "name": "Marca gélida",
            "level": 3,
            "description": "La escarcha te cubre a ti y a tu presa, protegiéndote y ralentizándola. Cuando lanzas Marca del cazador, ganas puntos de golpe temporales iguales a 1d10 + tu nivel de explorador.\n\nAdemás, mientras una criatura esté marcada por tu Marca del cazador, no puede realizar la acción de Destrabarse."
          },
          "winter_walker_spells": {
            "name": "Conjuros del Caminante Invernal",
            "level": 3,
            "description": "Cuando alcances un nivel de explorador especificado en la tabla «Conjuros del Caminante Invernal», siempre tendrás preparados los conjuros indicados.",
            "table": {
              "title": "Conjuros del Caminante Invernal",
              "columns": [
                "Nivel de explorador",
                "Conjuro preparado"
              ],
              "rows": [
                [
                  "3",
                  "Cuchillo de hielo"
                ],
                [
                  "5",
                  "Pasar sin rastro"
                ],
                [
                  "9",
                  "Levantar maldición"
                ],
                [
                  "13",
                  "Tormenta de hielo"
                ],
                [
                  "17",
                  "Cono de frío"
                ]
              ]
            }
          },
          "fortifying_soul": {
            "name": "Alma endurecida",
            "level": 7,
            "description": "Tu experiencia sobreviviendo a entornos aterradores te permite reforzar a tus aliados además de a ti mismo. Cuando terminas un descanso corto, puedes elegir un número de criaturas que puedas ver igual a tu modificador por Sabiduría, con un mínimo de una. Cada criatura elegida recupera una cantidad de puntos de golpe igual a 1d10 + tu nivel de explorador y tiene ventaja en las tiradas de salvación para evitar o terminar el estado de asustado durante 1 hora.\n\nUna vez que uses este rasgo, no podrás volver a hacerlo hasta terminar un descanso largo."
          },
          "chilling_retribution": {
            "name": "Venganza helada",
            "level": 11,
            "description": "Cuando una criatura te impacte con una tirada de ataque, puedes usar tu reacción para obligarla a hacer una tirada de salvación de Sabiduría contra la CD de salvación de tus conjuros. Si falla, obtiene el estado de asustado hasta el final de tu siguiente turno. Mientras esté asustada de este modo, su velocidad se reduce a 0 pies.\n\nPuedes usar esta reacción un número de veces igual a tu modificador por Sabiduría, con un mínimo de una vez, y recuperas todos los usos gastados al terminar un descanso largo."
          },
          "frozen_haunt": {
            "name": "Espíritu del invierno",
            "level": 15,
            "description": "Cuando lanzas Marca del cazador, puedes adoptar una forma fantasmal y nevada. Esta forma dura hasta que el conjuro termina y, mientras estás en ella, obtienes los beneficios siguientes. Una vez que uses este rasgo, no podrás volver a hacerlo hasta terminar un descanso largo, salvo que gastes un espacio de conjuro de nivel 4 o superior, sin requerir acción.\n\nAlma congelada. Tienes inmunidad al daño de frío. Cuando adoptas por primera vez esta forma y al comienzo de cada uno de tus turnos posteriores, cada criatura de tu elección en una emanación de 15 pies originada en ti recibe 2d4 de daño de frío.\n\nParcialmente incorpóreo. Tienes inmunidad a los estados de agarrado, derribado y apresado. Puedes moverte a través de criaturas y objetos como si fueran terreno difícil, pero recibes 1d10 de daño de fuerza si terminas tu turno dentro de una criatura o de un objeto. Si la forma termina mientras estás dentro de una criatura o de un objeto, eres desplazado al espacio desocupado más cercano."
          }
        },
        "tables": {
          "winter_walker_spells_table": {
            "title": "Conjuros del Caminante Invernal",
            "columns": [
              "Nivel de explorador",
              "Conjuro preparado"
            ],
            "rows": [
              [
                "3",
                "Cuchillo de hielo"
              ],
              [
                "5",
                "Pasar sin rastro"
              ],
              [
                "9",
                "Levantar maldición"
              ],
              [
                "13",
                "Tormenta de hielo"
              ],
              [
                "17",
                "Cono de frío"
              ]
            ]
          }
        }
      }
    }
  },
  "guerrero": {
    "id": "guerrero",
    "name": "Guerrero",
    "primaryAbility": [
      "Fuerza",
      "Destreza"
    ],
    "hitDie": "1d10",
    "savingThrows": [
      "Fuerza",
      "Constitución"
    ],
    "skillChoices": {
      "choose": 2,
      "from": [
        "Acrobacias",
        "Atletismo",
        "Historia",
        "Intimidación",
        "Percepción",
        "Perspicacia",
        "Persuasión",
        "Supervivencia",
        "Trato con animales"
      ]
    },
    "weaponProficiencies": [
      "Armas sencillas",
      "Armas marciales"
    ],
    "armorTraining": [
      "Armaduras ligeras",
      "Armaduras medias",
      "Armaduras pesadas",
      "Escudos"
    ],
    "startingEquipment": {
      "options": [
        {
          "label": "A",
          "items": [
            "Cota de malla",
            "Espadón",
            "Mangual",
            "3 jabalinas",
            "Paquete de explorador de mazmorras",
            "4 po"
          ]
        },
        {
          "label": "B",
          "items": [
            "Armadura de cuero tachonado",
            "Cimitarra",
            "Espada corta",
            "Arco largo",
            "20 flechas",
            "Aljaba",
            "Paquete de explorador de mazmorras",
            "1 po"
          ]
        },
        {
          "label": "C",
          "items": [
            "155 po"
          ]
        }
      ]
    },
    "levels": {
      "1": {
        "proficiencyBonus": "+2",
        "secondWindUses": 2,
        "weaponMasteryCount": 3,
        "features": [
          "fighting_style_fighter",
          "weapon_mastery_fighter",
          "second_wind"
        ]
      },
      "2": {
        "proficiencyBonus": "+2",
        "secondWindUses": 2,
        "weaponMasteryCount": 3,
        "features": [
          "action_surge",
          "tactical_mind"
        ]
      },
      "3": {
        "proficiencyBonus": "+2",
        "secondWindUses": 2,
        "weaponMasteryCount": 3,
        "features": [
          "fighter_subclass"
        ]
      },
      "4": {
        "proficiencyBonus": "+2",
        "secondWindUses": 3,
        "weaponMasteryCount": 4,
        "features": [
          "ability_score_improvement_fighter"
        ]
      },
      "5": {
        "proficiencyBonus": "+3",
        "secondWindUses": 3,
        "weaponMasteryCount": 4,
        "features": [
          "extra_attack_fighter",
          "tactical_shift"
        ]
      },
      "6": {
        "proficiencyBonus": "+3",
        "secondWindUses": 3,
        "weaponMasteryCount": 4,
        "features": [
          "ability_score_improvement_fighter"
        ]
      },
      "7": {
        "proficiencyBonus": "+3",
        "secondWindUses": 3,
        "weaponMasteryCount": 4,
        "features": [],
        "subclassFeatures": true
      },
      "8": {
        "proficiencyBonus": "+3",
        "secondWindUses": 3,
        "weaponMasteryCount": 4,
        "features": [
          "ability_score_improvement_fighter"
        ]
      },
      "9": {
        "proficiencyBonus": "+4",
        "secondWindUses": 3,
        "weaponMasteryCount": 4,
        "features": [
          "indomitable",
          "tactical_master"
        ]
      },
      "10": {
        "proficiencyBonus": "+4",
        "secondWindUses": 4,
        "weaponMasteryCount": 5,
        "features": [],
        "subclassFeatures": true
      },
      "11": {
        "proficiencyBonus": "+4",
        "secondWindUses": 4,
        "weaponMasteryCount": 5,
        "features": [
          "extra_attack_2"
        ]
      },
      "12": {
        "proficiencyBonus": "+4",
        "secondWindUses": 4,
        "weaponMasteryCount": 5,
        "features": [
          "ability_score_improvement_fighter"
        ]
      },
      "13": {
        "proficiencyBonus": "+5",
        "secondWindUses": 4,
        "weaponMasteryCount": 5,
        "features": [
          "studied_attacks"
        ]
      },
      "14": {
        "proficiencyBonus": "+5",
        "secondWindUses": 4,
        "weaponMasteryCount": 5,
        "features": [
          "ability_score_improvement_fighter"
        ]
      },
      "15": {
        "proficiencyBonus": "+5",
        "secondWindUses": 4,
        "weaponMasteryCount": 5,
        "features": [],
        "subclassFeatures": true
      },
      "16": {
        "proficiencyBonus": "+5",
        "secondWindUses": 4,
        "weaponMasteryCount": 6,
        "features": [
          "ability_score_improvement_fighter"
        ]
      },
      "17": {
        "proficiencyBonus": "+6",
        "secondWindUses": 4,
        "weaponMasteryCount": 6,
        "features": [
          "action_surge",
          "indomitable"
        ]
      },
      "18": {
        "proficiencyBonus": "+6",
        "secondWindUses": 4,
        "weaponMasteryCount": 6,
        "features": [],
        "subclassFeatures": true
      },
      "19": {
        "proficiencyBonus": "+6",
        "secondWindUses": 4,
        "weaponMasteryCount": 6,
        "features": [
          "epic_boon_fighter"
        ]
      },
      "20": {
        "proficiencyBonus": "+6",
        "secondWindUses": 4,
        "weaponMasteryCount": 6,
        "features": [
          "extra_attack_3"
        ]
      }
    },
    "features": {
      "fighting_style_fighter": {
        "name": "Estilo de Combate",
        "level": 1,
        "description": "Has pulido tu destreza marcial y obtienes una dote de estilo de combate de tu elección. Se recomienda Defensa.\n\nCada vez que subas un nivel de guerrero, puedes sustituir la dote que hayas elegido por otra dote de estilo de combate."
      },
      "weapon_mastery_fighter": {
        "name": "Maestría con Armas",
        "level": 1,
        "description": "Tu entrenamiento con armas te permite utilizar las propiedades de maestría con tres tipos de armas sencillas o marciales de tu elección.\n\nTras finalizar un descanso largo, puedes llevar a cabo ejercicios con armas y cambiar una de dichas elecciones.\n\nCuando alcances ciertos niveles de guerrero, adquirirás la capacidad de usar las propiedades de maestría con más tipos de armas, como se muestra en la columna Maestría con armas de la tabla Rasgos de guerrero."
      },
      "second_wind": {
        "name": "Tomar Aliento",
        "level": 1,
        "description": "Posees una pequeña reserva de resistencia física y mental a la que puedes recurrir. Como acción adicional, puedes usarla para recuperar una cantidad de puntos de golpe igual a 1d10 más tu nivel de guerrero.\n\nPuedes usar este rasgo dos veces. Recuperas uno de los usos gastados tras finalizar un descanso corto y todos tras finalizar un descanso largo.\n\nObtienes usos adicionales cuando alcanzas ciertos niveles de guerrero, como se muestra en la columna Tomar aliento de la tabla Rasgos de guerrero."
      },
      "action_surge": {
        "name": "Acción Súbita",
        "level": 2,
        "description": "Puedes superar tus límites normales durante un instante. En tu turno, puedes llevar a cabo una acción más, salvo la acción de magia.\n\nCuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso corto o largo. A partir del nivel 17, podrás usarlo dos veces antes de descansar, pero solo una vez por turno."
      },
      "tactical_mind": {
        "name": "Mente Táctica",
        "level": 2,
        "description": "Tienes facilidad para la estrategia dentro y fuera del campo de batalla. Cuando falles una prueba de característica, podrás gastar un uso de tu rasgo Tomar aliento para esforzarte por superarla.\n\nEn vez de recuperar puntos de golpe, tiras 1d10 y sumas el resultado a la prueba de característica, lo que podría convertir el fallo en un éxito.\n\nSi sigues sin superar la prueba, este uso de Tomar aliento no se gasta."
      },
      "fighter_subclass": {
        "name": "Subclase de Guerrero",
        "level": 3,
        "description": "Consigues una subclase de guerrero de tu elección.\n\nLas subclases de Caballero Arcano, Campeón, Guerrero Psiónico y Maestro del Combate se detallan tras la descripción de esta clase. Una subclase es una especialización que te proporciona rasgos cuando alcanzas ciertos niveles de guerrero. De aquí en adelante, obtienes todos los rasgos de tu subclase que sean de tu nivel de guerrero e inferiores."
      },
      "ability_score_improvement_fighter": {
        "name": "Mejora de Característica",
        "level": 4,
        "description": "Obtienes la dote Mejora de característica u otra dote de tu elección para la que cumplas las condiciones.\n\nVuelves a obtener este rasgo en los niveles 6, 8, 12, 14 y 16 de guerrero."
      },
      "extra_attack_fighter": {
        "name": "Ataque Adicional",
        "level": 5,
        "description": "Cuando lleves a cabo la acción de atacar en tu turno, podrás hacer dos ataques en lugar de uno."
      },
      "tactical_shift": {
        "name": "Desplazamiento Táctico",
        "level": 5,
        "description": "Cuando uses tu rasgo Tomar aliento con una acción adicional, podrás moverte hasta la mitad de tu velocidad sin provocar ataques de oportunidad."
      },
      "indomitable": {
        "name": "Indómito",
        "level": 9,
        "description": "Si fallas una tirada de salvación, puedes repetirla con un bonificador igual a tu nivel de guerrero.\n\nDeberás quedarte con el nuevo resultado y no podrás volver a utilizar este rasgo hasta que finalices un descanso largo.\n\nPuedes usar este rasgo dos veces entre descansos largos a partir del nivel 13 y tres veces entre descansos largos a partir del nivel 17."
      },
      "tactical_master": {
        "name": "Maestro Táctico",
        "level": 9,
        "description": "Cuando ataques usando un arma con la que puedas utilizar su propiedad de maestría, puedes sustituir la propiedad para ese ataque por la de debilitar, empujar o ralentizar."
      },
      "extra_attack_2": {
        "name": "Dos Ataques Adicionales",
        "level": 11,
        "description": "Cuando lleves a cabo la acción de atacar en tu turno, podrás hacer tres ataques en lugar de uno."
      },
      "studied_attacks": {
        "name": "Ataques Estudiados",
        "level": 13,
        "description": "Estudias a tus adversarios y aprendes con cada ataque que realizas. Si haces una tirada de ataque contra una criatura y fallas, tendrás ventaja en tu siguiente tirada de ataque contra esa criatura antes del final de tu siguiente turno."
      },
      "epic_boon_fighter": {
        "name": "Don Épico",
        "level": 19,
        "description": "Obtienes una dote de don épico u otra dote de tu elección para la que cumplas las condiciones. Se recomienda Don de la pericia en combate."
      },
      "extra_attack_3": {
        "name": "Tres Ataques Adicionales",
        "level": 20,
        "description": "Cuando lleves a cabo la acción de atacar en tu turno, podrás hacer cuatro ataques en lugar de uno."
      }
    },
    "subclasses": {
      "caballero_arcano": {
        "name": "Caballero Arcano",
        "levels": {
          "3": {
            "features": [
              "arcane_knight_spellcasting",
              "weapon_bond"
            ]
          },
          "7": {
            "features": [
              "war_magic"
            ]
          },
          "10": {
            "features": [
              "eldritch_strike"
            ]
          },
          "15": {
            "features": [
              "arcane_charge"
            ]
          },
          "18": {
            "features": [
              "improved_war_magic"
            ]
          }
        },
        "features": {
          "arcane_knight_spellcasting": {
            "name": "Lanzamiento de Conjuros",
            "level": 3,
            "description": "Has aprendido a lanzar conjuros. Consulta el capítulo 7 para ver las reglas sobre el lanzamiento de conjuros. La información presentada a continuación detalla cómo usar esas reglas como caballero arcano.\n\nTrucos. Conoces dos trucos de tu elección de la lista de conjuros de mago. Cada vez que subas un nivel de guerrero, podrás reemplazar uno de estos trucos por otro truco de tu elección de la lista de conjuros de mago. Cuando alcanzas el nivel 10 de guerrero, aprendes otro truco de mago de tu elección.\n\nEspacios de conjuro. La tabla Lanzamiento de conjuros del caballero arcano muestra cuántos espacios de conjuro tienes para lanzar tus conjuros de nivel 1 y superiores. Recuperas todos los espacios utilizados tras finalizar un descanso largo.\n\nConjuros preparados de nivel 1 y superiores. Preparas una serie de conjuros de nivel 1 y superiores, que son los que podrás lanzar con este rasgo. Para empezar, elige tres conjuros de nivel 1 de la lista de conjuros de mago.\n\nEl número de conjuros de tu lista aumenta conforme subes de nivel de guerrero, como se muestra en la columna Conjuros preparados de la tabla Lanzamiento de conjuros del caballero arcano. Cuando ese número aumente, elige conjuros adicionales de la lista de conjuros de mago hasta que el número de conjuros de tu lista coincida con el número de la tabla. Estos conjuros deben ser de un nivel para el que tengas espacios de conjuro.\n\nCambiar los conjuros preparados. Cada vez que subas un nivel de guerrero, puedes sustituir un conjuro de tu lista por otro conjuro de mago para el que tengas espacios de conjuro.\n\nAptitud mágica. La Inteligencia es tu aptitud mágica en lo que respecta a tus conjuros de mago.\n\nCanalizador mágico. Puedes utilizar un canalizador arcano como canalizador mágico para tus conjuros de mago."
          },
          "weapon_bond": {
            "name": "Vínculo de Guerra",
            "level": 3,
            "description": "Aprendes un ritual que te vincula mágicamente a un arma. Este ritual requiere 1 hora y puede tener lugar durante un descanso corto. El arma debe estar a tu alcance durante el ritual y, cuando este acabe, la tocarás y forjarás el vínculo.\n\nEl vínculo falla si otro guerrero está vinculado al arma o si el arma es un objeto mágico al que esté sintonizado alguien más.\n\nCuando te hayas vinculado con el arma, no podrán desarmarte de ella salvo que tengas el estado de incapacitado. Si está en el mismo plano de existencia, puedes invocar el arma como acción adicional y teletransportarla de inmediato a tu mano.\n\nPuedes tener hasta dos armas vinculadas, pero solo puedes invocar una cada vez con una acción adicional. Si tratas de vincularte con una tercera arma, deberás romper el vínculo con una de las otras dos."
          },
          "war_magic": {
            "name": "Magia de Guerra",
            "level": 7,
            "description": "Cuando lleves a cabo la acción de atacar en tu turno, puedes sustituir uno de los ataques por el lanzamiento de uno de tus trucos de mago que tenga un tiempo de lanzamiento de una acción."
          },
          "eldritch_strike": {
            "name": "Golpe Sobrenatural",
            "level": 10,
            "description": "Aprendes a hacer que los ataques con tus armas minen la resistencia de una criatura a tus conjuros. Cuando aciertes a una criatura con un ataque con un arma, tendrá desventaja en la siguiente tirada de salvación que haga contra un conjuro que lances antes del final de tu siguiente turno."
          },
          "arcane_charge": {
            "name": "Carga Arcana",
            "level": 15,
            "description": "Cuando utilices tu rasgo Acción súbita, podrás teletransportarte hasta 30 pies a un espacio sin ocupar que puedas ver. Puedes teletransportarte antes o después de la acción adicional."
          },
          "improved_war_magic": {
            "name": "Magia de Guerra Mejorada",
            "level": 18,
            "description": "Cuando lleves a cabo la acción de atacar en tu turno, puedes sustituir dos de los ataques por el lanzamiento de uno de tus conjuros de mago de nivel 1 o 2 que tenga un tiempo de lanzamiento de una acción."
          }
        },
        "tables": {
          "arcane_knight_spellcasting_table": {
            "title": "Lanzamiento de Conjuros del Caballero Arcano",
            "columns": [
              "Nivel de guerrero",
              "Conjuros preparados",
              "1",
              "2",
              "3",
              "4"
            ],
            "rows": [
              [
                "3",
                "3",
                "2",
                "-",
                "-",
                "-"
              ],
              [
                "4",
                "4",
                "3",
                "-",
                "-",
                "-"
              ],
              [
                "5",
                "4",
                "3",
                "-",
                "-",
                "-"
              ],
              [
                "6",
                "4",
                "3",
                "-",
                "-",
                "-"
              ],
              [
                "7",
                "5",
                "4",
                "2",
                "-",
                "-"
              ],
              [
                "8",
                "6",
                "4",
                "2",
                "-",
                "-"
              ],
              [
                "9",
                "6",
                "4",
                "2",
                "-",
                "-"
              ],
              [
                "10",
                "7",
                "4",
                "3",
                "-",
                "-"
              ],
              [
                "11",
                "8",
                "4",
                "3",
                "-",
                "-"
              ],
              [
                "12",
                "8",
                "4",
                "3",
                "-",
                "-"
              ],
              [
                "13",
                "9",
                "4",
                "3",
                "2",
                "-"
              ],
              [
                "14",
                "10",
                "4",
                "3",
                "2",
                "-"
              ],
              [
                "15",
                "10",
                "4",
                "3",
                "2",
                "-"
              ],
              [
                "16",
                "11",
                "4",
                "3",
                "3",
                "-"
              ],
              [
                "17",
                "11",
                "4",
                "3",
                "3",
                "-"
              ],
              [
                "18",
                "11",
                "4",
                "3",
                "3",
                "-"
              ],
              [
                "19",
                "12",
                "4",
                "3",
                "3",
                "1"
              ],
              [
                "20",
                "13",
                "4",
                "3",
                "3",
                "1"
              ]
            ]
          }
        }
      },
      "campeon": {
        "name": "Campeón",
        "levels": {
          "3": {
            "features": [
              "remarkable_athlete",
              "improved_critical"
            ]
          },
          "7": {
            "features": [
              "additional_fighting_style"
            ]
          },
          "10": {
            "features": [
              "heroic_warrior"
            ]
          },
          "15": {
            "features": [
              "superior_critical"
            ]
          },
          "18": {
            "features": [
              "survivor"
            ]
          }
        },
        "features": {
          "remarkable_athlete": {
            "name": "Atleta Sobresaliente",
            "level": 3,
            "description": "Gracias a tus capacidades atléticas, tienes ventaja en las tiradas de iniciativa y las pruebas de Fuerza (Atletismo).\n\nAdemás, justo después de causar un crítico, puedes moverte hasta la mitad de tu velocidad sin provocar ataques de oportunidad."
          },
          "improved_critical": {
            "name": "Crítico Mejorado",
            "level": 3,
            "description": "Tus tiradas de ataque con armas y tus ataques sin armas pueden causar críticos con un resultado de 19 o 20 en el d20."
          },
          "additional_fighting_style": {
            "name": "Estilo de Combate Adicional",
            "level": 7,
            "description": "Obtienes otra dote de estilo de combate de tu elección."
          },
          "heroic_warrior": {
            "name": "Guerrero Heroico",
            "level": 10,
            "description": "La emoción de la batalla te empuja hacia la victoria. Durante un combate, puedes otorgarte inspiración heroica siempre que empieces tu turno sin ella."
          },
          "superior_critical": {
            "name": "Crítico Superior",
            "level": 15,
            "description": "Tus tiradas de ataque con armas y tus ataques sin armas ahora pueden causar críticos con un resultado de 18 a 20 en el d20."
          },
          "survivor": {
            "name": "Superviviente",
            "level": 18,
            "description": "Alcanzas la cumbre de la resistencia en batalla, lo que te otorga estos beneficios.\n\nDesafiar a la muerte. Tienes ventaja en las tiradas de salvación contra muerte. Asimismo, cuando saques de 18 a 20 en una tirada de salvación contra muerte, obtendrás el beneficio de sacar un 20 en ella.\n\nMejoría heroica. Al principio de cada uno de tus turnos, recuperas una cantidad de puntos de golpe igual a 5 más tu modificador por Constitución si estás maltrecho y tienes al menos 1 punto de golpe."
          }
        }
      },
      "guerrero_psionico": {
        "name": "Guerrero Psiónico",
        "levels": {
          "3": {
            "features": [
              "psionic_power"
            ]
          },
          "7": {
            "features": [
              "telekinetic_adept"
            ]
          },
          "10": {
            "features": [
              "guarded_mind"
            ]
          },
          "15": {
            "features": [
              "bulwark_of_force"
            ]
          },
          "18": {
            "features": [
              "telekinetic_master"
            ]
          }
        },
        "features": {
          "psionic_power": {
            "name": "Poder Psiónico",
            "level": 3,
            "description": "Albergas una fuente de energía psiónica en tu interior. Esta se representa mediante dados de energía psiónica, que alimentan los poderes que tienes por esta subclase.\n\nCualquier rasgo de esta subclase que emplee dados de energía psiónica utiliza solamente los dados de esta subclase. Algunos de tus poderes gastan un dado de energía psiónica, por lo que no podrás usar un poder que requiera emplear un dado si ya los has gastado todos.\n\nRecuperas uno de tus dados de energía psiónica tras finalizar un descanso corto y todos tras finalizar un descanso largo.\n\nCampo protector. Cuando tú u otra criatura que puedas ver a 30 pies o menos de ti recibáis daño, puedes usar una reacción para gastar un dado de energía psiónica; tira el dado y reduce el daño sufrido en una cantidad igual al resultado más tu modificador por Inteligencia. El daño se reduce en 1 como mínimo.\n\nGolpe psiónico. Una vez en cada uno de tus turnos, inmediatamente después de acertar a un objetivo que esté a 30 pies o menos de ti con un ataque e infligirle daño con un arma, puedes gastar un dado de energía psiónica, tirarlo e infligir una cantidad de daño de fuerza al objetivo igual al resultado más tu modificador por Inteligencia.\n\nMovimiento telequinético. Como acción de magia, eliges un objetivo que puedas ver a 30 pies o menos de ti; deberá ser un objeto suelto Grande o más pequeño o una criatura voluntaria que no seas tú. Transportas al objetivo hasta 30 pies a un espacio sin ocupar que puedas ver. Como alternativa, si se trata de un objeto Diminuto, puedes moverlo hacia tu mano o desde ella.\n\nCuando lleves a cabo esta acción, no podrás volver a hacerla hasta que finalices un descanso corto o largo, a menos que gastes un dado de energía psiónica, sin requerir acción, para restablecer su uso.",
            "table": {
              "title": "Dados de Energía del Guerrero Psiónico",
              "columns": [
                "Nivel de guerrero",
                "Tamaño del dado",
                "Cantidad"
              ],
              "rows": [
                [
                  "3",
                  "d6",
                  "4"
                ],
                [
                  "5",
                  "d8",
                  "6"
                ],
                [
                  "9",
                  "d8",
                  "8"
                ],
                [
                  "11",
                  "d10",
                  "8"
                ],
                [
                  "13",
                  "d10",
                  "10"
                ],
                [
                  "17",
                  "d12",
                  "12"
                ]
              ]
            }
          },
          "telekinetic_adept": {
            "name": "Adepto Telequinético",
            "level": 7,
            "description": "Has dominado nuevas formas de usar tus habilidades telequinéticas.\n\nEmpujón telequinético. Cuando inflijas daño a un objetivo con tu Golpe psiónico, puedes obligarlo a hacer una tirada de salvación de Fuerza, con CD 8 más tu modificador por Inteligencia y tu bonificador por competencia. Si la falla, el objetivo tendrá el estado de derribado o lo transportarás hasta 10 pies en horizontal.\n\nSalto psiónico. Como acción adicional, obtienes una velocidad volando igual al doble de tu velocidad hasta el final del turno actual. Cuando lleves a cabo esta acción adicional, no podrás volver a hacerla hasta que finalices un descanso corto o largo, a menos que gastes un dado de energía psiónica, sin requerir acción, para restablecer su uso."
          },
          "guarded_mind": {
            "name": "Mente Robusta",
            "level": 10,
            "description": "Tienes resistencia al daño psíquico. Además, si comienzas tu turno con el estado de asustado o hechizado, puedes gastar un dado de energía psiónica, sin requerir acción, y poner fin a todos los efectos que te causen dichos estados."
          },
          "bulwark_of_force": {
            "name": "Bastión de Fuerza",
            "level": 15,
            "description": "Puedes proteger a los demás o a ti con fuerza telequinética. Como acción adicional, puedes elegir hasta una cantidad de criaturas, entre las que puedes estar tú, a 30 pies o menos de ti igual a tu modificador por Inteligencia, con un mínimo de una criatura. Cada una de las criaturas elegidas tendrá cobertura media durante 1 minuto o hasta que tengas el estado de incapacitado.\n\nCuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo, a menos que gastes un dado de energía psiónica, sin requerir acción, para restablecer su uso."
          },
          "telekinetic_master": {
            "name": "Maestro Telequinético",
            "level": 18,
            "description": "Siempre tienes el conjuro Telequinesis preparado. Con este rasgo, puedes lanzarlo sin un espacio de conjuro ni componentes, y tu aptitud mágica para hacerlo es la Inteligencia. En cada uno de tus turnos en los que mantengas la concentración en el conjuro, incluido el turno en el que lo lances, podrás realizar un ataque con un arma como acción adicional.\n\nCuando lances el conjuro con este rasgo, no podrás volver a hacerlo de esta forma hasta que finalices un descanso largo, a menos que gastes un dado de energía psiónica, sin requerir acción, para restablecer su uso."
          }
        },
        "tables": {
          "psionic_energy_dice": {
            "title": "Dados de Energía del Guerrero Psiónico",
            "columns": [
              "Nivel de guerrero",
              "Tamaño del dado",
              "Cantidad"
            ],
            "rows": [
              [
                "3",
                "d6",
                "4"
              ],
              [
                "5",
                "d8",
                "6"
              ],
              [
                "9",
                "d8",
                "8"
              ],
              [
                "11",
                "d10",
                "8"
              ],
              [
                "13",
                "d10",
                "10"
              ],
              [
                "17",
                "d12",
                "12"
              ]
            ]
          }
        }
      },
      "maestro_del_combate": {
        "name": "Maestro del Combate",
        "levels": {
          "3": {
            "features": [
              "student_of_war",
              "combat_superiority"
            ]
          },
          "7": {
            "features": [
              "know_your_enemy"
            ]
          },
          "10": {
            "features": [
              "improved_combat_superiority"
            ]
          },
          "15": {
            "features": [
              "relentless_battle_master"
            ]
          },
          "18": {
            "features": [
              "ultimate_combat_superiority"
            ]
          }
        },
        "features": {
          "student_of_war": {
            "name": "Estudioso de la Guerra",
            "level": 3,
            "description": "Ganas competencia con un tipo de herramientas de artesano de tu elección y en una habilidad de tu elección de las habilidades disponibles para los guerreros de nivel 1."
          },
          "combat_superiority": {
            "name": "Supremacía en Combate",
            "level": 3,
            "description": "Tu experiencia en el campo de batalla ha pulido tus técnicas de combate. Aprendes maniobras que emplean unos dados especiales llamados dados de supremacía.\n\nManiobras. Aprendes tres maniobras de tu elección del apartado Opciones de maniobras. Muchas maniobras mejoran los ataques de alguna forma. Solo puedes emplear una maniobra por ataque.\n\nAprendes dos maniobras adicionales de tu elección cuando alcanzas los niveles 7, 10 y 15 de guerrero. Cada vez que aprendes nuevas maniobras, puedes sustituir una maniobra que conozcas por otra.\n\nDados de supremacía. Posees cuatro dados de supremacía, todos ellos d8. Cada vez que empleas uno de ellos, se gasta. Recuperas todos los dados de supremacía gastados tras finalizar un descanso corto o largo.\n\nObtienes un dado de supremacía más cuando alcanzas los niveles 7, con cinco dados en total, y 15, con seis dados en total, de guerrero.\n\nTiradas de salvación. Si una maniobra requiere una tirada de salvación, la CD será igual a 8 más tu modificador por Fuerza o Destreza, a tu elección, y tu bonificador por competencia."
          },
          "know_your_enemy": {
            "name": "Conoce a tu Enemigo",
            "level": 7,
            "description": "Como acción adicional, puedes distinguir determinadas fortalezas y debilidades de una criatura que puedas ver a 30 pies o menos de ti. Sabrás si la criatura tiene alguna inmunidad, resistencia o vulnerabilidad y, de ser así, sabrás cuáles son.\n\nCuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo. También puedes recuperar un uso del rasgo gastando un dado de supremacía, sin requerir acción."
          },
          "improved_combat_superiority": {
            "name": "Supremacía en Combate Mejorada",
            "level": 10,
            "description": "Tu dado de supremacía se convierte en un d10."
          },
          "relentless_battle_master": {
            "name": "Incansable",
            "level": 15,
            "description": "Una vez por turno, cuando utilices una maniobra, puedes tirar 1d8 y utilizar el resultado en vez de gastar un dado de supremacía."
          },
          "ultimate_combat_superiority": {
            "name": "Supremacía en Combate Definitiva",
            "level": 18,
            "description": "Tu dado de supremacía se convierte en un d12."
          }
        },
        "tables": {
          "combat_superiority_progression": {
            "title": "Dados de Supremacía",
            "columns": [
              "Nivel de guerrero",
              "Tamaño del dado",
              "Cantidad"
            ],
            "rows": [
              [
                "3",
                "d8",
                "4"
              ],
              [
                "7",
                "d8",
                "5"
              ],
              [
                "10",
                "d10",
                "5"
              ],
              [
                "15",
                "d10",
                "6"
              ],
              [
                "18",
                "d12",
                "6"
              ]
            ]
          }
        },
        "maneuvers": {
          "arremetida": {
            "name": "Arremetida",
            "description": "Como acción adicional, puedes gastar un dado de supremacía y llevar a cabo la acción de correr. Si te mueves al menos 5 pies en línea recta justo antes de acertar con un ataque cuerpo a cuerpo como parte de la acción de atacar en este turno, podrás sumar el dado de supremacía a la tirada de daño del ataque."
          },
          "ataque_amenazador": {
            "name": "Ataque Amenazador",
            "description": "Cuando aciertes a una criatura con una tirada de ataque, puedes gastar un dado de supremacía para intentar asustar al objetivo. Suma el dado de supremacía a la tirada de daño del ataque. El objetivo deberá superar una tirada de salvación de Sabiduría o tendrá el estado de asustado hasta el final de tu siguiente turno."
          },
          "ataque_de_barrido": {
            "name": "Ataque de Barrido",
            "description": "Cuando aciertes a una criatura con una tirada de ataque cuerpo a cuerpo usando un arma o un ataque sin armas, puedes gastar un dado de supremacía para intentar dañar a otra criatura. Elige otra criatura a 5 pies o menos del objetivo original y que esté a tu alcance. Si la tirada de ataque original hubiera acertado a la segunda criatura, esta sufrirá una cantidad de daño igual al resultado que saques en el dado de supremacía. El daño es del mismo tipo que inflija el ataque original."
          },
          "ataque_preciso": {
            "name": "Ataque Preciso",
            "description": "Cuando falles con una tirada de ataque, puedes gastar un dado de supremacía, tirarlo y sumar el resultado a la tirada de ataque, lo que podría hacer que el ataque acierte."
          },
          "ataque_provocador": {
            "name": "Ataque Provocador",
            "description": "Cuando aciertes a una criatura con una tirada de ataque, puedes gastar un dado de supremacía para intentar provocar al objetivo para que te ataque. Suma el dado de supremacía a la tirada de daño del ataque. El objetivo deberá superar una tirada de salvación de Sabiduría o tendrá desventaja en sus tiradas de ataque contra cualquier objetivo que no seas tú hasta el final de tu siguiente turno."
          },
          "ataque_y_derribo": {
            "name": "Ataque y Derribo",
            "description": "Cuando aciertes a una criatura con una tirada de ataque usando un arma o un ataque sin armas, puedes gastar un dado de supremacía y sumarlo a la tirada de daño del ataque. Si el objetivo es Grande o más pequeño, deberá superar una tirada de salvación de Fuerza o tendrá el estado de derribado."
          },
          "ataque_y_desarme": {
            "name": "Ataque y Desarme",
            "description": "Cuando aciertes a una criatura con una tirada de ataque, puedes gastar un dado de supremacía para intentar desarmar al objetivo. Suma el dado de supremacía a la tirada de daño del ataque. El objetivo deberá superar una tirada de salvación de Fuerza o soltará un objeto de tu elección que esté sujetando, que caerá en su espacio."
          },
          "ataque_y_distraccion": {
            "name": "Ataque y Distracción",
            "description": "Cuando aciertes a una criatura con una tirada de ataque, puedes gastar un dado de supremacía para distraer al objetivo. Suma el dado de supremacía a la tirada de daño del ataque. La siguiente tirada de ataque contra el objetivo que realice un atacante que no seas tú tendrá ventaja si el ataque se lleva a cabo antes del principio de tu siguiente turno."
          },
          "ataque_y_empujon": {
            "name": "Ataque y Empujón",
            "description": "Cuando aciertes a una criatura con una tirada de ataque usando un arma o un ataque sin armas, puedes gastar un dado de supremacía para intentar hacer retroceder al objetivo. Suma el dado de supremacía a la tirada de daño del ataque. Si el objetivo es Grande o más pequeño, deberá superar una tirada de salvación de Fuerza o será empujado hasta 15 pies respecto a ti."
          },
          "ataque_y_maniobra": {
            "name": "Ataque y Maniobra",
            "description": "Cuando aciertes a una criatura con una tirada de ataque, puedes gastar un dado de supremacía para que uno de tus compañeros maniobre para cambiar de posición. Suma el dado de supremacía a la tirada de daño del ataque y elige a una criatura voluntaria que pueda verte u oírte. La criatura podrá usar su reacción para moverse hasta la mitad de su velocidad sin provocar un ataque de oportunidad por parte del objetivo de tu ataque."
          },
          "cambio_de_posicion_ventajoso": {
            "name": "Cambio de Posición Ventajoso",
            "description": "Si en tu turno estás a 5 pies o menos de una criatura, puedes gastar un dado de supremacía y cambiar tu posición por la de ella, siempre que gastes al menos 5 pies de movimiento y que esa criatura acceda voluntariamente y no tenga el estado de incapacitada. Este movimiento no provoca ataques de oportunidad.\n\nTira el dado de supremacía. Hasta el principio de tu siguiente turno, tú o la otra criatura, a tu elección, obtenéis un bonificador a la CA igual al resultado."
          },
          "contraataque": {
            "name": "Contraataque",
            "description": "Cuando una criatura falle una tirada de ataque cuerpo a cuerpo contra ti, puedes llevar a cabo una reacción y gastar un dado de supremacía para realizar una tirada de ataque cuerpo a cuerpo con un arma o con un ataque sin armas contra esa criatura. Si aciertas, suma el dado de supremacía al daño del ataque."
          },
          "emboscada": {
            "name": "Emboscada",
            "description": "Cuando hagas una prueba de Destreza (Sigilo) o una tirada de iniciativa, puedes gastar un dado de supremacía y sumarlo a la tirada, salvo que tengas el estado de incapacitado."
          },
          "evaluacion_tactica": {
            "name": "Evaluación Táctica",
            "description": "Cuando hagas una prueba de Inteligencia (Historia o Investigación) o de Sabiduría (Perspicacia), puedes gastar un dado de supremacía y sumarlo a la prueba de característica."
          },
          "finta": {
            "name": "Finta",
            "description": "Como acción adicional, puedes gastar un dado de supremacía para realizar una finta eligiendo a una criatura a 5 pies o menos de ti como objetivo. Tendrás ventaja en tu siguiente tirada de ataque contra ese objetivo ese turno. Si el ataque acierta, suma el dado de supremacía a la tirada de daño del ataque."
          },
          "juego_de_pies_evasivo": {
            "name": "Juego de Pies Evasivo",
            "description": "Como acción adicional, puedes gastar un dado de supremacía y llevar a cabo la acción de destrabarse. También tiras el dado y sumas el resultado a tu CA hasta el principio de tu siguiente turno."
          },
          "orden_de_ataque": {
            "name": "Orden de Ataque",
            "description": "Cuando lleves a cabo la acción de atacar en tu turno, puedes renunciar a uno de tus ataques para ordenar a uno de tus compañeros que ataque. Cuando lo hagas, elige una criatura voluntaria que puedas ver u oír y gasta un dado de supremacía. Esa criatura podrá usar su reacción de inmediato para realizar un ataque con un arma o un ataque sin armas y sumar el dado de supremacía a la tirada de daño del ataque si acierta."
          },
          "parada": {
            "name": "Parada",
            "description": "Cuando otra criatura te dañe con una tirada de ataque cuerpo a cuerpo, puedes llevar a cabo una reacción y gastar un dado de supremacía para reducir el daño en una cantidad igual al resultado del dado de supremacía más tu modificador por Fuerza o Destreza, a tu elección."
          },
          "presencia_imponente": {
            "name": "Presencia Imponente",
            "description": "Cuando hagas una prueba de Carisma (Interpretación, Intimidación o Persuasión), puedes gastar un dado de supremacía y sumarlo a la tirada."
          },
          "reagrupar": {
            "name": "Reagrupar",
            "description": "Como acción adicional, puedes gastar un dado de supremacía para reforzar la determinación de un compañero. Elige a un aliado que esté a 30 pies o menos de ti y que pueda verte u oírte. La criatura obtendrá una cantidad de puntos de golpe temporales igual al resultado del dado de supremacía más la mitad de tu nivel de guerrero, redondeando hacia abajo."
          }
        }
      },
      "banneret": {
        "name": "Portaestandarte",
        "source": "Forgotten Realms: Heroes of Faerûn",
        "levels": {
          "3": {
            "features": [
              "knightly_envoy",
              "group_recovery"
            ]
          },
          "7": {
            "features": [
              "team_tactics"
            ]
          },
          "10": {
            "features": [
              "rallying_surge"
            ]
          },
          "15": {
            "features": [
              "shared_resilience"
            ]
          },
          "18": {
            "features": [
              "inspiring_commander"
            ]
          }
        },
        "features": {
          "knightly_envoy": {
            "name": "Emisario caballeresco",
            "level": 3,
            "description": "Sabes conducirte con la gracia de un noble embajador. Obtienes los siguientes beneficios.\n\nComprensión. Puedes lanzar el conjuro Entender idiomas, pero solo como ritual. Carisma es tu aptitud mágica para este conjuro.\n\nPolíglota. Aprendes un idioma de las tablas de idiomas. Cuando terminas un descanso largo, puedes reemplazar un idioma aprendido con este beneficio por otro idioma que hayas oído, visto signado o leído en las últimas 24 horas.\n\nBuen porte. Ganas competencia en una de las siguientes habilidades de tu elección: Perspicacia, Intimidación, Persuasión o Interpretación."
          },
          "group_recovery": {
            "name": "Recuperación en grupo",
            "level": 3,
            "description": "Cuando uses tu rasgo Tomar aliento para recuperar puntos de golpe, puedes elegir a un número de aliados dentro de una emanación de 30 pies originada en ti, hasta un máximo igual a tu modificador por Carisma, con un mínimo de un aliado. Cada uno de esos aliados recupera una cantidad de puntos de golpe igual a 1d4 + tu nivel de guerrero.\n\nUna vez que uses esta capacidad, no podrás volver a hacerlo hasta terminar un descanso corto o largo."
          },
          "team_tactics": {
            "name": "Tácticas de equipo",
            "level": 7,
            "description": "Cuando uses Recuperación en grupo, cada aliado elegido tiene ventaja en las pruebas de d20 hasta el comienzo de tu siguiente turno."
          },
          "rallying_surge": {
            "name": "Arremetida de arenga",
            "level": 10,
            "description": "Cuando uses tu Acción súbita, puedes elegir aliados dentro de una emanación de 30 pies originada en ti, hasta un número de aliados igual a tu modificador por Carisma, con un mínimo de uno. Cada uno de esos aliados puede usar inmediatamente su reacción para elegir una de las siguientes opciones.\n\nAtacar. El aliado realiza un ataque con un arma o un ataque sin armas.\n\nMoverse. El aliado se mueve hasta la mitad de su velocidad sin provocar ataques de oportunidad."
          },
          "shared_resilience": {
            "name": "Resiliencia compartida",
            "level": 15,
            "description": "Cuando un aliado que puedas ver a 60 pies o menos de ti falle una tirada de salvación, puedes usar tu reacción para gastar un uso de tu rasgo Indómito. El aliado puede repetir inmediatamente la tirada de salvación con un bonificador igual a tu nivel de guerrero; debe usar el nuevo resultado."
          },
          "inspiring_commander": {
            "name": "Comandante inspirador",
            "level": 18,
            "description": "Obtienes los siguientes beneficios.\n\nArenga reforzada. El área de efecto tanto de Recuperación en grupo como de Arremetida de arenga pasa a ser una emanación de 60 pies.\n\nValentía inquebrantable. Tienes inmunidad a los estados de hechizado y asustado."
          }
        }
      }
    },
    "tables": {
      "progression": {
        "title": "Rasgos de Guerrero",
        "columns": [
          "Nivel",
          "Bonificador por competencia",
          "Maestría con armas",
          "Tomar aliento",
          "Rasgos de clase"
        ],
        "rows": [
          [
            "1",
            "+2",
            "3",
            "2",
            "Estilo de Combate, Maestría con Armas, Tomar Aliento"
          ],
          [
            "2",
            "+2",
            "3",
            "2",
            "Acción Súbita, Mente Táctica"
          ],
          [
            "3",
            "+2",
            "3",
            "2",
            "Subclase de Guerrero"
          ],
          [
            "4",
            "+2",
            "4",
            "3",
            "Mejora de Característica"
          ],
          [
            "5",
            "+3",
            "4",
            "3",
            "Ataque Adicional, Desplazamiento Táctico"
          ],
          [
            "6",
            "+3",
            "4",
            "3",
            "Mejora de Característica"
          ],
          [
            "7",
            "+3",
            "4",
            "3",
            "Rasgo de subclase"
          ],
          [
            "8",
            "+3",
            "4",
            "3",
            "Mejora de Característica"
          ],
          [
            "9",
            "+4",
            "4",
            "3",
            "Indómito, Maestro Táctico"
          ],
          [
            "10",
            "+4",
            "5",
            "4",
            "Rasgo de subclase"
          ],
          [
            "11",
            "+4",
            "5",
            "4",
            "Dos Ataques Adicionales"
          ],
          [
            "12",
            "+4",
            "5",
            "4",
            "Mejora de Característica"
          ],
          [
            "13",
            "+5",
            "5",
            "4",
            "Ataques Estudiados"
          ],
          [
            "14",
            "+5",
            "5",
            "4",
            "Mejora de Característica"
          ],
          [
            "15",
            "+5",
            "5",
            "4",
            "Rasgo de subclase"
          ],
          [
            "16",
            "+5",
            "6",
            "4",
            "Mejora de Característica"
          ],
          [
            "17",
            "+6",
            "6",
            "4",
            "Acción Súbita, Indómito"
          ],
          [
            "18",
            "+6",
            "6",
            "4",
            "Rasgo de subclase"
          ],
          [
            "19",
            "+6",
            "6",
            "4",
            "Don Épico"
          ],
          [
            "20",
            "+6",
            "6",
            "4",
            "Tres Ataques Adicionales"
          ]
        ]
      }
    }
  },
  "hechicero": {
    "id": "hechicero",
    "name": "Hechicero",
    "primaryAbility": [
      "Carisma"
    ],
    "hitDie": "1d6",
    "savingThrows": [
      "Constitución",
      "Carisma"
    ],
    "skillChoices": {
      "choose": 2,
      "from": [
        "Conocimiento arcano",
        "Engaño",
        "Intimidación",
        "Perspicacia",
        "Persuasión",
        "Religión"
      ]
    },
    "weaponProficiencies": [
      "Armas sencillas"
    ],
    "armorTraining": [],
    "startingEquipment": {
      "options": [
        {
          "label": "A",
          "items": [
            "Lanza",
            "2 dagas",
            "Canalizador arcano (cristal)",
            "Paquete de explorador de mazmorras",
            "28 po"
          ]
        },
        {
          "label": "B",
          "items": [
            "50 po"
          ]
        }
      ]
    },
    "features": {
      "spellcasting_sorcerer": {
        "name": "Lanzamiento de Conjuros",
        "level": 1,
        "description": "Recurres a tu magia innata, lo que te permite lanzar conjuros. Consulta el capítulo 7 para ver las reglas sobre el lanzamiento de conjuros. La información presentada a continuación detalla cómo usar esas reglas con los conjuros de hechicero.\n\nTrucos. Conoces cuatro trucos de hechicero de tu elección. Cada vez que subas un nivel de hechicero, puedes sustituir uno de tus trucos de este rasgo por otro truco de hechicero de tu elección. Cuando alcanzas los niveles 4 y 10 de hechicero, aprendes otro truco de hechicero de tu elección.\n\nEspacios de conjuro. La tabla “Rasgos de hechicero” muestra cuántos espacios de conjuro tienes para lanzar tus conjuros de nivel 1 y superiores. Recuperas todos los espacios utilizados tras finalizar un descanso largo.\n\nConjuros preparados de nivel 1 y superiores. Preparas una serie de conjuros de nivel 1 y superiores, que son los que podrás lanzar con este rasgo. Para empezar, elige dos conjuros de hechicero de nivel 1. El número de conjuros de tu lista aumenta conforme subes de nivel de hechicero, como se muestra en la columna “Conjuros preparados” de la tabla “Rasgos de hechicero”. Cuando ese número aumente, elige conjuros de hechicero adicionales hasta que el número de conjuros de tu lista coincida con el número de la tabla. Estos conjuros deben ser de un nivel para el que tengas espacios de conjuro.\n\nSi otro rasgo de hechicero te proporciona conjuros que siempre tienes preparados, esos conjuros no cuentan para el total que puedes preparar con este rasgo, pero sí cuentan como conjuros de hechicero para ti.\n\nCambiar los conjuros preparados. Cada vez que subas un nivel de hechicero, puedes sustituir un conjuro de tu lista por otro conjuro de hechicero para el que tengas espacios de conjuro.\n\nAptitud mágica. El Carisma es tu aptitud mágica en lo que respecta a tus conjuros de hechicero.\n\nCanalizador mágico. Puedes utilizar un canalizador arcano como canalizador mágico para tus conjuros de hechicero."
      },
      "innate_sorcery": {
        "name": "Hechicería Innata",
        "level": 1,
        "description": "Un suceso de tu pasado dejó una marca indeleble en ti, llenándote de magia latente. Como acción adicional, puedes desatar esa magia durante 1 minuto, durante el cual obtienes los siguientes beneficios:\n\n• La CD de salvación de tus conjuros de hechicero aumenta en 1.\n• Tienes ventaja en las tiradas de ataque de los conjuros de hechicero que lances.\n\nPuedes usar este rasgo dos veces y recuperas todos los usos tras finalizar un descanso largo."
      },
      "font_of_magic": {
        "name": "Fuente de Magia",
        "level": 2,
        "description": "Puedes acceder a una abundante fuente de magia que nace de tu interior. Esta fuente se representa mediante una serie de puntos de hechicería, que te permiten crear una gran variedad de efectos mágicos.\n\nPosees 2 puntos de hechicería, pero obtendrás más conforme subas de nivel en esta clase, como se muestra en la columna “Puntos de hechicería” de la tabla “Rasgos de hechicero”. No puedes tener más puntos de hechicería que la cantidad indicada en la tabla para tu nivel. Recuperas todos los puntos de hechicería gastados tras finalizar un descanso largo.\n\nPuedes emplear tus puntos de hechicería en las opciones presentadas a continuación y en otros rasgos que usan dichos puntos, como el de Metamagia.\n\nConvertir espacios de conjuro en puntos de hechicería. Puedes gastar un espacio de conjuro para obtener tantos puntos de hechicería como el nivel del espacio (no requiere acción).\n\nCrear espacios de conjuro. Como acción adicional, puedes transformar puntos de hechicería que no hayas gastado aún en un espacio de conjuro. La tabla “Crear espacios de conjuro” indica el coste de crear un espacio de conjuro de un nivel determinado y el nivel mínimo de hechicero que debes tener para crear un espacio. Puedes crear espacios de conjuro de nivel 5 como máximo. Cualquier espacio creado mediante este rasgo se desvanece tras finalizar un descanso largo."
      },
      "metamagic": {
        "name": "Metamagia",
        "level": 2,
        "description": "Como la magia fluye desde tu interior, puedes alterar tus conjuros y adaptarlos a conveniencia. Consigues dos de las opciones de metamagia de tu elección del apartado “Opciones de metamagia” que aparece más adelante en la descripción de esta clase. Usarás las opciones elegidas para modificar temporalmente los conjuros que lances. Para usar una, deberás gastar la cantidad de puntos de hechicería que cueste.\n\nSolo puedes usar una opción de metamagia en un conjuro cuando lo lanzas, a menos que se especifique otra cosa en las opciones.\n\nCada vez que subas un nivel de hechicero, puedes sustituir una de las opciones de metamagia por otra que no conozcas. Obtienes dos opciones más en el nivel 10 de hechicero y otras dos más en el nivel 17."
      },
      "sorcerer_subclass": {
        "name": "Subclase de Hechicero",
        "level": 3,
        "description": "Consigues una subclase de hechicero de tu elección.\n\nLas subclases de Hechicería aberrante, Hechicería de magia salvaje, Hechicería dracónica y Hechicería mecánica se detallan tras la descripción de esta clase. Una subclase es una especialización que te proporciona rasgos cuando alcanzas ciertos niveles de hechicero. De aquí en adelante, obtienes todos los rasgos de tu subclase que sean de tu nivel de hechicero e inferiores."
      },
      "ability_score_improvement_sorcerer": {
        "name": "Mejora de Característica",
        "level": 4,
        "description": "Obtienes la dote Mejora de característica u otra dote de tu elección para la que cumplas las condiciones.\n\nVuelves a obtener este rasgo en los niveles 8, 12 y 16 de hechicero."
      },
      "sorcerous_restoration": {
        "name": "Recuperación Mágica",
        "level": 5,
        "description": "Tras finalizar un descanso corto, puedes recuperar una cantidad de puntos de hechicería igual o inferior a la mitad de tu nivel de hechicero, redondeando hacia abajo.\n\nCuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo."
      },
      "sorcery_incarnate": {
        "name": "Encarnación Mágica",
        "level": 7,
        "description": "Si no te quedan usos del rasgo Hechicería innata, puedes usarlo si gastas 2 puntos de hechicería cuando empleas la acción adicional para activarlo.\n\nAdemás, mientras tengas activo el rasgo Hechicería innata, puedes usar hasta dos de tus opciones de metamagia en cada conjuro que lances."
      },
      "epic_boon_sorcerer": {
        "name": "Don Épico",
        "level": 19,
        "description": "Obtienes una dote de don épico u otra dote de tu elección para la que cumplas las condiciones. Se recomienda Don del viaje dimensional."
      },
      "arcane_apotheosis": {
        "name": "Apoteosis Arcana",
        "level": 20,
        "description": "Mientras tengas activo el rasgo Hechicería innata, puedes usar una opción de metamagia en cada uno de tus turnos sin gastar puntos de hechicería."
      }
    },
    "levels": {
      "1": {
        "features": [
          "spellcasting_sorcerer",
          "innate_sorcery"
        ],
        "cantripsKnown": 4,
        "preparedSpells": 2,
        "proficiencyBonus": "+2"
      },
      "2": {
        "features": [
          "font_of_magic",
          "metamagic"
        ],
        "sorceryPoints": 2,
        "cantripsKnown": 4,
        "preparedSpells": 4,
        "proficiencyBonus": "+2"
      },
      "3": {
        "features": [
          "sorcerer_subclass"
        ],
        "sorceryPoints": 3,
        "cantripsKnown": 4,
        "preparedSpells": 6,
        "proficiencyBonus": "+2"
      },
      "4": {
        "features": [
          "ability_score_improvement_sorcerer"
        ],
        "sorceryPoints": 4,
        "cantripsKnown": 5,
        "preparedSpells": 7,
        "proficiencyBonus": "+2"
      },
      "5": {
        "features": [
          "sorcerous_restoration"
        ],
        "sorceryPoints": 5,
        "cantripsKnown": 5,
        "preparedSpells": 9,
        "proficiencyBonus": "+3"
      },
      "6": {
        "sorceryPoints": 6,
        "cantripsKnown": 5,
        "preparedSpells": 10,
        "proficiencyBonus": "+3"
      },
      "7": {
        "features": [
          "sorcery_incarnate"
        ],
        "sorceryPoints": 7,
        "cantripsKnown": 5,
        "preparedSpells": 11,
        "proficiencyBonus": "+3"
      },
      "8": {
        "features": [
          "ability_score_improvement_sorcerer"
        ],
        "sorceryPoints": 8,
        "cantripsKnown": 5,
        "preparedSpells": 12,
        "proficiencyBonus": "+3"
      },
      "9": {
        "sorceryPoints": 9,
        "cantripsKnown": 5,
        "preparedSpells": 14,
        "proficiencyBonus": "+4"
      },
      "10": {
        "features": [
          "metamagic"
        ],
        "sorceryPoints": 10,
        "cantripsKnown": 6,
        "preparedSpells": 15,
        "proficiencyBonus": "+4"
      },
      "11": {
        "sorceryPoints": 11,
        "cantripsKnown": 6,
        "preparedSpells": 16,
        "proficiencyBonus": "+4"
      },
      "12": {
        "features": [
          "ability_score_improvement_sorcerer"
        ],
        "sorceryPoints": 12,
        "cantripsKnown": 6,
        "preparedSpells": 16,
        "proficiencyBonus": "+4"
      },
      "13": {
        "sorceryPoints": 13,
        "cantripsKnown": 6,
        "preparedSpells": 17,
        "proficiencyBonus": "+5"
      },
      "14": {
        "sorceryPoints": 14,
        "cantripsKnown": 6,
        "preparedSpells": 17,
        "proficiencyBonus": "+5"
      },
      "15": {
        "sorceryPoints": 15,
        "cantripsKnown": 6,
        "preparedSpells": 18,
        "proficiencyBonus": "+5"
      },
      "16": {
        "features": [
          "ability_score_improvement_sorcerer"
        ],
        "sorceryPoints": 16,
        "cantripsKnown": 6,
        "preparedSpells": 18,
        "proficiencyBonus": "+5"
      },
      "17": {
        "features": [
          "metamagic"
        ],
        "sorceryPoints": 17,
        "cantripsKnown": 6,
        "preparedSpells": 19,
        "proficiencyBonus": "+6"
      },
      "18": {
        "sorceryPoints": 18,
        "cantripsKnown": 6,
        "preparedSpells": 20,
        "proficiencyBonus": "+6"
      },
      "19": {
        "features": [
          "epic_boon_sorcerer"
        ],
        "sorceryPoints": 19,
        "cantripsKnown": 6,
        "preparedSpells": 21,
        "proficiencyBonus": "+6"
      },
      "20": {
        "features": [
          "arcane_apotheosis"
        ],
        "sorceryPoints": 20,
        "cantripsKnown": 6,
        "preparedSpells": 22,
        "proficiencyBonus": "+6"
      }
    },
    "metamagicOptions": {
      "conjuro_acelerado": {
        "name": "Conjuro Acelerado",
        "cost": 2,
        "description": "Cuando lanzas un conjuro con un tiempo de lanzamiento de una acción, puedes gastar 2 puntos de hechicería para hacer que el tiempo de lanzamiento sea de una acción adicional a efectos de este lanzamiento. No puedes modificar un conjuro de esta forma si ya has lanzado un conjuro de nivel 1 o superior en el turno actual ni lanzar un conjuro de nivel 1 o superior este turno tras modificar un conjuro de esta forma."
      },
      "conjuro_buscador": {
        "name": "Conjuro Buscador",
        "cost": 1,
        "description": "Si realizas una tirada de ataque para un conjuro y fallas, puedes gastar 1 punto de hechicería para volver a tirar el d20, pero tendrás que usar el nuevo resultado.\n\nPuedes usar Conjuro buscador aunque ya hayas empleado una opción diferente de metamagia durante el lanzamiento del conjuro."
      },
      "conjuro_cuidadoso": {
        "name": "Conjuro Cuidadoso",
        "cost": 1,
        "description": "Cuando lanzas un conjuro que obliga a otras criaturas a realizar una tirada de salvación, puedes proteger a algunas de esas criaturas de la fuerza completa del conjuro. Para ello, gasta 1 punto de hechicería y escoge hasta una cantidad de criaturas igual a tu modificador por Carisma, con un mínimo de una criatura. Las criaturas elegidas tienen éxito automáticamente en sus tiradas de salvación contra el conjuro y no reciben daño alguno si normalmente recibirían la mitad de daño del mismo al superar una tirada de salvación."
      },
      "conjuro_distante": {
        "name": "Conjuro Distante",
        "cost": 1,
        "description": "Cuando lanzas un conjuro que tenga como mínimo un alcance de 5 pies, puedes gastar 1 punto de hechicería para duplicar el alcance del conjuro. Como alternativa, cuando lanzas un conjuro que tenga un alcance de toque, puedes gastar 1 punto de hechicería para hacer que su alcance sea de 30 pies."
      },
      "conjuro_extendido": {
        "name": "Conjuro Extendido",
        "cost": 1,
        "description": "Cuando lanzas un conjuro que tenga una duración de al menos 1 minuto, puedes gastar 1 punto de hechicería para duplicar su duración, hasta un máximo de 24 horas.\n\nSi el conjuro afectado requiere concentración, tienes ventaja en cualquier tirada de salvación que hagas para mantener la concentración."
      },
      "conjuro_gemelo": {
        "name": "Conjuro Gemelo",
        "cost": 1,
        "description": "Cuando lances un conjuro, como hechizar persona, que puede lanzarse mediante un espacio de conjuro de niveles superiores para hacer objetivo a criaturas adicionales, puedes gastar 1 punto de hechicería para aumentar el nivel efectivo del conjuro en 1."
      },
      "conjuro_intensificado": {
        "name": "Conjuro Intensificado",
        "cost": 2,
        "description": "Cuando lanzas un conjuro que obliga como mínimo a una criatura a hacer una tirada de salvación, puedes gastar 2 puntos de hechicería para que uno de los objetivos del conjuro tenga desventaja en las tiradas de salvación que realice contra el conjuro."
      },
      "conjuro_potenciado": {
        "name": "Conjuro Potenciado",
        "cost": 1,
        "description": "Cuando tiras el daño de un conjuro, puedes gastar 1 punto de hechicería para repetir la tirada de, como mucho, tantos dados de daño como tu modificador por Carisma, con un mínimo de un dado, y deberás usar los nuevos resultados.\n\nPuedes usar Conjuro potenciado aunque ya hayas empleado una opción diferente de metamagia durante el lanzamiento del conjuro."
      },
      "conjuro_sutil": {
        "name": "Conjuro Sutil",
        "cost": 1,
        "description": "Cuando lanzas un conjuro, puedes gastar 1 punto de hechicería para hacerlo sin componentes verbales, somáticos ni materiales, salvo por componentes materiales que se consuman como parte del conjuro o que tengan un coste especificado en él."
      },
      "conjuro_transmutado": {
        "name": "Conjuro Transmutado",
        "cost": 1,
        "description": "Cuando lances un conjuro que inflija un tipo de daño de la siguiente lista, puedes gastar 1 punto de hechicería para cambiar ese tipo de daño a uno de los otros tipos indicados: ácido, frío, fuego, relámpago, trueno y veneno."
      }
    },
    "subclasses": {
      "hechiceria_aberrante": {
        "name": "Hechicería Aberrante",
        "levels": {
          "3": {
            "features": [
              "psionic_spells",
              "telepathic_speech"
            ]
          },
          "6": {
            "features": [
              "psychic_defenses",
              "psionic_sorcery"
            ]
          },
          "14": {
            "features": [
              "revelation_in_flesh"
            ]
          },
          "18": {
            "features": [
              "warping_implosion"
            ]
          }
        },
        "features": {
          "psionic_spells": {
            "name": "Conjuros Psiónicos",
            "level": 3,
            "description": "Cuando alcances un nivel de hechicero especificado en la tabla “Conjuros psiónicos”, a partir de entonces siempre tendrás preparados los conjuros que se indican. Estos conjuros no cuentan para el número de conjuros que puedes preparar, pero sí cuentan como conjuros de hechicero para ti."
          },
          "telepathic_speech": {
            "name": "Habla Telepática",
            "level": 3,
            "description": "Puedes establecer una conexión telepática con la mente de otra criatura. Como acción adicional, elige una criatura que puedas ver a 30 pies o menos de ti. La criatura elegida y tú podréis comunicaros telepáticamente mientras estéis a una distancia máxima igual a 1 milla × tu modificador por Carisma, con un mínimo de 1 milla.\n\nPara entenderos, debéis emplear mentalmente un idioma que ambos conozcáis. La conexión telepática dura un número de minutos igual a tu nivel de hechicero. Terminará antes de tiempo si usas esta capacidad para establecer una conexión con otra criatura."
          },
          "psychic_defenses": {
            "name": "Defensas Psíquicas",
            "level": 6,
            "description": "Tienes resistencia al daño psíquico y ventaja en las tiradas de salvación para evitar o poner fin a los estados de asustado o hechizado."
          },
          "psionic_sorcery": {
            "name": "Hechicería Psiónica",
            "level": 6,
            "description": "Cuando lanzas cualquier conjuro de nivel 1 o superior de tu rasgo Conjuros psiónicos, puedes hacerlo gastando un espacio de conjuro de la forma normal o gastando una cantidad de puntos de hechicería igual al nivel del conjuro.\n\nSi lanzas el conjuro usando puntos de hechicería, no requerirá componentes verbales ni somáticos, ni tampoco componentes materiales, a menos que se consuman como parte del conjuro o que tengan un coste especificado en él."
          },
          "revelation_in_flesh": {
            "name": "Revelación en Carne",
            "level": 14,
            "description": "Puedes desatar la aberrante verdad que se esconde en tu interior. Como acción adicional, puedes gastar 1 o más puntos de hechicería para alterar mágicamente tu cuerpo durante 10 minutos. Por cada punto de hechicería que gastes, obtienes uno de los siguientes beneficios, a tu elección, y sus efectos duran hasta que la alteración finalice.\n\nAdaptación acuática. Obtienes una velocidad nadando igual al doble de tu velocidad y puedes respirar bajo el agua. Te crecen branquias en el cuello o se te despliegan tras las orejas, y te salen membranas entre los dedos o te brotan cilios que se retuercen.\n\nMovimiento anélido. Tu cuerpo, junto con cualquier equipo que vistas o lleves contigo, se vuelve baboso y maleable. Puedes colarte por cualquier espacio hasta de 1 pulgada de ancho y puedes gastar 5 pies de movimiento para escapar de limitaciones no mágicas o del estado de agarrado.\n\nVer lo invisible. Puedes ver a cualquier criatura invisible que esté a 60 pies o menos de ti que no esté tras una cobertura completa. Además, tus ojos se vuelven negros o se convierten en zarcillos sensoriales serpenteantes.\n\nVuelo brillante. Obtienes una velocidad volando igual a tu velocidad y puedes levitar. Cuando vuelas, tu piel resplandece recubierta de mucosa o luz espectral."
          },
          "warping_implosion": {
            "name": "Implosión Deformadora",
            "level": 18,
            "description": "Puedes desencadenar una anomalía que distorsiona el espacio. Como acción de magia, te teletransportas a un espacio sin ocupar que puedas ver a 120 pies o menos de ti.\n\nInmediatamente después de que desaparezcas, cada criatura que esté a 30 pies o menos del espacio que hayas abandonado deberá realizar una tirada de salvación de Fuerza contra tu CD de salvación de conjuros. Si la falla, recibirá 3d10 de daño de fuerza y será arrastrada directamente al espacio que hayas abandonado, acabando en un espacio sin ocupar lo más cercano posible a tu espacio anterior. Si la supera, solo sufrirá la mitad de ese daño.\n\nCuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo, a menos que gastes 5 puntos de hechicería, sin requerir acción, para restablecer su uso."
          }
        },
        "tables": {
          "psionic_spells_table": {
            "title": "Conjuros Psiónicos",
            "columns": [
              "Nivel de hechicero",
              "Conjuros"
            ],
            "rows": [
              [
                "3",
                "Brazos de Hadar, calmar emociones, detectar pensamientos, fragmento mental, susurros discordantes"
              ],
              [
                "5",
                "Hambre de Hadar, enviar"
              ],
              [
                "7",
                "Invocar aberración, tentáculos negros de Evard"
              ],
              [
                "9",
                "Enlace telepático de Rary, telequinesis"
              ]
            ]
          }
        }
      },
      "hechiceria_magia_salvaje": {
        "name": "Hechicería de Magia Salvaje",
        "levels": {
          "3": {
            "features": [
              "tides_of_chaos",
              "wild_magic_surge"
            ]
          },
          "6": {
            "features": [
              "bend_luck"
            ]
          },
          "14": {
            "features": [
              "controlled_chaos"
            ]
          },
          "18": {
            "features": [
              "tamed_surge"
            ]
          }
        },
        "features": {
          "tides_of_chaos": {
            "name": "Mareas del Caos",
            "level": 3,
            "description": "Puedes manipular el propio caos para otorgarte ventaja en una prueba con d20 antes de que tires el dado. Una vez que lo hagas, deberás lanzar un conjuro de hechicero con un espacio de conjuro o finalizar un descanso largo para poder usar este rasgo de nuevo.\n\nSi lanzas un conjuro de hechicero usando un espacio de conjuro antes de finalizar un descanso largo, tira automáticamente en la tabla “Sobrecarga de magia salvaje”."
          },
          "wild_magic_surge": {
            "name": "Sobrecarga de Magia Salvaje",
            "level": 3,
            "description": "Tu lanzamiento de conjuros puede desencadenar sobrecargas de magia descontrolada. Una vez por turno, puedes tirar 1d20 nada más lanzar un conjuro de hechicero con un espacio de conjuro. Si sacas un 20, tira en la tabla “Sobrecarga de magia salvaje” para crear un efecto mágico.\n\nSi el efecto mágico es un conjuro, este será demasiado salvaje para verse afectado por tu metamagia."
          },
          "bend_luck": {
            "name": "Doblegar la Suerte",
            "level": 6,
            "description": "Tienes la capacidad de retorcer el destino con tu magia salvaje. Inmediatamente después de que otra criatura que puedas ver tire para una prueba con d20, puedes usar una reacción y gastar 1 punto de hechicería para tirar 1d4 y aplicar el resultado como bonificador o penalizador, tú eliges, a ese d20."
          },
          "controlled_chaos": {
            "name": "Caos Controlado",
            "level": 14,
            "description": "Adquieres un ápice de control sobre las sobrecargas de tu magia salvaje. Siempre que tires en la tabla “Sobrecarga de magia salvaje”, puedes lanzar dos veces y usar el resultado que quieras."
          },
          "tamed_surge": {
            "name": "Sobrecarga Domada",
            "level": 18,
            "description": "Inmediatamente después de lanzar un conjuro de hechicero con un espacio de conjuro, puedes crear un efecto de tu elección de la tabla “Sobrecarga de magia salvaje” en lugar de tirar en la tabla. Puedes elegir cualquier efecto de la tabla excepto la última fila, y si el efecto elegido implica una tirada, debes hacerla.\n\nCuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo."
          }
        },
        "tables": {
          "wild_magic_surge_table": {
            "title": "Sobrecarga de Magia Salvaje",
            "dice": "1d100",
            "entries": [
              {
                "range": "01-04",
                "effect": "Tira en esta tabla al principio de cada uno de tus turnos durante el próximo minuto, ignorando este resultado en esas tiradas."
              },
              {
                "range": "05-08",
                "effect": "Una criatura amistosa contigo aparecerá en un espacio sin ocupar aleatorio a 60 pies o menos de ti. La criatura está bajo el control de tu DM y desaparecerá 1 minuto después. Tira 1d4 para determinar la criatura: 1 modron duodron, 2 flumph, 10 piesodron monodron, 4 unicornio."
              },
              {
                "range": "09-12",
                "effect": "Durante el próximo minuto, recuperas 5 puntos de golpe al principio de cada uno de tus turnos."
              },
              {
                "range": "13-16",
                "effect": "Las criaturas tienen desventaja en las tiradas de salvación contra el siguiente conjuro que lances durante el próximo minuto que implique tiradas de salvación."
              },
              {
                "range": "17-20",
                "effect": "Sufres un efecto durante 1 minuto. Tira 1d8: 1 música etérea audible a 5 pies, 2 aumentas una categoría de tamaño, 3 barba de plumas, 4 debes gritar al hablar, 5 mariposas ilusorias a 10 pies, 6 ojo en la frente con ventaja en pruebas de Sabiduría (Percepción), 7 burbujas rosas al hablar, 8 piel azul durante 24 horas o hasta que se le ponga fin al efecto con un conjuro levantar maldición."
              },
              {
                "range": "21-24",
                "effect": "Durante el próximo minuto, todos tus conjuros con un tiempo de lanzamiento de una acción poseen un tiempo de lanzamiento de una acción adicional."
              },
              {
                "range": "25-28",
                "effect": "Te teletransportas al Plano Astral hasta el final de tu siguiente turno. A continuación, vuelves al espacio que ocupabas antes o al más cercano sin ocupar si ese espacio ya está ocupado."
              },
              {
                "range": "29-32",
                "effect": "La siguiente vez que lances un conjuro que cause daño durante el próximo minuto, no tiras los dados de daño del conjuro. En su lugar, usa el número más alto posible para cada dado de daño."
              },
              {
                "range": "33-36",
                "effect": "Tienes resistencia a todo el daño durante el próximo minuto."
              },
              {
                "range": "37-40",
                "effect": "Te transformas en una planta en una maceta hasta el principio de tu siguiente turno. Mientras seas una planta, tendrás el estado de incapacitado y serás vulnerable a todo el daño. Si tus puntos de golpe se reducen a 0, se romperá la maceta y volverás a tu forma anterior."
              },
              {
                "range": "41-44",
                "effect": "Durante el próximo minuto, puedes teletransportarte hasta 20 pies como acción adicional durante cada uno de tus turnos."
              },
              {
                "range": "45-48",
                "effect": "Tú y hasta tres criaturas que elijas a 30 pies o menos de ti tenéis el estado de invisibles durante 1 minuto. Esta invisibilidad terminará inmediatamente después de que una criatura realice una tirada de ataque, cause daño o lance un conjuro."
              },
              {
                "range": "49-52",
                "effect": "Un escudo espectral levita cerca de ti durante el próximo minuto, lo que te otorga un bonificador de +2 a la CA e inmunidad a proyectil mágico."
              },
              {
                "range": "53-56",
                "effect": "Puedes realizar una acción extra durante este turno."
              },
              {
                "range": "57-60",
                "effect": "Lanzas un conjuro aleatorio. Si normalmente requiere concentración, no la necesitará en este caso; el conjuro se mantiene toda su duración. Tira 1d10 para determinar el conjuro: 1 bola de fuego; 2 confusión; 3 grasa; 4 imagen múltiple; 5 levitar sobre ti; 6 nube de oscurecimiento; 7 polimorfar sobre ti, y si fallas la tirada de salvación te conviertes en una cabra; 8 proyectil mágico como conjuro de nivel 5; 9 ver invisibilidad; 10 volar sobre una criatura aleatoria que esté a 60 pies o menos de ti."
              },
              {
                "range": "61-64",
                "effect": "Durante el próximo minuto, cualquier objeto no mágico inflamable que toques y no esté llevando o vistiendo otra criatura se prenderá fuego. Si es un objeto que puede sufrir daño, recibe 1d4 de daño de fuego y arde."
              },
              {
                "range": "65-68",
                "effect": "Si mueres durante la próxima hora, volverás inmediatamente a la vida como si te hubieran lanzado el conjuro reencarnar."
              },
              {
                "range": "69-72",
                "effect": "Tienes el estado de asustado hasta el final de tu siguiente turno. Tu DM establece el motivo del miedo."
              },
              {
                "range": "73-76",
                "effect": "Te teletransportas hasta 60 pies a un espacio sin ocupar que puedas ver."
              },
              {
                "range": "77-80",
                "effect": "Una criatura aleatoria a 60 pies o menos de ti tendrá el estado de envenenada durante 1d4 horas."
              },
              {
                "range": "81-84",
                "effect": "Durante el próximo minuto, emites una luz brillante en un radio de 30 pies. Cualquier criatura que acabe su turno a 5 pies o menos de ti tendrá el estado de cegada hasta el final de su siguiente turno."
              },
              {
                "range": "85-88",
                "effect": "Hasta tres criaturas de tu elección que puedas ver a 30 pies o menos de ti sufren 4d10 de daño necrótico. Recuperas una cantidad de puntos de golpe igual al daño necrótico causado."
              },
              {
                "range": "89-92",
                "effect": "Hasta tres criaturas de tu elección que puedas ver a 30 pies o menos de ti sufren 4d10 de daño de relámpago."
              },
              {
                "range": "93-96",
                "effect": "Tú y todas las criaturas que estén a 30 pies o menos de ti tenéis vulnerabilidad al daño perforante durante el próximo minuto."
              },
              {
                "range": "97-00",
                "effect": "Tira 1d6. Si el resultado es 1, recuperas 2d10 puntos de golpe; si es 2, un aliado de tu elección a 300 pies o menos de ti recupera 2d10 puntos de golpe; si es 3, recuperas tu espacio de conjuro de menor nivel; si es 4, un aliado de tu elección a 300 pies o menos de ti recupera su espacio de conjuro de menor nivel; si es 5, recuperas todos los puntos de hechicería; si es 6, se aplican a la vez todos los efectos de la fila 17-20."
              }
            ]
          }
        }
      },
      "hechiceria_draconica": {
        "name": "Hechicería Dracónica",
        "levels": {
          "3": {
            "features": [
              "draconic_spells",
              "draconic_resilience"
            ]
          },
          "6": {
            "features": [
              "elemental_affinity"
            ]
          },
          "14": {
            "features": [
              "dragon_wings"
            ]
          },
          "18": {
            "features": [
              "dragon_companion"
            ]
          }
        },
        "features": {
          "draconic_spells": {
            "name": "Conjuros Dracónicos",
            "level": 3,
            "description": "Cuando alcances un nivel de hechicero especificado en la tabla “Conjuros dracónicos”, a partir de entonces siempre tendrás preparados los conjuros que se indican. Estos conjuros no cuentan para el número de conjuros que puedes preparar, pero sí cuentan como conjuros de hechicero para ti."
          },
          "draconic_resilience": {
            "name": "Resistencia Dracónica",
            "level": 3,
            "description": "La magia de tu cuerpo manifiesta tu don dracónico de forma física. Tus puntos de golpe máximos aumentan en 3 y en 1 más por cada nivel de hechicero que subas en el futuro.\n\nAdemás, partes de tu cuerpo se cubren de escamas similares a las de los dragones. Mientras no lleves armadura, tu clase de armadura base será igual a 10 más tus modificadores por Destreza y Carisma."
          },
          "elemental_affinity": {
            "name": "Afinidad Elemental",
            "level": 6,
            "description": "Tu magia dracónica tiene afinidad con un tipo de daño asociado a los dragones. Elige uno de estos tipos: ácido, frío, fuego, relámpago o veneno.\n\nTienes resistencia a ese tipo de daño. Además, cuando lances un conjuro que inflija daño de ese tipo, puedes sumar tu modificador por Carisma a una tirada de daño del conjuro."
          },
          "dragon_wings": {
            "name": "Alas de Dragón",
            "level": 14,
            "description": "Como acción adicional, puedes hacer que te crezcan alas dracónicas de la espalda. Las alas permanecen 1 hora o hasta que las hagas desaparecer, sin requerir acción. Mientras dure el efecto, tienes una velocidad volando de 60 pies.\n\nCuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo, a menos que gastes 3 puntos de hechicería, sin requerir acción, para restablecer su uso."
          },
          "dragon_companion": {
            "name": "Compañero Dragón",
            "level": 18,
            "description": "Puedes lanzar invocar dragón sin ningún componente material. También puedes lanzarlo una vez sin gastar un espacio de conjuro y recuperas la capacidad de hacerlo de esta forma tras finalizar un descanso largo.\n\nCuando empieces a lanzar el conjuro, puedes modificarlo para que no requiera concentración. Si lo haces, la duración del conjuro es de 1 minuto para ese lanzamiento."
          }
        },
        "tables": {
          "draconic_spells_table": {
            "title": "Conjuros Dracónicos",
            "columns": [
              "Nivel de hechicero",
              "Conjuros"
            ],
            "rows": [
              [
                "3",
                "Aliento de dragón, alterar el propio aspecto, orbe cromático, orden imperiosa"
              ],
              [
                "5",
                "Terror, volar"
              ],
              [
                "7",
                "Hechizar monstruo, ojo arcano"
              ],
              [
                "9",
                "Conocer las leyendas, invocar dragón"
              ]
            ]
          }
        }
      },
      "hechiceria_mecanica": {
        "name": "Hechicería Mecánica",
        "levels": {
          "3": {
            "features": [
              "clockwork_spells",
              "restore_balance"
            ]
          },
          "6": {
            "features": [
              "bastion_of_law"
            ]
          },
          "14": {
            "features": [
              "trance_of_order"
            ]
          },
          "18": {
            "features": [
              "clockwork_cavalcade"
            ]
          }
        },
        "features": {
          "clockwork_spells": {
            "name": "Conjuros Mecánicos",
            "level": 3,
            "description": "Cuando alcances un nivel de hechicero especificado en la tabla “Conjuros mecánicos”, a partir de entonces siempre tendrás preparados los conjuros que se indican. Estos conjuros no cuentan para el número de conjuros que puedes preparar, pero sí cuentan como conjuros de hechicero para ti.\n\nAdemás, consulta la tabla “Manifestaciones del orden” y elige o determina al azar el modo en que quieres que se manifieste tu conexión con el orden mientras lanzas cualquiera de tus conjuros de hechicero.",
            "tables": [
              {
                "title": "Conjuros Mecánicos",
                "columns": [
                  "Nivel de hechicero",
                  "Conjuros"
                ],
                "rows": [
                  [
                    "3",
                    "Alarma, auxilio, protección contra el bien y el mal, restablecimiento menor"
                  ],
                  [
                    "5",
                    "Disipar magia, protección contra energía"
                  ],
                  [
                    "7",
                    "Invocar autómata, libertad de movimiento"
                  ],
                  [
                    "9",
                    "Muro de fuerza, restablecimiento mayor"
                  ]
                ]
              },
              {
                "title": "Manifestaciones del Orden",
                "columns": [
                  "1d6",
                  "Manifestación"
                ],
                "rows": [
                  [
                    "1",
                    "Unos engranajes espectrales levitan tras de ti."
                  ],
                  [
                    "2",
                    "Las manecillas de un reloj giran en tus ojos."
                  ],
                  [
                    "3",
                    "Tu piel resplandece con un brillo metálico."
                  ],
                  [
                    "4",
                    "Objetos geométricos y ecuaciones flotantes recubren tu cuerpo."
                  ],
                  [
                    "5",
                    "Tu canalizador mágico adopta temporalmente la forma de un mecanismo de relojería Diminuto."
                  ],
                  [
                    "6",
                    "Tanto tú como aquellos afectados por tu magia podéis escuchar el tictac de los engranajes o el timbre de un reloj."
                  ]
                ]
              }
            ]
          },
          "restore_balance": {
            "name": "Restablecer Equilibrio",
            "level": 3,
            "description": "Tu conexión con el plano del orden absoluto te permite ecualizar momentos caóticos. Cuando una criatura que puedas ver a 60 pies o menos de ti esté a punto de tirar un d20 con ventaja o desventaja, puedes usar una reacción para impedir que la tirada tenga ventaja o desventaja.\n\nPuedes usar este rasgo una cantidad de veces igual a tu modificador por Carisma, con un mínimo de una vez, y recuperas todos los usos tras finalizar un descanso largo."
          },
          "bastion_of_law": {
            "name": "Bastión de la Ley",
            "level": 6,
            "description": "Puedes acceder a la gran ecuación de la existencia para imbuir a una criatura de un escudo resplandeciente de orden. Como acción de magia, puedes gastar de 1 a 5 puntos de hechicería para crear una protección mágica a tu alrededor o alrededor de otra criatura que puedas ver a 30 pies o menos de ti.\n\nEsta protección está representada por un número de d8 igual a la cantidad de puntos de hechicería gastados para crearla. Si la criatura protegida recibe daño, puede gastar varios de esos dados, tirarlos y restar el resultado al daño recibido.\n\nLa protección durará hasta que finalices un descanso largo o hasta que vuelvas a usar este rasgo."
          },
          "trance_of_order": {
            "name": "Trance de Orden",
            "level": 14,
            "description": "Obtienes la capacidad de alinear tu consciencia con los infinitos cálculos de Mechanus. Como acción adicional, puedes entrar en este estado durante 1 minuto. Mientras dure, las tiradas de ataque contra ti no podrán tener ventaja y siempre que realices una prueba con d20, podrás sustituir un resultado de 9 o menos en el d20 por un 10.\n\nCuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo, a menos que gastes 5 puntos de hechicería, sin requerir acción, para restablecer su uso."
          },
          "clockwork_cavalcade": {
            "name": "Cabalgata Mecánica",
            "level": 18,
            "description": "Invocas espíritus del orden temporalmente para acabar con el desorden que te rodea. Como acción de magia, invocas los espíritus en un cubo de 30 pies de lado que se origina en ti. Los espíritus tienen aspecto de modrons o de otros autómatas de tu elección. Los espíritus son intangibles e invulnerables y crean los efectos indicados a continuación dentro del cubo antes de desvanecerse.\n\nCuando uses esta acción, no podrás volver a hacerlo hasta que finalices un descanso largo, a menos que gastes 7 puntos de hechicería, sin requerir acción, para restablecer su uso.\n\nCurar. Los espíritus permiten recuperar hasta 100 puntos de golpe, repartidos como tú elijas entre una cantidad de criaturas de tu elección que estén en el cubo.\n\nReparar. Todos los objetos dañados que estén por completo en el cubo se reparan al instante.\n\nDisipar. Se acaban todos los conjuros de nivel 6 o inferior sobre criaturas u objetos de tu elección que estén en el cubo."
          }
        },
        "tables": {
          "clockwork_spells_table": {
            "title": "Conjuros Mecánicos",
            "columns": [
              "Nivel de hechicero",
              "Conjuros"
            ],
            "rows": [
              [
                "3",
                "Alarma, auxilio, protección contra el bien y el mal, restablecimiento menor"
              ],
              [
                "5",
                "Disipar magia, protección contra energía"
              ],
              [
                "7",
                "Invocar autómata, libertad de movimiento"
              ],
              [
                "9",
                "Muro de fuerza, restablecimiento mayor"
              ]
            ]
          },
          "manifestaciones_del_orden_table": {
            "title": "Manifestaciones del Orden",
            "columns": [
              "1d6",
              "Manifestación"
            ],
            "rows": [
              [
                "1",
                "Unos engranajes espectrales levitan tras de ti."
              ],
              [
                "2",
                "Las manecillas de un reloj giran en tus ojos."
              ],
              [
                "3",
                "Tu piel resplandece con un brillo metálico."
              ],
              [
                "4",
                "Objetos geométricos y ecuaciones flotantes recubren tu cuerpo."
              ],
              [
                "5",
                "Tu canalizador mágico adopta temporalmente la forma de un mecanismo de relojería Diminuto."
              ],
              [
                "6",
                "Tanto tú como aquellos afectados por tu magia podéis escuchar el tictac de los engranajes o el timbre de un reloj."
              ]
            ]
          }
        }
      },
      "hechiceria_de_fuego_de_conjuros": {
        "name": "Hechicería de Fuego Mágico",
        "source": "Forgotten Realms: Heroes of Faerûn / Unearthed Arcana 2025",
        "levels": {
          "3": {
            "features": [
              "spellfire_burst",
              "spellfire_spells"
            ]
          },
          "6": {
            "features": [
              "absorb_spells"
            ]
          },
          "14": {
            "features": [
              "honed_spellfire"
            ]
          },
          "18": {
            "features": [
              "crown_of_spellfire"
            ]
          }
        },
        "features": {
          "spellfire_burst": {
            "name": "Estallido de fuego mágico",
            "level": 3,
            "description": "Cuando gastes al menos 1 punto de Hechicería como parte de una acción de Magia o de una acción adicional en tu turno, puedes desatar uno de los siguientes efectos mágicos de tu elección. Solo puedes hacerlo una vez por turno.\n\nLlamas fortalecedoras. Tú o una criatura que puedas ver a 30 pies o menos de ti gana puntos de golpe temporales iguales a 1d4 + tu modificador por Carisma.\n\nFuego radiante. Una criatura que puedas ver a 30 pies o menos de ti debe superar una tirada de salvación de Destreza contra la CD de salvación de tus conjuros o recibir 1d6 de daño de fuego o radiante, a tu elección."
          },
          "spellfire_spells": {
            "name": "Conjuros de fuego de conjuros",
            "level": 3,
            "description": "Cuando alcances un nivel de hechicero especificado en la tabla «Conjuros de fuego de conjuros», siempre tendrás preparados los conjuros indicados.",
            "table": {
              "title": "Conjuros de Fuego de Conjuros",
              "columns": [
                "Nivel de hechicero",
                "Conjuros preparados"
              ],
              "rows": [
                [
                  "3",
                  "Curar heridas, Saeta guía, Restablecimiento menor, Rayo abrasador"
                ],
                [
                  "5",
                  "Aura de vitalidad, Disipar magia"
                ],
                [
                  "7",
                  "Escudo de fuego, Muro de fuego"
                ],
                [
                  "9",
                  "Restablecimiento mayor, Golpe flamígero"
                ]
              ]
            }
          },
          "absorb_spells": {
            "name": "Absorber conjuros",
            "level": 6,
            "description": "Siempre tienes preparado Contrahechizo.\n\nAdemás, siempre que un objetivo falle la tirada de salvación contra un Contrahechizo que lances, recuperas 1d4 puntos de Hechicería."
          },
          "honed_spellfire": {
            "name": "Fuego mágico perfeccionado",
            "level": 14,
            "description": "Tu Estallido de fuego de conjuros mejora. Añades tu nivel de hechicero a los puntos de golpe temporales otorgados por Llamas fortalecedoras, y el 1d6 de Fuego radiante pasa a ser 3d6."
          },
          "crown_of_spellfire": {
            "name": "Corona de fuego mágico",
            "level": 18,
            "description": "Como acción adicional, obtienes los siguientes beneficios durante 1 minuto. Una vez que uses esta acción adicional, no podrás volver a hacerlo hasta terminar un descanso largo, salvo que gastes 7 puntos de Hechicería, sin requerir acción, para recuperar su uso.\n\nFuerza vital ardiente. Una vez por turno, cuando seas impactado por una tirada de ataque, puedes gastar un número de dados de golpe hasta un máximo igual a tu modificador por Carisma, con un mínimo de uno. Tira los dados gastados y reduce el daño de ese ataque en una cantidad igual al total obtenido + tu nivel de hechicero.\n\nVuelo. Ganas una velocidad de vuelo de 60 pies y puedes mantenerte flotando.\n\nEvasión mágica. Cuando estés sometido a un conjuro o efecto mágico que te permita hacer una tirada de salvación para sufrir solo la mitad del daño, en su lugar no sufres daño si tienes éxito en la salvación y solo la mitad si fallas. No puedes usar este beneficio si tienes el estado de incapacitado."
          }
        },
        "tables": {
          "spellfire_spells_table": {
            "title": "Conjuros de Fuego de Conjuros",
            "columns": [
              "Nivel de hechicero",
              "Conjuros preparados"
            ],
            "rows": [
              [
                "3",
                "Curar heridas, Saeta guía, Restablecimiento menor, Rayo abrasador"
              ],
              [
                "5",
                "Aura de vitalidad, Disipar magia"
              ],
              [
                "7",
                "Escudo de fuego, Muro de fuego"
              ],
              [
                "9",
                "Restablecimiento mayor, Golpe flamígero"
              ]
            ]
          }
        }
      }
    },
    "tables": {
      "sorcerer_progression": {
        "title": "Rasgos de Hechicero",
        "columns": [
          "Nivel",
          "Bonificador por competencia",
          "Rasgos de clase",
          "Puntos de hechicería",
          "Trucos",
          "Conjuros preparados",
          "1",
          "2",
          "3",
          "4",
          "5",
          "6",
          "7",
          "8",
          "9"
        ],
        "rows": [
          [
            "1",
            "+2",
            "Lanzamiento de conjuros, Hechicería innata",
            "—",
            "4",
            "2",
            "2",
            "—",
            "—",
            "—",
            "—",
            "—",
            "—",
            "—",
            "—"
          ],
          [
            "2",
            "+2",
            "Fuente de magia, Metamagia",
            "2",
            "4",
            "4",
            "3",
            "—",
            "—",
            "—",
            "—",
            "—",
            "—",
            "—",
            "—"
          ],
          [
            "3",
            "+2",
            "Subclase de hechicero",
            "3",
            "4",
            "6",
            "4",
            "2",
            "—",
            "—",
            "—",
            "—",
            "—",
            "—",
            "—"
          ],
          [
            "4",
            "+2",
            "Mejora de característica",
            "4",
            "5",
            "7",
            "4",
            "3",
            "—",
            "—",
            "—",
            "—",
            "—",
            "—",
            "—"
          ],
          [
            "5",
            "+3",
            "Recuperación mágica",
            "5",
            "5",
            "9",
            "4",
            "3",
            "2",
            "—",
            "—",
            "—",
            "—",
            "—",
            "—"
          ],
          [
            "6",
            "+3",
            "Rasgo de subclase",
            "6",
            "5",
            "10",
            "4",
            "3",
            "3",
            "—",
            "—",
            "—",
            "—",
            "—",
            "—"
          ],
          [
            "7",
            "+3",
            "Encarnación mágica",
            "7",
            "5",
            "11",
            "4",
            "3",
            "3",
            "1",
            "—",
            "—",
            "—",
            "—",
            "—"
          ],
          [
            "8",
            "+3",
            "Mejora de característica",
            "8",
            "5",
            "12",
            "4",
            "3",
            "3",
            "2",
            "—",
            "—",
            "—",
            "—",
            "—"
          ],
          [
            "9",
            "+4",
            "—",
            "9",
            "5",
            "14",
            "4",
            "3",
            "3",
            "3",
            "1",
            "—",
            "—",
            "—",
            "—"
          ],
          [
            "10",
            "+4",
            "Metamagia",
            "10",
            "6",
            "15",
            "4",
            "3",
            "3",
            "3",
            "2",
            "—",
            "—",
            "—",
            "—"
          ],
          [
            "11",
            "+4",
            "—",
            "11",
            "6",
            "16",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "—",
            "—",
            "—"
          ],
          [
            "12",
            "+4",
            "Mejora de característica",
            "12",
            "6",
            "16",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "—",
            "—",
            "—"
          ],
          [
            "13",
            "+5",
            "—",
            "13",
            "6",
            "17",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "—",
            "—"
          ],
          [
            "14",
            "+5",
            "Rasgo de subclase",
            "14",
            "6",
            "17",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "—",
            "—"
          ],
          [
            "15",
            "+5",
            "—",
            "15",
            "6",
            "18",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "1",
            "—"
          ],
          [
            "16",
            "+5",
            "Mejora de característica",
            "16",
            "6",
            "18",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "1",
            "—"
          ],
          [
            "17",
            "+6",
            "Metamagia",
            "17",
            "6",
            "19",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "1",
            "1"
          ],
          [
            "18",
            "+6",
            "Rasgo de subclase",
            "18",
            "6",
            "20",
            "4",
            "3",
            "3",
            "3",
            "3",
            "1",
            "1",
            "1",
            "1"
          ],
          [
            "19",
            "+6",
            "Don épico",
            "19",
            "6",
            "21",
            "4",
            "3",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "1"
          ],
          [
            "20",
            "+6",
            "Apoteosis arcana",
            "20",
            "6",
            "22",
            "4",
            "3",
            "3",
            "3",
            "3",
            "2",
            "2",
            "1",
            "1"
          ]
        ]
      },
      "create_spell_slots": {
        "title": "Crear Espacios de Conjuro",
        "columns": [
          "Nivel del espacio de conjuro",
          "Coste en puntos de hechicería",
          "Nivel mínimo de hechicero"
        ],
        "rows": [
          [
            "1",
            "2",
            "2"
          ],
          [
            "2",
            "3",
            "3"
          ],
          [
            "3",
            "5",
            "5"
          ],
          [
            "4",
            "6",
            "7"
          ],
          [
            "5",
            "7",
            "9"
          ]
        ]
      }
    }
  },
  "mago": {
    "id": "mago",
    "name": "Mago",
    "primaryAbility": [
      "Inteligencia"
    ],
    "hitDie": "1d6",
    "savingThrows": [
      "Inteligencia",
      "Sabiduría"
    ],
    "skillChoices": {
      "choose": 2,
      "from": [
        "Conocimiento arcano",
        "Historia",
        "Investigación",
        "Medicina",
        "Naturaleza",
        "Perspicacia",
        "Religión"
      ]
    },
    "weaponProficiencies": [
      "Armas sencillas"
    ],
    "armorTraining": [],
    "startingEquipment": {
      "options": [
        {
          "label": "A",
          "items": [
            "2 dagas",
            "Canalizador arcano (bastón)",
            "Libro de conjuros",
            "Paquete de erudito",
            "Túnica",
            "5 po"
          ]
        },
        {
          "label": "B",
          "items": [
            "55 po"
          ]
        }
      ]
    },
    "features": {
      "wizard_spellcasting": {
        "name": "Lanzamiento de Conjuros",
        "level": 1,
        "description": "Como estudiante de magia arcana que eres, has aprendido a lanzar conjuros. Consulta el capítulo 7 para ver las reglas sobre el lanzamiento de conjuros. La información presentada a continuación detalla cómo usar esas reglas con los conjuros de mago.\n\nTrucos. Conoces tres trucos de mago de tu elección. Tras finalizar un descanso largo, puedes sustituir uno de tus trucos de este rasgo por otro truco de mago de tu elección. Cuando alcanzas los niveles 4 y 10 de mago, aprendes otro truco de mago de tu elección.\n\nLibro de conjuros. Tu aprendizaje de mago culminó con la creación de un libro único: tu libro de conjuros. Es un objeto Diminuto que pesa 1,5 kg, contiene 100 páginas y solo podéis leerlo tú o alguien que lance identificar. Tú decides la apariencia y los materiales del libro. El libro contiene los conjuros de nivel 1 y superiores que conoces. Empiezas con seis conjuros de mago de nivel 1 de tu elección.\n\nSiempre que subas un nivel de mago después del 1, añade dos conjuros de mago de tu elección a tu libro de conjuros. Estos conjuros deben ser de un nivel para el que tengas espacios de conjuro, como se indica en la tabla Rasgos de mago.\n\nEspacios de conjuro. La tabla Rasgos de mago muestra cuántos espacios de conjuro tienes para lanzar tus conjuros de nivel 1 y superiores. Recuperas todos los espacios utilizados tras finalizar un descanso largo.\n\nConjuros preparados de nivel 1 y superiores. Preparas una serie de conjuros de nivel 1 y superiores, que son los que podrás lanzar con este rasgo. Para ello, elige cuatro conjuros de tu libro de conjuros. Estos conjuros deben ser de un nivel para el que tengas espacios de conjuro. El número de conjuros de tu lista aumenta conforme subes de nivel de mago, como se muestra en la columna Conjuros preparados de la tabla Rasgos de mago. Cuando ese número aumente, elige conjuros de mago adicionales hasta que el número de conjuros de tu lista coincida con el número de la tabla. Estos conjuros deben ser de un nivel para el que tengas espacios de conjuro.\n\nSi otro rasgo de mago te proporciona conjuros que siempre tienes preparados, esos conjuros no cuentan para el total que puedes preparar con este rasgo, pero sí que cuentan como conjuros de mago para ti.\n\nCambiar los conjuros preparados. Tras finalizar un descanso largo, puedes cambiar los conjuros que tienes preparados sustituyendo los que quieras por otros de tu libro de conjuros.\n\nAptitud mágica. La Inteligencia es tu aptitud mágica en lo que respecta a tus conjuros de mago.\n\nCanalizador mágico. Puedes utilizar un canalizador arcano o tu libro de conjuros como canalizador mágico para tus conjuros de mago."
      },
      "ritual_adept": {
        "name": "Adepto en Rituales",
        "level": 1,
        "description": "Puedes lanzar de forma ritual cualquier conjuro de mago que figure en tu libro de conjuros y esté marcado como ritual. No necesitas tenerlo preparado, pero debes leerlo del libro para lanzarlo de esta forma."
      },
      "arcane_recovery": {
        "name": "Recuperación Arcana",
        "level": 1,
        "description": "Puedes recuperar parte de tu energía mágica estudiando tu libro de conjuros. Tras finalizar un descanso corto, puedes elegir espacios de conjuro gastados y recuperarlos. La suma de niveles de estos espacios de conjuro debe ser igual o inferior a la mitad de tu nivel de mago, redondeando hacia arriba, y ninguno de los espacios puede ser de nivel 6 o más.\n\nCuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo."
      },
      "academic": {
        "name": "Académico",
        "level": 2,
        "description": "Mientras estudiabas magia, también te especializaste en otro campo. Elige una de las siguientes habilidades en la que tengas competencia: Conocimiento arcano, Historia, Investigación, Medicina, Naturaleza o Religión. Ganas pericia en la habilidad elegida.",
        "extraBlock": {
          "type": "table_panel",
          "title": "AMPLIAR Y SUSTITUIR UN LIBRO DE CONJUROS",
          "noTable": true,
          "content": "Copiar un conjuro en tu libro. Cuando encuentres un conjuro de mago de nivel 1 o superior, podrás añadirlo a tu libro de conjuros si es de un nivel que puedas preparar y dispones del tiempo suficiente para copiarlo. La transcripción exige 2 horas y 50 po por cada nivel del conjuro. Después, podrás preparar el conjuro como cualquier otro de tu libro.\n\nCopiar el libro. Puedes copiar un conjuro de tu libro de conjuros en otro libro. Este proceso es el mismo que cuando copias un conjuro en tu libro, pero más rápido, pues ya sabes cómo lanzarlo. Solo necesitas dedicar 1 hora e invertir 10 po por cada nivel del conjuro copiado.\n\nSi perdieras tu libro de conjuros, podrías recurrir al mismo procedimiento para transcribir los conjuros de mago que tengas preparados en ese momento en un nuevo libro. Para seguir llenándolo, tendrás que volver a encontrar conjuros nuevos. Por este motivo, muchos magos tienen un libro de conjuros de reserva."
        }
      },
      "wizard_subclass": {
        "name": "Subclase de Mago",
        "level": 3,
        "description": "Consigues una subclase de mago de tu elección.\n\nLas subclases de abjurador, adivino, evocador e ilusionista se detallan tras la descripción de esta clase. Una subclase es una especialización que te proporciona rasgos cuando alcanzas ciertos niveles de mago. De aquí en adelante, obtienes todos los rasgos de tu subclase que sean de tu nivel de mago e inferiores."
      },
      "ability_score_improvement_wizard": {
        "name": "Mejora de Característica",
        "level": 4,
        "description": "Obtienes la dote Mejora de característica u otra dote de tu elección para la que cumplas las condiciones.\n\nVuelves a obtener este rasgo en los niveles 8, 12 y 16 de mago."
      },
      "memorize_spell": {
        "name": "Memorizar Conjuro",
        "level": 5,
        "description": "Tras finalizar un descanso corto, puedes estudiar tu libro de conjuros y sustituir un conjuro de mago de nivel 1 o superior que tengas preparado con tu rasgo Lanzamiento de conjuros por otro de nivel 1 o superior del libro."
      },
      "spell_mastery": {
        "name": "Maestría sobre Conjuros",
        "level": 18,
        "description": "Has alcanzado tal maestría sobre ciertos conjuros que puedes lanzarlos a voluntad. Elige un conjuro de nivel 1 y otro de nivel 2 de tu libro de conjuros con un tiempo de lanzamiento de una acción. Siempre tienes esos conjuros preparados y puedes lanzarlos a su nivel más bajo sin gastar un espacio de conjuro. Para lanzar cualquiera de ellos a un nivel superior, deberás gastar un espacio de conjuro.\n\nTras finalizar un descanso largo, puedes estudiar tu libro de conjuros y sustituir uno de los conjuros por otro del libro del mismo nivel que cumpla los requisitos."
      },
      "epic_boon_wizard": {
        "name": "Don Épico",
        "level": 19,
        "description": "Obtienes una dote de don épico u otra dote de tu elección para la que cumplas las condiciones. Se recomienda Don del recuerdo de conjuros."
      },
      "signature_spells": {
        "name": "Conjuros Característicos",
        "level": 20,
        "description": "Escoge dos conjuros de nivel 3 que figuren en tu libro de conjuros como conjuros característicos. Siempre tienes esos conjuros preparados y puedes lanzar cada uno de ellos una vez a nivel 3 sin gastar un espacio de conjuro.\n\nUna vez que los lances, no podrás volver a hacerlo de este modo hasta que finalices un descanso corto o largo.\n\nPara lanzar cualquiera de ellos a un nivel superior, deberás gastar un espacio de conjuro."
      }
    },
    "levels": {
      "1": {
        "features": [
          "wizard_spellcasting",
          "ritual_adept",
          "arcane_recovery"
        ],
        "cantripsKnown": 3,
        "preparedSpells": 4,
        "proficiencyBonus": "+2"
      },
      "2": {
        "features": [
          "academic"
        ],
        "cantripsKnown": 3,
        "preparedSpells": 5,
        "proficiencyBonus": "+2"
      },
      "3": {
        "features": [
          "wizard_subclass"
        ],
        "cantripsKnown": 3,
        "preparedSpells": 6,
        "proficiencyBonus": "+2"
      },
      "4": {
        "features": [
          "ability_score_improvement_wizard"
        ],
        "cantripsKnown": 4,
        "preparedSpells": 7,
        "proficiencyBonus": "+2"
      },
      "5": {
        "features": [
          "memorize_spell"
        ],
        "cantripsKnown": 4,
        "preparedSpells": 9,
        "proficiencyBonus": "+3"
      },
      "6": {
        "cantripsKnown": 4,
        "preparedSpells": 10,
        "proficiencyBonus": "+3"
      },
      "7": {
        "cantripsKnown": 4,
        "preparedSpells": 11,
        "proficiencyBonus": "+3"
      },
      "8": {
        "features": [
          "ability_score_improvement_wizard"
        ],
        "cantripsKnown": 4,
        "preparedSpells": 12,
        "proficiencyBonus": "+3"
      },
      "9": {
        "cantripsKnown": 4,
        "preparedSpells": 14,
        "proficiencyBonus": "+4"
      },
      "10": {
        "cantripsKnown": 5,
        "preparedSpells": 15,
        "proficiencyBonus": "+4"
      },
      "11": {
        "cantripsKnown": 5,
        "preparedSpells": 16,
        "proficiencyBonus": "+4"
      },
      "12": {
        "features": [
          "ability_score_improvement_wizard"
        ],
        "cantripsKnown": 5,
        "preparedSpells": 16,
        "proficiencyBonus": "+4"
      },
      "13": {
        "cantripsKnown": 5,
        "preparedSpells": 17,
        "proficiencyBonus": "+5"
      },
      "14": {
        "cantripsKnown": 5,
        "preparedSpells": 18,
        "proficiencyBonus": "+5"
      },
      "15": {
        "cantripsKnown": 5,
        "preparedSpells": 19,
        "proficiencyBonus": "+5"
      },
      "16": {
        "features": [
          "ability_score_improvement_wizard"
        ],
        "cantripsKnown": 5,
        "preparedSpells": 21,
        "proficiencyBonus": "+5"
      },
      "17": {
        "cantripsKnown": 5,
        "preparedSpells": 22,
        "proficiencyBonus": "+6"
      },
      "18": {
        "features": [
          "spell_mastery"
        ],
        "cantripsKnown": 5,
        "preparedSpells": 23,
        "proficiencyBonus": "+6"
      },
      "19": {
        "features": [
          "epic_boon_wizard"
        ],
        "cantripsKnown": 5,
        "preparedSpells": 24,
        "proficiencyBonus": "+6"
      },
      "20": {
        "features": [
          "signature_spells"
        ],
        "cantripsKnown": 5,
        "preparedSpells": 25,
        "proficiencyBonus": "+6"
      }
    },
    "subclasses": {
      "abjurador": {
        "name": "Abjurador",
        "levels": {
          "3": {
            "features": [
              "abjuration_savant",
              "arcane_ward"
            ]
          },
          "6": {
            "features": [
              "projected_ward"
            ]
          },
          "10": {
            "features": [
              "spell_breaker"
            ]
          },
          "14": {
            "features": [
              "spell_resistance"
            ]
          }
        },
        "features": {
          "abjuration_savant": {
            "name": "Experto en Abjuración",
            "level": 3,
            "description": "Elige dos conjuros de mago de la escuela de abjuración de nivel 2 o inferior y añádelos a tu libro de conjuros sin coste.\n\nAdemás, siempre que consigas un nuevo nivel de espacios de conjuro de esta clase, puedes añadir un conjuro de mago de la escuela de abjuración a tu libro de conjuros sin coste. El conjuro elegido debe ser de un nivel para el que tengas espacios de conjuro."
          },
          "arcane_ward": {
            "name": "Salvaguarda Arcana",
            "level": 3,
            "description": "Puedes tejer una protección mágica a tu alrededor. Cuando lances un conjuro de abjuración con un espacio de conjuro, puedes usar simultáneamente una hebra mágica del conjuro para crear sobre ti una salvaguarda que durará hasta que finalices un descanso largo.\n\nEsta salvaguarda tiene una cantidad de puntos de golpe máximos igual al doble de tu nivel de mago más tu modificador por Inteligencia. Cada vez que fueras a recibir daño, la salvaguarda lo hará en tu lugar. Si tienes alguna resistencia o vulnerabilidad, aplícalas antes de reducir los puntos de golpe de la salvaguarda. Si el daño reduce a 0 los puntos de golpe de la salvaguarda, recibirás el daño restante. La salvaguarda no podrá absorber daño mientras tenga 0 puntos de golpe, pero su magia permanecerá.\n\nSiempre que lances un conjuro de abjuración con un espacio de conjuro, la salvaguarda recuperará una cantidad de puntos de golpe igual al doble del nivel del espacio de conjuro. Como alternativa, puedes gastar un espacio de conjuro como acción adicional para que la salvaguarda recupere una cantidad de puntos de golpe igual al doble del nivel del espacio de conjuro gastado.\n\nUna vez creada la salvaguarda, deberás finalizar un descanso largo para poder formarla de nuevo."
          },
          "projected_ward": {
            "name": "Salvaguarda Proyectada",
            "level": 6,
            "description": "Cuando una criatura que puedas ver a 30 pies o menos de ti reciba daño, puedes utilizar una reacción para hacer que tu salvaguarda arcana absorba dicho daño. Si ese daño reduce a 0 los puntos de golpe de la salvaguarda, la criatura protegida recibirá el daño restante. Si esa criatura tiene alguna resistencia o vulnerabilidad, aplícalas antes de reducir los puntos de golpe de la salvaguarda."
          },
          "spell_breaker": {
            "name": "Rompeconjuros",
            "level": 10,
            "description": "Siempre tienes los conjuros Contrahechizo y Disipar magia preparados. Además, puedes lanzar Disipar magia como acción adicional y sumar tu bonificador por competencia a su prueba de característica.\n\nCuando lanzas cualquiera de esos conjuros con un espacio de conjuro, el espacio no se gasta si el conjuro no consigue neutralizar otro."
          },
          "spell_resistance": {
            "name": "Resistencia a Conjuros",
            "level": 14,
            "description": "Tienes ventaja en las tiradas de salvación contra conjuros y posees resistencia contra el daño de conjuros."
          }
        }
      },
      "adivino": {
        "name": "Adivino",
        "levels": {
          "3": {
            "features": [
              "divination_savant",
              "portent"
            ]
          },
          "6": {
            "features": [
              "expert_divination"
            ]
          },
          "10": {
            "features": [
              "the_third_eye"
            ]
          },
          "14": {
            "features": [
              "greater_portent"
            ]
          }
        },
        "features": {
          "divination_savant": {
            "name": "Experto en Adivinación",
            "level": 3,
            "description": "Elige dos conjuros de mago de la escuela de adivinación de nivel 2 o inferior y añádelos a tu libro de conjuros sin coste.\n\nAdemás, siempre que consigas un nuevo nivel de espacios de conjuro de esta clase, puedes añadir un conjuro de mago de la escuela de adivinación a tu libro de conjuros sin coste. El conjuro elegido debe ser de un nivel para el que tengas espacios de conjuro."
          },
          "portent": {
            "name": "Presagio",
            "level": 3,
            "description": "Empiezas a vislumbrar retazos del futuro. Tras finalizar un descanso largo, tira 2d20 y anota los resultados.\n\nPuedes sustituir cualquier prueba con d20 que hagáis tú o una criatura que puedas ver por uno de los resultados presagiados. Debes indicar que haces esto antes de llevar a cabo la tirada y solo puedes sustituir una tirada de esta forma una vez por turno.\n\nCada resultado presagiado solo puede usarse una vez. Tras finalizar un descanso largo, pierdes todos los resultados presagiados que no hayas utilizado."
          },
          "expert_divination": {
            "name": "Adivino Avezado",
            "level": 6,
            "description": "Lanzar conjuros de adivinación te resulta tan fácil que solo requiere una pequeña parte de tus esfuerzos. Cuando lances un conjuro de adivinación usando un espacio de nivel 2 o superior, recuperarás un espacio de conjuro gastado. El espacio que recuperes debe ser de un nivel inferior al del espacio gastado y no puede ser superior a 5."
          },
          "the_third_eye": {
            "name": "El Tercer Ojo",
            "level": 10,
            "description": "Puedes aumentar tus poderes de percepción. Como acción adicional, elige uno de los siguientes beneficios, que durará hasta que empieces un descanso corto o largo. No podrás volver a usar este rasgo hasta que finalices un descanso corto o largo.\n\nComprensión superior. Puedes leer cualquier idioma.\n\nVer invisibilidad. Puedes lanzar Ver invisibilidad sin gastar un espacio de conjuro.\n\nVisión en la oscuridad. Obtienes visión en la oscuridad hasta 120 pies."
          },
          "greater_portent": {
            "name": "Presagio Mayor",
            "level": 14,
            "description": "Las visiones de tus sueños se intensifican y dibujan en tu mente una imagen más clara de lo que está por acontecer. Tira 3d20 cuando uses el rasgo Presagio en vez de dos."
          }
        }
      },
      "evocador": {
        "name": "Evocador",
        "levels": {
          "3": {
            "features": [
              "evocation_savant",
              "potent_cantrip"
            ]
          },
          "6": {
            "features": [
              "sculpt_spells"
            ]
          },
          "10": {
            "features": [
              "empowered_evocation"
            ]
          },
          "14": {
            "features": [
              "overchannel"
            ]
          }
        },
        "features": {
          "evocation_savant": {
            "name": "Experto en Evocación",
            "level": 3,
            "description": "Elige dos conjuros de mago de la escuela de evocación de nivel 2 o inferior y añádelos a tu libro de conjuros sin coste.\n\nAdemás, siempre que consigas un nuevo nivel de espacios de conjuro de esta clase, puedes añadir un conjuro de mago de la escuela de evocación a tu libro de conjuros sin coste. El conjuro elegido debe ser de un nivel para el que tengas espacios de conjuro."
          },
          "potent_cantrip": {
            "name": "Truco Potente",
            "level": 3,
            "description": "Tus trucos que causen daño pueden afectar incluso a las criaturas que hayan evitado la peor parte del efecto. Cuando lances un truco a una criatura y falles la tirada de ataque o el objetivo supere la tirada de salvación contra el truco, el objetivo recibirá la mitad del daño del truco, si es que causa alguno, pero no sufrirá ningún otro de sus efectos adicionales."
          },
          "sculpt_spells": {
            "name": "Esculpir Conjuros",
            "level": 6,
            "description": "Puedes crear espacios de relativa seguridad en el interior de los efectos generados por tu magia de evocación. Cuando lances un conjuro de evocación que afecte a otras criaturas que puedas ver, puedes elegir una cantidad de ellas igual a 1 más el nivel del conjuro. Las criaturas elegidas tienen éxito automáticamente en sus tiradas de salvación contra el conjuro y no reciben daño alguno si normalmente recibirían la mitad de daño al superar una tirada de salvación."
          },
          "empowered_evocation": {
            "name": "Evocación Potenciada",
            "level": 10,
            "description": "Siempre que lances un conjuro de mago de la escuela de evocación, puedes sumar tu modificador por Inteligencia a una tirada de daño del conjuro."
          },
          "overchannel": {
            "name": "Sobrecanalizar",
            "level": 14,
            "description": "Puedes aumentar el poder de tus conjuros. Cuando lances un conjuro de mago que cause daño usando un espacio de conjuro de niveles entre 1 y 5, puedes infligir el máximo daño posible con ese conjuro el turno en que lo lanzas.\n\nLa primera vez que hagas esto no sufrirás ningún efecto negativo, pero si usas este rasgo de nuevo sin haber finalizado un descanso largo antes, recibirás 2d12 de daño necrótico por cada nivel del espacio de conjuro inmediatamente después de lanzarlo. Este daño ignora cualquier resistencia e inmunidad.\n\nCada vez que vuelvas a utilizar este rasgo sin haber terminado un descanso largo, el daño necrótico por cada nivel del conjuro aumentará en 1d12."
          }
        }
      },
      "ilusionista": {
        "name": "Ilusionista",
        "levels": {
          "3": {
            "features": [
              "illusion_savant",
              "improved_illusions"
            ]
          },
          "6": {
            "features": [
              "phantasmal_creatures"
            ]
          },
          "10": {
            "features": [
              "illusory_self"
            ]
          },
          "14": {
            "features": [
              "illusory_reality"
            ]
          }
        },
        "features": {
          "illusion_savant": {
            "name": "Experto en Ilusionismo",
            "level": 3,
            "description": "Elige dos conjuros de mago de la escuela de ilusionismo de nivel 2 o inferior y añádelos a tu libro de conjuros sin coste.\n\nAdemás, siempre que consigas un nuevo nivel de espacios de conjuro de esta clase, puedes añadir un conjuro de mago de la escuela de ilusionismo a tu libro de conjuros sin coste. El conjuro elegido debe ser de un nivel para el que tengas espacios de conjuro."
          },
          "improved_illusions": {
            "name": "Ilusiones Mejoradas",
            "level": 3,
            "description": "Puedes lanzar conjuros de ilusionismo sin emplear componentes verbales. Además, si un conjuro de ilusionismo que lances tiene un alcance de 10 pies o más, su alcance aumenta en 60 pies.\n\nTambién conoces el truco Ilusión menor. Si ya lo conoces, aprendes otro truco de mago de tu elección. Este truco no cuenta para tu límite de trucos conocidos. Además, puedes lanzar Ilusión menor como acción adicional y crear tanto un sonido como una imagen en el mismo lanzamiento."
          },
          "phantasmal_creatures": {
            "name": "Criaturas Fantasmales",
            "level": 6,
            "description": "Siempre tienes los conjuros Invocar bestia e Invocar feérico preparados. Cuando lances cualquiera de ellos, puedes cambiar su escuela a ilusionismo, lo que hará que la criatura invocada tenga un aspecto espectral.\n\nPuedes lanzar la versión de ilusionismo de cada conjuro sin gastar un espacio de conjuro, pero si lo haces de este modo, la criatura tendrá la mitad de sus puntos de golpe. Cuando lances cualquiera de ellos sin un espacio de conjuro, deberás finalizar un descanso largo antes de poder volver a lanzar ese conjuro de esta forma."
          },
          "illusory_self": {
            "name": "Yo Ilusorio",
            "level": 10,
            "description": "Cuando una criatura te acierte con una tirada de ataque, puedes usar una reacción para interponer un doble ilusorio entre la criatura atacante y tú. El ataque fallará automáticamente y la ilusión se disipará.\n\nCuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso corto o largo. También puedes restablecer su uso gastando un espacio de conjuro de nivel 2 o superior, sin requerir acción."
          },
          "illusory_reality": {
            "name": "Realidad Ilusoria",
            "level": 14,
            "description": "Has aprendido a tejer magia de las sombras en tus ilusiones para dotarlas de una pseudorrealidad. Cuando lances un conjuro de ilusionismo con un espacio de conjuro, puedes elegir un objeto no mágico e inanimado que forme parte de la ilusión para hacerlo real. Puedes realizar esto en tu turno como acción adicional mientras el conjuro esté activo.\n\nEl objeto es real durante 1 minuto, durante el que no podrá causar daño ni aplicar estados. Por ejemplo, podrías crear la ilusión de un puente que cruza un abismo y hacerlo real para poder recorrerlo."
          }
        }
      },
      "cantor_de_la_hoja": {
        "name": "Canto de Espadas",
        "source": "Forgotten Realms: Heroes of Faerûn / Unearthed Arcana 2025",
        "levels": {
          "3": {
            "features": [
              "bladesong",
              "training_in_war_and_song"
            ]
          },
          "6": {
            "features": [
              "extra_attack_bladesinger"
            ]
          },
          "10": {
            "features": [
              "song_of_defense"
            ]
          },
          "14": {
            "features": [
              "song_of_victory"
            ]
          }
        },
        "features": {
          "bladesong": {
            "name": "Canto de Espadas",
            "level": 3,
            "description": "Como acción adicional, invocas una magia élfica llamada Canto de la hoja, siempre que no lleves armadura ni uses escudo.\n\nEl Canto de la hoja dura 1 minuto y termina antes si tienes el estado de incapacitado, si te pones armadura o usas un escudo, o si utilizas dos manos para hacer un ataque con un arma. Puedes terminar el Canto de la hoja en cualquier momento, sin requerir acción.\n\nMientras el Canto de la hoja esté activo, obtienes los siguientes beneficios. Puedes invocar el Canto de la hoja un número de veces igual a tu modificador por Inteligencia, con un mínimo de una vez, y recuperas todos los usos gastados al terminar un descanso largo.\n\nAgilidad. Ganas un bonificador a tu CA igual a tu modificador por Inteligencia, con un mínimo de +1, y tu velocidad aumenta en 10 pies.\n\nTrabajo de hoja. Siempre que ataques con un arma con la que tengas competencia, puedes usar tu modificador por Inteligencia para las tiradas de ataque y daño en lugar de Fuerza o Destreza.\n\nConcentración. Cuando hagas una tirada de salvación de Constitución para mantener la concentración, puedes sumar tu modificador por Inteligencia al resultado."
          },
          "training_in_war_and_song": {
            "name": "Entrenamiento en guerra y magia",
            "level": 3,
            "description": "Ganas competencia con todas las armas marciales cuerpo a cuerpo que no tengan las propiedades A dos manos ni Pesada. Puedes usar un arma cuerpo a cuerpo con la que tengas competencia como canalizador mágico para tus conjuros de mago.\n\nAdemás, ganas competencia en una de las siguientes habilidades de tu elección: Acrobacias, Atletismo, Interpretación o Persuasión."
          },
          "extra_attack_bladesinger": {
            "name": "Ataque adicional",
            "level": 6,
            "description": "Puedes atacar dos veces, en lugar de una, siempre que realices la acción de Atacar en tu turno.\n\nAdemás, puedes lanzar uno de tus trucos de mago que tenga un tiempo de lanzamiento de una acción en lugar de uno de esos ataques."
          },
          "song_of_defense": {
            "name": "Canto de defensa",
            "level": 10,
            "description": "Cuando recibas daño mientras tu Canto de la hoja esté activo, puedes usar tu reacción para gastar un espacio de conjuro y reducir el daño recibido en una cantidad igual a cinco veces el nivel del espacio de conjuro gastado."
          },
          "song_of_victory": {
            "name": "Canto de victoria",
            "level": 14,
            "description": "Después de lanzar un conjuro que tenga un tiempo de lanzamiento de una acción, puedes hacer un ataque con un arma como acción adicional."
          }
        }
      }
    },
    "tables": {
      "wizard_progression": {
        "title": "Rasgos de Mago",
        "columns": [
          "Nivel",
          "Bonificador por competencia",
          "Rasgos de clase",
          "Trucos",
          "Conjuros preparados",
          "1",
          "2",
          "3",
          "4",
          "5",
          "6",
          "7",
          "8",
          "9"
        ],
        "rows": [
          [
            "1",
            "+2",
            "Lanzamiento de conjuros, Adepto en rituales, Recuperación arcana",
            "3",
            "4",
            "2",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "2",
            "+2",
            "Académico",
            "3",
            "5",
            "3",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "3",
            "+2",
            "Subclase de mago",
            "3",
            "6",
            "4",
            "2",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "4",
            "+2",
            "Mejora de característica",
            "4",
            "7",
            "4",
            "3",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "5",
            "+3",
            "Memorizar conjuro",
            "4",
            "9",
            "4",
            "3",
            "2",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "6",
            "+3",
            "Rasgo de subclase",
            "4",
            "10",
            "4",
            "3",
            "3",
            "-",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "7",
            "+3",
            "—",
            "4",
            "11",
            "4",
            "3",
            "3",
            "1",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "8",
            "+3",
            "Mejora de característica",
            "4",
            "12",
            "4",
            "3",
            "3",
            "2",
            "-",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "9",
            "+4",
            "—",
            "4",
            "14",
            "4",
            "3",
            "3",
            "3",
            "1",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "10",
            "+4",
            "Rasgo de subclase",
            "5",
            "15",
            "4",
            "3",
            "3",
            "3",
            "2",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "11",
            "+4",
            "—",
            "5",
            "16",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "-",
            "-",
            "-"
          ],
          [
            "12",
            "+4",
            "Mejora de característica",
            "5",
            "16",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "-",
            "-",
            "-"
          ],
          [
            "13",
            "+5",
            "—",
            "5",
            "17",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "-",
            "-"
          ],
          [
            "14",
            "+5",
            "Rasgo de subclase",
            "5",
            "18",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "-",
            "-"
          ],
          [
            "15",
            "+5",
            "—",
            "5",
            "19",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "1",
            "-"
          ],
          [
            "16",
            "+5",
            "Mejora de característica",
            "5",
            "21",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "1",
            "-"
          ],
          [
            "17",
            "+6",
            "—",
            "5",
            "22",
            "4",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "1",
            "1"
          ],
          [
            "18",
            "+6",
            "Maestría sobre conjuros",
            "5",
            "23",
            "4",
            "3",
            "3",
            "3",
            "3",
            "1",
            "1",
            "1",
            "1"
          ],
          [
            "19",
            "+6",
            "Don épico",
            "5",
            "24",
            "4",
            "3",
            "3",
            "3",
            "3",
            "2",
            "1",
            "1",
            "1"
          ],
          [
            "20",
            "+6",
            "Conjuros característicos",
            "5",
            "25",
            "4",
            "3",
            "3",
            "3",
            "3",
            "2",
            "2",
            "1",
            "1"
          ]
        ]
      }
    }
  },
  "monje": {
    "id": "monje",
    "name": "Monje",
    "primaryAbility": [
      "Destreza",
      "Sabiduría"
    ],
    "hitDie": "1d8",
    "savingThrows": [
      "Fuerza",
      "Destreza"
    ],
    "skillChoices": {
      "choose": 2,
      "from": [
        "Acrobacias",
        "Atletismo",
        "Historia",
        "Perspicacia",
        "Religión",
        "Sigilo"
      ]
    },
    "weaponProficiencies": [
      "Armas sencillas",
      "Armas marciales con la propiedad ligera"
    ],
    "toolProficiencies": {
      "choose": 1,
      "from": [
        "Herramientas de artesano",
        "Instrumento musical"
      ]
    },
    "armorTraining": [],
    "startingEquipment": {
      "options": [
        {
          "label": "A",
          "items": [
            "Lanza",
            "5 dagas",
            "Herramientas de artesano o instrumento musical (según competencia)",
            "Paquete de explorador",
            "11 po"
          ]
        },
        {
          "label": "B",
          "items": [
            "50 po"
          ]
        }
      ]
    },
    "features": {
      "martial_arts": {
        "name": "Artes Marciales",
        "level": 1,
        "description": "La práctica de las artes marciales te ha otorgado un dominio de los estilos de combate que emplean ataques sin armas y armas de monje, que son las siguientes:\n\n• armas cuerpo a cuerpo sencillas\n• armas cuerpo a cuerpo marciales que tengan la propiedad ligera\n\nObtienes los siguientes beneficios mientras no lleves armadura ni portes un escudo y estés desarmado o empuñes únicamente armas de monje:\n\nAtaque sin armas adicional. Puedes hacer un ataque sin armas como acción adicional.\n\nDado de Artes marciales. Puedes tirar 1d6 en lugar del daño normal de tus ataques sin armas o tus armas de monje. Este dado cambia según subes niveles como monje, como se muestra en la columna Artes marciales de la tabla Rasgos de monje.\n\nAtaques diestros. Puedes usar tu modificador por Destreza en lugar de tu modificador por Fuerza para las tiradas de ataque y de daño de tus ataques sin armas y tus armas de monje. Además, cuando uses las opciones de agarre o empujón de tu ataque sin armas, puedes usar tu modificador por Destreza en lugar de tu modificador por Fuerza para determinar la CD de salvación."
      },
      "unarmored_defense_monk": {
        "name": "Defensa sin Armadura",
        "level": 1,
        "description": "Mientras no lleves armadura ni portes un escudo, tu clase de armadura base será igual a 10 más tus modificadores por Destreza y Sabiduría."
      },
      "monks_focus": {
        "name": "Concentración de Monje",
        "level": 2,
        "description": "Tu concentración y tu entrenamiento marcial te permiten utilizar una reserva interna de energía extraordinaria. Esta energía se representa mediante los puntos de concentración. Tu nivel de monje determina cuántos de estos puntos posees, como se muestra en la columna Puntos de concentración de la tabla Rasgos de monje.\n\nPuedes gastar estos puntos para mejorar o alimentar determinados rasgos de monje. Empiezas con tres de estos rasgos:\n\nDefensa paciente. Puedes llevar a cabo la acción de destrabarse como acción adicional. De manera alternativa, puedes gastar 1 punto de concentración para llevar a cabo tanto la acción de destrabarse como la de esquivar como acción adicional.\n\nPaso del viento. Puedes llevar a cabo la acción de correr como acción adicional. De manera alternativa, puedes gastar 1 punto de concentración para llevar a cabo tanto la acción de destrabarse como la de correr como acción adicional, y tu distancia de salto se duplicará durante el turno.\n\nRáfaga de golpes. Puedes gastar 1 punto de concentración para hacer dos ataques sin armas como acción adicional.\n\nCuando gastes un punto de concentración, no estará disponible hasta que finalices un descanso corto o largo, tras el cual recuperarás todos los puntos gastados.\n\nAlgunos rasgos que usan puntos de concentración requieren que tu objetivo haga una tirada de salvación. La CD de salvación es igual a 8 más tu modificador por Sabiduría y tu bonificador por competencia."
      },
      "patient_defense": {
        "name": "Defensa Paciente",
        "level": 2,
        "description": "Puedes llevar a cabo la acción de destrabarse como acción adicional. De manera alternativa, puedes gastar 1 punto de concentración para llevar a cabo tanto la acción de destrabarse como la de esquivar como acción adicional."
      },
      "step_of_the_wind": {
        "name": "Paso del Viento",
        "level": 2,
        "description": "Puedes llevar a cabo la acción de correr como acción adicional. De manera alternativa, puedes gastar 1 punto de concentración para llevar a cabo tanto la acción de destrabarse como la de correr como acción adicional, y tu distancia de salto se duplicará durante el turno."
      },
      "flurry_of_blows": {
        "name": "Ráfaga de Golpes",
        "level": 2,
        "description": "Puedes gastar 1 punto de concentración para hacer dos ataques sin armas como acción adicional."
      },
      "remarkable_metabolism": {
        "name": "Metabolismo Asombroso",
        "level": 2,
        "description": "Cuando tires iniciativa, puedes recuperar todos los puntos de concentración gastados. Cuando lo hagas, tira tu dado de Artes marciales y recupera una cantidad de puntos de golpe igual a tu nivel de monje más el resultado obtenido.\n\nCuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo."
      },
      "unarmored_movement": {
        "name": "Movimiento sin Armadura",
        "level": 2,
        "description": "Tu velocidad aumenta en 10 pies si no llevas armadura ni portas un escudo. Esta bonificación aumenta cuando alcanzas ciertos niveles de monje, como se muestra en la tabla Rasgos de monje."
      },
      "deflect_attacks": {
        "name": "Desviar Ataques",
        "level": 3,
        "description": "Cuando una tirada de ataque te acierte y su daño incluya los tipos contundente, cortante o perforante, puedes llevar a cabo una reacción para reducir el daño total que sufras del ataque. Se reducirá en 1d10 más tu modificador por Destreza y nivel de monje.\n\nSi reduces el daño a 0, puedes gastar 1 punto de concentración para redirigir una parte de la fuerza del ataque. Si lo haces, elige una criatura que puedas ver a 5 pies o menos de ti si el ataque fue cuerpo a cuerpo o una criatura que puedas ver a 60 pies o menos de ti que no esté tras cobertura completa si el ataque fue a distancia. La criatura deberá superar una tirada de salvación de Destreza o sufrirá una cantidad de daño igual al resultado de dos tiradas de tu dado de Artes marciales más tu modificador por Destreza. El daño será del mismo tipo que inflija el ataque."
      },
      "monk_subclass": {
        "name": "Subclase de Monje",
        "level": 3,
        "description": "Consigues una subclase de monje de tu elección.\n\nLas subclases de guerrero de la mano abierta, guerrero de la misericordia, guerrero de la sombra y guerrero de los elementos se detallan tras la descripción de esta clase. Una subclase es una especialización que te proporciona rasgos cuando alcanzas ciertos niveles de monje. De aquí en adelante, obtienes todos los rasgos de tu subclase que sean de tu nivel de monje e inferiores."
      },
      "slow_fall": {
        "name": "Caída Lenta",
        "level": 4,
        "description": "Puedes llevar a cabo una reacción cuando caigas para reducir cualquier daño que sufras de la caída en una cantidad igual a cinco veces tu nivel de monje."
      },
      "ability_score_improvement_monk": {
        "name": "Mejora de Característica",
        "level": 4,
        "description": "Obtienes la dote Mejora de característica u otra dote de tu elección para la que cumplas las condiciones.\n\nVuelves a obtener este rasgo en los niveles 8, 12 y 16 de monje."
      },
      "extra_attack_monk": {
        "name": "Ataque Adicional",
        "level": 5,
        "description": "Cuando lleves a cabo la acción de atacar en tu turno, podrás hacer dos ataques en lugar de uno."
      },
      "stunning_strike": {
        "name": "Golpe Aturdidor",
        "level": 5,
        "description": "Una vez por turno cuando aciertes a una criatura con un arma de monje o un ataque sin armas, puedes gastar 1 punto de concentración para intentar propinar un golpe aturdidor. El objetivo deberá hacer una tirada de salvación de Constitución. Si la falla, tendrá el estado de aturdido hasta el principio de tu siguiente turno.\n\nSi la supera, su velocidad se reducirá a la mitad hasta el principio de tu siguiente turno y la siguiente tirada de ataque realizada contra él antes de ese momento tendrá ventaja."
      },
      "empowered_strikes": {
        "name": "Golpes Potenciados",
        "level": 6,
        "description": "Siempre que inflijas daño con tu ataque sin armas, puedes elegir entre causar daño de fuerza o su tipo de daño normal."
      },
      "evasion": {
        "name": "Evasión",
        "level": 7,
        "description": "Cuando sufras un efecto que te permita hacer una tirada de salvación de Destreza para sufrir solo la mitad de daño, no recibes daño alguno si la superas y solo sufres la mitad si la fallas.\n\nNo te beneficias de este rasgo si tienes el estado de incapacitado."
      },
      "acrobatic_movement": {
        "name": "Movimiento Acrobático",
        "level": 9,
        "description": "Mientras no lleves armadura ni portes un escudo, obtienes la capacidad de moverte por superficies verticales y sobre líquidos sin caerte."
      },
      "self_restoration": {
        "name": "Autorrestablecimiento",
        "level": 10,
        "description": "Por pura fuerza de voluntad, puedes eliminar uno de los siguientes estados que te afecten al final de cada uno de tus turnos: asustado, envenenado o hechizado.\n\nAdemás, privarte de comida y bebida no te aplica niveles de cansancio."
      },
      "heightened_focus": {
        "name": "Concentración Agudizada",
        "level": 10,
        "description": "Tus rasgos Defensa paciente, Paso del viento y Ráfaga de golpes obtienen los siguientes beneficios:\n\nDefensa paciente. Cuando gastes un punto de concentración para usar Defensa paciente, obtienes una cantidad de puntos de golpe temporales igual al resultado de dos tiradas de tu dado de Artes marciales.\n\nPaso del viento. Cuando gastes un punto de concentración para usar Paso del viento, puedes elegir una criatura voluntaria Grande o más pequeña que esté a 5 pies o menos de ti. Moverás a la criatura contigo hasta el final de tu turno. El movimiento de la criatura no provoca ataques de oportunidad.\n\nRáfaga de golpes. Puedes gastar 1 punto de concentración para usar Ráfaga de golpes y hacer tres ataques sin armas en lugar de dos."
      },
      "deflect_energy": {
        "name": "Desviar Energía",
        "level": 13,
        "description": "Ahora puedes usar tu rasgo Desviar ataques contra ataques que causen cualquier tipo de daño, no solo contundente, cortante o perforante."
      },
      "disciplined_survivor": {
        "name": "Superviviente Disciplinado",
        "level": 14,
        "description": "Tu disciplina física y mental te otorga competencia en todas las tiradas de salvación.\n\nAdemás, cuando hagas una tirada de salvación y falles, puedes gastar 1 punto de concentración para repetirla, pero deberás utilizar el nuevo resultado."
      },
      "perfect_focus": {
        "name": "Concentración Perfecta",
        "level": 15,
        "description": "Cuando tires iniciativa y no utilices Metabolismo asombroso, recuperas los puntos de concentración gastados hasta que tengas 4 si te quedan 3 o menos."
      },
      "superior_defense": {
        "name": "Defensa Superior",
        "level": 18,
        "description": "Al principio de tu turno, puedes gastar 3 puntos de concentración para protegerte del daño durante 1 minuto o hasta que tengas el estado de incapacitado. Durante ese tiempo, tendrás resistencia a todo el daño excepto al de fuerza."
      },
      "epic_boon_monk": {
        "name": "Don Épico",
        "level": 19,
        "description": "Obtienes una dote de don épico u otra dote de tu elección para la que cumplas las condiciones. Se recomienda Don del ataque imparable."
      },
      "body_and_mind": {
        "name": "Cuerpo y Mente",
        "level": 20,
        "description": "Has llevado tu cuerpo y mente a otro nivel. Tus puntuaciones de Destreza y Sabiduría aumentan en 4, hasta un máximo de 25."
      }
    },
    "levels": {
      "1": {
        "features": [
          "martial_arts",
          "unarmored_defense_monk"
        ],
        "focusPoints": 0,
        "proficiencyBonus": "+2"
      },
      "2": {
        "features": [
          "monks_focus",
          "remarkable_metabolism",
          "unarmored_movement"
        ],
        "focusPoints": 2,
        "proficiencyBonus": "+2"
      },
      "3": {
        "features": [
          "deflect_attacks",
          "monk_subclass"
        ],
        "focusPoints": 3,
        "proficiencyBonus": "+2"
      },
      "4": {
        "features": [
          "slow_fall",
          "ability_score_improvement_monk"
        ],
        "focusPoints": 4,
        "proficiencyBonus": "+2"
      },
      "5": {
        "features": [
          "extra_attack_monk",
          "stunning_strike"
        ],
        "focusPoints": 5,
        "proficiencyBonus": "+3"
      },
      "6": {
        "features": [
          "empowered_strikes"
        ],
        "focusPoints": 6,
        "proficiencyBonus": "+3"
      },
      "7": {
        "features": [
          "evasion"
        ],
        "focusPoints": 7,
        "proficiencyBonus": "+3"
      },
      "8": {
        "features": [
          "ability_score_improvement_monk"
        ],
        "focusPoints": 8,
        "proficiencyBonus": "+3"
      },
      "9": {
        "features": [
          "acrobatic_movement"
        ],
        "focusPoints": 9,
        "proficiencyBonus": "+4"
      },
      "10": {
        "features": [
          "self_restoration",
          "heightened_focus"
        ],
        "focusPoints": 10,
        "proficiencyBonus": "+4"
      },
      "11": {
        "focusPoints": 11,
        "proficiencyBonus": "+4"
      },
      "12": {
        "features": [
          "ability_score_improvement_monk"
        ],
        "focusPoints": 12,
        "proficiencyBonus": "+4"
      },
      "13": {
        "features": [
          "deflect_energy"
        ],
        "focusPoints": 13,
        "proficiencyBonus": "+5"
      },
      "14": {
        "features": [
          "disciplined_survivor"
        ],
        "focusPoints": 14,
        "proficiencyBonus": "+5"
      },
      "15": {
        "features": [
          "perfect_focus"
        ],
        "focusPoints": 15,
        "proficiencyBonus": "+5"
      },
      "16": {
        "features": [
          "ability_score_improvement_monk"
        ],
        "focusPoints": 16,
        "proficiencyBonus": "+5"
      },
      "17": {
        "focusPoints": 17,
        "proficiencyBonus": "+6"
      },
      "18": {
        "features": [
          "superior_defense"
        ],
        "focusPoints": 18,
        "proficiencyBonus": "+6"
      },
      "19": {
        "features": [
          "epic_boon_monk"
        ],
        "focusPoints": 19,
        "proficiencyBonus": "+6"
      },
      "20": {
        "features": [
          "body_and_mind"
        ],
        "focusPoints": 20,
        "proficiencyBonus": "+6"
      }
    },
    "subclasses": {
      "open_hand": {
        "name": "Guerrero de la Mano Abierta",
        "features": {
          "open_hand_technique": {
            "name": "Técnica de la Mano Abierta",
            "level": 3,
            "description": "Siempre que aciertes a una criatura con un ataque proporcionado por Ráfaga de golpes, puedes imponerle uno de los siguientes efectos:\n\nDerribar. El objetivo deberá superar una tirada de salvación de Destreza o tendrá el estado de derribado.\n\nDesconcertar. El objetivo no podrá realizar ataques de oportunidad hasta el principio de su siguiente turno.\n\nEmpujar. El objetivo deberá superar una tirada de salvación de Fuerza o será empujado hasta 15 pies respecto a ti."
          },
          "wholeness_of_body": {
            "name": "Plenitud de Cuerpo",
            "level": 6,
            "description": "Obtienes la capacidad de sanar tu propio cuerpo. Como acción adicional, puedes tirar tu dado de Artes marciales. Recuperas una cantidad de puntos de golpe igual al resultado más tu modificador por Sabiduría (recuperas 1 punto de golpe como mínimo).\n\nPuedes usar este rasgo una cantidad de veces igual a tu modificador por Sabiduría (mínimo una vez) y recuperas todos los usos tras finalizar un descanso largo."
          },
          "fleet_step": {
            "name": "Paso Veloz",
            "level": 11,
            "description": "Cuando utilices una acción adicional que no sea Paso del viento, podrás usar también Paso del viento inmediatamente después de esa acción adicional."
          },
          "quivering_palm": {
            "name": "Palma Estremecedora",
            "level": 17,
            "description": "Consigues la capacidad de transmitir vibraciones letales al cuerpo de un oponente. Cuando aciertes a una criatura con un ataque sin armas, puedes gastar 4 puntos de concentración para iniciar estas vibraciones imperceptibles, que durarán tantos días como tu nivel de monje.\n\nLas vibraciones son inofensivas, salvo si usas tu acción para hacer que terminen. Como alternativa, cuando lleves a cabo la acción de atacar en tu turno, puedes renunciar a uno de los ataques para poner fin a las vibraciones. Para ello, el objetivo y tú debéis estar en el mismo plano de existencia.\n\nCuando les pongas fin, el objetivo deberá realizar una tirada de salvación de Constitución; sufrirá 10d12 de daño de fuerza si la falla o la mitad del daño si la supera.\n\nSolo puedes tener a una criatura bajo el efecto de este rasgo al mismo tiempo. Puedes poner fin a las vibraciones de forma inocua (no requiere acción)."
          }
        },
        "levels": {
          "3": {
            "features": [
              "open_hand_technique"
            ]
          },
          "6": {
            "features": [
              "wholeness_of_body"
            ]
          },
          "11": {
            "features": [
              "fleet_step"
            ]
          },
          "17": {
            "features": [
              "quivering_palm"
            ]
          }
        }
      },
      "mercy": {
        "name": "Guerrero de la Misericordia",
        "features": {
          "implements_of_mercy": {
            "name": "Instrumentos de Misericordia",
            "level": 3,
            "description": "Ganas competencia en las habilidades Medicina y Perspicacia y con los útiles de herborista."
          },
          "hand_of_harm": {
            "name": "Mano de Aflicción",
            "level": 3,
            "description": "Una vez por turno, cuando aciertes a una criatura con un ataque sin armas y le causes daño, puedes gastar 1 punto de concentración para infligir una cantidad adicional de daño necrótico igual al resultado de una tirada de tu dado de Artes marciales más tu modificador por Sabiduría."
          },
          "hand_of_healing": {
            "name": "Mano de Curación",
            "level": 3,
            "description": "Como acción de magia, puedes gastar 1 punto de concentración para tocar a una criatura y hacer que recupere una cantidad de puntos de golpe igual al resultado de una tirada de tu dado de Artes marciales más tu modificador por Sabiduría.\n\nCuando uses Ráfaga de golpes, puedes sustituir uno de los ataques sin armas por un uso de este rasgo sin gastar un punto de concentración para curar."
          },
          "physicians_touch": {
            "name": "Toque de Galeno",
            "level": 6,
            "description": "Tu Mano de aflicción y Mano de curación mejoran, como se detalla a continuación:\n\nMano de aflicción. Cuando uses Mano de aflicción en una criatura, también podrás infligirle el estado de envenenada hasta el final de tu siguiente turno.\n\nMano de curación. Cuando uses Mano de curación, también podrás poner fin a uno de los siguientes estados en la criatura a la que cures: aturdida, cegada, ensordecida, envenenada o paralizada."
          },
          "flurry_of_healing_and_harm": {
            "name": "Ráfaga de Curación y Aflicción",
            "level": 11,
            "description": "Cuando uses Ráfaga de golpes, puedes sustituir cada uno de los ataques sin armas por un uso de Mano de curación sin gastar puntos de concentración para curar.\n\nAdemás, cuando hagas un ataque sin armas con Ráfaga de golpes y causes daño, podrás usar Mano de aflicción en ese ataque sin gastar un punto de concentración. Solo puedes usar Mano de aflicción una vez por turno.\n\nPuedes utilizar estos beneficios una cantidad de veces igual a tu modificador por Sabiduría (mínimo una vez). Recuperas todos los usos tras finalizar un descanso largo."
          },
          "hand_of_ultimate_mercy": {
            "name": "Mano de Misericordia Suprema",
            "level": 17,
            "description": "Tu dominio de la energía vital te abre las puertas de la misericordia suprema. Como acción de magia, puedes tocar el cadáver de una criatura que haya muerto en las últimas 24 horas y gastar 5 puntos de concentración.\n\nLa criatura volverá a la vida con una cantidad de puntos de golpe igual a 4d10 más tu modificador por Sabiduría. Si la criatura murió mientras tenía alguno de los siguientes estados, revivirá sin ellos: aturdida, cegada, ensordecida, envenenada y paralizada.\n\nCuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo."
          }
        },
        "levels": {
          "3": {
            "features": [
              "implements_of_mercy",
              "hand_of_harm",
              "hand_of_healing"
            ]
          },
          "6": {
            "features": [
              "physicians_touch"
            ]
          },
          "11": {
            "features": [
              "flurry_of_healing_and_harm"
            ]
          },
          "17": {
            "features": [
              "hand_of_ultimate_mercy"
            ]
          }
        }
      },
      "shadow": {
        "name": "Guerrero de la Sombra",
        "features": {
          "shadow_arts": {
            "name": "Artes Sombrías",
            "level": 3,
            "description": "Has aprendido a manejar el poder del Páramo Sombrío, lo que te proporciona los siguientes beneficios:\n\nIlusiones sombrías. Conoces el truco Ilusión menor. La Sabiduría es tu aptitud mágica para lanzarlo.\n\nOscuridad. Puedes gastar 1 punto de concentración para lanzar el conjuro Oscuridad sin necesidad de componentes. Puedes ver dentro de la zona del conjuro cuando lo lanzas con este rasgo. Mientras se mantenga el conjuro, podrás mover la zona de oscuridad a un espacio a 60 pies o menos de ti al principio de cada uno de tus turnos.\n\nVisión en la oscuridad. Obtienes visión en la oscuridad hasta 60 pies. Si ya posees visión en la oscuridad, su alcance aumenta en 60 pies."
          },
          "shadow_step": {
            "name": "Paso entre Sombras",
            "level": 6,
            "description": "Cuando estés por completo en una zona de luz tenue u oscuridad, puedes utilizar una acción adicional para teletransportarte hasta 60 pies a un espacio sin ocupar que puedas ver y que también esté en condiciones de luz tenue u oscuridad. Luego tendrás ventaja en el siguiente ataque cuerpo a cuerpo que hagas antes del final de ese turno."
          },
          "improved_shadow_step": {
            "name": "Paso entre Sombras Mejorado",
            "level": 11,
            "description": "Puedes recurrir a tu conexión con el Páramo Sombrío para potenciar tu teletransportación. Cuando uses Paso entre sombras, puedes gastar 1 punto de concentración para eliminar el requisito de comenzar y terminar en una zona de luz tenue u oscuridad para ese uso del rasgo. Como parte de esta acción adicional, puedes hacer un ataque sin armas inmediatamente después de teletransportarte."
          },
          "cloak_of_shadows": {
            "name": "Capa de Sombras",
            "level": 17,
            "description": "Como acción de magia cuando estés por completo en una zona de luz tenue u oscuridad, puedes gastar 3 puntos de concentración para envolverte en sombras durante 1 minuto, hasta que tengas el estado de incapacitado o hasta que termines tu turno en una zona de luz brillante. Mientras estés envuelto en estas sombras, obtienes los siguientes beneficios:\n\nIncorporeidad parcial. Puedes atravesar espacios ocupados como si fueran terreno difícil. Si terminas tu turno en un espacio así, irás a parar al último espacio sin ocupar en el que hayas estado.\n\nInvisibilidad. Tienes el estado de invisible.\n\nRáfaga de sombras. Puedes utilizar tu Ráfaga de golpes sin gastar puntos de concentración."
          }
        },
        "levels": {
          "3": {
            "features": [
              "shadow_arts"
            ]
          },
          "6": {
            "features": [
              "shadow_step"
            ]
          },
          "11": {
            "features": [
              "improved_shadow_step"
            ]
          },
          "17": {
            "features": [
              "cloak_of_shadows"
            ]
          }
        }
      },
      "elements": {
        "name": "Guerrero de los Elementos",
        "features": {
          "elemental_attunement": {
            "name": "Armonía con los Elementos",
            "level": 3,
            "description": "Al principio de tu turno, puedes gastar 1 punto de concentración para imbuirte de energía elemental. La energía dura 10 minutos o hasta que tengas el estado de incapacitado. Mientras este rasgo esté activo, obtienes los siguientes beneficios:\n\nAlcance. Cuando realizas un ataque sin armas, tu alcance es 10 pies superior al normal, ya que la energía elemental surge de ti.\n\nGolpes elementales. Siempre que aciertes con tu ataque sin armas, puedes hacer que cause el tipo de daño que quieras entre ácido, frío, fuego, relámpago o trueno en vez de su tipo de daño normal. Cuando inflijas uno de estos tipos con él, también puedes obligar al objetivo a hacer una tirada de salvación de Fuerza. Si la falla, puedes mover al objetivo hasta 10 pies hacia ti o en dirección contraria, ya que la energía elemental se arremolina a su alrededor."
          },
          "shape_the_elements": {
            "name": "Manipular los Elementos",
            "level": 3,
            "description": "Conoces el conjuro Elementalismo. La Sabiduría es tu aptitud mágica para lanzarlo."
          },
          "elemental_burst": {
            "name": "Explosión Elemental",
            "level": 6,
            "description": "Como acción de magia, puedes gastar 2 puntos de concentración para que la energía elemental explote en una esfera de 20 pies de radio centrada en un punto a 120 pies o menos de ti. Elige un tipo de daño: ácido, frío, fuego, relámpago o trueno.\n\nTodas las criaturas situadas en esa esfera deberán hacer una tirada de salvación de Destreza. Si la fallan, sufrirán una cantidad de daño del tipo elegido igual al resultado de tres tiradas de tu dado de Artes marciales. Si la superan, recibirán la mitad de ese daño."
          },
          "stride_of_the_elements": {
            "name": "Paso de los Elementos",
            "level": 11,
            "description": "Mientras tu Armonía con los elementos esté activa, tendrás también una velocidad nadando y una velocidad volando iguales a tu velocidad."
          },
          "elemental_paradigm": {
            "name": "Paradigma Elemental",
            "level": 17,
            "description": "Mientras tu Armonía con los elementos esté activa, obtienes también los siguientes beneficios:\n\nGolpes potenciados. Una vez en cada uno de tus turnos, puedes causar a un objetivo una cantidad adicional de daño igual al resultado de una tirada de tu dado de Artes marciales cuando le aciertes con un ataque sin armas. El daño adicional será del mismo tipo que inflija el ataque.\n\nPaso destructivo. Cuando utilices tu Paso del viento, tu velocidad aumenta en 20 pies hasta el final del turno. Durante ese tiempo, cualquier criatura de tu elección sufre una cantidad de daño igual al resultado de una tirada de tu dado de Artes marciales cuando entres en un espacio a 5 pies o menos de ella. Elige el tipo de daño: ácido, frío, fuego, relámpago o trueno. Una criatura solo puede sufrir este daño una vez por turno.\n\nResistencia al daño. Ganas resistencia a uno de los siguientes tipos de daño, a tu elección: ácido, frío, fuego, relámpago o trueno. Al principio de cada uno de tus turnos, puedes cambiar esta elección."
          }
        },
        "levels": {
          "3": {
            "features": [
              "elemental_attunement",
              "shape_the_elements"
            ]
          },
          "6": {
            "features": [
              "elemental_burst"
            ]
          },
          "11": {
            "features": [
              "stride_of_the_elements"
            ]
          },
          "17": {
            "features": [
              "elemental_paradigm"
            ]
          }
        }
      }
    },
    "tables": {
      "monk_progression": {
        "title": "Rasgos de Monje",
        "columns": [
          "Nivel",
          "Bonificador por competencia",
          "Rasgos de clase",
          "Puntos de concentración",
          "Artes marciales",
          "Movimiento sin armadura"
        ],
        "rows": [
          [
            "1",
            "+2",
            "Artes marciales, Defensa sin armadura",
            "—",
            "1d6",
            "—"
          ],
          [
            "2",
            "+2",
            "Concentración de monje, Metabolismo asombroso, Movimiento sin armadura",
            "2",
            "1d6",
            "+10 pies"
          ],
          [
            "3",
            "+2",
            "Desviar ataques, Subclase de monje",
            "3",
            "1d6",
            "+10 pies"
          ],
          [
            "4",
            "+2",
            "Caída lenta, Mejora de característica",
            "4",
            "1d6",
            "+10 pies"
          ],
          [
            "5",
            "+3",
            "Ataque adicional, Golpe aturdidor",
            "5",
            "1d8",
            "+10 pies"
          ],
          [
            "6",
            "+3",
            "Golpes potenciados, rasgo de subclase",
            "6",
            "1d8",
            "+15 pies"
          ],
          [
            "7",
            "+3",
            "Evasión",
            "7",
            "1d8",
            "+15 pies"
          ],
          [
            "8",
            "+3",
            "Mejora de característica",
            "8",
            "1d8",
            "+15 pies"
          ],
          [
            "9",
            "+4",
            "Movimiento acrobático",
            "9",
            "1d8",
            "+15 pies"
          ],
          [
            "10",
            "+4",
            "Autorrestablecimiento, Concentración agudizada",
            "10",
            "1d8",
            "+20 pies"
          ],
          [
            "11",
            "+4",
            "Rasgo de subclase",
            "11",
            "1d10",
            "+20 pies"
          ],
          [
            "12",
            "+4",
            "Mejora de característica",
            "12",
            "1d10",
            "+20 pies"
          ],
          [
            "13",
            "+5",
            "Desviar energía",
            "13",
            "1d10",
            "+20 pies"
          ],
          [
            "14",
            "+5",
            "Superviviente disciplinado",
            "14",
            "1d10",
            "+25 pies"
          ],
          [
            "15",
            "+5",
            "Concentración perfecta",
            "15",
            "1d10",
            "+25 pies"
          ],
          [
            "16",
            "+5",
            "Mejora de característica",
            "16",
            "1d10",
            "+25 pies"
          ],
          [
            "17",
            "+6",
            "Rasgo de subclase",
            "17",
            "1d12",
            "+25 pies"
          ],
          [
            "18",
            "+6",
            "Defensa superior",
            "18",
            "1d12",
            "+30 pies"
          ],
          [
            "19",
            "+6",
            "Don épico",
            "19",
            "1d12",
            "+30 pies"
          ],
          [
            "20",
            "+6",
            "Cuerpo y mente",
            "20",
            "1d12",
            "+30 pies"
          ]
        ]
      }
    }
  },
  "paladin": {
    "id": "paladin",
    "name": "Paladín",
    "primaryAbility": [
      "Fuerza",
      "Carisma"
    ],
    "hitDie": "1d10",
    "savingThrows": [
      "Sabiduría",
      "Carisma"
    ],
    "skillChoices": {
      "choose": 2,
      "from": [
        "Atletismo",
        "Intimidación",
        "Medicina",
        "Perspicacia",
        "Persuasión",
        "Religión"
      ]
    },
    "weaponProficiencies": [
      "Armas sencillas",
      "Armas marciales"
    ],
    "armorTraining": [
      "Armaduras ligeras",
      "Armaduras medias",
      "Armaduras pesadas",
      "Escudos"
    ],
    "startingEquipment": {
      "options": [
        {
          "label": "A",
          "items": [
            "Cota de malla",
            "Escudo",
            "Espada larga",
            "6 jabalinas",
            "Símbolo sagrado",
            "Paquete de sacerdote",
            "9 po"
          ]
        },
        {
          "label": "B",
          "items": [
            "150 po"
          ]
        }
      ]
    },
    "features": {
      "lay_on_hands": {
        "name": "Imponer las manos",
        "level": 1,
        "description": "Tu toque bendito puede curar heridas. Tienes una reserva de poder de curación que se rellena tras finalizar un descanso largo. Puedes recurrir a esta reserva para restaurar tantos puntos de golpe como cinco veces tu nivel de paladín.\n\nComo acción adicional, puedes tocar a una criatura (que puedes ser tú) y extraer energía de la reserva de curación para hacer que esa criatura recupere una cantidad de puntos de golpe, que como máximo será la cantidad que te quede en dicha reserva.\n\nTambién puedes gastar 5 puntos de golpe de la reserva para eliminar el estado de envenenada de la criatura, pero esos puntos gastados no restaurarán puntos de golpe."
      },
      "paladin_spellcasting": {
        "name": "Lanzamiento de conjuros",
        "level": 1,
        "description": "Has aprendido a lanzar conjuros gracias a la oración y la meditación. Consulta el capítulo 7 para ver las reglas sobre el lanzamiento de conjuros. La información presentada a continuación detalla cómo usar esas reglas con los conjuros de paladín, que encontrarás más adelante en la lista de conjuros de paladín de la descripción de la clase.\n\nEspacios de conjuro. La tabla “Rasgos de paladín” muestra cuántos espacios de conjuro tienes para lanzar tus conjuros de nivel 1 y superiores. Recuperas todos los espacios utilizados tras finalizar un descanso largo.\n\nConjuros preparados de nivel 1 y superiores. Preparas una serie de conjuros de nivel 1 y superiores, que son los que podrás lanzar con este rasgo. Para empezar, elige dos conjuros de paladín de nivel 1. Se recomiendan castigo abrasador y heroísmo.\n\nEl número de conjuros de tu lista aumenta conforme subes de nivel de paladín, como se muestra en la columna “Conjuros preparados” de la tabla “Rasgos de paladín”. Cuando ese número aumente, elige conjuros de paladín adicionales hasta que el número de conjuros de tu lista coincida con el número de la tabla “Rasgos de paladín”.\n\nEstos conjuros deben ser de un nivel para el que tengas espacios de conjuro. Por ejemplo, si eres un paladín de nivel 5, podrías preparar cualquier combinación de seis conjuros de paladín de nivel 1 o 2.\n\nSi otro rasgo de paladín te proporciona conjuros que siempre tienes preparados, esos conjuros no cuentan para el total que puedes preparar con este rasgo, pero sí que cuentan como conjuros de paladín para ti.\n\nCambiar los conjuros preparados. Tras finalizar un descanso largo, puedes sustituir un conjuro de tu lista por otro conjuro de paladín para el que tengas espacios de conjuro.\n\nAptitud mágica. El Carisma es tu aptitud mágica en lo que respecta a tus conjuros de paladín.\n\nCanalizador mágico. Puedes utilizar un símbolo sagrado como canalizador mágico para tus conjuros de paladín."
      },
      "weapon_mastery_paladin": {
        "name": "Maestría con armas",
        "level": 1,
        "description": "Tu entrenamiento con armas te permite utilizar las propiedades de maestría con dos tipos de armas de tu elección con las que tengas competencia, como espadas largas y jabalinas.\n\nTras finalizar un descanso largo, puedes cambiar los tipos de armas elegidas. Por ejemplo, podrías pasar a utilizar las propiedades de maestría con alabardas y manguales."
      },
      "paladins_smite": {
        "name": "Castigo de paladín",
        "level": 2,
        "description": "Siempre tienes el conjuro castigo divino preparado. Además, puedes lanzarlo sin gastar un espacio de conjuro, pero debes finalizar un descanso largo antes de poder volver a lanzarlo de este modo."
      },
      "fighting_style_paladin": {
        "name": "Estilo de combate",
        "level": 2,
        "description": "Obtienes una dote de estilo de combate de tu elección (consulta las dotes en el capítulo 5). En lugar de elegir una de esas dotes, puedes elegir la opción presentada a continuación.\n\nGuerrero bendito. Aprendes dos trucos de clérigo de tu elección (consulta la sección de la clase clérigo para ver la lista de conjuros de clérigo). Se recomiendan guía y llama sagrada. Los trucos elegidos cuentan como conjuros de paladín para ti y el Carisma es tu aptitud mágica para lanzarlos. Cada vez que subas un nivel de paladín, puedes sustituir uno de estos trucos por otro truco de clérigo."
      },
      "channel_divinity_paladin": {
        "name": "Canalizar divinidad",
        "level": 3,
        "description": "Puedes canalizar energía divina directamente de los Planos Exteriores para alimentar varios efectos mágicos. Empiezas con uno de esos efectos: Sentidos divinos, que se describe a continuación. Otros rasgos de paladín ofrecen opciones adicionales como efectos de Canalizar divinidad.\n\nCada vez que utilices el rasgo Canalizar divinidad de esta clase, elige qué efecto de esta clase creas.\n\nPuedes usar el rasgo Canalizar divinidad dos veces. Recuperas uno de los usos gastados tras finalizar un descanso corto y todos tras finalizar un descanso largo. Obtienes un uso adicional cuando alcances el nivel 11 de paladín.\n\nSi un efecto de Canalizar divinidad requiere una tirada de salvación, la CD será igual a la CD de salvación de conjuros del rasgo Lanzamiento de conjuros de esta clase.\n\nSentidos divinos. Como acción adicional, puedes expandir tu percepción para detectar celestiales, infernales y muertos vivientes. Durante los siguientes 10 minutos o hasta que tengas el estado de incapacitado, conoces la ubicación de cualquier criatura de esos tipos que se encuentre a 60 pies o menos de ti y su tipo de criatura. En el mismo radio, también detectarás la presencia de cualquier lugar u objeto que haya sido consagrado o profanado, como con el conjuro consagrar,"
      },
      "paladin_subclass": {
        "name": "Subclase de paladín",
        "level": 3,
        "description": "Consigues una subclase de paladín de tu elección.\n\nLas subclases del juramento de entrega, el juramento de gloria, el juramento de los antiguos y el juramento de venganza se detallan tras la descripción de esta clase.\n\nUna subclase es una especialización que te proporciona rasgos cuando alcanzas ciertos niveles de paladín. De aquí en adelante, obtienes todos los rasgos de tu subclase que sean de tu nivel de paladín e inferiores."
      },
      "ability_score_improvement_paladin": {
        "name": "Mejora de característica",
        "level": 4,
        "description": "Obtienes la dote Mejora de característica (consulta el capítulo 5) u otra dote de tu elección para la que cumplas las condiciones. Vuelves a obtener este rasgo en los niveles 8, 12 y 16 de paladín."
      },
      "extra_attack_paladin": {
        "name": "Ataque adicional",
        "level": 5,
        "description": "Cuando lleves a cabo la acción de atacar en tu turno, podrás hacer dos ataques en lugar de uno."
      },
      "faithful_steed": {
        "name": "Corcel fiel",
        "level": 5,
        "description": "Puedes invocar la ayuda de un corcel sobrenatural. Siempre tienes el conjuro hallar corcel preparado.\n\nTambién puedes lanzarlo una vez sin gastar un espacio de conjuro y recuperas la capacidad de hacerlo tras finalizar un descanso largo."
      },
      "aura_of_protection": {
        "name": "Aura de protección",
        "level": 6,
        "description": "Irradias un aura protectora e invisible en una emanación de 10 pies que se origina de ti. El aura estará inactiva mientras tengas el estado de incapacitado.\n\nTus aliados dentro del aura y tú obtenéis un bonificador a las tiradas de salvación igual a tu modificador por Carisma (mínimo de +1).\n\nSi hay otro paladín presente, una criatura solo puede beneficiarse de un Aura de protección a la vez; esa criatura elegirá cuál de ellas mientras esté dentro de ambas."
      },
      "abjure_enemies": {
        "name": "Abjurar de los enemigos",
        "level": 9,
        "description": "Como acción de magia, puedes gastar uno de los usos de Canalizar divinidad de esta clase para sobrecoger a tus enemigos. Mientras muestras tu símbolo sagrado o arma, puedes hacer objetivo a una cantidad de criaturas que puedas ver a 60 pies o menos de ti igual a tu modificador por Carisma (mínimo una criatura). Cada objetivo deberá superar una tirada de salvación de Sabiduría o tendrá el estado de asustado durante 1 minuto o hasta recibir daño.\n\nMientras esté asustado de esta forma, un objetivo solo podrá hacer una de estas opciones en sus turnos: moverse, realizar una acción o realizar una acción adicional."
      },
      "aura_of_courage": {
        "name": "Aura de coraje",
        "level": 10,
        "description": "Tus aliados y tú tenéis inmunidad al estado de asustados mientras estéis dentro de tu Aura de protección. Si un aliado asustado entra en el aura, ese estado no tendrá efecto en él mientras esté dentro."
      },
      "radiant_strikes": {
        "name": "Golpes radiantes",
        "level": 11,
        "description": "Ahora, tus golpes tienen un poder sobrenatural. Cuando aciertes a un objetivo con una tirada de ataque usando un arma cuerpo a cuerpo o un ataque sin armas, el objetivo recibirá 1d8 de daño radiante adicional."
      },
      "restoring_touch": {
        "name": "Toque reparador",
        "level": 14,
        "description": "Cuando uses Imponer las manos sobre una criatura, también podrás eliminar uno o más de los siguientes estados que la afecten: asustado, aturdido, cegado, ensordecido, hechizado o paralizado.\n\nDeberás gastar 5 puntos de golpe de la reserva de curación de Imponer las manos por cada uno de los estados que elimines, pero esos puntos gastados no restaurarán puntos de golpe."
      },
      "expanded_aura": {
        "name": "Expansión de aura",
        "level": 18,
        "description": "Tu Aura de protección ahora es una emanación de 30 pies."
      },
      "epic_boon_paladin": {
        "name": "Don épico",
        "level": 19,
        "description": "Obtienes una dote de don épico (consulta el capítulo 5) u otra dote de tu elección para la que cumplas las condiciones. Se recomienda Don de la visión verdadera"
      }
    },
    "levels": {
      "1": {
        "features": [
          "lay_on_hands",
          "paladin_spellcasting",
          "weapon_mastery_paladin"
        ],
        "proficiencyBonus": "+2",
        "preparedSpells": 2,
        "channelDivinityUses": 0,
        "layOnHandsPool": 5,
        "weaponMasteryCount": 2,
        "spellSlots": [
          2,
          0,
          0,
          0,
          0
        ]
      },
      "2": {
        "features": [
          "paladins_smite",
          "fighting_style_paladin"
        ],
        "proficiencyBonus": "+2",
        "preparedSpells": 3,
        "channelDivinityUses": 0,
        "layOnHandsPool": 10,
        "weaponMasteryCount": 2,
        "spellSlots": [
          2,
          0,
          0,
          0,
          0
        ]
      },
      "3": {
        "features": [
          "channel_divinity_paladin",
          "paladin_subclass"
        ],
        "proficiencyBonus": "+2",
        "preparedSpells": 4,
        "channelDivinityUses": 2,
        "layOnHandsPool": 15,
        "weaponMasteryCount": 2,
        "spellSlots": [
          3,
          0,
          0,
          0,
          0
        ]
      },
      "4": {
        "features": [
          "ability_score_improvement_paladin"
        ],
        "proficiencyBonus": "+2",
        "preparedSpells": 5,
        "channelDivinityUses": 2,
        "layOnHandsPool": 20,
        "weaponMasteryCount": 2,
        "spellSlots": [
          3,
          0,
          0,
          0,
          0
        ]
      },
      "5": {
        "features": [
          "extra_attack_paladin",
          "faithful_steed"
        ],
        "proficiencyBonus": "+3",
        "preparedSpells": 6,
        "channelDivinityUses": 2,
        "layOnHandsPool": 25,
        "weaponMasteryCount": 2,
        "spellSlots": [
          4,
          2,
          0,
          0,
          0
        ]
      },
      "6": {
        "features": [
          "aura_of_protection"
        ],
        "proficiencyBonus": "+3",
        "preparedSpells": 6,
        "channelDivinityUses": 2,
        "layOnHandsPool": 30,
        "weaponMasteryCount": 2,
        "spellSlots": [
          4,
          2,
          0,
          0,
          0
        ]
      },
      "7": {
        "proficiencyBonus": "+3",
        "preparedSpells": 7,
        "channelDivinityUses": 2,
        "layOnHandsPool": 35,
        "weaponMasteryCount": 2,
        "spellSlots": [
          4,
          3,
          0,
          0,
          0
        ]
      },
      "8": {
        "features": [
          "ability_score_improvement_paladin"
        ],
        "proficiencyBonus": "+3",
        "preparedSpells": 7,
        "channelDivinityUses": 2,
        "layOnHandsPool": 40,
        "weaponMasteryCount": 2,
        "spellSlots": [
          4,
          3,
          0,
          0,
          0
        ]
      },
      "9": {
        "features": [
          "abjure_enemies"
        ],
        "proficiencyBonus": "+4",
        "preparedSpells": 9,
        "channelDivinityUses": 2,
        "layOnHandsPool": 45,
        "weaponMasteryCount": 2,
        "spellSlots": [
          4,
          3,
          2,
          0,
          0
        ]
      },
      "10": {
        "features": [
          "aura_of_courage"
        ],
        "proficiencyBonus": "+4",
        "preparedSpells": 9,
        "channelDivinityUses": 2,
        "layOnHandsPool": 50,
        "weaponMasteryCount": 2,
        "spellSlots": [
          4,
          3,
          2,
          0,
          0
        ]
      },
      "11": {
        "features": [
          "radiant_strikes"
        ],
        "proficiencyBonus": "+4",
        "preparedSpells": 10,
        "channelDivinityUses": 3,
        "layOnHandsPool": 55,
        "weaponMasteryCount": 2,
        "spellSlots": [
          4,
          3,
          3,
          0,
          0
        ]
      },
      "12": {
        "features": [
          "ability_score_improvement_paladin"
        ],
        "proficiencyBonus": "+4",
        "preparedSpells": 10,
        "channelDivinityUses": 3,
        "layOnHandsPool": 60,
        "weaponMasteryCount": 2,
        "spellSlots": [
          4,
          3,
          3,
          0,
          0
        ]
      },
      "13": {
        "proficiencyBonus": "+5",
        "preparedSpells": 11,
        "channelDivinityUses": 3,
        "layOnHandsPool": 65,
        "weaponMasteryCount": 2,
        "spellSlots": [
          4,
          3,
          3,
          1,
          0
        ]
      },
      "14": {
        "features": [
          "restoring_touch"
        ],
        "proficiencyBonus": "+5",
        "preparedSpells": 11,
        "channelDivinityUses": 3,
        "layOnHandsPool": 70,
        "weaponMasteryCount": 2,
        "spellSlots": [
          4,
          3,
          3,
          1,
          0
        ]
      },
      "15": {
        "proficiencyBonus": "+5",
        "preparedSpells": 12,
        "channelDivinityUses": 3,
        "layOnHandsPool": 75,
        "weaponMasteryCount": 2,
        "spellSlots": [
          4,
          3,
          3,
          2,
          0
        ]
      },
      "16": {
        "features": [
          "ability_score_improvement_paladin"
        ],
        "proficiencyBonus": "+5",
        "preparedSpells": 12,
        "channelDivinityUses": 3,
        "layOnHandsPool": 80,
        "weaponMasteryCount": 2,
        "spellSlots": [
          4,
          3,
          3,
          2,
          0
        ]
      },
      "17": {
        "proficiencyBonus": "+6",
        "preparedSpells": 14,
        "channelDivinityUses": 3,
        "layOnHandsPool": 85,
        "weaponMasteryCount": 2,
        "spellSlots": [
          4,
          3,
          3,
          3,
          1
        ]
      },
      "18": {
        "features": [
          "expanded_aura"
        ],
        "proficiencyBonus": "+6",
        "preparedSpells": 14,
        "channelDivinityUses": 3,
        "layOnHandsPool": 90,
        "weaponMasteryCount": 2,
        "spellSlots": [
          4,
          3,
          3,
          3,
          1
        ]
      },
      "19": {
        "features": [
          "epic_boon_paladin"
        ],
        "proficiencyBonus": "+6",
        "preparedSpells": 15,
        "channelDivinityUses": 3,
        "layOnHandsPool": 95,
        "weaponMasteryCount": 2,
        "spellSlots": [
          4,
          3,
          3,
          3,
          2
        ]
      },
      "20": {
        "proficiencyBonus": "+6",
        "preparedSpells": 15,
        "channelDivinityUses": 3,
        "layOnHandsPool": 100,
        "weaponMasteryCount": 2,
        "spellSlots": [
          4,
          3,
          3,
          3,
          2
        ]
      }
    },
    "subclasses": {
      "juramento_de_entrega": {
        "name": "Juramento de la Entrega",
        "levels": {
          "3": {
            "features": [
              "sacred_weapon",
              "oath_of_devotion_spells"
            ]
          },
          "7": {
            "features": [
              "aura_of_devotion"
            ]
          },
          "15": {
            "features": [
              "protective_smite"
            ]
          },
          "20": {
            "features": [
              "holy_nimbus"
            ]
          }
        },
        "features": {
          "sacred_weapon": {
            "name": "Arma sagrada",
            "level": 3,
            "description": "Cuando realizas la acción de atacar, puedes gastar uno de los usos de Canalizar divinidad para imbuir de energía positiva un arma cuerpo a cuerpo que sostengas. Durante 10 minutos o hasta que vuelvas a usar este rasgo, sumas tu modificador por Carisma a las tiradas de ataque que hagas con esa arma (mínimo de +1), y cada vez que aciertes con ella, haces que inflija su tipo de daño normal o daño radiante.\n\nEl arma también emite luz brillante en un radio de 20 pies y luz tenue 20 pies más allá.\n\nPuedes poner fin a este efecto antes (no requiere acción). El efecto también terminará si no llevas el arma contigo."
          },
          "oath_of_devotion_spells": {
            "name": "Conjuros del juramento de entrega",
            "level": 3,
            "description": "La magia de tu juramento garantiza que siempre tengas ciertos conjuros preparados. Cuando alcances un nivel de paladín especificado en la tabla “Conjuros del juramento de entrega”, a partir de entonces siempre tendrás preparados los conjuros que se indican.",
            "table": {
              "title": "Conjuros del juramento de entrega",
              "columns": [
                "Nivel de paladín",
                "Conjuros"
              ],
              "rows": [
                [
                  "3",
                  "Escudo de fe, protección contra el bien y el mal"
                ],
                [
                  "5",
                  "Auxilio, zona de la verdad"
                ],
                [
                  "9",
                  "Disipar magia, señal de esperanza"
                ],
                [
                  "13",
                  "Guardián de la fe, libertad de movimiento"
                ],
                [
                  "17",
                  "Comunión, golpe flamígero"
                ]
              ]
            }
          },
          "aura_of_devotion": {
            "name": "Aura de entrega",
            "level": 7,
            "description": "Tus aliados y tú tenéis inmunidad al estado de hechizados mientras estéis dentro de tu Aura de protección. Si un aliado hechizado entra en el aura, ese estado no tendrá efecto en él mientras esté dentro."
          },
          "protective_smite": {
            "name": "Castigo protector",
            "level": 15,
            "description": "Tu castigo mágico ahora irradia energía protectora. Siempre que lances castigo divino, tus aliados y tú tenéis cobertura media mientras estéis dentro de tu Aura de protección. El aura tiene este beneficio hasta el principio de tu siguiente turno."
          },
          "holy_nimbus": {
            "name": "Halo sagrado",
            "level": 20,
            "description": "Como acción adicional, puedes imbuir de poder divino tu Aura de protección, lo que otorga los beneficios indicados a continuación durante 10 minutos o hasta que les pongas fin (no requiere acción). Cuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo.\n\nTambién puedes restablecer su uso gastando un espacio de conjuro de nivel 5 (no requiere acción).\n\nDaño radiante. Siempre que un enemigo comience su turno dentro del aura, esa criatura recibirá una cantidad de daño radiante igual a tu modificador por Carisma más tu bonificador por competencia.\n\nLuz solar. El aura está llena de luz brillante del sol.\n\nProtección sagrada. Tienes ventaja en las tiradas de salvación que te obliguen a hacer infernales o muertos vivientes."
          }
        }
      },
      "juramento_de_gloria": {
        "name": "Juramento de la Gloria",
        "levels": {
          "3": {
            "features": [
              "peerless_athlete",
              "inspiring_smite",
              "oath_of_glory_spells"
            ]
          },
          "7": {
            "features": [
              "aura_of_alacrity"
            ]
          },
          "15": {
            "features": [
              "glorious_defense"
            ]
          },
          "20": {
            "features": [
              "living_legend"
            ]
          }
        },
        "features": {
          "peerless_athlete": {
            "name": "Atleta sin parangón",
            "level": 3,
            "description": "Como acción adicional, puedes gastar uno de los usos de Canalizar divinidad para potenciar tus capacidades atléticas. Durante 1 hora, tendrás ventaja en las pruebas de Fuerza (Atletismo) y Destreza (Acrobacias) y la distancia de tus saltos de longitud y de altura aumentará en 10 pies (para esta distancia adicional, tendrás que gastar movimiento del modo habitual)."
          },
          "inspiring_smite": {
            "name": "Castigo inspirador",
            "level": 3,
            "description": "Inmediatamente después de que lances castigo divino, puedes gastar uno de los usos de Canalizar divinidad y distribuir puntos de golpe temporales entre criaturas de tu elección (que puede incluirte a ti) que estén a 30 pies o menos de ti. La cantidad total de puntos de golpe temporales es igual a 2d8 más tu nivel de paladín, repartidos como tú quieras entre las criaturas elegidas."
          },
          "oath_of_glory_spells": {
            "name": "Conjuros del juramento de gloria",
            "level": 3,
            "description": "La magia de tu juramento garantiza que siempre tengas ciertos conjuros preparados. Cuando alcances un nivel de paladín especificado en la tabla “Conjuros del juramento de gloria”, a partir de entonces siempre tendrás preparados los conjuros que se indican.",
            "table": {
              "title": "Conjuros del juramento de gloria",
              "columns": [
                "Nivel de paladín",
                "Conjuros"
              ],
              "rows": [
                [
                  "3",
                  "Heroísmo, saeta guía"
                ],
                [
                  "5",
                  "Arma mágica, potenciar característica"
                ],
                [
                  "9",
                  "Acelerar, protección contra energía"
                ],
                [
                  "13",
                  "Compulsión, libertad de movimiento"
                ],
                [
                  "17",
                  "Conocer las leyendas, presencia regia de Yolande"
                ]
              ]
            }
          },
          "aura_of_alacrity": {
            "name": "Aura de celeridad",
            "level": 7,
            "description": "Tu velocidad aumenta en 10 pies.\n\nAdemás, siempre que un aliado entre en tu Aura de protección por primera vez en un turno o comience su turno dentro de ella, la velocidad de ese aliado aumentará en 10 pies hasta el final de su próximo turno."
          },
          "glorious_defense": {
            "name": "Defensa gloriosa",
            "level": 15,
            "description": "Puedes convertir la defensa en un ataque súbito. Si una tirada de ataque os acierta a ti o a otra criatura que puedas ver a 10 pies o menos de ti, puedes llevar a cabo una reacción para sumar un bonificador a la CA del objetivo contra ese ataque, lo que podría hacer que falle. El bonificador es igual a tu modificador por Carisma (mínimo de +1). Si el ataque falla, como parte de esta reacción podrás hacer un ataque con un arma contra el atacante si está en el alcance de tu arma.\n\nPuedes usar este rasgo una cantidad de veces igual a tu modificador por Carisma (mínimo una vez) y recuperas todos los usos tras finalizar un descanso largo."
          },
          "living_legend": {
            "name": "Leyenda viviente",
            "level": 20,
            "description": "Puedes fortalecerte con las leyendas (ya sean veraces o exageradas) de tus grandes hazañas. Como acción adicional, obtienes los beneficios presentados a continuación durante 10 minutos. Cuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo.\n\nTambién puedes restablecer su uso gastando un espacio de conjuro de nivel 5 (no requiere acción).\n\nCarismático. Estás bendecido por una presencia sobrenatural y tienes ventaja en todas las pruebas de Carisma.\n\nGolpe certero. Una vez en cada uno de tus turnos, si fallas una tirada de ataque con un arma, puedes hacer que el ataque acierte.\n\nRepetir tiradas de salvación. Si fallas una tirada de salvación, puedes llevar a cabo una reacción para repetirla. Deberás usar el resultado de la nueva tirada."
          }
        }
      },
      "juramento_de_los_antiguos": {
        "name": "Juramento de los Antiguos",
        "levels": {
          "3": {
            "features": [
              "oath_of_ancients_spells",
              "natures_wrath"
            ]
          },
          "7": {
            "features": [
              "aura_of_warding"
            ]
          },
          "15": {
            "features": [
              "undying_sentinel"
            ]
          },
          "20": {
            "features": [
              "elder_champion"
            ]
          }
        },
        "features": {
          "oath_of_ancients_spells": {
            "name": "Conjuros del juramento de los antiguos",
            "level": 3,
            "description": "La magia de tu juramento garantiza que siempre tengas ciertos conjuros preparados. Cuando alcances un nivel de paladín especificado en la tabla “Conjuros del juramento de los antiguos”, a partir de entonces siempre tendrás preparados los conjuros que se indican.",
            "table": {
              "title": "Conjuros del juramento de los antiguos",
              "columns": [
                "Nivel de paladín",
                "Conjuros"
              ],
              "rows": [
                [
                  "3",
                  "Golpe apresador, hablar con los animales"
                ],
                [
                  "5",
                  "Paso brumoso, rayo de luna"
                ],
                [
                  "9",
                  "Crecimiento vegetal, protección contra energía"
                ],
                [
                  "13",
                  "Piel pétrea, tormenta de hielo"
                ],
                [
                  "17",
                  "Comunión con la naturaleza, paso arbóreo"
                ]
              ]
            }
          },
          "natures_wrath": {
            "name": "Ira de la naturaleza",
            "level": 3,
            "description": "Como acción de magia, puedes gastar uno de los usos de Canalizar divinidad para invocar enredaderas espectrales alrededor de las criaturas cercanas. Todas las criaturas de tu elección que puedas ver a 15 pies o menos de ti deberán superar una tirada de salvación de Fuerza o tendrán el estado de apresadas durante 1 minuto. Una criatura apresada repetirá la tirada de salvación al final de cada uno de sus turnos y, si tiene éxito, se librará del efecto."
          },
          "aura_of_warding": {
            "name": "Aura de salvaguarda",
            "level": 7,
            "description": "La magia ancestral recae sobre ti con tanta fuerza que forma una protección sobrenatural con energía de más allá del Plano Material. Tus aliados y tú tenéis resistencia al daño necrótico, psíquico y radiante mientras estéis dentro de tu Aura de protección."
          },
          "undying_sentinel": {
            "name": "Centinela imperecedero",
            "level": 15,
            "description": "Cuando tus puntos de golpe se reducen a 0 pero no mueres inmediatamente, puedes quedarte con 1 punto de golpe y recuperas una cantidad de ellos igual a tres veces tu nivel de paladín. Cuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo.\n\nAdemás, no podrás envejecer por medios mágicos y dejarás de hacerlo de forma visible."
          },
          "elder_champion": {
            "name": "Campeón ancestral",
            "level": 20,
            "description": "Como acción adicional, puedes imbuir tu Aura de protección de un poder primordial, lo que otorga los beneficios indicados a continuación durante 1 minuto o hasta que les pongas fin (no requiere acción). Cuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo. También puedes restablecer su uso gastando un espacio de conjuro de nivel 5 (no requiere acción).\n\nConjuros veloces. Siempre que lances un conjuro que tenga un tiempo de lanzamiento de una acción, puedes lanzarlo usando una acción adicional en su lugar.\n\nMermar la oposición. Los enemigos dentro del aura tendrán desventaja en las tiradas de salvación contra tus conjuros y opciones de Canalizar divinidad.\n\nRegeneración. Al principio de cada uno de tus turnos, recuperas 10 puntos de golpe."
          }
        }
      },
      "juramento_de_venganza": {
        "name": "Juramento de la Venganza",
        "levels": {
          "3": {
            "features": [
              "oath_of_vengeance_spells",
              "vow_of_enmity"
            ]
          },
          "7": {
            "features": [
              "relentless_avenger"
            ]
          },
          "15": {
            "features": [
              "soul_of_vengeance"
            ]
          },
          "20": {
            "features": [
              "avenging_angel"
            ]
          }
        },
        "features": {
          "oath_of_vengeance_spells": {
            "name": "Conjuros del juramento de venganza",
            "level": 3,
            "description": "La magia de tu juramento garantiza que siempre tengas ciertos conjuros preparados. Cuando alcances un nivel de paladín especificado en la tabla “Conjuros del juramento de venganza”, a partir de entonces siempre tendrás preparados los conjuros que se indican.",
            "table": {
              "title": "Conjuros del juramento de venganza",
              "columns": [
                "Nivel de paladín",
                "Conjuros"
              ],
              "rows": [
                [
                  "3",
                  "Marca del cazador, perdición"
                ],
                [
                  "5",
                  "Inmovilizar persona, paso brumoso"
                ],
                [
                  "9",
                  "Acelerar, protección contra energía"
                ],
                [
                  "13",
                  "Destierro, puerta dimensional"
                ],
                [
                  "17",
                  "Escudriñar, inmovilizar monstruo"
                ]
              ]
            }
          },
          "vow_of_enmity": {
            "name": "Voto de enemistad",
            "level": 3,
            "description": "Cuando realizas la acción de atacar, puedes gastar uno de los usos de Canalizar divinidad para murmurar un voto de enemistad contra una criatura que puedas ver a 30 pies o menos de ti. Tienes ventaja en las tiradas de ataque contra esa criatura durante 1 minuto o hasta que vuelvas a usar este rasgo.\n\nSi los puntos de golpe de la criatura se reducen a 0 antes de que termine el voto, podrás transferirlo a una criatura distinta a 30 pies o menos de ti (no requiere acción)."
          },
          "relentless_avenger": {
            "name": "Vengador implacable",
            "level": 7,
            "description": "Tu concentración sobrenatural te permite impedir la retirada de un enemigo. Cuando aciertes un ataque de oportunidad contra una criatura, puedes reducir su velocidad a 0 hasta el final del turno actual. A continuación, puedes moverte hasta la mitad de tu velocidad como parte de la misma reacción. Este movimiento no provoca ataques de oportunidad."
          },
          "soul_of_vengeance": {
            "name": "Espíritu vengativo",
            "level": 15,
            "description": "Inmediatamente después de que una criatura bajo los efectos de tu Voto de enemistad acierte o falle una tirada de ataque, podrás llevar a cabo una reacción para realizar un ataque cuerpo a cuerpo contra esa criatura si se encuentra dentro del alcance."
          },
          "avenging_angel": {
            "name": "Ángel vengador",
            "level": 20,
            "description": "Como acción adicional, obtienes los beneficios presentados a continuación durante 10 minutos o hasta que les pongas fin (no requiere acción). Cuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo.\n\nTambién puedes restablecer su uso gastando un espacio de conjuro de nivel 5 (no requiere acción).\n\nAura aterradora. Siempre que un enemigo comience su turno dentro de tu Aura de protección, esa criatura deberá superar una tirada de salvación de Sabiduría o tendrá el estado de asustada durante 1 minuto o hasta recibir daño. Las tiradas de ataque contra las criaturas asustadas tienen ventaja.\n\nVuelo. Te crecen unas alas espectrales en la espalda, tienes una velocidad volando de 60 pies y puedes levitar."
          }
        }
      },
      "juramento_de_los_nobles_genios": {
        "name": "Juramento de los Genios Nobles",
        "source": "Forgotten Realms: Heroes of Faerûn / Unearthed Arcana 2025",
        "levels": {
          "3": {
            "features": [
              "elemental_smite",
              "genie_spells",
              "genies_splendor"
            ]
          },
          "7": {
            "features": [
              "aura_of_elemental_shielding"
            ]
          },
          "15": {
            "features": [
              "elemental_rebuke"
            ]
          },
          "20": {
            "features": [
              "noble_scion"
            ]
          }
        },
        "features": {
          "elemental_smite": {
            "name": "Castigo de los genios",
            "level": 3,
            "description": "Inmediatamente después de lanzar Castigo divino, puedes gastar un uso de tu Canalizar Divinidad e invocar uno de los siguientes efectos.\n\nAplastamiento del dao. El objetivo obtiene el estado de agarrado (CD para escapar igual a la CD de salvación de tus conjuros). Mientras esté agarrado de este modo, también tiene el estado de apresado.\n\nHuida del djinni. Te teletransportas a un espacio desocupado que puedas ver a 30 pies o menos de ti y adoptas una forma brumosa hasta el final de tu siguiente turno. Mientras estés en esta forma, tienes inmunidad a los estados de agarrado, derribado y apresado.\n\nFuria del efreeti. El objetivo recibe 2d4 de daño de fuego adicionales.\n\nOleada del marid. El objetivo y cada criatura de tu elección en una emanación de 10 pies originada en ti hacen una tirada de salvación de Fuerza contra la CD de salvación de tus conjuros. Si la fallan, son empujados 15 pies en línea recta alejándose de ti y obtienen el estado de derribado."
          },
          "genie_spells": {
            "name": "Conjuros de genio",
            "level": 3,
            "description": "Cuando alcances un nivel de paladín especificado en la tabla «Conjuros de genio», siempre tendrás preparados los conjuros indicados.",
            "table": {
              "title": "Conjuros de Genio",
              "columns": [
                "Nivel de paladín",
                "Conjuros preparados"
              ],
              "rows": [
                [
                  "3",
                  "Orbe cromático, Elementalismo, Castigo atronador"
                ],
                [
                  "5",
                  "Imagen múltiple, Fuerza fantasmal"
                ],
                [
                  "9",
                  "Volar, Forma gaseosa"
                ],
                [
                  "13",
                  "Conjurar elementales menores, Invocar elemental"
                ],
                [
                  "17",
                  "Castigo desterrador, Contactar con otro plano"
                ]
              ]
            }
          },
          "genies_splendor": {
            "name": "Esplendor genio",
            "level": 3,
            "description": "Cuando no lleves armadura media ni pesada, ganas un bonificador a tu CA igual a tu modificador por Carisma, con un mínimo de +1.\n\nAdemás, ganas competencia en una de las siguientes habilidades de tu elección: Acrobacias, Intimidación, Interpretación o Persuasión."
          },
          "aura_of_elemental_shielding": {
            "name": "Aura elemental",
            "level": 7,
            "description": "Elige uno de los siguientes tipos de daño: ácido, frío, fuego, relámpago o trueno. Tú y tus aliados tenéis resistencia a ese tipo de daño mientras estéis dentro de tu Aura de protección.\n\nAl comienzo de cada uno de tus turnos, puedes cambiar el tipo de daño afectado por este rasgo por otro de la lista, sin requerir acción."
          },
          "elemental_rebuke": {
            "name": "Reprimenda elemental",
            "level": 15,
            "description": "Cuando una tirada de ataque te impacte, puedes usar tu reacción para reducir a la mitad el daño que te inflige el ataque, redondeando hacia abajo, y obligar al atacante a hacer una tirada de salvación de Destreza contra la CD de salvación de tus conjuros. Si falla, recibe 4d10 + tu modificador por Carisma de daño, del tipo que elijas entre ácido, frío, fuego, relámpago o trueno. Si tiene éxito, recibe la mitad del daño.\n\nPuedes usar este rasgo un número de veces igual a tu modificador por Carisma, con un mínimo de una vez, y recuperas todos los usos gastados al terminar un descanso largo."
          },
          "noble_scion": {
            "name": "Vástago noble",
            "level": 20,
            "description": "Como acción adicional, obtienes los beneficios siguientes durante 10 minutos o hasta que los termines, sin requerir acción. Una vez que uses este rasgo, no podrás volver a usarlo hasta terminar un descanso largo. También puedes recuperar su uso gastando un espacio de conjuro de nivel 5, sin requerir acción.\n\nVuelo. Ganas una velocidad de vuelo de 60 pies y puedes mantenerte flotando.\n\nDeseo menor. Cuando tú o un aliado dentro de tu Aura de protección falle una prueba de d20, puedes usar tu reacción para hacer que la prueba tenga éxito en su lugar."
          }
        },
        "tables": {
          "genie_spells_table": {
            "title": "Conjuros de Genio",
            "columns": [
              "Nivel de paladín",
              "Conjuros preparados"
            ],
            "rows": [
              [
                "3",
                "Orbe cromático, Elementalismo, Castigo atronador"
              ],
              [
                "5",
                "Imagen múltiple, Fuerza fantasmal"
              ],
              [
                "9",
                "Volar, Forma gaseosa"
              ],
              [
                "13",
                "Conjurar elementales menores, Invocar elemental"
              ],
              [
                "17",
                "Castigo desterrador, Contactar con otro plano"
              ]
            ]
          }
        }
      }
    },
    "tables": {
      "paladin_progression": {
        "title": "Rasgos de Paladín",
        "columns": [
          "Nivel",
          "Bonificador por competencia",
          "Rasgos de clase",
          "Canalizar divinidad",
          "Conjuros preparados",
          "1",
          "2",
          "3",
          "4",
          "5"
        ],
        "rows": [
          [
            "1",
            "+2",
            "Imponer las manos, Lanzamiento de conjuros, Maestría con armas",
            "0",
            "2",
            "2",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "2",
            "+2",
            "Castigo de paladín, Estilo de combate",
            "0",
            "3",
            "2",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "3",
            "+2",
            "Canalizar divinidad, Subclase de paladín",
            "2",
            "4",
            "3",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "4",
            "+2",
            "Mejora de característica",
            "2",
            "5",
            "3",
            "-",
            "-",
            "-",
            "-"
          ],
          [
            "5",
            "+3",
            "Ataque adicional, Corcel fiel",
            "2",
            "6",
            "4",
            "2",
            "-",
            "-",
            "-"
          ],
          [
            "6",
            "+3",
            "Aura de protección",
            "2",
            "6",
            "4",
            "2",
            "-",
            "-",
            "-"
          ],
          [
            "7",
            "+3",
            "Rasgo de subclase",
            "2",
            "7",
            "4",
            "3",
            "-",
            "-",
            "-"
          ],
          [
            "8",
            "+3",
            "Mejora de característica",
            "2",
            "7",
            "4",
            "3",
            "-",
            "-",
            "-"
          ],
          [
            "9",
            "+4",
            "Abjurar de los enemigos",
            "2",
            "9",
            "4",
            "3",
            "2",
            "-",
            "-"
          ],
          [
            "10",
            "+4",
            "Aura de coraje",
            "2",
            "9",
            "4",
            "3",
            "2",
            "-",
            "-"
          ],
          [
            "11",
            "+4",
            "Golpes radiantes",
            "3",
            "10",
            "4",
            "3",
            "3",
            "-",
            "-"
          ],
          [
            "12",
            "+4",
            "Mejora de característica",
            "3",
            "10",
            "4",
            "3",
            "3",
            "-",
            "-"
          ],
          [
            "13",
            "+5",
            "—",
            "3",
            "11",
            "4",
            "3",
            "3",
            "1",
            "-"
          ],
          [
            "14",
            "+5",
            "Toque reparador",
            "3",
            "11",
            "4",
            "3",
            "3",
            "1",
            "-"
          ],
          [
            "15",
            "+5",
            "Rasgo de subclase",
            "3",
            "12",
            "4",
            "3",
            "3",
            "2",
            "-"
          ],
          [
            "16",
            "+5",
            "Mejora de característica",
            "3",
            "12",
            "4",
            "3",
            "3",
            "2",
            "-"
          ],
          [
            "17",
            "+6",
            "—",
            "3",
            "14",
            "4",
            "3",
            "3",
            "3",
            "1"
          ],
          [
            "18",
            "+6",
            "Expansión de aura",
            "3",
            "14",
            "4",
            "3",
            "3",
            "3",
            "1"
          ],
          [
            "19",
            "+6",
            "Don épico",
            "3",
            "15",
            "4",
            "3",
            "3",
            "3",
            "2"
          ],
          [
            "20",
            "+6",
            "Rasgo de subclase",
            "3",
            "15",
            "4",
            "3",
            "3",
            "3",
            "2"
          ]
        ]
      }
    }
  },
  "picaro": {
    "id": "picaro",
    "name": "Pícaro",
    "primaryAbility": [
      "Destreza"
    ],
    "hitDie": "1d8",
    "savingThrows": [
      "Destreza",
      "Inteligencia"
    ],
    "skillChoices": {
      "choose": 4,
      "from": [
        "Acrobacias",
        "Atletismo",
        "Engaño",
        "Intimidación",
        "Investigación",
        "Juego de manos",
        "Percepción",
        "Perspicacia",
        "Persuasión",
        "Sigilo"
      ]
    },
    "weaponProficiencies": [
      "Armas sencillas",
      "Armas marciales con la propiedad ligera",
      "Armas marciales con la propiedad sutil"
    ],
    "toolProficiencies": [
      "Herramientas de ladrón"
    ],
    "armorTraining": [
      "Armaduras ligeras"
    ],
    "startingEquipment": {
      "options": [
        {
          "label": "A",
          "items": [
            "Armadura de cuero",
            "2 dagas",
            "Espada corta",
            "Arco corto",
            "20 flechas",
            "Aljaba",
            "Herramientas de ladrón",
            "Paquete de ladrón",
            "3 po"
          ]
        },
        {
          "label": "B",
          "items": [
            "100 po"
          ]
        }
      ]
    },
    "features": {
      "sneak_attack": {
        "name": "Ataque furtivo",
        "level": 1,
        "description": "Sabes cómo atacar sutilmente y aprovecharte de un enemigo distraído. Una vez por turno, puedes infligir 1d6 de daño adicional a una criatura a la que aciertes con una tirada de ataque si tienes ventaja en la tirada y si ha sido utilizando un arma sutil o a distancia. El daño adicional es del mismo tipo que el del arma.\n\nNo necesitas tener ventaja en la tirada de ataque si al menos uno de tus aliados está a 5 pies o menos del objetivo, dicho aliado no tiene el estado de incapacitado y no sufres desventaja en la tirada de ataque.\n\nEl daño adicional aumenta conforme subes de nivel de pícaro, como se muestra en la columna “Ataque furtivo” de la tabla “Rasgos de pícaro”."
      },
      "thieves_cant": {
        "name": "Jerga de ladrones",
        "level": 1,
        "description": "Has aprendido varios idiomas en las comunidades donde empleabas tus talentos de pícaro. Conoces la jerga de ladrones y otro idioma de tu elección de las tablas de idiomas del capítulo 2."
      },
      "weapon_mastery_rogue": {
        "name": "Maestría con armas",
        "level": 1,
        "description": "Tu entrenamiento con armas te permite utilizar las propiedades de maestría con dos tipos de armas de tu elección con las que tengas competencia, como dagas y arcos cortos.\n\nTras finalizar un descanso largo, puedes cambiar los tipos de armas elegidas. Por ejemplo, podrías pasar a utilizar las propiedades de maestría con cimitarras y espadas cortas."
      },
      "expertise": {
        "name": "Pericia",
        "level": 1,
        "description": "Ganas pericia en dos de tus competencias en habilidades de tu elección. Se recomiendan Juego de manos y Sigilo si eres competente en ellas.\n\nEn el nivel 6 de pícaro ganas pericia en otras dos competencias en habilidades de tu elección."
      },
      "cunning_action": {
        "name": "Acción astuta",
        "level": 2,
        "description": "Tu agilidad mental y tu rapidez te permiten moverte y actuar con presteza. En tu turno, puedes llevar a cabo una de las siguientes acciones como acción adicional: correr, destrabarse o esconderse."
      },
      "steady_aim": {
        "name": "Puntería certera",
        "level": 3,
        "description": "Como acción adicional, te concedes ventaja en tu siguiente tirada de ataque del turno actual. Solo puedes usar este rasgo si no te has movido durante este turno y, después de usarlo, tu velocidad es 0 hasta el final del turno."
      },
      "rogue_subclass": {
        "name": "Subclase de pícaro",
        "level": 3,
        "description": "Consigues una subclase de pícaro de tu elección.\n\nLas subclases de asesino, embaucador arcano, ladrón y rebanaalmas se detallan tras la descripción de esta clase.\n\nUna subclase es una especialización que te proporciona rasgos cuando alcanzas ciertos niveles de pícaro. De aquí en adelante, obtienes todos los rasgos de tu subclase que sean de tu nivel de pícaro e inferiores."
      },
      "ability_score_improvement_rogue": {
        "name": "Mejora de característica",
        "level": 4,
        "description": "Obtienes la dote Mejora de característica (consulta el capítulo 5) u otra dote de tu elección para la que cumplas las condiciones. Vuelves a obtener este rasgo en los niveles 8, 10, 12 y 16 de pícaro."
      },
      "uncanny_dodge": {
        "name": "Esquiva asombrosa",
        "level": 5,
        "description": "Cuando un atacante que puedas ver te acierte con una tirada de ataque, puedes usar una reacción para reducir a la mitad el daño que te causa dicho ataque (redondeando hacia abajo)."
      },
      "cunning_strike": {
        "name": "Golpe astuto",
        "level": 5,
        "description": "Has desarrollado formas astutas de usar tu Ataque furtivo. Cuando infliges daño de Ataque furtivo, puedes añadir uno de los siguientes efectos de Golpe astuto. Cada uno tiene un coste en dados que es la cantidad de dados de daño de Ataque furtivo a los que debes renunciar para añadir el efecto. Retiras la cantidad de dados antes de tirar y el efecto se produce inmediatamente después de que se cause el daño del ataque. Por ejemplo, si añades el efecto de veneno, quita 1d6 del daño de Ataque furtivo antes de tirar.\n\nSi un efecto de Golpe astuto requiere una tirada de salvación, la CD es igual a 8 más tu modificador por Destreza y tu bonificador por competencia.\n\nRetirada (coste: 1d6). Justo después del ataque, te mueves hasta la mitad de tu velocidad sin provocar ataques de oportunidad.\n\nTropiezo (coste: 1d6). Si el objetivo es Grande o más pequeño, deberá superar una tirada de salvación de Destreza o tendrá el estado de derribado.\n\nVeneno (coste: 1d6). Añades una toxina a tu golpe, lo que obliga al objetivo a hacer una tirada de salvación de Constitución. Si la falla, tendrá el estado de envenenado durante 1 minuto. Al final de cada uno de sus turnos, el objetivo envenenado repetirá la tirada de salvación y, si tiene éxito, se librará del efecto.\n\nPara usar este efecto, debes llevar contigo unos útiles de envenenador."
      },
      "evasion": {
        "name": "Evasión",
        "level": 7,
        "description": "Puedes esquivar con agilidad ciertos peligros. Cuando sufras un efecto que te permita hacer una tirada de salvación de Destreza para sufrir solo la mitad de daño, no recibes daño alguno si la superas y solo sufres la mitad si la fallas. No puedes usar este rasgo si tienes el estado de incapacitado."
      },
      "reliable_talent": {
        "name": "Talentos fiables",
        "level": 7,
        "description": "Cuando hagas una prueba de característica que utilice una de tus competencias en habilidades o con herramientas, puedes sustituir un resultado de 9 o menos en el d20 por un 10."
      },
      "improved_cunning_strike": {
        "name": "Golpe astuto mejorado",
        "level": 11,
        "description": "Puedes usar hasta dos efectos de Golpe astuto cuando inflijas daño de Ataque furtivo pagando el coste en dados por cada efecto."
      },
      "devious_strikes": {
        "name": "Golpes taimados",
        "level": 14,
        "description": "Has practicado nuevas formas de usar tu Ataque furtivo de forma artera. Entre las opciones de Golpe astuto se encuentran ahora los siguientes efectos.\n\nConfundir (coste: 2d6). El objetivo deberá superar una tirada de salvación de Constitución. Si no lo hace, en su próximo turno solo podrá moverse, realizar una acción o realizar una acción adicional.\n\nNoquear (coste: 6d6). El objetivo deberá superar una tirada de salvación de Constitución o tendrá el estado de inconsciente durante 1 minuto o hasta recibir daño. El objetivo inconsciente repetirá la tirada de salvación al final de cada uno de sus turnos y, si tiene éxito, se librará del efecto.\n\nOfuscar (coste: 3d6). El objetivo deberá superar una tirada de salvación de Destreza o tendrá el estado de cegado hasta el final de su siguiente turno."
      },
      "slippery_mind": {
        "name": "Mente escurridiza",
        "level": 15,
        "description": "Tu mente astuta es excepcionalmente difícil de controlar. Ganas competencia en las tiradas de salvación de Sabiduría y Carisma."
      },
      "elusive": {
        "name": "Elusivo",
        "level": 18,
        "description": "Eres tan escurridizo que será raro que un atacante pueda golpearte con facilidad. Ninguna tirada de ataque contra ti tendrá ventaja a menos que tengas el estado de incapacitado."
      },
      "epic_boon_rogue": {
        "name": "Don épico",
        "level": 19,
        "description": "Obtienes una dote de don épico (consulta el capítulo 5) u otra dote de tu elección para la que cumplas las condiciones. Se recomienda Don del espíritu de la noche."
      },
      "stroke_of_luck": {
        "name": "Golpe de suerte",
        "level": 20,
        "description": "Has desarrollado una capacidad asombrosa para tener éxito justo cuando lo necesitas. Si fallas una prueba con d20, puedes convertir el resultado de la tirada en un 20.\n\nCuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso corto o largo."
      }
    },
    "levels": {
      "1": {
        "proficiencyBonus": "+2",
        "sneakAttackDice": "1d6",
        "features": [
          "sneak_attack",
          "thieves_cant",
          "weapon_mastery_rogue",
          "expertise"
        ]
      },
      "2": {
        "proficiencyBonus": "+2",
        "sneakAttackDice": "1d6",
        "features": [
          "cunning_action"
        ]
      },
      "3": {
        "proficiencyBonus": "+2",
        "sneakAttackDice": "2d6",
        "features": [
          "steady_aim",
          "rogue_subclass"
        ]
      },
      "4": {
        "proficiencyBonus": "+2",
        "sneakAttackDice": "2d6",
        "features": [
          "ability_score_improvement_rogue"
        ]
      },
      "5": {
        "proficiencyBonus": "+3",
        "sneakAttackDice": "3d6",
        "features": [
          "uncanny_dodge",
          "cunning_strike"
        ]
      },
      "6": {
        "proficiencyBonus": "+3",
        "sneakAttackDice": "3d6",
        "features": [
          "expertise"
        ]
      },
      "7": {
        "proficiencyBonus": "+3",
        "sneakAttackDice": "4d6",
        "features": [
          "evasion",
          "reliable_talent"
        ]
      },
      "8": {
        "proficiencyBonus": "+3",
        "sneakAttackDice": "4d6",
        "features": [
          "ability_score_improvement_rogue"
        ]
      },
      "9": {
        "proficiencyBonus": "+4",
        "sneakAttackDice": "5d6"
      },
      "10": {
        "proficiencyBonus": "+4",
        "sneakAttackDice": "5d6",
        "features": [
          "ability_score_improvement_rogue"
        ]
      },
      "11": {
        "proficiencyBonus": "+4",
        "sneakAttackDice": "6d6",
        "features": [
          "improved_cunning_strike"
        ]
      },
      "12": {
        "proficiencyBonus": "+4",
        "sneakAttackDice": "6d6",
        "features": [
          "ability_score_improvement_rogue"
        ]
      },
      "13": {
        "proficiencyBonus": "+5",
        "sneakAttackDice": "7d6"
      },
      "14": {
        "proficiencyBonus": "+5",
        "sneakAttackDice": "7d6",
        "features": [
          "devious_strikes"
        ]
      },
      "15": {
        "proficiencyBonus": "+5",
        "sneakAttackDice": "8d6",
        "features": [
          "slippery_mind"
        ]
      },
      "16": {
        "proficiencyBonus": "+5",
        "sneakAttackDice": "8d6",
        "features": [
          "ability_score_improvement_rogue"
        ]
      },
      "17": {
        "proficiencyBonus": "+6",
        "sneakAttackDice": "9d6"
      },
      "18": {
        "proficiencyBonus": "+6",
        "sneakAttackDice": "9d6",
        "features": [
          "elusive"
        ]
      },
      "19": {
        "proficiencyBonus": "+6",
        "sneakAttackDice": "10d6",
        "features": [
          "epic_boon_rogue"
        ]
      },
      "20": {
        "proficiencyBonus": "+6",
        "sneakAttackDice": "10d6",
        "features": [
          "stroke_of_luck"
        ]
      }
    },
    "subclasses": {
      "asesino": {
        "name": "Asesino",
        "levels": {
          "3": {
            "features": [
              "assassinate",
              "assassins_tools"
            ]
          },
          "9": {
            "features": [
              "infiltration_expertise"
            ]
          },
          "13": {
            "features": [
              "envenenar_armas"
            ]
          },
          "17": {
            "features": [
              "golpe_mortal"
            ]
          }
        },
        "features": {
          "assassinate": {
            "name": "Asesinar",
            "level": 3,
            "description": "Se te da muy bien emboscar objetivos, lo que te otorga los siguientes beneficios.\n\nGolpes sorprendentes. Durante el primer asalto de cada combate, tienes ventaja en las tiradas de ataque contra cualquier criatura que aún no haya jugado un turno. Si tu Ataque furtivo acierta a cualquier objetivo durante ese asalto, el objetivo recibirá un daño adicional del tipo del arma igual a tu nivel de pícaro.\n\nIniciativa. Tienes ventaja en las tiradas de iniciativa."
          },
          "assassins_tools": {
            "name": "Herramientas de asesino",
            "level": 3,
            "description": "Consigues útiles de envenenador y útiles para disfrazarse y tienes competencia con ellos."
          },
          "infiltration_expertise": {
            "name": "Pericia en infiltrarse",
            "level": 9,
            "description": "Eres experto en las siguientes técnicas que te ayudan en tus infiltraciones.\n\nImitación magistral. Puedes imitar a la perfección el habla de otra persona, su caligrafía o ambas si pasas al menos 1 hora estudiándolas.\n\nPuntería ambulante. Tu velocidad no se reduce a 0 cuando usas Puntería certera."
          },
          "envenenar_armas": {
            "name": "Envenenar armas",
            "level": 13,
            "description": "Cuando utilizas la opción de veneno de tu Golpe astuto, el objetivo también recibirá 2d6 de daño de veneno si falla la tirada de salvación. Este daño ignora la resistencia al daño de veneno."
          },
          "golpe_mortal": {
            "name": "Golpe mortal",
            "level": 17,
            "description": "Cuando aciertes con tu Ataque furtivo en el primer asalto de un combate, el objetivo deberá hacer una tirada de salvación de Constitución (CD 8 más tu modificador por Destreza y tu bonificador por competencia). Si no la supera, se duplicará el daño del ataque contra el objetivo."
          }
        }
      },
      "embaucador_arcano": {
        "name": "Embaucador Arcano",
        "levels": {
          "3": {
            "features": [
              "arcane_trickster_spellcasting",
              "mage_hand_versatility"
            ]
          },
          "9": {
            "features": [
              "magical_ambush"
            ]
          },
          "13": {
            "features": [
              "versatile_trickster"
            ]
          },
          "17": {
            "features": [
              "spell_thief"
            ]
          }
        },
        "features": {
          "arcane_trickster_spellcasting": {
            "name": "Lanzamiento de conjuros",
            "level": 3,
            "description": "Has aprendido a lanzar conjuros. Consulta el capítulo 7 para ver las reglas sobre el lanzamiento de conjuros. La información presentada a continuación detalla cómo usar esas reglas como embaucador arcano.\n\nTrucos. Conoces tres trucos: mano de mago y otros dos de tu elección de la lista de conjuros de mago (consulta esa clase para ver la lista). Se recomiendan fragmento mental e ilusión menor.\n\nCada vez que subas un nivel de pícaro, puedes sustituir uno de tus trucos, excepto mano de mago, por otro truco de mago de tu elección.\n\nCuando alcanzas el nivel 10 de pícaro, aprendes otro truco de mago de tu elección.\n\nEspacios de conjuro. La tabla “Lanzamiento de conjuros del embaucador arcano” muestra cuántos espacios de conjuro tienes para lanzar tus conjuros de nivel 1 y superiores. Recuperas todos los espacios utilizados tras finalizar un descanso largo.\n\nConjuros preparados de nivel 1 y superiores. Preparas una serie de conjuros de nivel 1 y superiores, que son los que podrás lanzar con este rasgo. Para empezar, elige tres conjuros de mago de nivel 1. Se recomiendan disfrazarse, hechizar persona y nube de oscurecimiento.\n\nEl número de conjuros de tu lista aumenta conforme subes de nivel de pícaro, como se muestra en la columna “Conjuros preparados” de la tabla “Lanzamiento de conjuros del embaucador arcano”. Cuando ese número aumente, elige conjuros de mago adicionales hasta que el número de conjuros de tu lista coincida con el número de la tabla “Lanzamiento de conjuros del embaucador arcano”. Estos conjuros deben ser de un nivel para el que tengas espacios de conjuro. Por ejemplo, si eres un pícaro de nivel 7, podrías preparar cualquier combinación de cinco conjuros de mago de nivel 1 o 2.\n\nCambiar los conjuros preparados. Cada vez que subas un nivel de pícaro, puedes sustituir un conjuro de tu lista por otro conjuro de mago para el que tengas espacio de conjuro.\n\nAptitud mágica. La Inteligencia es tu aptitud mágica en lo que respecta a tus conjuros de mago.\n\nCanalizador mágico. Puedes utilizar un canalizador arcano como canalizador mágico para tus conjuros de mago.",
            "table": {
              "title": "Lanzamiento de conjuros del embaucador arcano",
              "columns": [
                "Nivel de pícaro",
                "Conjuros preparados",
                "Nivel 1",
                "Nivel 2",
                "Nivel 3",
                "Nivel 4"
              ],
              "rows": [
                [
                  "3",
                  "3",
                  "2",
                  "—",
                  "—",
                  "—"
                ],
                [
                  "4",
                  "4",
                  "3",
                  "—",
                  "—",
                  "—"
                ],
                [
                  "5",
                  "4",
                  "3",
                  "—",
                  "—",
                  "—"
                ],
                [
                  "6",
                  "4",
                  "3",
                  "—",
                  "—",
                  "—"
                ],
                [
                  "7",
                  "5",
                  "4",
                  "2",
                  "—",
                  "—"
                ],
                [
                  "8",
                  "6",
                  "4",
                  "2",
                  "—",
                  "—"
                ],
                [
                  "9",
                  "6",
                  "4",
                  "2",
                  "—",
                  "—"
                ],
                [
                  "10",
                  "7",
                  "4",
                  "3",
                  "—",
                  "—"
                ],
                [
                  "11",
                  "8",
                  "4",
                  "3",
                  "—",
                  "—"
                ],
                [
                  "12",
                  "8",
                  "4",
                  "3",
                  "—",
                  "—"
                ],
                [
                  "13",
                  "9",
                  "4",
                  "3",
                  "2",
                  "—"
                ],
                [
                  "14",
                  "10",
                  "4",
                  "3",
                  "2",
                  "—"
                ],
                [
                  "15",
                  "10",
                  "4",
                  "3",
                  "2",
                  "—"
                ],
                [
                  "16",
                  "11",
                  "4",
                  "3",
                  "3",
                  "—"
                ],
                [
                  "17",
                  "11",
                  "4",
                  "3",
                  "3",
                  "2"
                ],
                [
                  "18",
                  "11",
                  "4",
                  "3",
                  "3",
                  "2"
                ],
                [
                  "19",
                  "12",
                  "4",
                  "3",
                  "3",
                  "1"
                ],
                [
                  "20",
                  "13",
                  "4",
                  "3",
                  "3",
                  "1"
                ]
              ]
            }
          },
          "mage_hand_versatility": {
            "name": "Destreza con mano de mago",
            "level": 3,
            "description": "Cuando lanzas mano de mago, puedes hacerlo como acción adicional y de modo que la mano espectral sea invisible.\n\nPuedes controlar la mano como acción adicional y usarla para hacer pruebas de Destreza (Juego de manos)."
          },
          "magical_ambush": {
            "name": "Emboscada mágica",
            "level": 9,
            "description": "Si tienes el estado de invisible cuando lances un conjuro sobre una criatura, tendrá desventaja en cualquier tirada de salvación que haga contra el conjuro ese mismo turno."
          },
          "versatile_trickster": {
            "name": "Embaucador versátil",
            "level": 13,
            "description": "Obtienes la capacidad de distraer a los objetivos con tu mano de mago. Cuando utilizas la opción de tropiezo de tu Golpe astuto sobre una criatura, también podrás usar esa opción sobre otra criatura a 5 pies o menos de la mano espectral."
          },
          "spell_thief": {
            "name": "Ladrón de conjuros",
            "level": 17,
            "description": "Obtienes la capacidad de robar mágicamente el conocimiento de otro lanzador para usar un conjuro.\n\nInmediatamente después de que una criatura lance un conjuro que te haga objetivo o cuya área de efecto te incluya, puedes usar una reacción para obligar a la criatura a hacer una tirada de salvación de Inteligencia. La CD es tu CD de salvación de conjuros. Si la falla, anularás los efectos del conjuro sobre ti y robarás el conocimiento de cómo lanzarlo si es al menos de nivel 1 y de un nivel que puedas lanzar (no tiene por qué ser un conjuro de mago).\n\nDurante las siguientes 8 horas, tendrás el conjuro preparado. Además, la criatura no podrá lanzarlo hasta que las 8 horas hayan pasado.\n\nUna vez robes un conjuro empleando este rasgo, no podrás volver a utilizar el rasgo hasta que finalices un descanso largo."
          }
        }
      },
      "ladron": {
        "name": "Ladrón",
        "levels": {
          "3": {
            "features": [
              "balconero",
              "manos_rapidas"
            ]
          },
          "9": {
            "features": [
              "sigilo_supremo"
            ]
          },
          "13": {
            "features": [
              "usar_objetos_magicos"
            ]
          },
          "17": {
            "features": [
              "reflejos_de_ladron"
            ]
          }
        },
        "features": {
          "balconero": {
            "name": "Balconero",
            "level": 3,
            "description": "Te has entrenado para llegar a lugares especialmente difíciles de alcanzar, lo que te otorga los siguientes beneficios.\n\nEscalador. Obtienes una velocidad trepando igual a tu velocidad.\n\nSaltador. Puedes determinar tu distancia de salto empleando tu Destreza en lugar de tu Fuerza."
          },
          "manos_rapidas": {
            "name": "Manos rápidas",
            "level": 3,
            "description": "Como acción adicional, puedes hacer una de las siguientes cosas:\n\nJuego de manos. Haz una prueba de Destreza (Juego de manos) para robarle a alguien o usar herramientas de ladrón para forzar una cerradura o desarmar una trampa.\n\nUsar un objeto. Emplea la acción de utilizar o la acción de magia para usar un objeto mágico que necesite una acción."
          },
          "sigilo_supremo": {
            "name": "Sigilo supremo",
            "level": 9,
            "description": "Obtienes la siguiente opción de Golpe astuto.\n\nAtaque sigiloso (coste: 1d6). Si tienes el estado de invisible por una acción de esconderse, este ataque no pone fin a ese estado si terminas el turno tras una cobertura tres cuartos o cobertura completa."
          },
          "usar_objetos_magicos": {
            "name": "Usar objetos mágicos",
            "level": 13,
            "description": "Has aprendido a sacarles el máximo provecho a los objetos mágicos, lo que te otorga los siguientes beneficios.\n\nCargas. Siempre que uses una propiedad de objeto mágico que gaste cargas, tira 1d6. Si sacas un 6, usa la propiedad sin gastar cargas.\n\nPergaminos. Puedes usar cualquier pergamino de conjuro empleando la Inteligencia como aptitud mágica para el conjuro. Si el conjuro es de nivel 1 o un truco, puedes lanzarlo de forma fiable. Si el pergamino contiene un conjuro de mayor nivel, primero deberás superar una prueba de Inteligencia (Conocimiento arcano) con CD 10 más el nivel del conjuro. Si la superas, podrás lanzar el conjuro desde el pergamino. Si la fallas, el pergamino se desintegrará.\n\nSintonización. Puedes sintonizarte con hasta cuatro objetos mágicos a la vez."
          },
          "reflejos_de_ladron": {
            "name": "Reflejos de ladrón",
            "level": 17,
            "description": "Eres experto en tender emboscadas y escapar rápidamente del peligro. Puedes actuar dos turnos durante el primer asalto de cualquier combate. Llevarás a cabo tu primer turno según tu iniciativa normal y el segundo en tu iniciativa menos 10."
          }
        }
      },
      "rebanaalmas": {
        "name": "Rebanaalmas",
        "levels": {
          "3": {
            "features": [
              "cuchillas_psiquicas",
              "poder_psionico"
            ]
          },
          "9": {
            "features": [
              "cuchillas_del_alma"
            ]
          },
          "13": {
            "features": [
              "velo_psiquico"
            ]
          },
          "17": {
            "features": [
              "desgarro_mental"
            ]
          }
        },
        "features": {
          "cuchillas_psiquicas": {
            "name": "Cuchillas psíquicas",
            "level": 3,
            "description": "Puedes hacer que tu poder se manifieste en forma de resplandecientes cuchillas de energía psíquica. Siempre que uses la acción de atacar o hagas un ataque de oportunidad, podrás hacer que aparezca una cuchilla psíquica en tu mano libre y realizar el ataque con esa arma. La cuchilla mágica tiene los siguientes atributos:\n\nCategoría de arma: cuerpo a cuerpo sencilla.\n\nDaño al acertar: 1d6 de daño psíquico más el modificador por característica usado para la tirada de ataque.\n\nPropiedades: arrojadiza (alcance 60/120 pies), sutil.\n\nMaestría: molestar (puedes usar esta propiedad y no contará para el total de propiedades que puedes usar con Maestría con armas).\n\nLa cuchilla se desvanecerá inmediatamente después de acertar o fallar contra su objetivo y no dejará ninguna marca aunque le inflija daño.\n\nTras atacar con la cuchilla en tu turno, puedes realizar un ataque cuerpo a cuerpo o a distancia con una segunda cuchilla psíquica como acción adicional en el mismo turno si tu otra mano está libre para crearla. El dado de daño de este ataque extra es 1d4, en vez de 1d6."
          },
          "poder_psionico": {
            "name": "Poder psiónico",
            "level": 3,
            "description": "Albergas una fuente de energía psiónica en tu interior. Esta se representa mediante dados de energía psiónica, que alimentan ciertos poderes que tienes por esta subclase. La tabla “Dados de energía del rebanaalmas” muestra la cantidad de dados que tienes cuando alcanzas ciertos niveles de pícaro y el tamaño del dado.\n\nCualquier rasgo de esta subclase que emplee dados de energía psiónica utiliza solamente los dados de esta subclase.\n\nAlgunos de tus poderes gastan un dado de energía psiónica, tal y como se especifica en la correspondiente descripción, por lo que no podrás usar un poder que requiera emplear un dado de energía psiónica si ya los has gastado todos.\n\nRecuperas uno de tus dados de energía psiónica tras finalizar un descanso corto y todos tras finalizar un descanso largo.\n\nDon psirreforzado. Si fallas una prueba de característica usando una habilidad o una herramienta en la que seas competente, podrás tirar un dado de energía psiónica y sumar el resultado a la prueba, lo que puede convertir un fallo en un éxito. El dado se gasta solo si la tirada tiene éxito.\n\nSusurros psíquicos. Puedes establecer comunicación telepática con otras criaturas. Como acción de magia, elige una o más criaturas que puedas ver, hasta una cantidad igual a tu bonificador por competencia, y luego tira un dado de energía psiónica. Durante un número de horas igual al resultado, las criaturas elegidas podrán hablar contigo telepáticamente y tú podrás hablar telepáticamente con ellas. Para enviar o recibir un mensaje (no requiere acción), la criatura en cuestión y tú debéis estar a 1 milla o menos de distancia. Una criatura puede finalizar el enlace telepático en cualquier momento (no requiere acción).\n\nLa primera vez que utilices este poder tras cada descanso largo, no gastarás el dado de energía psiónica. El resto de veces que uses el poder, gastarás el dado.",
            "table": {
              "title": "Dados de energía del rebanaalmas",
              "columns": [
                "Nivel de pícaro",
                "Tamaño del dado",
                "Cantidad"
              ],
              "rows": [
                [
                  "3",
                  "d6",
                  "4"
                ],
                [
                  "5",
                  "d8",
                  "6"
                ],
                [
                  "9",
                  "d8",
                  "8"
                ],
                [
                  "11",
                  "d10",
                  "9"
                ],
                [
                  "13",
                  "d10",
                  "10"
                ],
                [
                  "17",
                  "d12",
                  "12"
                ]
              ]
            }
          },
          "cuchillas_del_alma": {
            "name": "Cuchillas del alma",
            "level": 9,
            "description": "Ahora puedes usar los siguientes poderes con tus cuchillas psíquicas.\n\nGolpes teledirigidos. Si realizas una tirada de ataque con tu cuchilla psíquica y fallas, podrás tirar un dado de energía psiónica y sumar el número obtenido a la tirada de ataque. Si eso hace que el ataque acierte, gastarás el dado.\n\nTeletransporte psíquico. Como acción adicional, manifiestas una cuchilla psíquica, gastas un dado de energía psiónica y lo tiras, y lanzas la cuchilla a un espacio sin ocupar que puedas ver a hasta una cantidad de pies igual a 10 veces el resultado. Luego te teletransportarás a ese espacio y la cuchilla desparecerá."
          },
          "velo_psiquico": {
            "name": "Velo psíquico",
            "level": 13,
            "description": "Puedes tejer un velo de interferencias psíquicas para enmascararte. Como acción de magia, obtienes el estado de invisible durante 1 hora o hasta que disipes el efecto (no requiere acción). Esta invisibilidad terminará inmediatamente si infliges daño a una criatura o si obligas a una criatura a realizar una tirada de salvación.\n\nCuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo, a menos que gastes un dado de energía psiónica (no requiere acción) para restablecer su uso."
          },
          "desgarro_mental": {
            "name": "Desgarro mental",
            "level": 17,
            "description": "Puedes pegar un tajo a la mente de una criatura con tus cuchillas psíquicas. Cuando uses tus cuchillas psíquicas para infligir daño de Ataque furtivo a una criatura, podrás obligar a ese objetivo a realizar una tirada de salvación de Sabiduría (CD 8 más tu modificador por Destreza y tu bonificador por competencia). Si la falla, el objetivo tendrá el estado de aturdido durante 1 minuto. El objetivo aturdido repetirá la tirada de salvación al final de cada uno de sus turnos y, si tiene éxito, se librará del efecto.\n\nCuando uses este rasgo, no podrás volver a hacerlo hasta que finalices un descanso largo, a menos que gastes tres dados de energía psiónica (no requiere acción) para restablecer su uso."
          }
        }
      },
      "vástago_de_los_tres": {
        "name": "Heredero de los Tres",
        "source": "Forgotten Realms: Heroes of Faerûn / Unearthed Arcana 2025",
        "levels": {
          "3": {
            "features": [
              "bloodthirst",
              "dread_allegiance"
            ]
          },
          "9": {
            "features": [
              "strike_fear"
            ]
          },
          "13": {
            "features": [
              "aura_of_malevolence"
            ]
          },
          "17": {
            "features": [
              "dread_incarnate"
            ]
          }
        },
        "features": {
          "bloodthirst": {
            "name": "Ansia de sangre",
            "level": 3,
            "description": "Si tu Ataque furtivo impacta a una criatura ensangrentada, el objetivo recibe daño adicional del tipo del arma igual a la mitad de tu nivel de pícaro, redondeando hacia arriba.\n\nAdemás, cuando un enemigo que puedas ver es reducido a 0 puntos de golpe, puedes usar tu reacción para teletransportarte a un espacio desocupado que puedas ver a 30 pies o menos de ti. Luego puedes hacer un ataque cuerpo a cuerpo. Puedes usar esta reacción un número de veces igual a tu modificador por Inteligencia, con un mínimo de una vez, y recuperas todos los usos gastados al terminar un descanso largo."
          },
          "dread_allegiance": {
            "name": "Pacto oscuro",
            "level": 3,
            "description": "Elige uno de los Tres Muertos: Bane, Bhaal o Myrkul. Ganas resistencia a un tipo de daño y la capacidad de lanzar un truco, tal como se detalla en la tabla de Lealtad ominosa. Inteligencia es tu aptitud mágica para este truco. Cuando terminas un descanso largo, puedes cambiar tu elección.",
            "table": {
              "title": "Lealtad Ominosa",
              "columns": [
                "Dios",
                "Resistencia al daño",
                "Truco"
              ],
              "rows": [
                [
                  "Bane",
                  "Psíquico",
                  "Ilusión menor"
                ],
                [
                  "Bhaal",
                  "Veneno",
                  "Guardia de cuchillas"
                ],
                [
                  "Myrkul",
                  "Necrótico",
                  "Toque helado"
                ]
              ]
            }
          },
          "strike_fear": {
            "name": "Infundir terror",
            "level": 9,
            "description": "Obtienes la siguiente opción de Golpe artero.\n\nAterrorizar (Coste: 1d6). El objetivo debe superar una tirada de salvación de Sabiduría o tendrá el estado de asustado durante 1 minuto. La criatura asustada repite la tirada al final de cada uno de sus turnos y termina el efecto sobre sí misma si tiene éxito."
          },
          "aura_of_malevolence": {
            "name": "Aura maligna",
            "level": 13,
            "description": "Irradias un poder maligno asociado con uno de los Tres Muertos. Al comienzo de cada uno de tus turnos, cada criatura de tu elección dentro de una emanación de 10 pies originada en ti recibe daño igual a tu modificador por Inteligencia, con un mínimo de 1. El tipo de daño es el mismo que la resistencia al daño que te otorga tu elección en el rasgo Lealtad ominosa.\n\nEl daño infligido por esta aura ignora resistencias. El aura está inactiva mientras tengas el estado de incapacitado."
          },
          "dread_incarnate": {
            "name": "Encarnación oscura",
            "level": 17,
            "description": "Obtienes los siguientes beneficios.\n\nTirano de batalla. Tienes ventaja en las tiradas de ataque contra cualquier criatura que tenga el estado de asustado.\n\nIntención asesina. Cuando tires tus dados de Ataque furtivo, puedes tratar cualquier resultado de 1 o 2 en esos dados como si fuera un 3."
          }
        },
        "tables": {
          "dread_allegiance_table": {
            "title": "Lealtad Ominosa",
            "columns": [
              "Dios",
              "Resistencia al daño",
              "Truco"
            ],
            "rows": [
              [
                "Bane",
                "Psíquico",
                "Ilusión menor"
              ],
              [
                "Bhaal",
                "Veneno",
                "Guardia de cuchillas"
              ],
              [
                "Myrkul",
                "Necrótico",
                "Toque helado"
              ]
            ]
          }
        }
      }
    },
    "tables": {
      "progression": {
        "title": "Rasgos de Pícaro",
        "columns": [
          "Nivel",
          "Bonificador por competencia",
          "Rasgos de clase",
          "Ataque furtivo"
        ],
        "rows": [
          [
            "1",
            "+2",
            "Ataque furtivo, Jerga de ladrones, Maestría con armas, Pericia",
            "1d6"
          ],
          [
            "2",
            "+2",
            "Acción astuta",
            "1d6"
          ],
          [
            "3",
            "+2",
            "Puntería certera, Subclase de pícaro",
            "2d6"
          ],
          [
            "4",
            "+2",
            "Mejora de característica",
            "2d6"
          ],
          [
            "5",
            "+3",
            "Esquiva asombrosa, Golpe astuto",
            "3d6"
          ],
          [
            "6",
            "+3",
            "Pericia",
            "3d6"
          ],
          [
            "7",
            "+3",
            "Evasión, Talentos fiables",
            "4d6"
          ],
          [
            "8",
            "+3",
            "Mejora de característica",
            "4d6"
          ],
          [
            "9",
            "+4",
            "Rasgo de subclase",
            "5d6"
          ],
          [
            "10",
            "+4",
            "Mejora de característica",
            "5d6"
          ],
          [
            "11",
            "+4",
            "Golpe astuto mejorado",
            "6d6"
          ],
          [
            "12",
            "+4",
            "Mejora de característica",
            "6d6"
          ],
          [
            "13",
            "+5",
            "Rasgo de subclase",
            "7d6"
          ],
          [
            "14",
            "+5",
            "Golpes taimados",
            "7d6"
          ],
          [
            "15",
            "+5",
            "Mente escurridiza",
            "8d6"
          ],
          [
            "16",
            "+5",
            "Mejora de característica",
            "8d6"
          ],
          [
            "17",
            "+6",
            "Rasgo de subclase",
            "9d6"
          ],
          [
            "18",
            "+6",
            "Elusivo",
            "9d6"
          ],
          [
            "19",
            "+6",
            "Don épico",
            "10d6"
          ],
          [
            "20",
            "+6",
            "Golpe de suerte",
            "10d6"
          ]
        ]
      }
    }
  },
  "artifice": {
    "id": "artifice",
    "name": "Artífice",
    "primaryAbility": [
      "Inteligencia"
    ],
    "hitDie": "1d8",
    "savingThrows": [
      "Constitución",
      "Inteligencia"
    ],
    "skillChoices": {
      "choose": 2,
      "from": [
        "Arcanos",
        "Historia",
        "Investigación",
        "Medicina",
        "Naturaleza",
        "Percepción",
        "Juego de manos"
      ]
    },
    "weaponProficiencies": [
      "Armas sencillas"
    ],
    "toolProficiencies": [
      "Herramientas de ladrón",
      "Herramientas de manitas",
      "Un tipo de herramientas de artesano a tu elección"
    ],
    "armorTraining": [
      "Armaduras ligeras",
      "Armaduras medias",
      "Escudos"
    ],
    "startingEquipment": {
      "options": [
        {
          "label": "A",
          "items": [
            "Armadura de cuero tachonado",
            "Daga",
            "Herramientas de ladrón",
            "Herramientas de manitas",
            "Paquete de explorador de mazmorras",
            "16 po"
          ]
        },
        {
          "label": "B",
          "items": [
            "150 po"
          ]
        }
      ]
    },
    "classDescription": "Maestros de la invención, los artífices usan ingenio y magia para desbloquear capacidades extraordinarias en los objetos. Ven la magia como un sistema complejo que puede descifrarse y luego aprovecharse en sus conjuros e invenciones.",
    "becoming": {
      "level1": "Obtienes todos los rasgos de la tabla Rasgos básicos del artífice. También obtienes los rasgos de nivel 1 del artífice, que aparecen en la tabla Rasgos de artífice.",
      "multiclass": "Obtienes los siguientes rasgos de la tabla Rasgos básicos del artífice: dado de golpe, competencia con herramientas de manitas, competencia en una habilidad de tu elección de la lista de habilidades del artífice y entrenamiento con armaduras ligeras, armaduras medias y escudos. También obtienes los rasgos de nivel 1 del artífice. Para determinar tus espacios de conjuro disponibles con multiclase, suma la mitad de tus niveles de artífice, redondeando hacia arriba."
    },
    "levels": {
      "1": {
        "proficiencyBonus": "+2",
        "cantripsKnown": 2,
        "preparedSpells": 2,
        "spellSlots": {
          "1": 2,
          "2": 0,
          "3": 0,
          "4": 0,
          "5": 0
        },
        "features": [
          "spellcasting_artifice",
          "tinkers_magic"
        ]
      },
      "2": {
        "proficiencyBonus": "+2",
        "cantripsKnown": 2,
        "preparedSpells": 3,
        "spellSlots": {
          "1": 2,
          "2": 0,
          "3": 0,
          "4": 0,
          "5": 0
        },
        "features": [
          "replicate_magic_item"
        ],
        "plansKnown": 4,
        "magicItems": 2
      },
      "3": {
        "proficiencyBonus": "+2",
        "cantripsKnown": 2,
        "preparedSpells": 4,
        "spellSlots": {
          "1": 3,
          "2": 0,
          "3": 0,
          "4": 0,
          "5": 0
        },
        "features": [
          "artifice_subclass"
        ],
        "plansKnown": 4,
        "magicItems": 2
      },
      "4": {
        "proficiencyBonus": "+2",
        "cantripsKnown": 2,
        "preparedSpells": 5,
        "spellSlots": {
          "1": 3,
          "2": 0,
          "3": 0,
          "4": 0,
          "5": 0
        },
        "features": [
          "ability_score_improvement_artifice"
        ],
        "plansKnown": 4,
        "magicItems": 2
      },
      "5": {
        "proficiencyBonus": "+3",
        "cantripsKnown": 2,
        "preparedSpells": 6,
        "spellSlots": {
          "1": 4,
          "2": 2,
          "3": 0,
          "4": 0,
          "5": 0
        },
        "features": [],
        "plansKnown": 4,
        "magicItems": 2,
        "subclassFeatures": true
      },
      "6": {
        "proficiencyBonus": "+3",
        "cantripsKnown": 2,
        "preparedSpells": 6,
        "spellSlots": {
          "1": 4,
          "2": 2,
          "3": 0,
          "4": 0,
          "5": 0
        },
        "features": [
          "magic_item_tinker"
        ],
        "plansKnown": 5,
        "magicItems": 3
      },
      "7": {
        "proficiencyBonus": "+3",
        "cantripsKnown": 2,
        "preparedSpells": 7,
        "spellSlots": {
          "1": 4,
          "2": 3,
          "3": 0,
          "4": 0,
          "5": 0
        },
        "features": [
          "flash_of_genius"
        ],
        "plansKnown": 5,
        "magicItems": 3
      },
      "8": {
        "proficiencyBonus": "+3",
        "cantripsKnown": 2,
        "preparedSpells": 7,
        "spellSlots": {
          "1": 4,
          "2": 3,
          "3": 0,
          "4": 0,
          "5": 0
        },
        "features": [
          "ability_score_improvement_artifice"
        ],
        "plansKnown": 5,
        "magicItems": 3
      },
      "9": {
        "proficiencyBonus": "+4",
        "cantripsKnown": 2,
        "preparedSpells": 9,
        "spellSlots": {
          "1": 4,
          "2": 3,
          "3": 2,
          "4": 0,
          "5": 0
        },
        "features": [],
        "plansKnown": 5,
        "magicItems": 3,
        "subclassFeatures": true
      },
      "10": {
        "proficiencyBonus": "+4",
        "cantripsKnown": 3,
        "preparedSpells": 9,
        "spellSlots": {
          "1": 4,
          "2": 3,
          "3": 2,
          "4": 0,
          "5": 0
        },
        "features": [
          "magic_item_adept"
        ],
        "plansKnown": 6,
        "magicItems": 4
      },
      "11": {
        "proficiencyBonus": "+4",
        "cantripsKnown": 3,
        "preparedSpells": 10,
        "spellSlots": {
          "1": 4,
          "2": 3,
          "3": 3,
          "4": 0,
          "5": 0
        },
        "features": [
          "spell_storing_item"
        ],
        "plansKnown": 6,
        "magicItems": 4
      },
      "12": {
        "proficiencyBonus": "+4",
        "cantripsKnown": 3,
        "preparedSpells": 10,
        "spellSlots": {
          "1": 4,
          "2": 3,
          "3": 3,
          "4": 0,
          "5": 0
        },
        "features": [
          "ability_score_improvement_artifice"
        ],
        "plansKnown": 6,
        "magicItems": 4
      },
      "13": {
        "proficiencyBonus": "+5",
        "cantripsKnown": 3,
        "preparedSpells": 11,
        "spellSlots": {
          "1": 4,
          "2": 3,
          "3": 3,
          "4": 1,
          "5": 0
        },
        "features": [],
        "plansKnown": 6,
        "magicItems": 4
      },
      "14": {
        "proficiencyBonus": "+5",
        "cantripsKnown": 4,
        "preparedSpells": 11,
        "spellSlots": {
          "1": 4,
          "2": 3,
          "3": 3,
          "4": 1,
          "5": 0
        },
        "features": [
          "advanced_artifice"
        ],
        "plansKnown": 7,
        "magicItems": 5
      },
      "15": {
        "proficiencyBonus": "+5",
        "cantripsKnown": 4,
        "preparedSpells": 12,
        "spellSlots": {
          "1": 4,
          "2": 3,
          "3": 3,
          "4": 2,
          "5": 0
        },
        "features": [],
        "plansKnown": 7,
        "magicItems": 5,
        "subclassFeatures": true
      },
      "16": {
        "proficiencyBonus": "+5",
        "cantripsKnown": 4,
        "preparedSpells": 12,
        "spellSlots": {
          "1": 4,
          "2": 3,
          "3": 3,
          "4": 2,
          "5": 0
        },
        "features": [
          "ability_score_improvement_artifice"
        ],
        "plansKnown": 7,
        "magicItems": 5
      },
      "17": {
        "proficiencyBonus": "+6",
        "cantripsKnown": 4,
        "preparedSpells": 14,
        "spellSlots": {
          "1": 4,
          "2": 3,
          "3": 3,
          "4": 3,
          "5": 1
        },
        "features": [],
        "plansKnown": 7,
        "magicItems": 5
      },
      "18": {
        "proficiencyBonus": "+6",
        "cantripsKnown": 4,
        "preparedSpells": 14,
        "spellSlots": {
          "1": 4,
          "2": 3,
          "3": 3,
          "4": 3,
          "5": 1
        },
        "features": [
          "magic_item_master"
        ],
        "plansKnown": 8,
        "magicItems": 6
      },
      "19": {
        "proficiencyBonus": "+6",
        "cantripsKnown": 4,
        "preparedSpells": 15,
        "spellSlots": {
          "1": 4,
          "2": 3,
          "3": 3,
          "4": 3,
          "5": 2
        },
        "features": [
          "epic_boon_artifice"
        ],
        "plansKnown": 8,
        "magicItems": 6
      },
      "20": {
        "proficiencyBonus": "+6",
        "cantripsKnown": 4,
        "preparedSpells": 15,
        "spellSlots": {
          "1": 4,
          "2": 3,
          "3": 3,
          "4": 3,
          "5": 2
        },
        "features": [
          "soul_of_artifice"
        ],
        "plansKnown": 8,
        "magicItems": 6
      }
    },
    "features": {
      "spellcasting_artifice": {
        "name": "Lanzamiento de Conjuros",
        "level": 1,
        "description": "Has aprendido a canalizar energía mágica a través de objetos. Consulta el manual del jugador para las reglas de lanzamiento de conjuros. La información siguiente detalla cómo utilizas esas reglas con los conjuros de artífice.\n\nHerramientas necesarias. Produces tus conjuros de artífice mediante herramientas. Puedes usar herramientas de ladrón, herramientas de manitas u otro tipo de herramientas de artesano con el que tengas competencia como canalizador mágico, y debes tener uno de esos canalizadores en la mano cuando lances un conjuro de artífice.\n\nTrucos. Conoces dos trucos de artífice a tu elección. Se recomiendan Salpicadura ácida y Prestidigitación. Cada vez que terminas un descanso largo, puedes reemplazar uno de los trucos de este rasgo por otro truco de artífice a tu elección. Cuando alcanzas los niveles 10 y 14 de artífice, aprendes otro truco de artífice, tal y como muestra la columna Trucos de la tabla Rasgos de artífice.\n\nEspacios de conjuro. La tabla Rasgos de artífice muestra cuántos espacios de conjuro tienes para lanzar tus conjuros de nivel 1 o superior. Recuperas todos los espacios gastados al terminar un descanso largo.\n\nConjuros preparados de nivel 1 o superior. Preparas la lista de conjuros de nivel 1 o superior que tienes disponibles para lanzar con este rasgo. Para empezar, elige dos conjuros de nivel 1 de la lista de artífice. Se recomiendan Curar heridas y Grasa.\n\nEl número de conjuros de tu lista aumenta a medida que subes de nivel de artífice, como muestra la columna Conjuros preparados de la tabla Rasgos de artífice. Cada vez que ese número aumente, elige conjuros de artífice adicionales hasta que el total coincida con el valor de la tabla. Los conjuros elegidos deben ser de un nivel para el que tengas espacios de conjuro. Si otro rasgo de artífice te da conjuros que siempre tienes preparados, esos conjuros no cuentan para este límite, aunque siguen contando como conjuros de artífice para ti.\n\nCambiar conjuros preparados. Cada vez que terminas un descanso largo, puedes cambiar tu lista de conjuros preparados sustituyendo cualquiera de ellos por otros conjuros de artífice para los que tengas espacios de conjuro.\n\nAptitud mágica. La Inteligencia es tu aptitud mágica para tus conjuros de artífice."
      },
      "tinkers_magic": {
        "name": "Magia de Manitas",
        "level": 1,
        "description": "Conoces el truco Remendar.\n\nComo acción de magia mientras sostienes herramientas de manitas, puedes crear un objeto en un espacio desocupado a 5 pies de ti, eligiéndolo de la siguiente lista: abrojos, antorcha, barril de aceite, bedroll/ petate, campana, candelabro/vela, cesta, cadena y polea, caltrops/abrojos, cubo, cuerda, frasco, garfio de abordaje, grilletes, jarra, lámpara, manta, mochila/saco, papel, pala, palanca, pergamino, pértiga, red, saco, tarro de cristal, yesca, viales, bola de rodamientos, cepo de caza, picas de hierro, cuerda y cordel.\n\nConsulta las reglas del objeto en el Manual del Jugador. El objeto dura hasta que terminas un descanso largo; en ese momento desaparece.\n\nPuedes usar este rasgo un número de veces igual a tu modificador por Inteligencia (mínimo una vez), y recuperas todos los usos gastados al terminar un descanso largo."
      },
      "replicate_magic_item": {
        "name": "Reproducir Objeto Mágico",
        "level": 2,
        "description": "Has aprendido planos arcanos que utilizas para fabricar objetos mágicos.\n\nPlanos conocidos. Cuando obtienes este rasgo, eliges cuatro planos de la tabla Planos de objetos mágicos (artífice nivel 2+). Se recomiendan Bolsa de contención, Gorro de respiración acuática, Herramienta multiforma y Arma de disparo repetidor. Cada vez que subes un nivel de artífice, puedes reemplazar uno de los planos que conoces por otro plano nuevo para el que cumplas los requisitos.\n\nAprendes otro plano a tu elección cuando alcanzas ciertos niveles de artífice, como muestra la columna Planos conocidos de la tabla Rasgos de artífice. Cuando eliges un plano, puedes escogerlo de cualquier tabla de planos de objetos mágicos para la que cumplas los requisitos; tu elegibilidad depende de tu nivel de artífice.\n\nCrear un objeto. Cada vez que terminas un descanso largo, puedes crear uno o dos objetos mágicos distintos si tienes herramientas de manitas en la mano. Cada objeto se basa en uno de los planos que conoces con este rasgo. Si un objeto creado requiere sintonización, puedes sintonizarte con él en el instante en que lo creas.\n\nCuando alcanzas ciertos niveles de artífice indicados en la columna Objetos mágicos de la tabla Rasgos de artífice, el número de objetos mágicos que puedes crear al final de un descanso largo aumenta. Cada objeto creado debe basarse en un plano distinto que conozcas. No puedes tener más objetos mágicos de este rasgo que el número indicado en la tabla para tu nivel. Si intentas superar ese máximo, el objeto más antiguo desaparece y después aparece el nuevo.\n\nDuración. Un objeto mágico creado con este rasgo funciona como el objeto mágico normal, salvo que su magia no es permanente: cuando mueres, el objeto desaparece tras 1d4 días. Si sustituyes un plano conocido por otro nuevo, cualquier objeto mágico creado con el plano sustituido desaparece de inmediato. Si el objeto era un contenedor, como una Bolsa de contención, su contenido aparece sin daño en su espacio y a su alrededor cuando desaparece.\n\nCanalizador mágico. Puedes usar cualquier varita o arma creada con este rasgo como canalizador mágico en lugar de un juego de herramientas de artesano."
      },
      "artifice_subclass": {
        "name": "Subclase de Artifice",
        "level": 3,
        "description": "Obtienes una subclase de artífice a tu elección. Las subclases Alquimista, Armero, Artillero, Herrero de Batalla y Cartógrafo se detallan tras la descripción de la clase. Una subclase es una especialización que te concede rasgos a ciertos niveles de artífice. A partir de ahora, obtienes todos los rasgos de tu subclase cuyo nivel de artífice sea igual o inferior al tuyo."
      },
      "ability_score_improvement_artifice": {
        "name": "Mejora de Característica",
        "level": 4,
        "description": "Obtienes la dote Mejora de característica u otra dote de tu elección para la que cumplas los requisitos. Vuelves a obtener este rasgo en los niveles 8, 12 y 16 de artífice."
      },
      "magic_item_tinker": {
        "name": "Manitas de Objetos Mágicos",
        "level": 6,
        "description": "Tu rasgo Reproducir objeto mágico obtiene las siguientes opciones.\n\nCargar objeto mágico. Como acción adicional, puedes tocar un objeto mágico creado por ti con Reproducir objeto mágico que esté a 5 pies de ti y que use cargas. Gastas un espacio de conjuro de nivel 1 o superior y recargas el objeto. Recupera un número de cargas igual al nivel del espacio gastado.\n\nDrenar objeto mágico. Como acción adicional, puedes tocar un objeto mágico creado por ti con Reproducir objeto mágico que esté a 5 pies de ti y hacer que desaparezca, convirtiendo su energía en un espacio de conjuro. El espacio es de nivel 1 si el objeto es común, o de nivel 2 si el objeto es poco común o raro. Una vez uses este beneficio, no podrás volver a hacerlo hasta terminar un descanso largo. Cualquier espacio creado con este rasgo desaparece cuando terminas un descanso largo.\n\nTransmutar objeto mágico. Como acción de magia, puedes tocar un objeto mágico creado por ti con Reproducir objeto mágico que esté a 5 pies de ti y transformarlo en otro objeto mágico. El objeto resultante debe basarse en un plano que conozcas. Una vez uses este beneficio, no podrás volver a hacerlo hasta terminar un descanso largo."
      },
      "flash_of_genius": {
        "name": "Destello de Genio",
        "level": 7,
        "description": "Cuando tú o una criatura que puedas ver a 30 pies de ti falle una prueba de característica o una tirada de salvación, puedes usar tu reacción para añadir un bonificador a la tirada, lo que podría convertir el fallo en un éxito. El bonificador es igual a tu modificador por Inteligencia (mínimo +1).\n\nPuedes usar esta reacción un número de veces igual a tu modificador por Inteligencia (mínimo una vez), y recuperas todos los usos gastados al terminar un descanso largo."
      },
      "magic_item_adept": {
        "name": "Adepto de Objetos Mágicos",
        "level": 10,
        "description": "Ahora puedes sintonizarte con hasta cuatro objetos mágicos a la vez."
      },
      "spell_storing_item": {
        "name": "Objeto Almacenaconjuros",
        "level": 11,
        "description": "Cada vez que terminas un descanso largo, puedes tocar un arma sencilla o marcial, o un objeto que puedas usar como canalizador mágico, y almacenar un conjuro en él. Elige un conjuro de artífice de nivel 1, 2 o 3 que tenga un tiempo de lanzamiento de una acción y no requiera un componente material que el conjuro consuma; no necesitas tenerlo preparado.\n\nMientras sostenga el objeto, una criatura puede usar una acción de magia para producir desde él el efecto del conjuro usando tu modificador de aptitud mágica. Si el conjuro requiere concentración, esa criatura debe mantenerla. Después de que una criatura use el objeto para producir el efecto del conjuro, no podrá volver a usarse así hasta el comienzo del siguiente turno de esa criatura.\n\nEl conjuro permanece en el objeto hasta que se haya usado un número de veces igual al doble de tu modificador por Inteligencia (mínimo dos veces) o hasta que vuelvas a usar este rasgo para almacenar un conjuro en otro objeto."
      },
      "advanced_artifice": {
        "name": "Artificio Avanzado",
        "level": 14,
        "description": "Obtienes los siguientes beneficios.\n\nExperto en objetos mágicos. Ahora puedes sintonizarte con hasta cinco objetos mágicos a la vez.\n\nGenio renovado. Cuando terminas un descanso corto, recuperas un uso gastado de tu rasgo Destello de genio."
      },
      "magic_item_master": {
        "name": "Maestro de Objetos Mágicos",
        "level": 18,
        "description": "Ahora puedes sintonizarte con hasta seis objetos mágicos a la vez."
      },
      "epic_boon_artifice": {
        "name": "Don Épico",
        "level": 19,
        "description": "Obtienes una dote de don épico u otra dote de tu elección para la que cumplas los requisitos. Se recomienda Don de resistencia a la energía."
      },
      "soul_of_artifice": {
        "name": "Alma del Artificio",
        "level": 20,
        "description": "Has desarrollado una conexión mística con tus objetos mágicos, de la que puedes extraer ayuda. Obtienes los siguientes beneficios.\n\nEngañar a la muerte. Si tus puntos de golpe se reducen a 0 pero no mueres en el acto, puedes desintegrar cualquier número de objetos mágicos poco comunes o raros creados con tu rasgo Reproducir objeto mágico. Si lo haces, tus puntos de golpe pasan a ser un número igual a 20 multiplicado por el número de objetos mágicos desintegrados.\n\nGuía mágica. Cuando terminas un descanso corto, recuperas todos los usos gastados de Destello de genio si estás sintonizado con al menos un objeto mágico."
      }
    },
    "subclasses": {
      "alquimista": {
        "name": "Alquimista",
        "levels": {
          "3": {
            "features": [
              "tools_of_the_trade_alchemist",
              "alchemist_spells",
              "experimental_elixir"
            ]
          },
          "5": {
            "features": [
              "alchemical_savant"
            ]
          },
          "9": {
            "features": [
              "restorative_reagents"
            ]
          },
          "15": {
            "features": [
              "chemical_mastery"
            ]
          }
        },
        "features": {
          "tools_of_the_trade_alchemist": {
            "name": "Herramientas del Oficio",
            "level": 3,
            "description": "Obtienes los siguientes beneficios.\n\nCompetencia con herramientas. Ganas competencia con útiles de alquimista y con el kit de herboristería. Si ya tienes una de esas competencias, ganas competencia con otro tipo de herramientas de artesano a tu elección; si ya tienes ambas, ganas competencia con otros dos tipos.\n\nFabricación de pociones. Cuando elaboras una poción usando las reglas de fabricación del Dungeon Master's Guide, el tiempo necesario se reduce a la mitad."
          },
          "alchemist_spells": {
            "name": "Conjuros de Alquimista",
            "level": 3,
            "description": "Cuando alcanzas un nivel de artífice indicado en la tabla Conjuros de alquimista, desde entonces siempre tienes preparados los conjuros indicados."
          },
          "experimental_elixir": {
            "name": "Elixir Experimental",
            "level": 3,
            "description": "Cada vez que terminas un descanso largo mientras sostienes útiles de alquimista, puedes usarlos para producir mágicamente dos elixires. Para cada elixir, tira en la tabla Elixir experimental para determinar su efecto; el efecto se activa cuando alguien bebe el elixir. El elixir aparece en un vial, y el vial desaparece cuando el elixir se bebe o se vierte. Si queda algún elixir cuando terminas un descanso largo, el elixir y su vial desaparecen.\n\nBeber un elixir. Como acción adicional, una criatura puede beber el elixir o administrárselo a otra criatura a 5 pies de ella.\n\nCrear elixires adicionales. Como acción de magia mientras sostienes útiles de alquimista, puedes gastar un espacio de conjuro para crear otro elixir. Cuando lo haces, eliges su efecto de la tabla Elixir experimental en lugar de tirar.\n\nCuando alcanzas ciertos niveles de artífice, puedes crear un elixir adicional al final de cada descanso largo: tres en total al nivel 5, cuatro al nivel 9 y cinco al nivel 15."
          },
          "alchemical_savant": {
            "name": "Sabio Alquímico",
            "level": 5,
            "description": "Siempre que lances un conjuro usando tus útiles de alquimista como canalizador mágico, obtienes un bonificador a una tirada de ese conjuro. Esa tirada debe restaurar puntos de golpe o ser una tirada de daño que inflija daño de ácido, fuego o veneno. El bonificador es igual a tu modificador por Inteligencia (mínimo +1)."
          },
          "restorative_reagents": {
            "name": "Reactivos Restauradores",
            "level": 9,
            "description": "Puedes lanzar Restauración menor sin gastar espacio de conjuro y sin tenerlo preparado, siempre que uses tus útiles de alquimista como canalizador mágico. Puedes hacerlo un número de veces igual a tu modificador por Inteligencia (mínimo una vez), y recuperas todos los usos gastados al terminar un descanso largo."
          },
          "chemical_mastery": {
            "name": "Maestría Química",
            "level": 15,
            "description": "Obtienes los siguientes beneficios.\n\nErupción alquímica. Cuando lanzas un conjuro de artífice que inflige daño de ácido, fuego o veneno a un objetivo, también puedes infligir 2d8 de daño de fuerza a ese objetivo. Solo puedes usar este beneficio una vez en cada uno de tus turnos.\n\nResistencia química. Obtienes resistencia al daño de ácido y al daño de veneno. También ganas inmunidad a la condición Envenenado.\n\nCaldero conjurado. Puedes lanzar Caldero burbujeante de Tasha sin gastar espacio de conjuro, sin tenerlo preparado y sin componentes materiales, siempre que uses tus útiles de alquimista como canalizador mágico. Una vez uses este rasgo, no podrás volver a hacerlo hasta terminar un descanso largo."
          }
        },
        "tables": {
          "alchemist_spells_table": {
            "title": "Conjuros de Alquimista",
            "columns": [
              "Nivel de artífice",
              "Conjuros"
            ],
            "rows": [
              [
                "3",
                "Palabra de curación, Rayo nauseabundo"
              ],
              [
                "5",
                "Esfera de llamas, Flecha ácida de Melf"
              ],
              [
                "9",
                "Forma gaseosa, Palabra de curación en masa"
              ],
              [
                "13",
                "Guarda contra la muerte, Esfera vitriólica"
              ],
              [
                "17",
                "Nube aniquiladora, Alzar a los muertos"
              ]
            ]
          },
          "experimental_elixir_table": {
            "title": "Elixir experimental",
            "columns": [
              "1d6",
              "Efecto"
            ],
            "rows": [
              [
                "1",
                "Curación. El bebedor recupera 2d8 + tu modificador por Inteligencia puntos de golpe. La curación aumenta a 3d8 al nivel 9 y a 4d8 al nivel 15."
              ],
              [
                "2",
                "Rapidez. La velocidad del bebedor aumenta 10 pies durante 1 hora. El bono aumenta a 15 pies al nivel 9 y a 20 pies al nivel 15."
              ],
              [
                "3",
                "Resistencia. El bebedor obtiene un bonificador de +1 a la CA durante 10 minutos. La duración aumenta a 1 hora al nivel 9 y a 8 horas al nivel 15."
              ],
              [
                "4",
                "Osadía. El bebedor puede tirar 1d4 y sumar el resultado a todas las tiradas de ataque y tiradas de salvación que haga durante 1 minuto. La duración aumenta a 10 minutos al nivel 9 y a 1 hora al nivel 15."
              ],
              [
                "5",
                "Vuelo. El bebedor obtiene una velocidad de vuelo de 10 pies durante 10 minutos. La velocidad de vuelo aumenta a 20 pies al nivel 9 y a 30 pies al nivel 15."
              ],
              [
                "6",
                "Tú determinas el efecto del elixir eligiendo una de las otras filas de esta tabla."
              ]
            ]
          }
        }
      },
      "armero": {
        "name": "Armero",
        "levels": {
          "3": {
            "features": [
              "tools_of_the_trade_armorer",
              "armorer_spells",
              "arcane_armor",
              "armor_model"
            ]
          },
          "5": {
            "features": [
              "extra_attack_armorer"
            ]
          },
          "9": {
            "features": [
              "improved_armorer"
            ]
          },
          "15": {
            "features": [
              "perfected_armor"
            ]
          }
        },
        "features": {
          "tools_of_the_trade_armorer": {
            "name": "Herramientas del Oficio",
            "level": 3,
            "description": "Obtienes los siguientes beneficios.\n\nEntrenamiento con armadura. Ganas entrenamiento con armaduras pesadas.\n\nCompetencia con herramientas. Ganas competencia con herramientas de herrero. Si ya tienes esa competencia, ganas competencia con otro tipo de herramientas de artesano a tu elección.\n\nFabricación de armaduras. Cuando fabricas una armadura mágica o no mágica, el tiempo necesario se reduce a la mitad."
          },
          "armorer_spells": {
            "name": "Conjuros de Armero",
            "level": 3,
            "description": "Cuando alcanzas un nivel de artífice indicado en la tabla Conjuros de armero, desde entonces siempre tienes preparados los conjuros indicados."
          },
          "arcane_armor": {
            "name": "Armadura Arcana",
            "level": 3,
            "description": "Como acción de magia mientras tienes herramientas de herrero en la mano, puedes convertir una armadura que lleves puesta en Armadura Arcana. La armadura sigue siendo Armadura Arcana hasta que te pongas otra o mueras.\n\nObtienes los siguientes beneficios mientras la llevas.\n\nSin requisito de Fuerza. Si la armadura normalmente tiene un requisito de Fuerza, para ti la Armadura Arcana no lo tiene.\n\nPonérsela y quitársela rápido. Puedes ponerte o quitarte la armadura como acción de Utilizar. La armadura no puede retirarse contra tu voluntad.\n\nCanalizador mágico. Puedes usar la Armadura Arcana como canalizador mágico para tus conjuros de artífice."
          },
          "armor_model": {
            "name": "Modelo de Armadura",
            "level": 3,
            "description": "Puedes personalizar tu Armadura Arcana. Cuando lo hagas, elige uno de los siguientes modelos: Azote Colosal, Guardián o Infiltrado. El modelo elegido te concede beneficios especiales mientras lo lleves.\n\nCada modelo incluye un arma especial. Cuando ataques con esa arma, puedes usar tu modificador por Inteligencia en lugar de Fuerza o Destreza para las tiradas de ataque y daño.\n\nPuedes cambiar el modelo de la armadura cada vez que terminas un descanso corto o largo si tienes herramientas de herrero en la mano.\n\nAzote Colosal. Diseñas tu armadura para convertirse en un coloso de batalla. Tiene los siguientes rasgos.\n\nDemoledor de fuerza. De tu armadura surge una bola demoledora o mazo arcano. Cuenta como arma sencilla cuerpo a cuerpo con la propiedad Alcance e inflige 1d10 de daño de fuerza al impactar. Si golpeas con él a una criatura de al menos una categoría de tamaño inferior a la tuya, puedes empujarla hasta 10 pies en línea recta alejándola de ti o atraerla hasta 10 pies hacia ti.\n\nEstatura gigante. Como acción adicional, transformas y agrandas tu armadura durante 1 minuto. Durante ese tiempo, tu alcance aumenta 5 pies y, si eres menor que Grande, pasas a ser Grande junto con todo lo que llevas puesto. Si no hay espacio suficiente para aumentar de tamaño, tu tamaño no cambia. Puedes usar esta acción adicional un número de veces igual a tu modificador por Inteligencia (mínimo una vez), y recuperas todos los usos gastados al terminar un descanso largo.\n\nGuardián. Diseñas tu armadura para ocupar la primera línea del conflicto. Tiene los siguientes rasgos.\n\nPulso de trueno. Puedes descargar ondas de choque con los golpes de tu armadura. Cuenta como arma sencilla cuerpo a cuerpo e inflige 1d8 de daño de trueno al impactar. Una criatura golpeada tiene desventaja en las tiradas de ataque contra objetivos distintos de ti hasta el comienzo de tu siguiente turno.\n\nCampo defensivo. Mientras estés Maltrecho, puedes usar una acción adicional para ganar puntos de golpe temporales iguales a tu nivel de artífice. Pierdes esos puntos de golpe temporales si te quitas la armadura.\n\nInfiltrado. Ajustas tu armadura para tareas más sutiles. Tiene los siguientes rasgos.\n\nLanzarrayos. En tu armadura aparece un nodo parecido a una gema desde el que puedes disparar rayos. Cuenta como arma sencilla a distancia con alcance normal de 90 pies y alcance largo de 300 pies, e inflige 1d6 de daño de relámpago al impactar. Una vez en cada uno de tus turnos, cuando golpeas a una criatura con él, puedes infligir 1d6 adicional de daño de relámpago a ese objetivo.\n\nPasos potenciados. Tu velocidad aumenta 5 pies.\n\nCampo amortiguador. Tienes ventaja en las pruebas de Destreza (Sigilo). Si la armadura impone desventaja en esas pruebas, ventaja y desventaja se anulan como de costumbre."
          },
          "extra_attack_armorer": {
            "name": "Ataque Adicional",
            "level": 5,
            "description": "Puedes atacar dos veces en lugar de una cuando realizas la acción de Atacar en tu turno."
          },
          "improved_armorer": {
            "name": "Armero Mejorado",
            "level": 9,
            "description": "Obtienes los siguientes beneficios.\n\nReplicación de armadura. Aprendes un plano adicional para tu rasgo Reproducir objeto mágico, y debe pertenecer a la categoría Armadura. Si sustituyes ese plano, debes cambiarlo por otro plano de Armadura.\n\nAdemás, puedes crear un objeto adicional con ese rasgo, y ese objeto también debe pertenecer a la categoría Armadura.\n\nArsenal mejorado. Obtienes un bonificador de +1 a las tiradas de ataque y daño hechas con el arma especial del modelo de tu Armadura Arcana."
          },
          "perfected_armor": {
            "name": "Armadura Perfeccionada",
            "level": 15,
            "description": "Tu Armadura Arcana obtiene beneficios adicionales según su modelo.\n\nAzote Colosal. El dado de daño de tu Demoledor de fuerza aumenta a 2d6 de daño de fuerza. Además, cuando usas tu Estatura gigante, tu alcance aumenta 10 pies, tu tamaño puede aumentar a Grande o Enorme (a tu elección) y tienes ventaja en las pruebas y tiradas de salvación de Fuerza durante toda la duración.\n\nGuardián. El dado de daño de tu Pulso de trueno aumenta a 1d10 de daño de trueno. Además, cuando una criatura Enorme o menor que puedas ver termina su turno a 30 pies de ti, puedes usar tu reacción para obligarla mágicamente a hacer una tirada de salvación de Fuerza contra tu CD de salvación de conjuros. Si falla, atraes a la criatura hasta 25 pies en línea recta hacia ti hasta un espacio desocupado. Si la atraes hasta un espacio a 5 pies de ti, puedes hacer un ataque con arma cuerpo a cuerpo contra ella como parte de la misma reacción. Puedes usar esta reacción un número de veces igual a tu modificador por Inteligencia (mínimo una vez), y recuperas todos los usos gastados al terminar un descanso largo.\n\nInfiltrado. El dado de daño de tu Lanzarrayos aumenta a 2d6 de daño de relámpago. Cualquier criatura que reciba daño de relámpago de tu Lanzarrayos queda iluminada por luz mágica hasta el comienzo de tu siguiente turno. La criatura iluminada emite luz tenue en un radio de 5 pies y tiene desventaja en las tiradas de ataque contra ti, ya que la luz la sacude si te ataca. Además, como acción adicional, puedes ganar una velocidad de vuelo igual al doble de tu velocidad hasta el final del turno actual. Puedes usar esta acción adicional un número de veces igual a tu modificador por Inteligencia (mínimo una vez), y recuperas todos los usos gastados al terminar un descanso largo."
          }
        },
        "tables": {
          "armorer_spells_table": {
            "title": "Conjuros de Armero",
            "columns": [
              "Nivel de artífice",
              "Conjuros"
            ],
            "rows": [
              [
                "3",
                "Proyectil mágico, Ola atronadora"
              ],
              [
                "5",
                "Imagen múltiple, Hacer añicos"
              ],
              [
                "9",
                "Patrón hipnótico, Relámpago"
              ],
              [
                "13",
                "Escudo de fuego, Invisibilidad mejorada"
              ],
              [
                "17",
                "Pasamuros, Muro de fuerza"
              ]
            ]
          }
        }
      },
      "artillero": {
        "name": "Artillero",
        "levels": {
          "3": {
            "features": [
              "tools_of_the_trade_artillerist",
              "artillerist_spells",
              "eldritch_cannon"
            ]
          },
          "5": {
            "features": [
              "arcane_firearm"
            ]
          },
          "9": {
            "features": [
              "explosive_cannon"
            ]
          },
          "15": {
            "features": [
              "fortified_position"
            ]
          }
        },
        "features": {
          "tools_of_the_trade_artillerist": {
            "name": "Herramientas del Oficio",
            "level": 3,
            "description": "Obtienes los siguientes beneficios.\n\nArmas a distancia. Ganas competencia con armas marciales a distancia.\n\nCompetencia con herramientas. Ganas competencia con herramientas de tallista de madera. Si ya la tienes, ganas competencia con otro tipo de herramientas de artesano a tu elección.\n\nFabricación de varitas. Cuando fabricas una varita mágica, el tiempo necesario se reduce a la mitad."
          },
          "artillerist_spells": {
            "name": "Conjuros de Artillero",
            "level": 3,
            "description": "Cuando alcanzas un nivel de artífice indicado en la tabla Conjuros de artillero, desde entonces siempre tienes preparados los conjuros indicados."
          },
          "eldritch_cannon": {
            "name": "Cañón Eldritch",
            "level": 3,
            "description": "Usando herramientas de herrero o herramientas de tallista de madera, puedes realizar una acción de magia para crear un Cañón Eldritch Pequeño o Diminuto en un espacio desocupado sobre una superficie horizontal a 5 pies de ti.\n\nSus estadísticas aparecen en el bloque de estadísticas del cañón. Tú determinas su apariencia, incluyendo si lo llevas encima o no, y si tiene patas o ruedas. Desaparece si se reduce a 0 puntos de golpe o al cabo de 1 hora. Puedes descartarlo antes con una acción de magia.\n\nUna vez creas un cañón, no puedes volver a hacerlo hasta terminar un descanso largo, a menos que gastes un espacio de conjuro para crear otro. Solo puedes tener un cañón a la vez y no puedes crear uno mientras ya tengas otro."
          },
          "arcane_firearm": {
            "name": "Arma de Fuego Arcana",
            "level": 5,
            "description": "Cada vez que terminas un descanso largo, puedes usar herramientas de tallista de madera para grabar sigilos especiales en una vara, bastón, varita o arma marcial a distancia y convertir ese objeto en tu arma de fuego arcana. Los sigilos desaparecen del objeto si más tarde los grabas en otro.\n\nPuedes usar tu arma de fuego arcana como canalizador mágico para tus conjuros de artífice. Cuando lances un conjuro de artífice a través de ella, tira 1d8 y obtienes un bonificador igual al resultado a una de las tiradas de daño del conjuro."
          },
          "explosive_cannon": {
            "name": "Cañón Explosivo",
            "level": 9,
            "description": "Cada Cañón Eldritch que creas es ahora más destructivo. Obtienes los siguientes beneficios.\n\nDetonar. Cuando tu cañón recibe daño, puedes usar tu reacción para ordenarle que detone si estás a 60 pies o menos de él. Al hacerlo, el cañón se destruye y cada criatura en un radio de 20 pies de él debe hacer una tirada de salvación de Destreza contra tu CD de salvación de conjuros. Sufre 3d10 de daño de fuerza con una salvación fallida, o la mitad con una salvación exitosa.\n\nPotencia de fuego. Las tiradas de daño del cañón y el número de puntos de golpe temporales que concede Protector aumentan en 1d8."
          },
          "fortified_position": {
            "name": "Posición Fortificada",
            "level": 15,
            "description": "Eres un maestro formando emplazamientos bien defendidos con tu Cañón Eldritch. Obtienes los siguientes beneficios.\n\nDoble potencia de fuego. Ahora puedes tener dos cañones al mismo tiempo y crear ambos con la misma acción de magia. Si gastas un espacio de conjuro para crear el primero, debes gastar otro para crear el segundo. Puedes activar ambos con la misma acción adicional, ordenándoles usar la misma opción de activación o distintas. No puedes crear un tercer cañón mientras tengas dos.\n\nProyección de campo centelleante. Tú y tus aliados tenéis media cobertura mientras estéis a 10 pies de tu Cañón Eldritch."
          }
        },
        "tables": {
          "artillerist_spells_table": {
            "title": "Conjuros de Artillero",
            "columns": [
              "Nivel de artífice",
              "Conjuros"
            ],
            "rows": [
              [
                "3",
                "Escudo, Ola atronadora"
              ],
              [
                "5",
                "Rayo abrasador, Hacer añicos"
              ],
              [
                "9",
                "Bola de fuego, Muro de viento"
              ],
              [
                "13",
                "Tormenta de hielo, Muro de fuego"
              ],
              [
                "17",
                "Cono de frío, Muro de fuerza"
              ]
            ]
          },
          "eldritch_cannon_statblock": {
            "title": "Cañón Eldritch",
            "columns": [
              "Rasgo",
              "Valor"
            ],
            "rows": [
              [
                "Tamaño",
                "Pequeño o Diminuto"
              ],
              [
                "Tipo",
                "Objeto"
              ],
              [
                "Clase de Armadura",
                "18"
              ],
              [
                "Puntos de golpe",
                "5 × tu nivel de artífice"
              ],
              [
                "Inmunidades",
                "Veneno, psíquico"
              ],
              [
                "Reparación con Remendar",
                "Lanzar Remendar sobre el cañón le restaura 2d6 puntos de golpe"
              ],
              [
                "Activar cañón",
                "Requiere que estés a 60 pies o menos del cañón y que uses una acción adicional"
              ],
              [
                "Movimiento al activarlo",
                "Puede moverse hasta 15 pies antes o después de usar su opción"
              ],
              [
                "Lanzallamas",
                "Cono de 15 pies; salvación de Destreza; 2d8 de daño de fuego, o la mitad con éxito"
              ],
              [
                "Balista de fuerza",
                "Ataque de conjuro a distancia desde el cañón contra un objetivo u objeto a 120 pies; 2d8 de daño de fuerza y empuja 5 pies al objetivo si es criatura"
              ],
              [
                "Protector",
                "El cañón y cada criatura de tu elección a 10 pies ganan 1d8 + tu modificador por Inteligencia puntos de golpe temporales (mínimo +1)"
              ]
            ]
          }
        }
      },
      "herrero_de_batalla": {
        "name": "Herrero de Batalla",
        "levels": {
          "3": {
            "features": [
              "tools_of_the_trade_battle_smith",
              "battle_smith_spells",
              "battle_ready",
              "steel_defender"
            ]
          },
          "5": {
            "features": [
              "extra_attack_battle_smith"
            ]
          },
          "9": {
            "features": [
              "arcane_jolt"
            ]
          },
          "15": {
            "features": [
              "improved_defender"
            ]
          }
        },
        "features": {
          "tools_of_the_trade_battle_smith": {
            "name": "Herramientas del Oficio",
            "level": 3,
            "description": "Obtienes los siguientes beneficios.\n\nCompetencia con herramientas. Ganas competencia con herramientas de herrero. Si ya la tienes, ganas competencia con otro tipo de herramientas de artesano a tu elección.\n\nFabricación de armas. Cuando fabricas un arma mágica o no mágica, el tiempo necesario se reduce a la mitad."
          },
          "battle_smith_spells": {
            "name": "Conjuros de Herrero de Batalla",
            "level": 3,
            "description": "Cuando alcanzas un nivel de artífice indicado en la tabla Conjuros de Herrero de Batalla, desde entonces siempre tienes preparados los conjuros indicados."
          },
          "battle_ready": {
            "name": "Listo para la Batalla",
            "level": 3,
            "description": "Tu entrenamiento para el combate y tus experimentos con la magia han dado fruto de dos formas.\n\nPotenciación arcana. Cuando atacas con un arma mágica, puedes usar tu modificador por Inteligencia en lugar de Fuerza o Destreza para las tiradas de ataque y daño.\n\nConocimiento de armas. Ganas competencia con armas marciales. Puedes usar un arma con la que seas competente como canalizador mágico para tus conjuros de artífice."
          },
          "steel_defender": {
            "name": "Defensor de Acero",
            "level": 3,
            "description": "Tus manipulaciones te han otorgado un compañero: un Defensor de Acero. Tú determinas su apariencia y si tiene dos patas o cuatro; esas decisiones no afectan a sus estadísticas.\n\nEl defensor es amistoso contigo y con tus aliados y te obedece. Desaparece si mueres.\n\nEl defensor en combate. En combate, el defensor actúa durante tu turno. Puede moverse y usar su reacción por sí mismo, pero la única acción que realiza es Esquivar, salvo que uses una acción adicional para ordenarle que realice otra acción. Si estás Incapacitado, el defensor actúa por sí mismo y no queda limitado a Esquivar.\n\nRestaurarlo o reemplazarlo. Si el defensor ha muerto durante la última hora, puedes realizar una acción de magia para tocarlo y gastar un espacio de conjuro. El defensor vuelve a la vida tras 1 minuto con todos sus puntos de golpe restaurados.\n\nCada vez que terminas un descanso largo, puedes crear un nuevo defensor si tienes herramientas de herrero en la mano. Si ya tienes uno de este rasgo, el anterior desaparece."
          },
          "extra_attack_battle_smith": {
            "name": "Ataque Adicional",
            "level": 5,
            "description": "Puedes atacar dos veces en lugar de una cuando realizas la acción de Atacar en tu turno. Cuando realizas la acción de Atacar, puedes renunciar a uno de tus ataques para ordenar a tu Defensor de Acero que use la acción Desgarrón potenciado por fuerza."
          },
          "arcane_jolt": {
            "name": "Sacudida Arcana",
            "level": 9,
            "description": "Cuando tú golpeas a un objetivo con una tirada de ataque usando un arma mágica, o cuando tu Defensor de Acero golpea a un objetivo, puedes canalizar energía mágica a través del golpe para crear uno de los siguientes efectos.\n\nEnergía destructiva. El objetivo sufre 2d6 de daño de fuerza adicional.\n\nEnergía restauradora. Elige una criatura u objeto que puedas ver a 30 pies del objetivo. Una energía curativa fluye hacia el receptor elegido y le restaura 2d6 puntos de golpe.\n\nPuedes usar esta energía un número de veces igual a tu modificador por Inteligencia (mínimo una vez), pero no más de una vez por turno. Recuperas todos los usos gastados al terminar un descanso largo."
          },
          "improved_defender": {
            "name": "Defensor Mejorado",
            "level": 15,
            "description": "Tu Sacudida Arcana y tu Defensor de Acero se vuelven más poderosos, otorgándote estos beneficios.\n\nSacudida mejorada. El daño adicional y la curación de tu Sacudida Arcana aumentan ambos a 4d6.\n\nDesvío mejorado. Siempre que tu Defensor de Acero use Desviar ataque, el atacante sufre daño de fuerza igual a 1d4 + tu modificador por Inteligencia."
          }
        },
        "tables": {
          "battle_smith_spells_table": {
            "title": "Conjuros de Herrero de Batalla",
            "columns": [
              "Nivel de artífice",
              "Conjuros"
            ],
            "rows": [
              [
                "3",
                "Heroísmo, Escudo"
              ],
              [
                "5",
                "Castigo brillante, Vínculo protector"
              ],
              [
                "9",
                "Aura de vitalidad, Conjurar descarga de proyectiles"
              ],
              [
                "13",
                "Aura de pureza, Escudo de fuego"
              ],
              [
                "17",
                "Castigo desterrador, Curar heridas en masa"
              ]
            ]
          },
          "steel_defender_statblock": {
            "title": "Defensor de Acero",
            "columns": [
              "Rasgo",
              "Valor"
            ],
            "rows": [
              [
                "Tamaño y tipo",
                "Constructo Mediano, neutral"
              ],
              [
                "CA",
                "12 + tu modificador por Inteligencia"
              ],
              [
                "PG",
                "5 + cinco veces tu nivel de artífice"
              ],
              [
                "Dados de golpe",
                "Número de d8 igual a tu nivel de artífice"
              ],
              [
                "Velocidad",
                "40 pies"
              ],
              [
                "Fuerza",
                "14 (+2)"
              ],
              [
                "Destreza",
                "12 (+1)"
              ],
              [
                "Constitución",
                "14 (+2)"
              ],
              [
                "Inteligencia",
                "4 (-3)"
              ],
              [
                "Sabiduría",
                "10 (+0)"
              ],
              [
                "Carisma",
                "6 (-2)"
              ],
              [
                "Inmunidades",
                "Veneno; Hechizado, Agotamiento y Envenenado"
              ],
              [
                "Sentidos",
                "Visión en la oscuridad 60 pies; Percepción pasiva 10"
              ],
              [
                "Idiomas",
                "Entiende los idiomas que conoces"
              ],
              [
                "VD",
                "Ninguno (XP 0; su bonificador por competencia es igual al tuyo)"
              ],
              [
                "Vínculo de acero",
                "Añade tu bonificador por competencia a cualquier prueba de característica o tirada de salvación que haga el defensor"
              ],
              [
                "Desgarrón potenciado por fuerza",
                "Ataque cuerpo a cuerpo; bonificador igual a tu modificador de ataque con conjuros; alcance 5 pies; impacto: 1d8 + 2 + tu modificador por Inteligencia de daño de fuerza"
              ],
              [
                "Reparar (3/día)",
                "El defensor, o un constructo u objeto a 5 pies de él que pueda ver, recupera 2d8 + tu modificador por Inteligencia puntos de golpe"
              ],
              [
                "Desviar ataque",
                "Reacción: cuando una criatura a 5 pies del defensor ataca a una criatura que no sea el defensor, la tirada de ataque se hace con desventaja"
              ]
            ]
          }
        }
      },
      "cartografo": {
        "name": "Cartógrafo",
        "levels": {
          "3": {
            "features": [
              "tools_of_the_trade_cartographer",
              "cartographer_spells",
              "adventurers_atlas",
              "mapping_magic"
            ]
          },
          "5": {
            "features": [
              "guided_precision"
            ]
          },
          "9": {
            "features": [
              "ingenious_movement"
            ]
          },
          "15": {
            "features": [
              "superior_atlas"
            ]
          }
        },
        "features": {
          "tools_of_the_trade_cartographer": {
            "name": "Herramientas del Oficio",
            "level": 3,
            "description": "Obtienes los siguientes beneficios.\n\nCompetencia con herramientas. Ganas competencia con útiles de calígrafo y herramientas de cartógrafo. Si ya tienes una de esas competencias, ganas competencia con otro tipo de herramientas de artesano a tu elección; si ya tienes ambas, ganas competencia con otros dos tipos.\n\nFabricación de pergaminos. Cuando escribes un pergamino de conjuro usando las reglas de fabricación del Manual del Jugador, el tiempo necesario se reduce a la mitad."
          },
          "cartographer_spells": {
            "name": "Conjuros de Cartógrafo",
            "level": 3,
            "description": "Cuando alcanzas un nivel de artífice indicado en la tabla Conjuros de cartógrafo, desde entonces siempre tienes preparados los conjuros indicados."
          },
          "adventurers_atlas": {
            "name": "Atlas del Aventurero",
            "level": 3,
            "description": "Cada vez que terminas un descanso largo mientras sostienes herramientas de cartógrafo, puedes usarlas para crear un conjunto de mapas mágicos tocando al menos a dos criaturas, una de las cuales puedes ser tú, hasta un máximo de criaturas igual a 1 + tu modificador por Inteligencia (mínimo dos criaturas). Cada objetivo recibe un mapa mágico que se actualiza constantemente para mostrar la posición relativa de todos los portadores del mapa, pero resulta ilegible para cualquier otra criatura. Los mapas duran hasta que mueras o hasta que vuelvas a usar este rasgo; entonces, todos los mapas anteriores desaparecen de inmediato.\n\nMientras una criatura lleva uno de estos mapas, obtiene los siguientes beneficios.\n\nConsciencia. El portador añade 1d4 a sus tiradas de iniciativa.\n\nPosicionamiento. El portador conoce la ubicación de todos los demás portadores del mapa que estén en el mismo plano de existencia. Además, al lanzar un conjuro o crear otro efecto que requiera poder ver al objetivo, un portador puede elegir como objetivo a otro portador del mapa sin importar la línea de visión ni la cobertura, siempre que el otro portador siga estando dentro del alcance del efecto."
          },
          "mapping_magic": {
            "name": "Magia Cartográfica",
            "level": 3,
            "description": "Obtienes los siguientes beneficios.\n\nCartografía iluminada. Puedes lanzar Fuego feérico sin gastar un espacio de conjuro, delineando a las criaturas afectadas como si estuvieran trazadas con tinta. Puedes hacerlo un número de veces igual a tu modificador por Inteligencia (mínimo una vez), y recuperas todos los usos gastados al terminar un descanso largo.\n\nSalto de portal. En tu turno, puedes gastar una cantidad de movimiento igual a la mitad de tu velocidad, redondeando hacia abajo, para teletransportarte a un espacio desocupado que puedas ver a 10 pies de ti o a 5 pies de una criatura que esté a 30 pies de ti y lleve uno de tus mapas del Atlas del Aventurero. No puedes usar este beneficio si tu velocidad es 0."
          },
          "guided_precision": {
            "name": "Precisión Guiada",
            "level": 5,
            "description": "Una vez por turno, cuando lances un conjuro de tu lista de Conjuros de cartógrafo o golpees con una tirada de ataque a una criatura afectada por tu Fuego feérico, puedes añadir tu modificador por Inteligencia a una de las tiradas de daño del conjuro o del ataque.\n\nAdemás, recibir daño no puede hacer que pierdas la concentración en Fuego feérico."
          },
          "ingenious_movement": {
            "name": "Movimiento Ingenioso",
            "level": 9,
            "description": "Cuando uses tu rasgo Destello de genio, tú o una criatura voluntaria que elijas y que puedas ver a 30 pies de ti podéis teletransportaros hasta 30 pies a un espacio desocupado que puedas ver como parte de esa misma reacción."
          },
          "superior_atlas": {
            "name": "Atlas Superior",
            "level": 15,
            "description": "Tu Atlas del Aventurero mejora y obtiene los siguientes beneficios.\n\nRefugio seguro. Cuando un portador del mapa fuera a reducirse a 0 puntos de golpe sin morir en el acto, puede destruir su mapa. En lugar de quedar a 0 puntos de golpe, sus puntos de golpe pasan a ser un número igual al doble de tu nivel de artífice, y la criatura se teletransporta a un espacio desocupado a 5 pies de ti o de otro portador del mapa de su elección.\n\nCamino infalible. Si tú eres uno de los portadores de mapas de tu Atlas del Aventurero, puedes lanzar Encontrar la senda sin gastar espacio de conjuro, sin prepararlo y sin necesitar componentes de conjuro. Una vez uses este beneficio, no podrás volver a hacerlo hasta terminar un descanso largo."
          }
        },
        "tables": {
          "cartographer_spells_table": {
            "title": "Conjuros de Cartógrafo",
            "columns": [
              "Nivel de artífice",
              "Conjuros"
            ],
            "rows": [
              [
                "3",
                "Fuego feérico, Saeta guía, Palabra de curación"
              ],
              [
                "5",
                "Localizar objeto, Clavo mental"
              ],
              [
                "9",
                "Llamar al relámpago, Clarividencia"
              ],
              [
                "13",
                "Destierro, Localizar criatura"
              ],
              [
                "17",
                "Escudriñar, Círculo de teletransportación"
              ]
            ]
          }
        }
      }
    },
    "tables": {
      "progression": {
        "title": "Rasgos de Artífice",
        "columns": [
          "Nivel",
          "Bonificador por competencia",
          "Rasgos de clase",
          "Planos conocidos",
          "Objetos mágicos",
          "Trucos",
          "Conjuros preparados",
          "Espacios 1",
          "Espacios 2",
          "Espacios 3",
          "Espacios 4",
          "Espacios 5"
        ],
        "rows": [
          [
            "1",
            "+2",
            "Lanzamiento de conjuros, Magia de manitas",
            "—",
            "—",
            "2",
            "2",
            "2",
            "—",
            "—",
            "—",
            "—"
          ],
          [
            "2",
            "+2",
            "Reproducir objeto mágico",
            "4",
            "2",
            "2",
            "3",
            "2",
            "—",
            "—",
            "—",
            "—"
          ],
          [
            "3",
            "+2",
            "Subclase de artífice",
            "4",
            "2",
            "2",
            "4",
            "3",
            "—",
            "—",
            "—",
            "—"
          ],
          [
            "4",
            "+2",
            "Mejora de característica",
            "4",
            "2",
            "2",
            "5",
            "3",
            "—",
            "—",
            "—",
            "—"
          ],
          [
            "5",
            "+3",
            "Rasgo de subclase",
            "4",
            "2",
            "2",
            "6",
            "4",
            "2",
            "—",
            "—",
            "—"
          ],
          [
            "6",
            "+3",
            "Manitas de objetos mágicos",
            "5",
            "3",
            "2",
            "6",
            "4",
            "2",
            "—",
            "—",
            "—"
          ],
          [
            "7",
            "+3",
            "Destello de genio",
            "5",
            "3",
            "2",
            "7",
            "4",
            "3",
            "—",
            "—",
            "—"
          ],
          [
            "8",
            "+3",
            "Mejora de característica",
            "5",
            "3",
            "2",
            "7",
            "4",
            "3",
            "—",
            "—",
            "—"
          ],
          [
            "9",
            "+4",
            "Rasgo de subclase",
            "5",
            "3",
            "2",
            "9",
            "4",
            "3",
            "2",
            "—",
            "—"
          ],
          [
            "10",
            "+4",
            "Adepto de objetos mágicos",
            "6",
            "4",
            "3",
            "9",
            "4",
            "3",
            "2",
            "—",
            "—"
          ],
          [
            "11",
            "+4",
            "Objeto almacenaconjuros",
            "6",
            "4",
            "3",
            "10",
            "4",
            "3",
            "3",
            "—",
            "—"
          ],
          [
            "12",
            "+4",
            "Mejora de característica",
            "6",
            "4",
            "3",
            "10",
            "4",
            "3",
            "3",
            "—",
            "—"
          ],
          [
            "13",
            "+5",
            "—",
            "6",
            "4",
            "3",
            "11",
            "4",
            "3",
            "3",
            "1",
            "—"
          ],
          [
            "14",
            "+5",
            "Artificio avanzado",
            "7",
            "5",
            "4",
            "11",
            "4",
            "3",
            "3",
            "1",
            "—"
          ],
          [
            "15",
            "+5",
            "Rasgo de subclase",
            "7",
            "5",
            "4",
            "12",
            "4",
            "3",
            "3",
            "2",
            "—"
          ],
          [
            "16",
            "+5",
            "Mejora de característica",
            "7",
            "5",
            "4",
            "12",
            "4",
            "3",
            "3",
            "2",
            "—"
          ],
          [
            "17",
            "+6",
            "—",
            "7",
            "5",
            "4",
            "14",
            "4",
            "3",
            "3",
            "3",
            "1"
          ],
          [
            "18",
            "+6",
            "Maestro de objetos mágicos",
            "8",
            "6",
            "4",
            "14",
            "4",
            "3",
            "3",
            "3",
            "1"
          ],
          [
            "19",
            "+6",
            "Don épico",
            "8",
            "6",
            "4",
            "15",
            "4",
            "3",
            "3",
            "3",
            "2"
          ],
          [
            "20",
            "+6",
            "Alma del artificio",
            "8",
            "6",
            "4",
            "15",
            "4",
            "3",
            "3",
            "3",
            "2"
          ]
        ]
      },
      "magic_item_plans_2_plus": {
        "title": "Planos de objetos mágicos (artífice nivel 2+)",
        "columns": [
          "Plano de objeto mágico",
          "Sintonización"
        ],
        "rows": [
          [
            "Jarra de alquimia",
            "No"
          ],
          [
            "Bolsa de contención",
            "No"
          ],
          [
            "Gorro de respiración acuática",
            "No"
          ],
          [
            "Objeto mágico común que no sea poción, pergamino ni maldito",
            "Varía"
          ],
          [
            "Anteojos de la noche",
            "No"
          ],
          [
            "Herramienta multiforma",
            "Sí"
          ],
          [
            "Arma de disparo repetidor",
            "Sí"
          ],
          [
            "Arma retornante",
            "No"
          ],
          [
            "Cuerda de escalada",
            "No"
          ],
          [
            "Piedras mensajeras",
            "No"
          ],
          [
            "Escudo +1",
            "No"
          ],
          [
            "Varita de detección mágica",
            "No"
          ],
          [
            "Varita de secretos",
            "No"
          ],
          [
            "Varita del mago de guerra +1",
            "Sí"
          ],
          [
            "Arma +1",
            "No"
          ],
          [
            "Envolturas de poder desarmado +1",
            "No"
          ]
        ]
      },
      "magic_item_plans_6_plus": {
        "title": "Planos de objetos mágicos (artífice nivel 6+)",
        "columns": [
          "Plano de objeto mágico",
          "Sintonización"
        ],
        "rows": [
          [
            "Armadura +1",
            "No"
          ],
          [
            "Botas élficas",
            "No"
          ],
          [
            "Botas del camino serpenteante",
            "Sí"
          ],
          [
            "Capa élfica",
            "Sí"
          ],
          [
            "Capa de la manta raya",
            "Sí"
          ],
          [
            "Arma deslumbrante",
            "Sí"
          ],
          [
            "Anteojos de encantamiento",
            "Sí"
          ],
          [
            "Anteojos de visión minuciosa",
            "No"
          ],
          [
            "Guantes de ladrón",
            "No"
          ],
          [
            "Yelmo de alerta",
            "No"
          ],
          [
            "Farol revelador",
            "No"
          ],
          [
            "Aguzador mental",
            "Sí"
          ],
          [
            "Collar de adaptación",
            "Sí"
          ],
          [
            "Flautas de acecho",
            "No"
          ],
          [
            "Escudo de repulsión",
            "No"
          ],
          [
            "Anillo de natación",
            "No"
          ],
          [
            "Anillo de caminar sobre las aguas",
            "No"
          ],
          [
            "Escudo centinela",
            "No"
          ],
          [
            "Anillo de recarga de conjuros",
            "Sí"
          ],
          [
            "Varita de proyectiles mágicos",
            "No"
          ],
          [
            "Varita de telaraña",
            "Sí"
          ],
          [
            "Arma de advertencia",
            "Sí"
          ]
        ]
      },
      "magic_item_plans_10_plus": {
        "title": "Planos de objetos mágicos (artífice nivel 10+)",
        "columns": [
          "Plano de objeto mágico",
          "Sintonización"
        ],
        "rows": [
          [
            "Armadura de resistencia",
            "Sí"
          ],
          [
            "Daga de la ponzoña",
            "No"
          ],
          [
            "Malla élfica",
            "No"
          ],
          [
            "Anillo de caída de pluma",
            "Sí"
          ],
          [
            "Anillo de salto",
            "Sí"
          ],
          [
            "Anillo de escudo mental",
            "Sí"
          ],
          [
            "Escudo +2",
            "No"
          ],
          [
            "Objeto maravilloso infrecuente que no esté maldito",
            "Varía"
          ],
          [
            "Varita del mago de guerra +2",
            "Sí"
          ],
          [
            "Arma +2",
            "No"
          ],
          [
            "Envolturas de poder desarmado +2",
            "No"
          ]
        ]
      },
      "magic_item_plans_14_plus": {
        "title": "Planos de objetos mágicos (artífice nivel 14+)",
        "columns": [
          "Plano de objeto mágico",
          "Sintonización"
        ],
        "rows": [
          [
            "Armadura +2",
            "No"
          ],
          [
            "Escudo de atraer proyectiles",
            "Sí"
          ],
          [
            "Lengua de fuego",
            "Sí"
          ],
          [
            "Objeto maravilloso raro que no esté maldito",
            "Varía"
          ],
          [
            "Anillo de libertad de movimiento",
            "Sí"
          ],
          [
            "Anillo de protección",
            "Sí"
          ],
          [
            "Anillo del carnero",
            "Sí"
          ]
        ]
      },
      "artificer_spell_list": {
        "title": "Lista de conjuros de Artífice",
        "columns": [
          "Nivel",
          "Conjuros"
        ],
        "rows": [
          [
            "Trucos",
            "Salpicadura ácida, Luces danzantes, Elementalismo, Descarga de fuego, Guía, Luz, Mano de mago, Mensaje, Rociada venenosa, Prestidigitación, Rayo de escarcha, Resistencia, Agarre electrizante, Piedad con los moribundos, Látigo de espinas, Tronar, Impacto certero"
          ],
          [
            "Nivel 1",
            "Alarma, Curar heridas, Detectar magia, Disfrazarse, Retirada expeditiva, Fuego feérico, Falsa Vida, Caída de pluma, Grasa, Identificar, Salto, Zancada prodigiosa, Purificar comida y bebida, Santuario"
          ],
          [
            "Nivel 2",
            "Auxilio, Alterar el propio aspecto, Cerradura arcana, Vigor arcano, Contorno borroso, Llama permanente, Visión en la oscuridad, Aliento de dragón, Potenciar característica, Agrandar/Reducir, Calentar metal, Sirviente homúnculo, Invisibilidad, Restablecimiento menor, Levitar, Boca mágica, Arma mágica, Protección contra veneno, Truco de la cuerda, Ver invisibilidad, Trepar cual arácnido, Telaraña"
          ],
          [
            "Nivel 3",
            "Desplazamiento, Crear comida y agua, Disipar magia, Arma elemental, Volar, Glifo custodio, Acelerar, Protección contra energía, Revivir, Respirar bajo el agua, Caminar sobre el agua"
          ],
          [
            "Nivel 4",
            "Ojo arcano, Fabricar, Libertad de movimiento, Cofre oculto de Leomund, Mastín fiel de Mordenkainen, Sanctasanctórum privado de Mordenkainen, Esfera elástica de Otiluke, Moldear la piedra, Piel pétrea, Invocar autómata"
          ],
          [
            "Nivel 5",
            "Animar objetos, Mano de Bigby, Círculo de poder, Creación, Restablecimiento mayor, Muro de piedra"
          ]
        ]
      }
    }
  }
};
