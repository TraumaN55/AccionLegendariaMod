(function(){
  window.INTEGRATED_CLASS_DATA = window.INTEGRATED_CLASS_DATA || {};
  Object.assign(window.INTEGRATED_CLASS_DATA, {
  "segador": {
    "id": "segador",
    "name": "Segador",
    "primaryAbility": [
      "Destreza",
      "Constitución"
    ],
    "hitDie": "1d8",
    "savingThrows": [
      "Constitución",
      "Sabiduría"
    ],
    "skillChoices": {
      "choose": 3,
      "from": [
        "Atletismo",
        "Conocimiento Arcano",
        "Historia",
        "Investigación",
        "Medicina",
        "Naturaleza",
        "Percepción",
        "Religión",
        "Supervivencia"
      ]
    },
    "weaponProficiencies": [
      "Armas sencillas",
      "Armas marciales"
    ],
    "armorTraining": [],
    "startingEquipment": {
      "options": [
        {
          "label": "A",
          "items": [
            "una espada larga o un hacha de batalla",
            "5 jabalinas",
            "dos dagas",
            "un paquete de explorador"
          ]
        },
        {
          "label": "B",
          "items": [
            "dos espadas cortas",
            "5 jabalinas",
            "dos dagas",
            "un paquete de explorador"
          ]
        }
      ]
    },
    "levels": {
      "1": {
        "proficiencyBonus": "+2",
        "chaosDie": null,
        "chaosPoints": null,
        "mutationsKnown": 0,
        "chaosAbilitiesKnown": 0,
        "features": [
          "marca_ritual",
          "maestria_con_armas"
        ],
        "cantripsKnown": 0
      },
      "2": {
        "proficiencyBonus": "+2",
        "chaosDie": "d6",
        "chaosPoints": 4,
        "mutationsKnown": 0,
        "chaosAbilitiesKnown": 4,
        "features": [
          "dominio_del_caos",
          "ritos_menores"
        ],
        "cantripsKnown": 2
      },
      "3": {
        "proficiencyBonus": "+2",
        "chaosDie": "d6",
        "chaosPoints": 4,
        "mutationsKnown": 1,
        "chaosAbilitiesKnown": 4,
        "features": [
          "subclase_segador",
          "mutaciones"
        ],
        "cantripsKnown": 2
      },
      "4": {
        "proficiencyBonus": "+2",
        "chaosDie": "d6",
        "chaosPoints": 4,
        "mutationsKnown": 1,
        "chaosAbilitiesKnown": 4,
        "features": [
          "mejora_de_caracteristica"
        ],
        "cantripsKnown": 2
      },
      "5": {
        "proficiencyBonus": "+3",
        "chaosDie": "d8",
        "chaosPoints": 6,
        "mutationsKnown": 1,
        "chaosAbilitiesKnown": 4,
        "features": [
          "ataque_adicional",
          "estilo_de_combate_de_segador"
        ],
        "cantripsKnown": 2
      },
      "6": {
        "proficiencyBonus": "+3",
        "chaosDie": "d8",
        "chaosPoints": 6,
        "mutationsKnown": 2,
        "chaosAbilitiesKnown": 4,
        "features": [],
        "cantripsKnown": 2
      },
      "7": {
        "proficiencyBonus": "+3",
        "chaosDie": "d8",
        "chaosPoints": 6,
        "mutationsKnown": 2,
        "chaosAbilitiesKnown": 4,
        "features": [],
        "subclassFeatures": true,
        "cantripsKnown": 2
      },
      "8": {
        "proficiencyBonus": "+3",
        "chaosDie": "d8",
        "chaosPoints": 6,
        "mutationsKnown": 2,
        "chaosAbilitiesKnown": 4,
        "features": [
          "mejora_de_caracteristica"
        ],
        "cantripsKnown": 2
      },
      "9": {
        "proficiencyBonus": "+4",
        "chaosDie": "d8",
        "chaosPoints": 8,
        "mutationsKnown": 3,
        "chaosAbilitiesKnown": 4,
        "features": [],
        "cantripsKnown": 2
      },
      "10": {
        "proficiencyBonus": "+4",
        "chaosDie": "d8",
        "chaosPoints": 8,
        "mutationsKnown": 3,
        "chaosAbilitiesKnown": 5,
        "features": [
          "dominio_del_caos_ampliado"
        ],
        "cantripsKnown": 3
      },
      "11": {
        "proficiencyBonus": "+4",
        "chaosDie": "d10",
        "chaosPoints": 8,
        "mutationsKnown": 3,
        "chaosAbilitiesKnown": 5,
        "features": [
          "caos_inexorable"
        ],
        "cantripsKnown": 3
      },
      "12": {
        "proficiencyBonus": "+4",
        "chaosDie": "d10",
        "chaosPoints": 8,
        "mutationsKnown": 3,
        "chaosAbilitiesKnown": 5,
        "features": [
          "mejora_de_caracteristica"
        ],
        "cantripsKnown": 3
      },
      "13": {
        "proficiencyBonus": "+5",
        "chaosDie": "d10",
        "chaosPoints": 10,
        "mutationsKnown": 4,
        "chaosAbilitiesKnown": 5,
        "features": [],
        "cantripsKnown": 3
      },
      "14": {
        "proficiencyBonus": "+5",
        "chaosDie": "d10",
        "chaosPoints": 10,
        "mutationsKnown": 4,
        "chaosAbilitiesKnown": 5,
        "features": [
          "liberacion_profana",
          "forzar_el_caos"
        ],
        "cantripsKnown": 3
      },
      "15": {
        "proficiencyBonus": "+5",
        "chaosDie": "d10",
        "chaosPoints": 10,
        "mutationsKnown": 4,
        "chaosAbilitiesKnown": 5,
        "features": [],
        "subclassFeatures": true,
        "cantripsKnown": 3
      },
      "16": {
        "proficiencyBonus": "+5",
        "chaosDie": "d10",
        "chaosPoints": 10,
        "mutationsKnown": 4,
        "chaosAbilitiesKnown": 5,
        "features": [
          "mejora_de_caracteristica"
        ],
        "cantripsKnown": 3
      },
      "17": {
        "proficiencyBonus": "+6",
        "chaosDie": "d12",
        "chaosPoints": 12,
        "mutationsKnown": 4,
        "chaosAbilitiesKnown": 5,
        "features": [],
        "cantripsKnown": 3
      },
      "18": {
        "proficiencyBonus": "+6",
        "chaosDie": "d12",
        "chaosPoints": 12,
        "mutationsKnown": 4,
        "chaosAbilitiesKnown": 6,
        "features": [
          "dominio_del_caos_absoluto"
        ],
        "cantripsKnown": 4
      },
      "19": {
        "proficiencyBonus": "+6",
        "chaosDie": "d12",
        "chaosPoints": 12,
        "mutationsKnown": 4,
        "chaosAbilitiesKnown": 6,
        "features": [
          "don_epico"
        ],
        "cantripsKnown": 4
      },
      "20": {
        "proficiencyBonus": "+6",
        "chaosDie": "d12",
        "chaosPoints": 12,
        "mutationsKnown": 4,
        "chaosAbilitiesKnown": 6,
        "features": [],
        "subclassFeatures": true,
        "cantripsKnown": 4
      }
    },
    "features": {
      "maestria_con_armas": {
        "name": "Maestría con Armas",
        "level": 1,
        "description": "Tu adiestramiento como Segador te permite dominar las propiedades de maestría de distintas armas. Elige dos tipos de armas con las que tengas competencia, como espadas largas, espadas cortas, hachas o ballestas. Puedes utilizar las propiedades de maestría de esas armas.\nTras finalizar un descanso largo, puedes cambiar los tipos de armas elegidas. Por ejemplo, podrías pasar a utilizar las propiedades de maestría con lanzas, machetes o ballestas pesadas."
      },
      "marca_ritual": {
        "name": "Marca Ritual",
        "level": 1,
        "description": "Tu cuerpo está marcado con runas que contienen la corrupción de la corriente en tu interior.\nMientras no lleves armadura ni escudo, tu Clase de Armadura es igual a 10 + tu modificador de Destreza + tu modificador de Constitución (máximo +2)."
      },
      "dominio_del_caos": {
        "name": "Dominio del Caos",
        "level": 2,
        "description": "Has aprendido a contener y canalizar el caos que fluye por tu cuerpo, utilizándolo como un arma contra tus enemigos. Este poder se manifiesta en forma de técnicas conocidas como habilidades de caos.\nObtienes los siguientes beneficios:\nDado de Caos. Tu dominio del caos se representa mediante un dado de caos. Este dado comienza siendo un d6 y aumenta a medida que subes de nivel en esta clase, hasta un máximo de d12, como se muestra en la columna «Dado de Caos» de la tabla de Segador.\nPuntos de Caos. Tu exposición al caos y tu entrenamiento como Segador te permiten manipular una reserva interna de energía corrupta. Esta energía se representa mediante los puntos de caos. Tu nivel de Segador determina cuántos de estos puntos posees, como se muestra en la columna «Puntos de Caos» de la tabla de Segador. Comienzas con 4 puntos de caos. Recuperas todos los puntos de caos al finalizar un descanso largo y recuperas un número de puntos de caos igual a tu bonificador de competencia al finalizar un descanso corto.\nLímite de Caos. Solo puedes gastar 1 punto de caos por turno. Este límite aumenta a 2 puntos por turno al nivel 10 y a 3 puntos por turno al nivel 18.\nPotenciación del Caos. Una vez por turno, cuando impactas con un ataque con arma, puedes gastar 1 o más puntos de caos para hacer que ese ataque inflija daño necrótico adicional igual a tu dado de caos por cada punto de caos gastado, hasta el máximo que te permita tu Límite de Caos.\nCD de Caos. Algunas de tus habilidades de caos requieren que el objetivo realice una tirada de salvación para resistir sus efectos. La CD se calcula como sigue:\n8 + tu bonificador de competencia + tu modificador de Constitución\nHabilidades de Caos. Tus habilidades de caos básicas son Hoja del Caos, Atormentar, Mutación Acelerada y Vista del Segador."
      },
      "mutaciones": {
        "name": "Mutaciones",
        "level": 3,
        "description": "Tu cuerpo ha sido alterado de forma permanente mediante rituales y exposición prolongada al caos. Estas alteraciones, conocidas como mutaciones, te otorgan capacidades sobrenaturales.\nTu nivel de Segador determina cuántas mutaciones puedes conocer al mismo tiempo, como se muestra en la columna «Mutaciones» de la tabla de Segador. Conoces 1 mutación al nivel 3, 2 al nivel 6, 3 al nivel 9 y 4 al nivel 13. La mutación otorgada por tu subclase no cuenta para este límite.\nCada vez que subes de nivel en esta clase, puedes sustituir una mutación que conozcas por otra para la que cumplas los requisitos."
      },
      "subclase_segador": {
        "name": "Subclase de Segador",
        "level": 3,
        "description": "Consigues una subclase de Segador de tu elección. Las subclases disponibles se detallan tras la descripción de esta clase. Una subclase es una especialización que define la forma en la que canalizas y controlas el caos, otorgándote rasgos adicionales cuando alcanzas ciertos niveles de Segador. De aquí en adelante, obtienes todos los rasgos de tu subclase que sean de tu nivel de segador e inferiores."
      },
      "mejora_de_caracteristica": {
        "name": "Mejora de característica",
        "level": 4,
        "description": "Obtienes la dote Mejora de característica (consulta el capítulo 5) u otra dote de tu elección para la que cumplas los requisitos. Vuelves a obtener este rasgo en los niveles 8, 12, 16 y 19 de Segador."
      },
      "ataque_adicional": {
        "name": "Ataque Adicional",
        "level": 5,
        "description": "Cuando realizas la acción de Atacar en tu turno, puedes hacer dos ataques en lugar de uno."
      },
      "estilo_de_combate_de_segador": {
        "name": "Estilo de Combate de Segador",
        "level": 5,
        "description": "Al alcanzar el nivel 5, eliges uno de los siguientes estilos de combate. No puedes cambiar esta elección salvo que subas de nivel en esta clase.\nEjecutor del Caos\nMientras empuñes un arma con la propiedad versátil con ambas manos y no lleves armadura, puedes usar Destreza en lugar de Fuerza para las tiradas de ataque y daño con esa arma.\nUna vez por turno, cuando impactes con esa arma, puedes añadir tu modificador de Constitución al daño.\nDepredador\nCuando realizas la acción de Atacar y empuñas dos armas ligeras, puedes realizar un ataque adicional como acción adicional. Este ataque forma parte de tu estilo de combate y no requiere la regla estándar de combate con dos armas.\nCazador del Umbral\nUna vez por turno, cuando impactas a una criatura con un ataque con arma, puedes perturbar su conexión con el Caos. Hasta el inicio de tu próximo turno, cuando esa criatura inflija daño con un conjuro, reduce el daño total de ese conjuro en una cantidad igual a tu dado de caos + tu modificador de Constitución."
      },
      "dominio_del_caos_ampliado": {
        "name": "Dominio del Caos Ampliado",
        "level": 10,
        "description": "Tu control sobre el Caos se intensifica, permitiéndote canalizar mayores cantidades en un mismo instante.\nA partir de este nivel, puedes gastar hasta 2 puntos de caos en un mismo turno, en lugar de 1. Además, aprendes una nueva habilidad de caos de tu elección."
      },
      "caos_inexorable": {
        "name": "Caos Inexorable",
        "level": 11,
        "description": "El daño necrótico que infligen tus dados de caos ignora resistencia al daño necrótico. Las criaturas inmunes al daño necrótico siguen siendo inmunes."
      },
      "liberacion_profana": {
        "name": "Liberación Profana",
        "level": 14,
        "description": "Tu control sobre el caos te permite expulsar las alteraciones que afectan a tu cuerpo.\nCuando estás bajo el efecto de una condición de asustado, aturdido, hechizado o paralizado, puedes usar tu reacción (incluso si estás incapacitado) para finalizar una de esas condiciones sobre ti, gastando 2 puntos de caos. Si usas este rasgo, tienes desventaja en la siguiente tirada que realices antes del final de tu siguiente turno."
      },
      "forzar_el_caos": {
        "name": "Forzar el Caos",
        "level": 14,
        "description": "La corrupción que habita en tu interior se niega a extinguirse por completo. Cuando tus reservas menguan, puedes obligarla a resurgir por pura fuerza de voluntad.\nUna vez por descanso largo, recuperas una cantidad de puntos de caos igual a tu bonificador por competencia. Este rasgo no requiere acción."
      },
      "dominio_del_caos_absoluto": {
        "name": "Dominio del Caos Absoluto",
        "level": 18,
        "description": "Tu conexión con la energía caótica se vuelve absoluta, permitiéndote canalizar mayores cantidades sin que tu cuerpo colapse bajo su inestabilidad.\nA partir de este nivel, puedes gastar hasta 3 puntos de caos en un mismo turno. Además, aprendes una nueva habilidad de caos de tu elección."
      },
      "don_epico": {
        "name": "Don épico",
        "level": 19,
        "description": "Obtienes la dote de don épico u otra dote de tu elección para la que cumplas los requisitos."
      },
      "ritos_menores": {
        "name": "Ritos Menores",
        "level": 2,
        "description": "Aprendes dos trucos de la siguiente lista: Taumaturgia, Prestidigitación, Luces danzantes, Guía, Resistencia, Mensaje, Disturbio Mental, Eco Residual y Toque Helado. Aprendes un truco adicional de esta lista al nivel 10 y otro al nivel 18, hasta un máximo de 4 trucos conocidos.\nCada vez que subes de nivel en esta clase, puedes sustituir uno de los trucos que conoces de este rasgo por otro truco de la misma lista.\nConstitución es tu aptitud mágica para los trucos de Segador."
      }
    },
    "chaosAbilities": {
      "atormentar": {
        "name": "Atormentar",
        "requirements": "",
        "description": "Como acción, gastas 1 punto de caos y eliges una criatura que puedas ver a 60 pies de ti. El objetivo debe superar una tirada de salvación de Sabiduría.\nSi falla, recibe daño igual a tu dado de caos + tu modificador de Constitución + tu bonificador de competencia, y tiene desventaja en sus tiradas de ataque contra criaturas que no seas tú hasta el final de tu siguiente turno. Si tiene éxito, recibe la mitad del daño y no sufre efectos adicionales.\nEliges si este daño es necrótico o de veneno."
      },
      "hoja_del_caos": {
        "name": "Hoja del Caos",
        "requirements": "",
        "description": "Como acción, puedes gastar 1 o más puntos de caos para moverte hasta la mitad de tu velocidad en línea recta sin provocar ataques de oportunidad. Si terminas este movimiento a 5 pies de una criatura, puedes realizar un ataque con arma cuerpo a cuerpo contra ella como parte de la misma acción. Si impactas, el ataque inflige daño adicional igual a tu dado de caos por cada punto de caos gastado. No puedes gastar más puntos de caos con esta habilidad de los que te permita tu Límite de Caos. Eliges si este daño es necrótico o de veneno."
      },
      "mutacion_acelerada": {
        "name": "Mutación Acelerada",
        "requirements": "",
        "description": "Tu cuerpo ha sido alterado mediante rituales y exposición al caos, permitiéndote forzar tu regeneración más allá de los límites naturales.\nComo acción, puedes gastar puntos de caos para recuperar una cantidad de puntos de golpe igual a tu dado de caos por cada punto de caos gastado, más tu nivel de Segador. El número máximo de puntos de caos que puedes gastar con esta habilidad a la vez es 1 al nivel 2, 2 al nivel 10 y 3 al nivel 18.\nAlternativamente, puedes gastar 1 punto de caos para finalizar sobre ti mismo las condiciones de envenenado, ensordecido o cegado. No puedes usar esta habilidad si estás a 0 puntos de golpe."
      },
      "vista_del_segador": {
        "name": "Vista del Segador",
        "requirements": "",
        "description": "Como acción de magia, puedes gastar 1 punto de caos para lanzarte uno de los siguientes conjuros ignorando todos sus componentes: detectar magia, detectar venenos y enfermedades o detectar el bien y el mal. Cuando lanzas un conjuro de esta manera, dura 1 minuto y requiere concentración."
      },
      "desviar_caos": {
        "name": "Desviar Caos",
        "requirements": "Segador de nivel 10 o superior.",
        "description": "Como reacción cuando recibes daño de un conjuro o efecto mágico que inflija daño necrótico, radiante, fuego, frío, relámpago o trueno, puedes gastar un punto de caos para reducir ese daño en una cantidad igual a tu dado de caos + tu modificador de Constitución + tu bonificador de competencia."
      },
      "distorsion_del_caos": {
        "name": "Distorsión del Caos",
        "requirements": "Segador de nivel 10 o superior.",
        "description": "Como reacción, cuando una criatura que puedas ver a 60 pies de ti lanza un conjuro, puedes gastar 1 punto de caos para distorsionar su energía. Obtienes ventaja en la siguiente tirada de salvación que realices contra ese conjuro. Si superas la tirada, puedes moverte hasta 10 pies sin provocar ataques de oportunidad."
      },
      "estallido_de_caos": {
        "name": "Estallido de Caos",
        "requirements": "Segador de nivel 10 o superior.",
        "description": "Como acción, gastas 1 punto de caos para liberar una explosión de energía corrupta en un radio de 10 pies centrado en ti. Las criaturas de tu elección en el área deben realizar una tirada de salvación de Destreza. Si fallan, sufren daño igual a tu dado de caos + tu modificador de Constitución. Si tienen éxito, sufren la mitad de daño.\nEliges si este daño es necrótico o de veneno."
      },
      "paso_del_umbral": {
        "name": "Paso del Umbral",
        "requirements": "Segador de nivel 10 o superior.",
        "description": "Como acción adicional, gastas 1 punto de caos para teletransportarte hasta 30 pies a un espacio desocupado que puedas ver."
      }
    },
    "mutations": {
      "adaptacion_depredadora": {
        "name": "Adaptación Depredadora",
        "requirements": "",
        "description": "El caos ha remodelado tus extremidades y tus órganos, permitiéndote desplazarte por tierra, agua y superficies irregulares con una facilidad antinatural.\nObtienes una velocidad de trepar y una velocidad de nado iguales a tu velocidad. Además, puedes contener la respiración durante 1 hora."
      },
      "anatomia_distorsionada": {
        "name": "Anatomía Distorsionada",
        "requirements": "",
        "description": "Tu cuerpo ha sido alterado hasta un punto en el que tus órganos vitales ya no siguen una disposición normal, dificultando que los golpes encuentren puntos letales.\nCuando una tirada de ataque con arma, un ataque sin armas o un ataque natural te cause un impacto crítico, ese ataque se considera un impacto normal en su lugar."
      },
      "avance_imparable": {
        "name": "Avance Imparable",
        "requirements": "",
        "description": "Tu cuerpo ha sido moldeado por el caos para avanzar sin obstáculos, ignorando aquello que frenaría a otros.\nTu velocidad aumenta en 10 pies, puedes ignorar el terreno difícil y levantarte del suelo no te cuesta movimiento adicional."
      },
      "mente_fragmentada": {
        "name": "Mente Fragmentada",
        "requirements": "",
        "description": "Tu mente ha sido desgarrada y reconstruida, volviéndose resistente a influencias externas.\nObtienes competencia en tiradas de salvación de Inteligencia o Carisma, a tu elección. Además, tienes ventaja en tiradas de salvación para resistir o terminar los estados asustado o hechizado."
      },
      "metabolismo_corrupto": {
        "name": "Metabolismo Corrupto",
        "requirements": "",
        "description": "La corrupción que recorre tu cuerpo consume toxinas y rechaza agentes extraños con una eficacia antinatural.\nTienes ventaja en tiradas de salvación para resistir veneno y enfermedad. Además, tienes resistencia al daño de veneno."
      },
      "osamenta_reforzada": {
        "name": "Osamenta Reforzada",
        "requirements": "",
        "description": "Tus huesos se han vuelto densos, elásticos y deformes, volviendo tu cuerpo difícil de someter y capaz de impulsarse con una fuerza antinatural.\nTienes ventaja en las tiradas de salvación y pruebas para resistir ser agarrado, derribado o movido contra tu voluntad. Además, tu distancia de salto se duplica y no necesitas tomar carrerilla para realizar saltos largos o altos."
      },
      "piel_endurecida": {
        "name": "Piel Endurecida",
        "requirements": "",
        "description": "Tu carne se endurece como respuesta a la violencia, adaptándose al castigo constante.\nObtienes un +1 a la Clase de Armadura mientras no lleves armadura ni escudo."
      },
      "resistencia_al_caos": {
        "name": "Resistencia al Caos",
        "requirements": "",
        "description": "Tu cuerpo ha aprendido a absorber las rupturas más violentas de la magia antes de que puedan destrozarte.\nCuando un ataque de conjuro o un ataque mágico que requiera tirada de ataque te cause un impacto crítico, ese ataque se considera un impacto normal en su lugar."
      },
      "sangre_corrupta": {
        "name": "Sangre Corrupta",
        "requirements": "",
        "description": "La corrupción del caos fluye por tus venas, convirtiendo tu propia sangre en un arma letal.\nComo acción adicional, puedes infligirte daño igual a tu bonificador de competencia para impregnar tu arma con tu sangre. Hasta el final de tu turno, el siguiente ataque con arma que impacte inflige daño de veneno adicional igual a tu bonificador de competencia."
      },
      "sentidos_alterados": {
        "name": "Sentidos Alterados",
        "requirements": "",
        "description": "Tus sentidos han sido afinados por el caos, permitiéndote percibir el peligro antes de que llegue a manifestarse por completo.\nObtienes pericia en la habilidad de Percepción, lo que te permite añadir el doble de tu bonificador de competencia a las tiradas que hagas con ella. Además, tienes ventaja en las tiradas de iniciativa y en las pruebas de Percepción."
      },
      "armadura_profana": {
        "name": "Armadura Profana",
        "requirements": "Mutación Piel Endurecida.",
        "description": "Tu carne se refuerza con energía corrupta, endureciéndose de forma antinatural.\nAl inicio de cada uno de tus turnos, obtienes puntos de golpe temporales iguales a tu bonificador de competencia. Estos puntos de golpe temporales se pierden al inicio de tu siguiente turno."
      },
      "armazon_monstruoso": {
        "name": "Armazón Monstruoso",
        "requirements": "Mutación Osamenta Reforzada.",
        "description": "Tus huesos, tendones y fluidos internos se han transformado en una estructura brutalmente eficiente para someter a otros cuerpos.\nCuentas como una categoría de tamaño mayor para determinar cuánto peso puedes empujar, arrastrar o levantar, y para determinar las criaturas a las que puedes agarrar o empujar. Además, la primera vez en cada uno de tus turnos que una criatura pase a estar agarrada por ti o empujada por ti, recibe daño de ácido igual a tu bonificador de competencia."
      },
      "desplazamiento_erratico": {
        "name": "Desplazamiento Errático",
        "requirements": "Mutación Avance Imparable.",
        "description": "Tu forma de moverte resulta antinatural e impredecible incluso cuando el enemigo cree haberte encerrado.\nLas tiradas de ataque de oportunidad contra ti tienen desventaja."
      },
      "filo_profano": {
        "name": "Filo Profano",
        "requirements": "Mutación Sangre Corrupta.",
        "description": "La corrupción que recorre tu sangre se fija de forma permanente a tus armas, volviendo sus tajos antinaturalmente eficaces.\nTus ataques con arma cuentan como mágicos a efectos de superar resistencias e inmunidades al daño no mágico. Además, mientras empuñas un arma no mágica, obtienes un bonificador de +1 a las tiradas de ataque y de daño que hagas con ella. Si el arma ya es mágica, no obtienes este bonificador."
      },
      "metabolismo_aberrante": {
        "name": "Metabolismo Aberrante",
        "requirements": "Mutación Metabolismo Corrupto.",
        "description": "La corrupción que recorre tu cuerpo descompone toxinas antes de que puedan dañarte por completo.\nEres inmune a la condición envenenado, al daño de veneno y a las enfermedades."
      },
      "presencia_inquietante": {
        "name": "Presencia Inquietante",
        "requirements": "Mutación Mente Fragmentada.",
        "description": "Tu mera existencia resulta perturbadora y antinatural, generando incomodidad y miedo en quienes te rodean.\nObtienes competencia en la habilidad de Intimidación. Si ya la tienes, añades el doble de tu bonificador de competencia a las tiradas que hagas con ella. Además, las criaturas tienen desventaja en las tiradas de salvación para resistir ser asustadas por ti."
      },
      "canalizacion_profana": {
        "name": "Canalización Profana",
        "requirements": "",
        "description": "El caos que recorre tu cuerpo alimenta los ritos menores que has aprendido.\nCuando lanzas un truco de Segador que cause daño, añades tu modificador de Constitución a una tirada de daño de ese truco."
      }
    },
    "subclasses": {
      "carcelero_del_pacto": {
        "name": "Carcelero del pacto",
        "levels": {
          "3": [
            "mutacion_de_subclase",
            "subclass_spells",
            "entidad_encadenada",
            "pseudopacto"
          ],
          "7": [
            "resonancia_del_pacto"
          ],
          "15": [
            "potenciar_el_pacto"
          ],
          "20": [
            "manifestacion_de_la_entidad"
          ]
        },
        "features": {
          "mutacion_de_subclase": {
            "name": "Mutación de subclase",
            "level": 3,
            "description": "Obtienes la mutación Mente Fragmentada. Esta mutación no cuenta para tu límite de mutaciones."
          },
          "subclass_spells": {
            "name": "Conjuros de Subclase",
            "level": 3,
            "description": "Obtienes conjuros adicionales según la entidad encadenada."
          },
          "entidad_encadenada": {
            "name": "Entidad Encadenada",
            "level": 3,
            "description": "Has atrapado una entidad dentro de tu cuerpo, forzándola a alimentarte con su poder a cambio de su existencia.\nElige el tipo de entidad que has encadenado: feérica, infernal, celestial o aberrante. Esta elección determina tu lista de conjuros.\nAdemás, conoces el truco Descarga de Caos."
          },
          "pseudopacto": {
            "name": "Pseudopacto",
            "level": 3,
            "description": "La entidad encadenada en tu interior te otorga acceso limitado a magia, que canalizas a través de tu propio cuerpo. Dispones de un número reducido de espacios de conjuro, que se recuperan al finalizar un descanso largo. Todos tus espacios de conjuro son del mismo nivel, como se muestra en la tabla de Pseudopacto. Después de usar un espacio de conjuro, no puedes usar una habilidad de caos hasta el inicio de tu siguiente turno."
          },
          "resonancia_del_pacto": {
            "name": "Resonancia del Pacto",
            "level": 7,
            "description": "La entidad en tu interior reacciona de forma automática cuando su poder se manifiesta a través de ti.\nUna vez por turno, cuando una criatura supere una tirada de salvación contra uno de tus conjuros de Pseudopacto, puedes usar tu reacción y gastar 1 punto de caos para restar a esa tirada una cantidad igual a tu modificador de Constitución (mínimo 1). Si esto hace que la tirada falle, la tirada falla."
          },
          "potenciar_el_pacto": {
            "name": "Potenciar el Pacto",
            "level": 15,
            "description": "El poder que fluye por tu interior ya no es algo que simplemente canalizas… es algo que desgarras y obligas a obedecer.\nCuando lanzas un conjuro mediante tu rasgo Pseudopacto, puedes forzar al Caos a intensificar sus efectos. Para hacerlo, gastas 1 punto de caos en el momento de lanzar el conjuro. Solo puedes usar este rasgo una vez por turno.\nEliges uno de los siguientes efectos:\n• El conjuro inflige daño adicional igual a tu dado de caos.\n• Aumentas en 10 pies el alcance o el radio del conjuro (a tu elección)."
          },
          "manifestacion_de_la_entidad": {
            "name": "Manifestación de la Entidad",
            "level": 20,
            "description": "La criatura que has encadenado alcanza su máxima expresión a través de ti, permitiéndote canalizar una fracción de su verdadero poder.\nObtienes acceso a un conjuro de nivel 8 determinado por tu Entidad Encadenada.\nPuedes lanzarlo siempre y cuando aún tengas al menos un espacio de conjuro disponible; al lanzarlo, pierdes todos los espacios de conjuro que te queden de tu rasgo Pseudopacto.\nSi no tienes espacios de conjuro disponibles, no puedes lanzar este conjuro.\nUna vez lanzas este conjuro, no puedes volver a hacerlo hasta finalizar un descanso largo."
          }
        },
        "tables": {
          "pseudopacto_progression": {
            "title": "Espacios de Conjuro del Carcelero del Pacto",
            "columns": [
              "Nivel de Segador",
              "Espacios",
              "Nivel de conjuro"
            ],
            "rows": [
              [
                "3–4",
                "1",
                "1"
              ],
              [
                "5–6",
                "2",
                "2"
              ],
              [
                "7–8",
                "2",
                "2"
              ],
              [
                "9–10",
                "2",
                "3"
              ],
              [
                "11–16",
                "3",
                "4"
              ],
              [
                "17–20",
                "3",
                "5"
              ]
            ]
          },
          "entidad_feerica_spells": {
            "title": "Entidad Feérica",
            "columns": [
              "Nivel",
              "Conjuros"
            ],
            "rows": [
              [
                "1",
                [
                  "Hechizar persona",
                  "Fuego feérico"
                ]
              ],
              [
                "2",
                [
                  "Calmar emociones",
                  "Invisibilidad"
                ]
              ],
              [
                "3",
                [
                  "Disipar magia",
                  "Agrandar/reducir"
                ]
              ],
              [
                "4",
                [
                  "Invisibilidad mejorada",
                  "Confusión"
                ]
              ],
              [
                "5",
                [
                  "Dominar persona",
                  "Alterar los recuerdos"
                ]
              ],
              [
                "8",
                [
                  "Laberinto"
                ]
              ]
            ]
          },
          "entidad_infernal_spells": {
            "title": "Entidad Infernal",
            "columns": [
              "Nivel",
              "Conjuros"
            ],
            "rows": [
              [
                "1",
                [
                  "Manos ardientes",
                  "Reprensión infernal"
                ]
              ],
              [
                "2",
                [
                  "Rayo abrasador",
                  "Sordera/ceguera"
                ]
              ],
              [
                "3",
                [
                  "Bola de fuego",
                  "Contrahechizo"
                ]
              ],
              [
                "4",
                [
                  "Escudo de fuego",
                  "Marchitar"
                ]
              ],
              [
                "5",
                [
                  "Inmovilizar monstruo",
                  "Muro de fuego"
                ]
              ],
              [
                "8",
                [
                  "Nube incendiaria"
                ]
              ]
            ]
          },
          "entidad_celestial_spells": {
            "title": "Entidad Celestial",
            "columns": [
              "Nivel",
              "Conjuros"
            ],
            "rows": [
              [
                "1",
                [
                  "Curar heridas",
                  "Saeta guía"
                ]
              ],
              [
                "2",
                [
                  "Restablecimiento menor",
                  "Auxilio"
                ]
              ],
              [
                "3",
                [
                  "Revivir",
                  "Luz del día"
                ]
              ],
              [
                "4",
                [
                  "Guardián de la fe",
                  "Aura de pureza"
                ]
              ],
              [
                "5",
                [
                  "Restablecimiento mayor",
                  "Disipar el bien y el mal"
                ]
              ],
              [
                "8",
                [
                  "Aura sagrada"
                ]
              ]
            ]
          },
          "entidad_aberrante_spells": {
            "title": "Entidad Aberrante",
            "columns": [
              "Nivel",
              "Conjuros"
            ],
            "rows": [
              [
                "1",
                [
                  "Susurros discordantes",
                  "Brazos de Hadar"
                ]
              ],
              [
                "2",
                [
                  "Detectar pensamientos",
                  "Inmovilizar persona"
                ]
              ],
              [
                "3",
                [
                  "Hambre de Hadar",
                  "Clarividencia"
                ]
              ],
              [
                "4",
                [
                  "Confusión",
                  "Tentáculos negros de Evard"
                ]
              ],
              [
                "5",
                [
                  "Telequinesis",
                  "Dominar persona"
                ]
              ],
              [
                "8",
                [
                  "Dominar monstruo"
                ]
              ]
            ]
          }
        }
      },
      "flagelante": {
        "name": "Flagelante",
        "levels": {
          "3": [
            "mutacion_de_subclase",
            "flagelacion"
          ],
          "7": [
            "umbral_de_dolor"
          ],
          "15": [
            "frenesi_profano"
          ],
          "20": [
            "apoteosis",
            "voluntad_inquebrantable"
          ]
        },
        "features": {
          "mutacion_de_subclase": {
            "name": "Mutación de subclase",
            "level": 3,
            "description": "Obtienes la mutación Sangre Corrupta. Esta mutación no cuenta para tu límite de mutaciones."
          },
          "flagelacion": {
            "name": "Flagelación",
            "level": 3,
            "description": "Puedes desgarrar tu propio cuerpo para liberar el caos.\nComo acción adicional, puedes infligirte daño necrótico igual a tu dado de caos. Este daño no puede ser reducido de ninguna forma. Hasta el final de tu turno, la siguiente vez que impactes con un ataque que inflija daño, ese ataque inflige daño necrótico adicional igual al daño sufrido de esta manera.\nEste rasgo sustituye cualquier daño adicional que obtendrías de Sangre Corrupta en ese ataque."
          },
          "umbral_de_dolor": {
            "name": "Umbral de Dolor",
            "level": 7,
            "description": "Cuando te encuentras al borde del colapso, tu cuerpo aprende a absorber parte del castigo que recibe.\nMientras tengas la mitad de tus puntos de golpe máximos o menos, cuando recibes daño de un ataque, puedes usar tu reacción para reducir ese daño en una cantidad igual a tu dado de caos."
          },
          "frenesi_profano": {
            "name": "Frenesí Profano",
            "level": 15,
            "description": "El dolor y la cercanía de la muerte desatan tu ferocidad más salvaje.\nMientras tengas menos de la mitad de tus puntos de golpe máximos, cuando tires tu dado de caos, puedes repetir la tirada si obtienes un 1 o un 2. Debes usar el nuevo resultado.\nAdemás, mientras tengas menos de la mitad de tus puntos de golpe máximos, tienes resistencia al daño necrótico y al veneno."
          },
          "apoteosis": {
            "name": "Apoteosis",
            "level": 20,
            "description": "Como acción adicional, puedes entrar en un estado de martirio durante 1 minuto. Una vez que usas este rasgo, no puedes volver a usarlo hasta finalizar un descanso largo.\nMientras este estado esté activo, obtienes los siguientes beneficios:\n• Al inicio de cada uno de tus turnos, sufres daño igual a tu bonificador de competencia. Este daño no puede ser reducido de ninguna forma.\n• Tienes ventaja en las tiradas de salvación contra efectos mágicos."
          },
          "voluntad_inquebrantable": {
            "name": "Voluntad Inquebrantable",
            "level": 20,
            "description": "Mientras este estado esté activo, si caes a 0 puntos de golpe, puedes quedarte a 1 punto de golpe en su lugar. Una vez que utilizas este efecto, no puedes volver a hacerlo hasta que finalice el estado."
          }
        }
      },
      "inquisidor": {
        "name": "Inquisidor",
        "levels": {
          "3": [
            "mutacion_de_subclase",
            "marca_del_juicio"
          ],
          "7": [
            "dominar_al_hereje"
          ],
          "15": [
            "veredicto_implacable"
          ],
          "20": [
            "juicio_absoluto"
          ]
        },
        "features": {
          "mutacion_de_subclase": {
            "name": "Mutación de subclase",
            "level": 3,
            "description": "Obtienes la mutación Sentidos Alterados. Esta mutación no cuenta para tu límite de mutaciones."
          },
          "marca_del_juicio": {
            "name": "Marca del Juicio",
            "level": 3,
            "description": "Una vez por turno, cuando impactas a una criatura con un ataque con arma, puedes marcarla durante 1 minuto o hasta que quedes incapacitado. Solo puedes tener una criatura marcada a la vez.\nMientras esté marcada, cuando la criatura trate de terminar voluntariamente su turno a más de 30 pies de ti, debe superar una tirada de salvación de Sabiduría contra tu CD de Caos o no puede alejarse más de 30 pies de ti hasta el final de su turno."
          },
          "dominar_al_hereje": {
            "name": "Dominar al Hereje",
            "level": 7,
            "description": "Una vez por turno, cuando impactas con un ataque con arma a una criatura marcada por tu Marca del Juicio, puedes obligarla a realizar una tirada de salvación de Constitución contra tu CD de Caos. Si falla, no puede emitir sonido ni proporcionar componentes verbales hasta el inicio de tu siguiente turno."
          },
          "veredicto_implacable": {
            "name": "Veredicto Implacable",
            "level": 15,
            "description": "Cuando una criatura marcada por tu Marca del Juicio falle una tirada de salvación, o falle una tirada de ataque, puedes usar tu reacción para infligirle daño psíquico igual a tu dado de caos + tu modificador de Constitución."
          },
          "juicio_absoluto": {
            "name": "Juicio Absoluto",
            "level": 20,
            "description": "Te conviertes en la encarnación del juicio contra el Caos.\nComo acción adicional, puedes entrar en estado de Juicio Absoluto durante 1 minuto:\n• Puedes tener hasta dos criaturas marcadas simultáneamente con Marca del Juicio.\n• Cuando una criatura marcada por tu Marca del Juicio lanza un conjuro o usa una habilidad mágica, recibe daño psíquico igual a tu dado de caos.\n• Obtienes ventaja en tiradas de salvación contra conjuros y efectos mágicos.\nUna vez usas este rasgo, no puedes volver a hacerlo hasta finalizar un descanso largo."
          }
        }
      },
      "centinela": {
        "name": "Centinela",
        "levels": {
          "3": [
            "mutacion_de_subclase",
            "entrenamiento_del_centinela",
            "escudo_de_guerra",
            "guardia_interpuesta"
          ],
          "7": [
            "bastion_inquebrantable"
          ],
          "15": [
            "presencia_del_bastion"
          ],
          "20": [
            "bastion_de_la_corriente"
          ]
        },
        "features": {
          "mutacion_de_subclase": {
            "name": "Mutación de subclase",
            "level": 3,
            "description": "Obtienes la mutación Osamenta Reforzada. Esta mutación no cuenta para tu límite de mutaciones."
          },
          "entrenamiento_del_centinela": {
            "name": "Entrenamiento del Centinela",
            "level": 3,
            "description": "Obtienes competencia con armaduras ligeras, medias y pesadas, así como con escudos."
          },
          "escudo_de_guerra": {
            "name": "Escudo de Guerra",
            "level": 3,
            "description": "Mientras empuñas un escudo, puedes usarlo como un arma cuerpo a cuerpo simple. Debes usar Fuerza para las tiradas de ataque y daño hechas con él, salvo que una regla indique lo contrario. El escudo inflige 1d6 de daño contundente.\nSi no empuñas otra arma ni objeto, puedes asir el escudo con ambas manos al realizar un ataque con él; cuando lo haces, el daño del escudo pasa a ser 1d10.\nSi el escudo incorpora hojas, púas u otras modificaciones ofensivas, el daño puede ser cortante en lugar de contundente. El escudo sigue otorgándote su bonificador normal a la CA."
          },
          "guardia_interpuesta": {
            "name": "Guardia Interpuesta",
            "level": 3,
            "description": "Cuando una criatura que puedas ver a 5 pies de ti reciba daño de un ataque, puedes reducir ese daño en una cantidad igual a tu dado de caos + tu bonificador de competencia.\nPuedes gastar 1 punto de caos al usar este rasgo para aumentar la reducción en un dado de caos adicional.\nPuedes usar este rasgo un número de veces igual a tu bonificador de competencia, y recuperas todos los usos gastados al finalizar un descanso largo. Usar este rasgo no consume tu reacción."
          },
          "bastion_inquebrantable": {
            "name": "Bastión Inquebrantable",
            "level": 7,
            "description": "No puedes ser derribado ni movido contra tu voluntad por una criatura de tu mismo tamaño o menor, salvo que tú lo permitas.\nAdemás, cuando uses Guardia Interpuesta, la criatura protegida puede desplazarse hasta 5 pies sin provocar ataques de oportunidad del atacante."
          },
          "presencia_del_bastion": {
            "name": "Presencia del Bastión",
            "level": 15,
            "description": "Las criaturas aliadas a 10 pies de ti obtienen un bonificador a las tiradas de salvación igual a tu modificador de Constitución (mínimo +1) contra efectos que las derriben, las empujen, las arrastren, las asusten o las hechicen.\nAdemás, cuando una criatura aliada dentro de ese alcance reciba daño, puedes usar Guardia Interpuesta aunque no esté a 5 pies de ti, siempre que puedas verla."
          },
          "bastion_de_la_corriente": {
            "name": "Bastión de la Corriente",
            "level": 20,
            "description": "Como acción adicional, desatas el poder protector que habita en tu interior durante 1 minuto. Mientras dure, tú y las criaturas aliadas a 30 pies de ti obtenéis un bonificador a las tiradas de salvación igual a tu modificador de Constitución (mínimo +1). Además, esas criaturas tienen ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos.\nUna vez uses este rasgo, no puedes volver a usarlo hasta terminar un descanso largo."
          }
        }
      }
    },
    "tables": {
      "segador_progression": {
        "title": "Rasgos de Segador",
        "columns": [
          "Nivel",
          "Bonif. competencia",
          "Rasgos de clase",
          "Dado de\nCaos",
          "Puntos de\nCaos",
          "Mutaciones",
          "Habilidades\nde Caos",
          "Ritos\nMenores"
        ],
        "rows": [
          [
            "1",
            "+2",
            "Marca Ritual, Maestría con Armas",
            "—",
            "—",
            "—",
            "—",
            "—"
          ],
          [
            "2",
            "+2",
            "Dominio del Caos, Ritos Menores",
            "d6",
            "4",
            "—",
            "4",
            "2"
          ],
          [
            "3",
            "+2",
            "Subclase de Segador, Mutaciones",
            "d6",
            "4",
            "1",
            "4",
            "2"
          ],
          [
            "4",
            "+2",
            "Mejora de característica",
            "d6",
            "4",
            "1",
            "4",
            "2"
          ],
          [
            "5",
            "+3",
            "Ataque Adicional, Estilo de Combate de Segador",
            "d8",
            "6",
            "1",
            "4",
            "2"
          ],
          [
            "6",
            "+3",
            "—",
            "d8",
            "6",
            "2",
            "4",
            "2"
          ],
          [
            "7",
            "+3",
            "Rasgo de subclase",
            "d8",
            "6",
            "2",
            "4",
            "2"
          ],
          [
            "8",
            "+3",
            "Mejora de característica",
            "d8",
            "6",
            "2",
            "4",
            "2"
          ],
          [
            "9",
            "+4",
            "—",
            "d8",
            "8",
            "3",
            "4",
            "2"
          ],
          [
            "10",
            "+4",
            "Dominio del Caos Ampliado",
            "d8",
            "8",
            "3",
            "5",
            "3"
          ],
          [
            "11",
            "+4",
            "Caos Inexorable",
            "d10",
            "8",
            "3",
            "5",
            "3"
          ],
          [
            "12",
            "+4",
            "Mejora de característica",
            "d10",
            "8",
            "3",
            "5",
            "3"
          ],
          [
            "13",
            "+5",
            "—",
            "d10",
            "10",
            "4",
            "5",
            "3"
          ],
          [
            "14",
            "+5",
            "Liberación Profana, Forzar el Caos",
            "d10",
            "10",
            "4",
            "5",
            "3"
          ],
          [
            "15",
            "+5",
            "Rasgo de subclase",
            "d10",
            "10",
            "4",
            "5",
            "3"
          ],
          [
            "16",
            "+5",
            "Mejora de característica",
            "d10",
            "10",
            "4",
            "5",
            "3"
          ],
          [
            "17",
            "+6",
            "—",
            "d12",
            "12",
            "4",
            "5",
            "3"
          ],
          [
            "18",
            "+6",
            "Dominio del Caos Absoluto",
            "d12",
            "12",
            "4",
            "6",
            "4"
          ],
          [
            "19",
            "+6",
            "Don épico",
            "d12",
            "12",
            "4",
            "6",
            "4"
          ],
          [
            "20",
            "+6",
            "Rasgo de subclase",
            "d12",
            "12",
            "4",
            "6",
            "4"
          ]
        ]
      }
    },
    "spellcastingAbility": "Constitución",
    "cantripsList": [
      "Taumaturgia",
      "Prestidigitación",
      "Luces danzantes",
      "Guía",
      "Resistencia",
      "Mensaje",
      "Disturbio Mental",
      "Eco Residual",
      "Toque Helado"
    ]
  }
}
);
})();
