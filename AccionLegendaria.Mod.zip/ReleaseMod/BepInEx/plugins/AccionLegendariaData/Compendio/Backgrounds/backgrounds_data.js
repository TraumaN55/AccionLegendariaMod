﻿window.BACKGROUNDS_DATA = [
    {
        "id":  "trasfondo_acolito",
        "nombre":  "AcÃ³lito",
        "tipo":  "trasfondo",
        "caracteristicas":  {
                                "puntuaciones":  [
                                                     "Inteligencia",
                                                     "SabidurÃ­a",
                                                     "Carisma"
                                                 ]
                            },
        "dote":  {
                     "nombre":  "Iniciado en la magia (clÃ©rigo)",
                     "referencia":  "capÃ­tulo 5"
                 },
        "competencias":  {
                             "habilidades":  [
                                                 "Perspicacia",
                                                 "ReligiÃ³n"
                                             ],
                             "herramientas":  [
                                                  "Suministros de calÃ­grafo"
                                              ]
                         },
        "equipo":  {
                       "opciones":  [
                                        {
                                            "id":  "A",
                                            "items":  [
                                                          "Suministros de calÃ­grafo",
                                                          "Libro (de oraciones)",
                                                          "Pergamino (10 hojas)",
                                                          "SÃ­mbolo sagrado",
                                                          "TÃºnica"
                                                      ],
                                            "oro":  8
                                        },
                                        {
                                            "id":  "B",
                                            "items":  [

                                                      ],
                                            "oro":  50
                                        }
                                    ]
                   },
        "descripcion":  "Dedicabas tu vida al servicio de un templo enclavado en un pueblo o apartado en un bosquecillo sagrado. En Ã©l, realizabas ceremonias en honor a un dios o panteÃ³n. ServÃ­as a las Ã³rdenes de un sacerdote y estudiabas la religiÃ³n. Gracias a la tutela de ese sacerdote y a tu propia devociÃ³n, tambiÃ©n aprendiste a canalizar un Ã¡pice de poder divino al servicio de tu lugar de culto y de la gente que rezaba en Ã©l."
    },
    {
        "id":  "trasfondo_artesano",
        "nombre":  "Artesano",
        "tipo":  "trasfondo",
        "caracteristicas":  {
                                "puntuaciones":  [
                                                     "Fuerza",
                                                     "Destreza",
                                                     "Inteligencia"
                                                 ]
                            },
        "dote":  {
                     "nombre":  "Fabricante",
                     "referencia":  "capÃ­tulo 5"
                 },
        "competencias":  {
                             "habilidades":  [
                                                 "InvestigaciÃ³n",
                                                 "PersuasiÃ³n"
                                             ],
                             "herramientas":  [
                                                  "Herramientas de artesano (elige un tipo)"
                                              ]
                         },
        "equipo":  {
                       "opciones":  [
                                        {
                                            "id":  "A",
                                            "items":  [
                                                          "Herramientas de artesano (las mismas elegidas)",
                                                          "2 bolsas",
                                                          "Ropas de viaje"
                                                      ],
                                            "oro":  32
                                        },
                                        {
                                            "id":  "B",
                                            "items":  [

                                                      ],
                                            "oro":  50
                                        }
                                    ]
                   },
        "descripcion":  "Comenzaste barriendo suelos y fregando las mesas del taller de un artesano a cambio de unas monedas al dÃ­a en cuanto tuviste fuerza suficiente para levantar un cubo. Cuando alcanzaste la edad necesaria para convertirte en aprendiz, empezaste a crear tus propias obras bÃ¡sicas, asÃ­ como a camelarte a los clientes exigentes que de vez en cuando llamaban a vuestra puerta. Tu oficio te brindÃ³ tambiÃ©n un buen ojo para los detalles."
    },
    {
        "id":  "trasfondo_campesino",
        "nombre":  "Campesino",
        "tipo":  "trasfondo",
        "caracteristicas":  {
                                "puntuaciones":  [
                                                     "Fuerza",
                                                     "ConstituciÃ³n",
                                                     "SabidurÃ­a"
                                                 ]
                            },
        "dote":  {
                     "nombre":  "Duro",
                     "referencia":  "capÃ­tulo 5"
                 },
        "competencias":  {
                             "habilidades":  [
                                                 "Naturaleza",
                                                 "Trato con animales"
                                             ],
                             "herramientas":  [
                                                  "Herramientas de carpintero"
                                              ]
                         },
        "equipo":  {
                       "opciones":  [
                                        {
                                            "id":  "A",
                                            "items":  [
                                                          "Hoz",
                                                          "Herramientas de carpintero",
                                                          "Ãštiles de sanador",
                                                          "Olla de hierro",
                                                          "Pala",
                                                          "Ropas de viaje"
                                                      ],
                                            "oro":  30
                                        },
                                        {
                                            "id":  "B",
                                            "items":  [

                                                      ],
                                            "oro":  50
                                        }
                                    ]
                   },
        "descripcion":  "Te criaste en el campo. Los aÃ±os cuidando animales y cultivando la tierra te recompensaron con paciencia y una salud de hierro. Sientes un gran aprecio por la generosidad de la naturaleza y un prudente respeto por su ira."
    },
    {
        "id":  "trasfondo_charlatan",
        "nombre":  "CharlatÃ¡n",
        "tipo":  "trasfondo",
        "caracteristicas":  {
                                "puntuaciones":  [
                                                     "Destreza",
                                                     "ConstituciÃ³n",
                                                     "Carisma"
                                                 ]
                            },
        "dote":  {
                     "nombre":  "Habilidoso",
                     "referencia":  "capÃ­tulo 5"
                 },
        "competencias":  {
                             "habilidades":  [
                                                 "EngaÃ±o",
                                                 "Juego de manos"
                                             ],
                             "herramientas":  [
                                                  "Ãštiles para falsificar"
                                              ]
                         },
        "equipo":  {
                       "opciones":  [
                                        {
                                            "id":  "A",
                                            "items":  [
                                                          "Ãštiles para falsificar",
                                                          "Disfraz",
                                                          "Ropas de calidad"
                                                      ],
                                            "oro":  15
                                        },
                                        {
                                            "id":  "B",
                                            "items":  [

                                                      ],
                                            "oro":  50
                                        }
                                    ]
                   },
        "descripcion":  "En cuanto tuviste edad suficiente para pedir una pinta, no tardaste en apropiarte de un taburete en cada taberna a 10 km a la redonda del lugar en que naciste. Mientras recorrÃ­as bares y antros, aprendiste a aprovecharte de los desafortunados que se dejaban colar alguna mentira reconfortante o dos, como una pociÃ³n falsa o un Ã¡rbol genealÃ³gico falsificado."
    },
    {
        "id":  "trasfondo_comerciante",
        "nombre":  "Comerciante",
        "tipo":  "trasfondo",
        "caracteristicas":  {
                                "puntuaciones":  [
                                                     "ConstituciÃ³n",
                                                     "Inteligencia",
                                                     "Carisma"
                                                 ]
                            },
        "dote":  {
                     "nombre":  "Afortunado",
                     "referencia":  "capÃ­tulo 5"
                 },
        "competencias":  {
                             "habilidades":  [
                                                 "PersuasiÃ³n",
                                                 "Trato con animales"
                                             ],
                             "herramientas":  [
                                                  "Herramientas de navegante"
                                              ]
                         },
        "equipo":  {
                       "opciones":  [
                                        {
                                            "id":  "A",
                                            "items":  [
                                                          "Herramientas de navegante",
                                                          "2 bolsas",
                                                          "Ropas de viaje"
                                                      ],
                                            "oro":  22
                                        },
                                        {
                                            "id":  "B",
                                            "items":  [

                                                      ],
                                            "oro":  50
                                        }
                                    ]
                   },
        "descripcion":  "Fuiste aprendiz de un comerciante, caravanero o tendero y aprendiste los rudimentos del comercio. Viajabas por todas partes y te ganabas la vida comprando y vendiendo las materias primas que los artesanos necesitaban para sus creaciones o las obras acabadas de aquellos profesionales. QuizÃ¡ transportabas mercancÃ­as de un lugar a otro en barco, carro o en caravana, o se las comprabas a mercaderes ambulantes y las vendÃ­as en tu propia tienda."
    },
    {
        "id":  "trasfondo_criminal",
        "nombre":  "Criminal",
        "tipo":  "trasfondo",
        "caracteristicas":  {
                                "puntuaciones":  [
                                                     "Destreza",
                                                     "ConstituciÃ³n",
                                                     "Inteligencia"
                                                 ]
                            },
        "dote":  {
                     "nombre":  "Alerta",
                     "referencia":  "capÃ­tulo 5"
                 },
        "competencias":  {
                             "habilidades":  [
                                                 "Juego de manos",
                                                 "Sigilo"
                                             ],
                             "herramientas":  [
                                                  "Herramientas de ladrÃ³n"
                                              ]
                         },
        "equipo":  {
                       "opciones":  [
                                        {
                                            "id":  "A",
                                            "items":  [
                                                          "2 dagas",
                                                          "Herramientas de ladrÃ³n",
                                                          "2 bolsas",
                                                          "Palanqueta",
                                                          "Ropas de viaje"
                                                      ],
                                            "oro":  16
                                        },
                                        {
                                            "id":  "B",
                                            "items":  [

                                                      ],
                                            "oro":  50
                                        }
                                    ]
                   },
        "descripcion":  "Te buscabas la vida en los callejones oscuros, birlando carteras o robando en comercios. QuizÃ¡ formabas parte de una pequeÃ±a banda de malhechores con ideas afines y dispuestos a echarse una mano. O puede que fueras un lobo solitario que se desmarcaba del gremio de ladrones local y de otros delincuentes mÃ¡s temibles."
    },
    {
        "id":  "trasfondo_ermitanio",
        "nombre":  "ErmitaÃ±o",
        "tipo":  "trasfondo",
        "caracteristicas":  {
                                "puntuaciones":  [
                                                     "ConstituciÃ³n",
                                                     "SabidurÃ­a",
                                                     "Carisma"
                                                 ]
                            },
        "dote":  {
                     "nombre":  "Sanador",
                     "referencia":  "capÃ­tulo 5"
                 },
        "competencias":  {
                             "habilidades":  [
                                                 "Medicina",
                                                 "ReligiÃ³n"
                                             ],
                             "herramientas":  [
                                                  "Ãštiles de herborista"
                                              ]
                         },
        "equipo":  {
                       "opciones":  [
                                        {
                                            "id":  "A",
                                            "items":  [
                                                          "BastÃ³n",
                                                          "Ãštiles de herborista",
                                                          "Aceite (3 frascos)",
                                                          "LÃ¡mpara",
                                                          "Libro (de filosofÃ­a)",
                                                          "Petate",
                                                          "Ropas de viaje"
                                                      ],
                                            "oro":  16
                                        },
                                        {
                                            "id":  "B",
                                            "items":  [

                                                      ],
                                            "oro":  50
                                        }
                                    ]
                   },
        "descripcion":  "Te pasaste los aÃ±os de juventud en un refugio o monasterio situado en medio de la nada. En aquella Ã©poca, tu Ãºnica compaÃ±Ã­a eran las criaturas del bosque y las visitas esporÃ¡dicas que traÃ­an noticias del exterior y suministros. La soledad te permitiÃ³ reflexionar durante muchas horas acerca de los misterios de la creaciÃ³n."
    },
    {
        "id":  "trasfondo_erudito",
        "nombre":  "Erudito",
        "tipo":  "trasfondo",
        "caracteristicas":  {
                                "puntuaciones":  [
                                                     "ConstituciÃ³n",
                                                     "Inteligencia",
                                                     "SabidurÃ­a"
                                                 ]
                            },
        "dote":  {
                     "nombre":  "Iniciado en la magia (mago)",
                     "referencia":  "capÃ­tulo 5"
                 },
        "competencias":  {
                             "habilidades":  [
                                                 "Conocimiento arcano",
                                                 "Historia"
                                             ],
                             "herramientas":  [
                                                  "Suministros de calÃ­grafo"
                                              ]
                         },
        "equipo":  {
                       "opciones":  [
                                        {
                                            "id":  "A",
                                            "items":  [
                                                          "BastÃ³n",
                                                          "Suministros de calÃ­grafo",
                                                          "Libro (de historia)",
                                                          "Pergamino (8 hojas)",
                                                          "TÃºnica"
                                                      ],
                                            "oro":  8
                                        },
                                        {
                                            "id":  "B",
                                            "items":  [

                                                      ],
                                            "oro":  50
                                        }
                                    ]
                   },
        "descripcion":  "Pasaste tus aÃ±os formativos viajando entre palacetes y monasterios, desempeÃ±ando diversos oficios y servicios para que te dejaran acceder a sus bibliotecas. Dedicaste muchas tardes a estudiar libros y pergaminos para adquirir conocimientos acerca del multiverso e incluso los rudimentos de la magia, y tu mente ansÃ­a mÃ¡s."
    },
    {
        "id":  "trasfondo_escriba",
        "nombre":  "Escriba",
        "tipo":  "trasfondo",
        "caracteristicas":  {
                                "puntuaciones":  [
                                                     "Destreza",
                                                     "Inteligencia",
                                                     "SabidurÃ­a"
                                                 ]
                            },
        "dote":  {
                     "nombre":  "Habilidoso",
                     "referencia":  "capÃ­tulo 5"
                 },
        "competencias":  {
                             "habilidades":  [
                                                 "InvestigaciÃ³n",
                                                 "PercepciÃ³n"
                                             ],
                             "herramientas":  [
                                                  "Suministros de calÃ­grafo"
                                              ]
                         },
        "equipo":  {
                       "opciones":  [
                                        {
                                            "id":  "A",
                                            "items":  [
                                                          "Suministros de calÃ­grafo",
                                                          "Aceite (3 frascos)",
                                                          "LÃ¡mpara",
                                                          "Pergamino (12 hojas)",
                                                          "Ropas de calidad"
                                                      ],
                                            "oro":  23
                                        },
                                        {
                                            "id":  "B",
                                            "items":  [

                                                      ],
                                            "oro":  50
                                        }
                                    ]
                   },
        "descripcion":  "Pasaste tus aÃ±os de formaciÃ³n en un scriptorium, un monasterio consagrado a la conservaciÃ³n del conocimiento o un organismo gubernamental, donde aprendiste a escribir con letra clara y producir textos exquisitos. QuizÃ¡ transcribÃ­as documentos oficiales o copiabas tomos de literatura. PodrÃ­as tener ciertas cualidades para la poesÃ­a, la narrativa o la investigaciÃ³n. Sobre todo, prestas mucha atenciÃ³n a los detalles, lo que te impide cometer errores en los documentos que copias y creas."
    },
    {
        "id":  "trasfondo_guardia",
        "nombre":  "Guardia",
        "tipo":  "trasfondo",
        "caracteristicas":  {
                                "puntuaciones":  [
                                                     "Fuerza",
                                                     "Inteligencia",
                                                     "SabidurÃ­a"
                                                 ]
                            },
        "dote":  {
                     "nombre":  "Alerta",
                     "referencia":  "capÃ­tulo 5"
                 },
        "competencias":  {
                             "habilidades":  [
                                                 "Atletismo",
                                                 "PercepciÃ³n"
                                             ],
                             "herramientas":  [
                                                  "Juego (elige un tipo)"
                                              ]
                         },
        "equipo":  {
                       "opciones":  [
                                        {
                                            "id":  "A",
                                            "items":  [
                                                          "Lanza",
                                                          "Ballesta ligera",
                                                          "20 virotes",
                                                          "Juego (el mismo elegido)",
                                                          "Aljaba",
                                                          "Esposas",
                                                          "Linterna sorda",
                                                          "Ropas de viaje"
                                                      ],
                                            "oro":  12
                                        },
                                        {
                                            "id":  "B",
                                            "items":  [

                                                      ],
                                            "oro":  50
                                        }
                                    ]
                   },
        "descripcion":  "Te duelen los pies al recordar las innumerables horas pasadas en tu puesto de la torre. Te entrenaron para permanecer ojo avizor ante lo que acontecÃ­a extramuros, en busca de merodeadores ocultos en el bosque, a la par que estabas pendiente de los posibles rateros y pendencieros de intramuros."
    },
    {
        "id":  "trasfondo_guia",
        "nombre":  "GuÃ­a",
        "tipo":  "trasfondo",
        "caracteristicas":  {
                                "puntuaciones":  [
                                                     "Destreza",
                                                     "ConstituciÃ³n",
                                                     "SabidurÃ­a"
                                                 ]
                            },
        "dote":  {
                     "nombre":  "Iniciado en la magia (druida)",
                     "referencia":  "capÃ­tulo 5"
                 },
        "competencias":  {
                             "habilidades":  [
                                                 "Sigilo",
                                                 "Supervivencia"
                                             ],
                             "herramientas":  [
                                                  "Herramientas de cartÃ³grafo"
                                              ]
                         },
        "equipo":  {
                       "opciones":  [
                                        {
                                            "id":  "A",
                                            "items":  [
                                                          "Arco corto",
                                                          "20 flechas",
                                                          "Herramientas de cartÃ³grafo",
                                                          "Aljaba",
                                                          "Petate",
                                                          "Tienda",
                                                          "Ropas de viaje"
                                                      ],
                                            "oro":  3
                                        },
                                        {
                                            "id":  "B",
                                            "items":  [

                                                      ],
                                            "oro":  50
                                        }
                                    ]
                   },
        "descripcion":  "Alcanzaste la mayorÃ­a de edad en plena naturaleza, lejos de tierras pobladas. Tu hogar era cualquier sitio donde pudieras extender tu petate. Las tierras salvajes estÃ¡n llenas de maravillas (monstruos extraÃ±os, bosques y arroyos inmaculados, ruinas descuidadas de grandes salones otrora recorridos por gigantes) y aprendiste a alertarlas por tu cuenta al explorarlas. De vez en cuando, servÃ­as de guÃ­a a sacerdotes de la naturaleza que te enseÃ±aron los fundamentos para canalizar la magia de la tierra."
    },
    {
        "id":  "trasfondo_marinero",
        "nombre":  "Marinero",
        "tipo":  "trasfondo",
        "caracteristicas":  {
                                "puntuaciones":  [
                                                     "Fuerza",
                                                     "Destreza",
                                                     "SabidurÃ­a"
                                                 ]
                            },
        "dote":  {
                     "nombre":  "MatÃ³n de taberna",
                     "referencia":  "capÃ­tulo 5"
                 },
        "competencias":  {
                             "habilidades":  [
                                                 "Acrobacias",
                                                 "PercepciÃ³n"
                                             ],
                             "herramientas":  [
                                                  "Herramientas de navegante"
                                              ]
                         },
        "equipo":  {
                       "opciones":  [
                                        {
                                            "id":  "A",
                                            "items":  [
                                                          "Daga",
                                                          "Herramientas de navegante",
                                                          "Cuerda",
                                                          "Ropas de viaje"
                                                      ],
                                            "oro":  20
                                        },
                                        {
                                            "id":  "B",
                                            "items":  [

                                                      ],
                                            "oro":  50
                                        }
                                    ]
                   },
        "descripcion":  "Llevaste una vida en la mar, con el viento en popa y las cubiertas meciÃ©ndose bajo tus pies. Visitaste mÃ¡s tabernas de los puertos de escala de las que puedes recordar, te enfrentaste a grandes tormentas e intercambiaste anÃ©cdotas con gente que vivÃ­a bajo las olas."
    },
    {
        "id":  "trasfondo_noble",
        "nombre":  "Noble",
        "tipo":  "trasfondo",
        "caracteristicas":  {
                                "puntuaciones":  [
                                                     "Fuerza",
                                                     "Inteligencia",
                                                     "Carisma"
                                                 ]
                            },
        "dote":  {
                     "nombre":  "Habilidoso",
                     "referencia":  "capÃ­tulo 5"
                 },
        "competencias":  {
                             "habilidades":  [
                                                 "Historia",
                                                 "PersuasiÃ³n"
                                             ],
                             "herramientas":  [
                                                  "Juego (elige un tipo)"
                                              ]
                         },
        "equipo":  {
                       "opciones":  [
                                        {
                                            "id":  "A",
                                            "items":  [
                                                          "Juego (el mismo elegido)",
                                                          "Perfume",
                                                          "Ropas de calidad"
                                                      ],
                                            "oro":  29
                                        },
                                        {
                                            "id":  "B",
                                            "items":  [

                                                      ],
                                            "oro":  50
                                        }
                                    ]
                   },
        "descripcion":  "Te criaste en un castillo entre riqueza, poder y privilegios. Tu familia de aristÃ³cratas menores procurÃ³ que recibieras la mejor educaciÃ³n, parte de la cual apreciabas y parte de la cual aborrecÃ­as. El tiempo que pasaste en el castillo, en especial las muchas horas que dedicabas a observar a tu familia en la corte, tambiÃ©n te aportÃ³ amplios conocimientos sobre el liderazgo."
    },
    {
        "id":  "trasfondo_soldado",
        "nombre":  "Soldado",
        "tipo":  "trasfondo",
        "caracteristicas":  {
                                "puntuaciones":  [
                                                     "Fuerza",
                                                     "Destreza",
                                                     "ConstituciÃ³n"
                                                 ]
                            },
        "dote":  {
                     "nombre":  "Atacante salvaje",
                     "referencia":  "capÃ­tulo 5"
                 },
        "competencias":  {
                             "habilidades":  [
                                                 "Atletismo",
                                                 "IntimidaciÃ³n"
                                             ],
                             "herramientas":  [
                                                  "Juego (elige un tipo)"
                                              ]
                         },
        "equipo":  {
                       "opciones":  [
                                        {
                                            "id":  "A",
                                            "items":  [
                                                          "Lanza",
                                                          "Arco corto",
                                                          "20 flechas",
                                                          "Aljaba",
                                                          "Juego (el mismo elegido)",
                                                          "Ãštiles de sanador",
                                                          "Ropas de viaje"
                                                      ],
                                            "oro":  14
                                        },
                                        {
                                            "id":  "B",
                                            "items":  [

                                                      ],
                                            "oro":  50
                                        }
                                    ]
                   },
        "descripcion":  "Comenzaste a entrenarte para la guerra nada mÃ¡s llegar a la edad adulta y tienes pocos recuerdos preciados de tu vida anterior a tomar las armas. Luchar es parte de tu identidad y a veces realizas sin darte cuenta los primeros ejercicios bÃ¡sicos de combate que aprendiste. En algÃºn momento, sacaste partido a tu entrenamiento en el campo de batalla y protegiste el reino."
    },
    {
        "id":  "trasfondo_vagabundo",
        "nombre":  "Vagabundo",
        "tipo":  "trasfondo",
        "caracteristicas":  {
                                "puntuaciones":  [
                                                     "Destreza",
                                                     "SabidurÃ­a",
                                                     "Carisma"
                                                 ]
                            },
        "dote":  {
                     "nombre":  "Afortunado",
                     "referencia":  "capÃ­tulo 5"
                 },
        "competencias":  {
                             "habilidades":  [
                                                 "Perspicacia",
                                                 "Sigilo"
                                             ],
                             "herramientas":  [
                                                  "Herramientas de ladrÃ³n"
                                              ]
                         },
        "equipo":  {
                       "opciones":  [
                                        {
                                            "id":  "A",
                                            "items":  [
                                                          "2 dagas",
                                                          "Herramientas de ladrÃ³n",
                                                          "Juego (cualquiera)",
                                                          "2 bolsas",
                                                          "Petate",
                                                          "Ropas de viaje"
                                                      ],
                                            "oro":  16
                                        },
                                        {
                                            "id":  "B",
                                            "items":  [

                                                      ],
                                            "oro":  50
                                        }
                                    ]
                   },
        "descripcion":  "Creciste en las calles junto a personas con expectativas tan aciagas como las tuyas, entre las que habÃ­a algunas amistades y algunos rivales. DormÃ­as donde podÃ­as y hacÃ­as encargos ocasionales a cambio de comida. A veces, cuando el hambre se volvÃ­a insoportable, recurrÃ­as al robo. Sin embargo, nunca renunciaste a tu orgullo ni perdiste la esperanza. El destino aÃºn tiene algo reservado para ti."
    }
];

