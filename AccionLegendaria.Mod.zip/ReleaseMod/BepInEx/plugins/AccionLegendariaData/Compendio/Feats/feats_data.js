window.FEATS_DATA = [
  {
    "name": "Afortunado",
    "category": "Dote de origen",
    "description": "Obtienes los siguientes beneficios:\n\nPuntos de suerte. Tienes una cantidad de puntos de suerte igual a tu bonificador por competencia. Recuperas todos los puntos gastados al finalizar un descanso largo.\n\nVentaja. Cuando realizas una tirada de d20, puedes gastar 1 punto de suerte para obtener ventaja en esa tirada.\n\nDesventaja. Cuando una criatura realiza una tirada de ataque contra ti, puedes gastar 1 punto de suerte para imponer desventaja en esa tirada.",
    "prerequisite": null,
    "id": "feat_0_afortunado"
  },
  {
    "name": "Alerta",
    "category": "Dote de origen",
    "description": "Obtienes los siguientes beneficios:\n\nCompetencia en iniciativa. Puedes añadir tu bonificador por competencia a tus tiradas de iniciativa.\n\nIntercambio de iniciativa. Justo después de tirar iniciativa, puedes intercambiar tu resultado con el de un aliado dispuesto en el mismo combate, siempre que ninguno de los dos esté incapacitado.",
    "prerequisite": null,
    "id": "feat_1_alerta"
  },
  {
    "name": "Atacante Salvaje",
    "category": "Dote de origen",
    "description": "Una vez por turno, cuando impactas a un objetivo con un arma, puedes tirar dos veces los dados de daño del arma y usar el resultado que prefieras.",
    "prerequisite": null,
    "id": "feat_2_atacante_salvaje"
  },
  {
    "name": "Duro",
    "category": "Dote de origen",
    "description": "Tus puntos de golpe máximos aumentan en una cantidad igual al doble de tu nivel de personaje cuando obtienes esta dote. Además, cada vez que subes de nivel, tus puntos de golpe máximos aumentan en 2 adicionales.",
    "prerequisite": null,
    "id": "feat_3_duro"
  },
  {
    "name": "Fabricante",
    "category": "Dote de origen",
    "description": "Obtienes los siguientes beneficios:\n\nCompetencia con herramientas. Ganas competencia con tres herramientas de artesano a tu elección de la tabla de fabricación rápida.\n\nDescuento. Cuando compras un objeto no mágico, obtienes un 20% de descuento.\n\nFabricación rápida. Tras finalizar un descanso largo, puedes fabricar un objeto de la tabla de fabricación rápida si posees y eres competente con las herramientas necesarias. El objeto dura hasta que completes otro descanso largo, momento en el que se deshace.",
    "prerequisite": null,
    "table": {
      "headers": [
        "Herramientas de artesano",
        "Equipo fabricado"
      ],
      "rows": [
        [
          "Herramientas de albañil",
          "Polipasto"
        ],
        [
          "Herramientas de alfarero",
          "Jarro, lámpara"
        ],
        [
          "Herramientas de carpintero",
          "Antorcha, escalera"
        ],
        [
          "Herramientas de curtidor",
          "Bolsa, estuche"
        ],
        [
          "Herramientas de ebanista",
          "Bastón, garrote, garrote grande"
        ],
        [
          "Herramientas de herrero",
          "Abrojos, bolas de metal, cubo, garfio de escalada, olla de hierro"
        ],
        [
          "Herramientas de manitas",
          "Campana, pala, yesca"
        ],
        [
          "Herramientas de tejedor",
          "Cesta, cuerda, red, tienda"
        ]
      ]
    },
    "id": "feat_4_fabricante"
  },
  {
    "name": "Habilidoso",
    "category": "Dote de origen",
    "description": "Obtienes los siguientes beneficios:\n\nCompetencias. Ganas competencia en cualquier combinación de tres habilidades o herramientas a tu elección.\n\nRepetible. Puedes elegir esta dote más de una vez.",
    "prerequisite": null,
    "id": "feat_5_habilidoso"
  },
  {
    "name": "Iniciado en la Magia",
    "category": "Dote de origen",
    "description": "Obtienes los siguientes beneficios:\n\nDos trucos. Aprendes dos trucos a tu elección de la lista de conjuros de clérigo, druida o mago. Tu característica para lanzarlos es Inteligencia, Sabiduría o Carisma (a elegir al obtener esta dote).\n\nConjuro de nivel 1. Elige un conjuro de nivel 1 de la misma lista. Siempre lo tienes preparado. Puedes lanzarlo una vez sin gastar un espacio de conjuro y recuperas este uso tras un descanso largo. También puedes lanzarlo usando espacios de conjuro.\n\nCambiar conjuro. Cada vez que subes de nivel, puedes reemplazar uno de los conjuros elegidos por otro de la misma lista y nivel.\n\nRepetible. Puedes elegir esta dote más de una vez, pero debes escoger una lista de conjuros distinta cada vez.",
    "prerequisite": null,
    "id": "feat_6_iniciado_en_la_magia"
  },
  {
    "name": "Matón de Taberna",
    "category": "Dote de origen",
    "description": "Obtienes los siguientes beneficios:\n\nAtaque sin armas mejorado. Tus ataques sin armas infligen 1d4 + tu modificador de Fuerza en lugar de su daño normal.\n\nRepetir tiradas de daño. Cuando tires daño con un ataque sin armas, puedes repetir el dado si obtienes un 1, debiendo usar el nuevo resultado.\n\nArmas improvisadas. Tienes competencia con armas improvisadas.\n\nEmpujar. Cuando impactas a una criatura con un ataque sin armas como parte de la acción de atacar en tu turno, puedes empujarla hasta 5 pies además de infligir daño. Solo puedes usar este efecto una vez por turno.",
    "prerequisite": null,
    "id": "feat_7_maton_de_taberna"
  },
  {
    "name": "Músico",
    "category": "Dote de origen",
    "description": "Obtienes los siguientes beneficios:\n\nFormación instrumental. Ganas competencia con tres instrumentos musicales a tu elección.\n\nCanción alentadora. Al finalizar un descanso corto o largo, puedes tocar un instrumento musical con el que seas competente para otorgar inspiración heroica a un número de aliados que te escuchen igual a tu bonificador por competencia.",
    "prerequisite": null,
    "id": "feat_8_musico"
  },
  {
    "name": "Sanador",
    "category": "Dote de origen",
    "description": "Obtienes los siguientes beneficios:\n\nMédico de batalla. Si tienes útiles de sanador, puedes gastar un uso como acción para tratar a una criatura a 5 pies o menos de ti. La criatura puede gastar un dado de golpe y tú lo tiras, recuperando puntos de golpe iguales al resultado más tu bonificador por competencia.\n\nRepetir tiradas de curación. Cuando tires dados para recuperar puntos de golpe con un conjuro o con el beneficio de médico de batalla, puedes repetir cualquier resultado de 1, debiendo usar el nuevo resultado.",
    "prerequisite": null,
    "id": "feat_9_sanador"
  },
  {
    "name": "Acechador",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Destreza en 1, hasta un máximo de 20.\n\nVisión ciega. Tienes visión ciega hasta 10 pies.\n\nNiebla de guerra. Tienes ventaja en las pruebas de Destreza (Sigilo) que hagas como parte de la acción de esconderte durante el combate.\n\nEn la sombra. Si realizas una tirada de ataque mientras estás escondido y fallas, tu posición no se revela.",
    "prerequisite": "Nivel 4 o más, Destreza 13 o más",
    "id": "feat_10_acechador"
  },
  {
    "name": "Actor",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Carisma en 1, hasta un máximo de 20.\n\nSuplantación. Mientras te disfraces de una persona real o ficticia, tienes ventaja en las pruebas de Carisma (Engaño o Interpretación) para hacerte pasar por ella.\n\nImitación. Puedes imitar sonidos de otras criaturas, incluido el habla. Una criatura que escuche la imitación debe superar una prueba de Sabiduría (Perspicacia) con CD 8 + tu modificador de Carisma + tu bonificador por competencia para detectar el engaño.",
    "prerequisite": "Nivel 4 o más, Carisma 13 o más",
    "id": "feat_11_actor"
  },
  {
    "name": "Apresador",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Fuerza o Destreza en 1, hasta un máximo de 20.\n\nGolpear y agarrar. Cuando impactas a una criatura con un ataque sin armas como parte de la acción de atacar en tu turno, puedes infligir daño y además intentar agarrarla. Solo puedes usar este beneficio una vez por turno.\n\nVentaja al atacar. Tienes ventaja en las tiradas de ataque contra criaturas a las que estés agarrando.\n\nLuchador rápido. No necesitas gastar movimiento adicional para mover a una criatura a la que estés agarrando si es de tu tamaño o menor.",
    "prerequisite": "Nivel 4 o más, Fuerza o Destreza 13 o más",
    "id": "feat_12_apresador"
  },
  {
    "name": "Atacante a la Carga",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Fuerza o Destreza en 1, hasta un máximo de 20.\n\nCarrera mejorada. Cuando realizas la acción de correr, tu velocidad aumenta en 10 pies para esa acción.\n\nAtaque con carga. Si te mueves al menos 10 pies en línea recta hacia un objetivo justo antes de impactarle con un ataque cuerpo a cuerpo como parte de la acción de atacar, puedes elegir uno de los siguientes efectos: el ataque inflige 1d8 de daño adicional o empujas al objetivo hasta 10 pies si su tamaño es, como máximo, una categoría superior al tuyo. Solo puedes usar este beneficio una vez por turno.",
    "prerequisite": "Nivel 4 o más, Fuerza o Destreza 13 o más",
    "id": "feat_13_atacante_a_la_carga"
  },
  {
    "name": "Atleta",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Fuerza o Destreza en 1, hasta un máximo de 20.\n\nVelocidad trepando. Obtienes una velocidad de trepar igual a tu velocidad.\n\nLevantarse de un salto. Cuando estás derribado, puedes ponerte de pie gastando solo 5 pies de movimiento.\n\nSaltar. Puedes realizar saltos de longitud o altura con carrerilla tras moverte solo 5 pies.",
    "prerequisite": "Nivel 4 o más, Fuerza o Destreza 13 o más",
    "id": "feat_14_atleta"
  },
  {
    "name": "Azote de Magos",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Fuerza o Destreza en 1, hasta un máximo de 20.\n\nAnticoncentración. Cuando dañas a una criatura que está concentrándose en un conjuro, tiene desventaja en la tirada de salvación para mantener la concentración.\n\nMente robusta. Si fallas una tirada de salvación de Inteligencia, Sabiduría o Carisma, puedes hacer que tenga éxito. Una vez usas este beneficio, no puedes volver a usarlo hasta finalizar un descanso corto o largo.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_15_azote_de_magos"
  },
  {
    "name": "Centinela",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Fuerza o Destreza en 1, hasta un máximo de 20.\n\nGuardián. Cuando una criatura a 5 pies o menos de ti realiza la acción de retirarse o impacta a un objetivo que no seas tú, puedes usar tu reacción para hacer un ataque de oportunidad contra ella.\n\nDetener. Cuando impactas a una criatura con un ataque de oportunidad, su velocidad se reduce a 0 hasta el final del turno actual.",
    "prerequisite": "Nivel 4 o más, Fuerza o Destreza 13 o más",
    "id": "feat_16_centinela"
  },
  {
    "name": "Chef",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Constitución o Sabiduría en 1, hasta un máximo de 20.\n\nÚtiles de cocinero. Obtienes competencia con útiles de cocinero si aún no la tienes.\n\nComida reconstituyente. Durante un descanso corto, puedes preparar una comida especial si tienes ingredientes y útiles de cocinero. Puedes preparar comida para un número de criaturas igual a 4 + tu bonificador por competencia. Al final del descanso, cualquier criatura que coma y gaste uno o más dados de golpe recupera 1d8 puntos de golpe adicionales.\n\nTentempiés tonificantes. Tras 1 hora de trabajo o al finalizar un descanso largo, puedes preparar un número de tentempiés igual a tu bonificador por competencia si tienes ingredientes y útiles de cocinero. Duran 8 horas. Una criatura puede usar una acción adicional para consumir uno y ganar puntos de golpe temporales iguales a tu bonificador por competencia.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_17_chef"
  },
  {
    "name": "Combatiente con Dos Armas",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Fuerza o Destreza en 1, hasta un máximo de 20.\n\nManejo doble mejorado. Cuando realizas la acción de atacar y usas un arma con la propiedad ligera, puedes hacer un ataque adicional como acción adicional con otra arma cuerpo a cuerpo distinta que no tenga la propiedad a dos manos. No añades tu modificador de característica al daño de este ataque, salvo que sea negativo.\n\nDesenvainar rápido. Puedes desenvainar o envainar dos armas que no tengan la propiedad a dos manos cuando normalmente solo podrías hacerlo con una.",
    "prerequisite": "Nivel 4 o más, Fuerza o Destreza 13 o más",
    "id": "feat_18_combatiente_con_dos_armas"
  },
  {
    "name": "Combatiente Montado",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Fuerza, Destreza o Sabiduría en 1, hasta un máximo de 20.\n\nGolpe montado. Mientras estás montando, tienes ventaja en las tiradas de ataque contra criaturas no montadas a 5 pies o menos de tu montura si su tamaño es al menos una categoría inferior.\n\nEsquivar de un salto. Si tu montura debe hacer una tirada de salvación de Destreza para recibir solo la mitad de daño, no recibe daño si la supera y solo la mitad si la falla, siempre que estés montándola y ninguno esté incapacitado.\n\nGirar bruscamente. Mientras estás montando, puedes hacer que un ataque que impacte a tu montura te impacte a ti en su lugar, siempre que no estés incapacitado.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_19_combatiente_montado"
  },
  {
    "name": "Duelista Defensivo",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Destreza en 1, hasta un máximo de 20.\n\nParada. Si empuñas un arma sutil y una criatura te impacta con un ataque cuerpo a cuerpo, puedes usar tu reacción para añadir tu bonificador por competencia a tu clase de armadura, pudiendo hacer que el ataque falle. Este bonificador se mantiene contra ataques cuerpo a cuerpo hasta el inicio de tu siguiente turno.",
    "prerequisite": "Nivel 4 o más, Destreza 13 o más",
    "id": "feat_20_duelista_defensivo"
  },
  {
    "name": "Entrenamiento con Armas Marciales",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Fuerza o Destreza en 1, hasta un máximo de 20.\n\nCompetencia con armas. Obtienes competencia con armas marciales.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_21_entrenamiento_con_armas_marciales"
  },
  {
    "name": "Envenenador",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Destreza o Inteligencia en 1, hasta un máximo de 20.\n\nVeneno potente. Cuando infliges daño de veneno, ignoras la resistencia a ese daño.\n\nPreparar veneno. Obtienes competencia con útiles de envenenador. Con 1 hora de trabajo y materiales por valor de 50 po, puedes crear un número de dosis de veneno igual a tu bonificador por competencia. Como acción adicional, puedes aplicar una dosis a un arma o munición. El veneno dura 1 minuto o hasta que inflijas daño. La criatura afectada debe superar una tirada de salvación de Constitución (CD 8 + modificador de la característica aumentada + bonificador por competencia) o recibe 2d8 de daño de veneno y queda envenenada hasta el final de tu siguiente turno.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_22_envenenador"
  },
  {
    "name": "Experto en Ballestas",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Destreza en 1, hasta un máximo de 20.\n\nIgnorar la recarga. Ignoras la propiedad de recarga de las ballestas. Puedes cargar munición aunque no tengas una mano libre.\n\nDisparar cuerpo a cuerpo. No sufres desventaja al realizar ataques con ballestas contra criaturas a 5 pies o menos de ti.\n\nManejo doble. Cuando realizas un ataque adicional con la propiedad ligera usando una ballesta ligera, puedes añadir tu modificador de característica al daño si no lo estás haciendo ya.",
    "prerequisite": "Nivel 4 o más, Destreza 13 o más",
    "id": "feat_23_experto_en_ballestas"
  },
  {
    "name": "Experto en Habilidades",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta una puntuación de característica de tu elección en 1, hasta un máximo de 20.\n\nCompetencia en una habilidad. Ganas competencia en una habilidad de tu elección.\n\nPericia. Elige una habilidad en la que tengas competencia y no tengas pericia. Obtienes pericia en esa habilidad.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_24_experto_en_habilidades"
  },
  {
    "name": "Influencia Feérica",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Inteligencia, Sabiduría o Carisma en 1, hasta un máximo de 20.\n\nMagia feérica. Elige un conjuro de nivel 1 de las escuelas de adivinación o encantamiento. Siempre tienes ese conjuro y paso brumoso preparados. Puedes lanzar cada uno una vez sin gastar espacio de conjuro, recuperando este uso tras un descanso largo. También puedes lanzarlos usando espacios de conjuro. La característica para lanzarlos es la aumentada por esta dote.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_25_influencia_feerica"
  },
  {
    "name": "Influencia Sombría",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Inteligencia, Sabiduría o Carisma en 1, hasta un máximo de 20.\n\nMagia de las sombras. Elige un conjuro de nivel 1 de las escuelas de ilusión o nigromancia. Siempre tienes ese conjuro e invisibilidad preparados. Puedes lanzar cada uno una vez sin gastar espacio de conjuro, recuperando este uso tras un descanso largo. También puedes lanzarlos usando espacios de conjuro. La característica para lanzarlos es la aumentada por esta dote.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_26_influencia_sombria"
  },
  {
    "name": "Lanzador en Combate",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Inteligencia, Sabiduría o Carisma en 1, hasta un máximo de 20.\n\nConcentración. Tienes ventaja en las tiradas de salvación de Constitución para mantener la concentración.\n\nConjuro reactivo. Cuando una criatura provoca un ataque de oportunidad al salir de tu alcance, puedes usar tu reacción para lanzar un conjuro en su lugar. El conjuro debe tener un tiempo de lanzamiento de una acción y solo puede tener como objetivo a esa criatura.\n\nComponentes somáticos. Puedes realizar los componentes somáticos de los conjuros incluso si tienes armas o un escudo en una o ambas manos.",
    "prerequisite": "Nivel 4 o más, rasgo Lanzamiento de conjuros o Magia del pacto",
    "id": "feat_27_lanzador_en_combate"
  },
  {
    "name": "Lanzador Preciso",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Inteligencia, Sabiduría o Carisma en 1, hasta un máximo de 20.\n\nSortear la cobertura. Tus tiradas de ataque con conjuros ignoran la cobertura media y tres cuartos.\n\nLanzar conjuros cuerpo a cuerpo. No sufres desventaja en tiradas de ataque con conjuros contra criaturas a 5 pies o menos de ti.\n\nAlcance aumentado. Cuando lanzas un conjuro con un alcance de al menos 10 pies que requiere una tirada de ataque, puedes aumentar su alcance en 60 pies.",
    "prerequisite": "Nivel 4 o más, rasgo Lanzamiento de conjuros o Magia del pacto",
    "id": "feat_28_lanzador_preciso"
  },
  {
    "name": "Lanzador Ritual",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Inteligencia, Sabiduría o Carisma en 1, hasta un máximo de 20.\n\nConjuros rituales. Elige un número de conjuros de nivel 1 con la etiqueta ritual igual a tu bonificador por competencia. Siempre los tienes preparados y puedes lanzarlos usando espacios de conjuro. La característica para lanzarlos es la aumentada por esta dote. Cada vez que tu bonificador por competencia aumenta, puedes añadir otro conjuro ritual de nivel 1.\n\nRitual rápido. Puedes lanzar uno de estos conjuros usando su tiempo de lanzamiento normal en lugar del de ritual sin gastar un espacio de conjuro. Tras hacerlo, no puedes volver a usar este beneficio hasta completar un descanso largo.",
    "prerequisite": "Nivel 4 o más, Inteligencia, Sabiduría o Carisma 13 o más",
    "id": "feat_29_lanzador_ritual"
  },
  {
    "name": "Líder Inspirador",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Sabiduría o Carisma en 1, hasta un máximo de 20.\n\nInterpretación fortalecedora. Tras finalizar un descanso corto o largo, puedes realizar una interpretación inspiradora (discurso, canción o baile). Elige hasta seis aliados a 30 pies o menos de ti, incluyéndote. Cada criatura gana puntos de golpe temporales iguales a tu nivel de personaje más el modificador de la característica aumentada por esta dote.",
    "prerequisite": "Nivel 4 o más, Sabiduría o Carisma 13 o más",
    "id": "feat_30_lider_inspirador"
  },
  {
    "name": "Ligeramente Acorazado",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Fuerza o Destreza en 1, hasta un máximo de 20.\n\nEntrenamiento con armaduras. Obtienes entrenamiento con armaduras ligeras y escudos.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_31_ligeramente_acorazado"
  },
  {
    "name": "Maestro de Armas",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Fuerza o Destreza en 1, hasta un máximo de 20.\n\nPropiedad de maestría. Puedes usar la propiedad de maestría con un tipo de arma sencilla o marcial de tu elección con la que tengas competencia. Tras un descanso largo, puedes cambiar el tipo de arma elegido.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_32_maestro_de_armas"
  },
  {
    "name": "Maestro en Armaduras Medias",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Fuerza o Destreza en 1, hasta un máximo de 20.\n\nPortador diestro. Mientras llevas armadura media, puedes añadir hasta +3 a tu CA por Destreza en lugar de +2 si tu Destreza es 16 o más.",
    "prerequisite": "Nivel 4 o más, entrenamiento con armaduras medias",
    "id": "feat_33_maestro_en_armaduras_medias"
  },
  {
    "name": "Maestro en Armaduras Pesadas",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Constitución o Fuerza en 1, hasta un máximo de 20.\n\nReducción de daño. Mientras llevas armadura pesada, el daño contundente, cortante y perforante que recibes se reduce en una cantidad igual a tu bonificador por competencia.",
    "prerequisite": "Nivel 4 o más, entrenamiento con armaduras pesadas",
    "id": "feat_34_maestro_en_armaduras_pesadas"
  },
  {
    "name": "Maestro en Armas de Asta",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Fuerza o Destreza en 1, hasta un máximo de 20.\n\nGolpe con asta. Tras realizar la acción de atacar con un bastón, lanza o arma con alcance y pesada, puedes hacer un ataque adicional como acción adicional con el extremo opuesto del arma (1d4 de daño contundente).\n\nGolpe reactivo. Mientras empuñas estas armas, puedes usar tu reacción para hacer un ataque cuerpo a cuerpo contra una criatura que entre en tu alcance.",
    "prerequisite": "Nivel 4 o más, Fuerza o Destreza 13 o más",
    "id": "feat_35_maestro_en_armas_de_asta"
  },
  {
    "name": "Maestro en Armas Pesadas",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Fuerza en 1, hasta un máximo de 20.\n\nMaestría con armas pesadas. Cuando impactas con un arma pesada como parte de la acción de atacar, infliges daño adicional igual a tu bonificador por competencia.\n\nAvasallar. Cuando causas un crítico o reduces a una criatura a 0 puntos de golpe con un arma cuerpo a cuerpo, puedes hacer un ataque adicional como acción adicional.",
    "prerequisite": "Nivel 4 o más, Fuerza 13 o más",
    "id": "feat_36_maestro_en_armas_pesadas"
  },
  {
    "name": "Maestro en Escudos",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Fuerza en 1, hasta un máximo de 20.\n\nGolpe con escudo. Cuando impactas a una criatura a 5 pies o menos con un ataque cuerpo a cuerpo, puedes usar tu escudo para empujarla o derribarla (TS de Fuerza CD 8 + modificador de Fuerza + bonificador por competencia). Solo una vez por turno.\n\nInterponer escudo. Si un efecto te permite hacer una tirada de salvación de Destreza para recibir la mitad de daño, puedes usar tu reacción para no recibir daño si la superas mientras llevas escudo.",
    "prerequisite": "Nivel 4 o más, entrenamiento con escudos",
    "id": "feat_37_maestro_en_escudos"
  },
  {
    "name": "Mejora de Característica",
    "category": "Dote general",
    "description": "Aumenta una puntuación de característica en 2 o dos puntuaciones en 1 cada una. Ninguna puede superar 20. Puedes elegir esta dote más de una vez.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_38_mejora_de_caracteristica"
  },
  {
    "name": "Mente Aguda",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Inteligencia en 1, hasta un máximo de 20.\n\nSabiduría popular. Elige entre Conocimiento arcano, Historia, Investigación, Naturaleza o Religión. Ganas competencia o pericia si ya la tenías.\n\nEstudio rápido. Puedes realizar la acción de estudiar como acción adicional.",
    "prerequisite": "Nivel 4 o más, Inteligencia 13 o más",
    "id": "feat_39_mente_aguda"
  },
  {
    "name": "Moderadamente Acorazado",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Fuerza o Destreza en 1, hasta un máximo de 20.\n\nEntrenamiento con armaduras. Obtienes entrenamiento con armaduras medias.",
    "prerequisite": "Nivel 4 o más, entrenamiento con armaduras ligeras",
    "id": "feat_40_moderadamente_acorazado"
  },
  {
    "name": "Muy Acorazado",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Constitución o Fuerza en 1, hasta un máximo de 20.\n\nEntrenamiento con armaduras. Obtienes entrenamiento con armaduras pesadas.",
    "prerequisite": "Nivel 4 o más, entrenamiento con armaduras medias",
    "id": "feat_41_muy_acorazado"
  },
  {
    "name": "Observador",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Inteligencia o Sabiduría en 1, hasta un máximo de 20.\n\nObservador perspicaz. Elige entre Investigación, Percepción o Perspicacia. Ganas competencia o pericia si ya la tenías.\n\nBúsqueda rápida. Puedes realizar la acción de buscar como acción adicional.",
    "prerequisite": "Nivel 4 o más, Inteligencia o Sabiduría 13 o más",
    "id": "feat_42_observador"
  },
  {
    "name": "Perforador",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Fuerza o Destreza en 1, hasta un máximo de 20.\n\nHoradar. Una vez por turno, cuando infliges daño perforante, puedes repetir uno de los dados de daño.\n\nCrítico potenciado. Cuando realizas un crítico con daño perforante, tiras un dado de daño adicional.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_43_perforador"
  },
  {
    "name": "Rebanador",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Fuerza o Destreza en 1, hasta un máximo de 20.\n\nLacerar. Una vez por turno, cuando impactas a una criatura con un ataque que inflige daño cortante, puedes reducir su velocidad en 10 pies hasta el inicio de tu siguiente turno.\n\nCrítico potenciado. Cuando realizas un crítico que inflige daño cortante, el objetivo tiene desventaja en sus tiradas de ataque hasta el inicio de tu siguiente turno.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_44_rebanador"
  },
  {
    "name": "Resiliente",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Elige una característica en la que no tengas competencia en tiradas de salvación. Aumenta esa puntuación en 1, hasta un máximo de 20.\n\nCompetencia en tiradas de salvación. Obtienes competencia en las tiradas de salvación de la característica elegida.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_45_resiliente"
  },
  {
    "name": "Resistente",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Constitución en 1, hasta un máximo de 20.\n\nDesafiar a la muerte. Tienes ventaja en las tiradas de salvación contra muerte.\n\nRecuperación rápida. Como acción adicional, puedes gastar un dado de golpe, tirarlo y recuperar puntos de golpe iguales al resultado.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_46_resistente"
  },
  {
    "name": "Telepático",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Inteligencia, Sabiduría o Carisma en 1, hasta un máximo de 20.\n\nHabla telepática. Puedes comunicarte telepáticamente con una criatura que puedas ver a 60 pies o menos. Debes compartir un idioma, y la criatura no puede responder telepáticamente.\n\nDetectar pensamientos. Siempre tienes preparado detectar pensamientos. Puedes lanzarlo una vez sin gastar espacio de conjuro ni componentes, recuperando este uso tras un descanso largo. También puedes lanzarlo usando espacios de conjuro. La característica para lanzarlo es la aumentada por esta dote.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_47_telepatico"
  },
  {
    "name": "Telequinético",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Inteligencia, Sabiduría o Carisma en 1, hasta un máximo de 20.\n\nTelequinesis menor. Aprendes mano de mago. Puedes lanzarlo sin componentes verbales ni somáticos, hacerlo invisible y aumentar su alcance en 30 pies. La característica para lanzarlo es la aumentada por esta dote.\n\nEmpellón telequinético. Como acción adicional, puedes forzar a una criatura a 30 pies o menos a hacer una tirada de salvación de Fuerza (CD 8 + modificador de característica + bonificador por competencia). Si falla, se mueve 5 pies hacia ti o lejos de ti.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_48_telequinetico"
  },
  {
    "name": "Tirador de Primera",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Destreza en 1, hasta un máximo de 20.\n\nSortear la cobertura. Tus ataques a distancia con armas ignoran la cobertura media y tres cuartos.\n\nDisparar cuerpo a cuerpo. No sufres desventaja en ataques a distancia contra criaturas a 5 pies o menos.\n\nTiros lejanos. No tienes desventaja al atacar a largo alcance con armas a distancia.",
    "prerequisite": "Nivel 4 o más, Destreza 13 o más",
    "id": "feat_49_tirador_de_primera"
  },
  {
    "name": "Triturador",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Fuerza o Constitución en 1, hasta un máximo de 20.\n\nEmpujar. Una vez por turno, cuando infliges daño contundente, puedes mover al objetivo 5 pies a un espacio desocupado si su tamaño es como máximo una categoría superior.\n\nCrítico potenciado. Cuando realizas un crítico con daño contundente, las tiradas de ataque contra el objetivo tienen ventaja hasta el inicio de tu siguiente turno.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_50_triturador"
  },
  {
    "name": "Veloz",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Destreza o Constitución en 1, hasta un máximo de 20.\n\nAumento de velocidad. Tu velocidad aumenta en 10 pies.\n\nCorrer por terreno difícil. Cuando realizas la acción de correr, el terreno difícil no te cuesta movimiento adicional ese turno.\n\nMovimiento ágil. Los ataques de oportunidad contra ti tienen desventaja.",
    "prerequisite": "Nivel 4 o más, Destreza o Constitución 13 o más",
    "id": "feat_51_veloz"
  },
  {
    "name": "Versado en un Elemento",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Inteligencia, Sabiduría o Carisma en 1, hasta un máximo de 20.\n\nDominio de la energía. Elige ácido, frío, fuego, relámpago o trueno. Tus conjuros ignoran la resistencia a ese tipo de daño y tratas los resultados de 1 en los dados de daño como 2.\n\nRepetible. Puedes elegir esta dote más de una vez, pero debes escoger un tipo de daño distinto cada vez.",
    "prerequisite": "Nivel 4 o más, rasgo Lanzamiento de conjuros o Magia del pacto",
    "id": "feat_52_versado_en_un_elemento"
  },
  {
    "name": "Combate con Armas a Dos Manos",
    "category": "Dote de estilo de combate",
    "description": "Cuando tiras el daño de un ataque con un arma cuerpo a cuerpo que empuñas con ambas manos, puedes tratar cualquier resultado de 1 o 2 en los dados de daño como un 3. El arma debe tener la propiedad a dos manos o versátil.",
    "prerequisite": "Rasgo Estilo de combate",
    "id": "feat_53_combate_con_armas_a_dos_manos"
  },
  {
    "name": "Combate con Armas Arrojadizas",
    "category": "Dote de estilo de combate",
    "description": "Cuando impactas con un ataque a distancia usando un arma con la propiedad arrojadiza, obtienes un bonificador de +2 a la tirada de daño.",
    "prerequisite": "Rasgo Estilo de combate",
    "id": "feat_54_combate_con_armas_arrojadizas"
  },
  {
    "name": "Combate con Dos Armas",
    "category": "Dote de estilo de combate",
    "description": "Cuando realizas un ataque adicional usando un arma con la propiedad ligera, puedes añadir tu modificador de característica al daño de ese ataque si no lo estás añadiendo ya.",
    "prerequisite": "Rasgo Estilo de combate",
    "id": "feat_55_combate_con_dos_armas"
  },
  {
    "name": "Combate sin Armas",
    "category": "Dote de estilo de combate",
    "description": "Cuando impactas con un ataque sin armas, infliges 1d6 + tu modificador de Fuerza en lugar del daño normal. Si no empuñas armas ni escudo, el dado pasa a ser 1d8.\n\nAl inicio de cada uno de tus turnos, puedes infligir 1d4 de daño contundente a una criatura a la que tengas agarrada.",
    "prerequisite": "Rasgo Estilo de combate",
    "id": "feat_56_combate_sin_armas"
  },
  {
    "name": "Defensa",
    "category": "Dote de estilo de combate",
    "description": "Mientras lleves armadura ligera, media o pesada, obtienes un bonificador de +1 a la clase de armadura.",
    "prerequisite": "Rasgo Estilo de combate",
    "id": "feat_57_defensa"
  },
  {
    "name": "Duelo",
    "category": "Dote de estilo de combate",
    "description": "Cuando empuñas un arma cuerpo a cuerpo con una mano y no llevas nada en la otra, obtienes un bonificador de +2 a las tiradas de daño con esa arma.",
    "prerequisite": "Rasgo Estilo de combate",
    "id": "feat_58_duelo"
  },
  {
    "name": "Intercepción",
    "category": "Dote de estilo de combate",
    "description": "Cuando una criatura que puedes ver impacta a otra criatura a 5 pies o menos de ti, puedes usar tu reacción para reducir el daño en 1d10 + tu bonificador por competencia. Debes estar empuñando un arma o llevando un escudo.",
    "prerequisite": "Rasgo Estilo de combate",
    "id": "feat_59_intercepcion"
  },
  {
    "name": "Lucha a Ciegas",
    "category": "Dote de estilo de combate",
    "description": "Tienes visión ciega hasta 10 pies.",
    "prerequisite": "Rasgo Estilo de combate",
    "id": "feat_60_lucha_a_ciegas"
  },
  {
    "name": "Protección",
    "category": "Dote de estilo de combate",
    "description": "Cuando una criatura que puedes ver ataca a un objetivo que no eres tú y está a 5 pies o menos de ti, puedes usar tu reacción para imponer desventaja a esa tirada de ataque si llevas un escudo. Si permaneces a 5 pies del objetivo, las tiradas de ataque posteriores contra él también tienen desventaja hasta el inicio de tu siguiente turno.",
    "prerequisite": "Rasgo Estilo de combate",
    "id": "feat_61_proteccion"
  },
  {
    "name": "Tiro con Arco",
    "category": "Dote de estilo de combate",
    "description": "Obtienes un bonificador de +2 a las tiradas de ataque con armas a distancia.",
    "prerequisite": "Rasgo Estilo de combate",
    "id": "feat_62_tiro_con_arco"
  },
  {
    "name": "Don de la Fortaleza",
    "category": "Dote de don épico",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta una puntuación de característica de tu elección en 1, hasta un máximo de 30.\n\nSalud fortalecida. Tus puntos de golpe máximos aumentan en 40. Además, cuando recuperas puntos de golpe, recuperas una cantidad adicional igual a tu modificador de Constitución. Una vez usas este beneficio, no puedes volver a hacerlo hasta el inicio de tu siguiente turno.",
    "prerequisite": "Nivel 19 o más",
    "id": "feat_63_don_de_la_fortaleza"
  },
  {
    "name": "Don de la Habilidad",
    "category": "Dote de don épico",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta una puntuación de característica de tu elección en 1, hasta un máximo de 30.\n\nExperto polifacético. Obtienes competencia en todas las habilidades.\n\nPericia. Elige una habilidad en la que no tengas pericia. Obtienes pericia en esa habilidad.",
    "prerequisite": "Nivel 19 o más",
    "id": "feat_64_don_de_la_habilidad"
  },
  {
    "name": "Don de la Pericia en Combate",
    "category": "Dote de don épico",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta una puntuación de característica de tu elección en 1, hasta un máximo de 30.\n\nPrecisión sin igual. Cuando fallas una tirada de ataque, puedes hacer que impacte. Una vez usas este beneficio, no puedes volver a hacerlo hasta el inicio de tu siguiente turno.",
    "prerequisite": "Nivel 19 o más",
    "id": "feat_65_don_de_la_pericia_en_combate"
  },
  {
    "name": "Don de la Recuperación",
    "category": "Dote de don épico",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta una puntuación de característica de tu elección en 1, hasta un máximo de 30.\n\nÚltima defensa. Cuando tus puntos de golpe se reducirían a 0, puedes quedarte en 1 punto de golpe y recuperar la mitad de tus puntos de golpe máximos. Una vez usas este beneficio, no puedes volver a hacerlo hasta finalizar un descanso largo.\n\nRecuperar vitalidad. Tienes una reserva de 10d10. Como acción adicional, puedes gastar dados de la reserva para recuperar puntos de golpe iguales al resultado. Recuperas todos los dados tras un descanso largo.",
    "prerequisite": "Nivel 19 o más",
    "id": "feat_66_don_de_la_recuperacion"
  },
  {
    "name": "Don de la Resistencia a Energías",
    "category": "Dote de don épico",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta una puntuación de característica de tu elección en 1, hasta un máximo de 30.\n\nResistencias a energías. Obtienes resistencia a dos tipos de daño a elegir entre ácido, frío, fuego, necrótico, psíquico, radiante, relámpago, trueno o veneno. Puedes cambiar la elección tras un descanso largo.\n\nRedirigir la energía. Cuando recibes daño de uno de los tipos elegidos, puedes usar tu reacción para infligir 2d12 + tu modificador de Constitución a una criatura que puedas ver a 60 pies o menos (TS de Destreza CD 8 + modificador de Constitución + bonificador por competencia para evitarlo).",
    "prerequisite": "Nivel 19 o más",
    "id": "feat_67_don_de_la_resistencia_a_energias"
  },
  {
    "name": "Don de la Velocidad",
    "category": "Dote de don épico",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta una puntuación de característica de tu elección en 1, hasta un máximo de 30.\n\nArtista escapista. Como acción adicional, puedes realizar la acción de retirarte y finalizar el estado de agarrado.\n\nCeleridad. Tu velocidad aumenta en 30 pies.",
    "prerequisite": "Nivel 19 o más",
    "id": "feat_68_don_de_la_velocidad"
  },
  {
    "name": "Don de la Visión Verdadera",
    "category": "Dote de don épico",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta una puntuación de característica de tu elección en 1, hasta un máximo de 30.\n\nVisión verdadera. Tienes visión verdadera hasta 60 pies.",
    "prerequisite": "Nivel 19 o más",
    "id": "feat_69_don_de_la_vision_verdadera"
  },
  {
    "name": "Don del Ataque Imparable",
    "category": "Dote de don épico",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Fuerza o Destreza en 1, hasta un máximo de 30.\n\nSuperar las defensas. El daño contundente, cortante y perforante que infliges ignora la resistencia.\n\nGolpe arrollador. Cuando obtienes un 20 natural en una tirada de ataque, infliges daño adicional igual a la puntuación de característica aumentada con esta dote.",
    "prerequisite": "Nivel 19 o más",
    "id": "feat_70_don_del_ataque_imparable"
  },
  {
    "name": "Don del Destino",
    "category": "Dote de don épico",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta una puntuación de característica de tu elección en 1, hasta un máximo de 30.\n\nMejorar el destino. Cuando tú u otra criatura a 60 pies o menos supera o falla una tirada de d20, puedes tirar 2d4 y aplicar el resultado como bonificador o penalizador. No puedes volver a usar este beneficio hasta que tires iniciativa o completes un descanso corto o largo.",
    "prerequisite": "Nivel 19 o más",
    "id": "feat_71_don_del_destino"
  },
  {
    "name": "Don del Espíritu de la Noche",
    "category": "Dote de don épico",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta una puntuación de característica de tu elección en 1, hasta un máximo de 30.\n\nFusionarse con las sombras. En luz tenue u oscuridad, puedes volverte invisible como acción adicional. La invisibilidad termina al realizar una acción, acción adicional o reacción.\n\nForma sombría. En luz tenue u oscuridad, tienes resistencia a todo el daño excepto psíquico y radiante.",
    "prerequisite": "Nivel 19 o más",
    "id": "feat_72_don_del_espiritu_de_la_noche"
  },
  {
    "name": "Don del Recuerdo de Conjuros",
    "category": "Dote de don épico",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Inteligencia, Sabiduría o Carisma en 1, hasta un máximo de 30.\n\nLanzamiento gratuito. Cuando lanzas un conjuro usando un espacio de nivel 1 a 4, tira 1d4. Si el resultado coincide con el nivel del espacio, no se consume.",
    "prerequisite": "Nivel 19 o más, rasgo Lanzamiento de conjuros",
    "id": "feat_73_don_del_recuerdo_de_conjuros"
  },
  {
    "name": "Don del Viaje Dimensional",
    "category": "Dote de don épico",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta una puntuación de característica de tu elección en 1, hasta un máximo de 30.\n\nPasos desplazadores. Tras realizar la acción de atacar o lanzar un conjuro, puedes teletransportarte hasta 30 pies a un espacio desocupado que puedas ver.",
    "prerequisite": "Nivel 19 o más",
    "id": "feat_74_don_del_viaje_dimensional"
  },
  {
    "name": "Juguete de Vampiro",
    "category": "Dote de origen",
    "description": "Obtienes los siguientes beneficios:\n\nDecantación. Cuando finalizas un descanso largo, puedes crear una Poción de curación o un Antitoxina, siempre que tengas un vial o frasco vacío. Estos líquidos se evaporan cuando finalizas otro descanso largo.\n\nRetirada oportuna. Puedes usar una acción adicional para realizar la acción de correr o retirarse. Puedes usar este beneficio un número de veces igual a tu bonificador por competencia, y recuperas todos los usos gastados al finalizar un descanso largo.\n\nConexión vampírica. El DM determina el destino de tu antiguo amo vampiro. Mientras tú y tu antiguo amo vampiro estéis en el mismo plano de existencia, el vampiro puede comunicarse contigo telepáticamente, y puedes elegir permitirle percibir a través de tus sentidos.",
    "prerequisite": null,
    "id": "feat_juguete_de_vampiro"
  },
  {
    "name": "Cazador de Vampiros",
    "category": "Dote de origen",
    "description": "Obtienes los siguientes beneficios:\n\nHuida diestra. Tienes ventaja en las pruebas para escapar de ataduras no mágicas o de la condición de agarrado.\n\nProtección de vitalidad. Cuando recibes daño necrótico, puedes usar tu reacción para mitigar ese daño. Tira un número de d6 igual a tu bonificador por competencia y suma los resultados. Reduce el daño necrótico que recibes en esa cantidad. Una vez uses este beneficio, no puedes volver a usarlo hasta finalizar un descanso corto o largo.",
    "prerequisite": null,
    "id": "feat_cazador_de_vampiros"
  },
  {
    "name": "Juerguista Incansable",
    "category": "Dote de origen",
    "description": "Obtienes el siguiente beneficio:\n\nCelebración inagotable. Cuando un aliado que puedas ver a 60 pies o menos de ti gasta Inspiración heroica, puedes obtener Inspiración heroica si no la tienes. Puedes usar este beneficio un número de veces igual a tu bonificador por competencia, y recuperas todos los usos gastados al finalizar un descanso corto o largo.",
    "prerequisite": null,
    "id": "feat_juerguista_incansable"
  },
  {
    "name": "Brujo de Shadowmoor",
    "category": "Dote de origen",
    "description": "Obtienes los siguientes beneficios:\n\nMaleficio. Siempre tienes preparado el conjuro maleficio. Inteligencia, Sabiduría o Carisma es tu característica para lanzarlo (eliges al obtener esta dote). Puedes lanzarlo una vez sin gastar un espacio de conjuro, y recuperas este uso al finalizar un descanso largo. También puedes lanzarlo usando cualquier espacio de conjuro que tengas.\n\nMagia de maleficio. Cuando una criatura a la que hayas afectado con maleficio te impacta con una tirada de ataque, recibe daño psíquico igual a tu bonificador por competencia. Una criatura solo puede recibir este daño una vez por turno.",
    "prerequisite": null,
    "id": "feat_brujo_de_shadowmoor"
  },
  {
    "name": "Hijo del Sol",
    "category": "Dote de origen",
    "description": "Obtienes los siguientes beneficios:\n\nOjos de Eirdu. Tú y los aliados a 10 pies o menos de ti tenéis ventaja en las tiradas de salvación para evitar o finalizar la condición cegado.\n\nFuego feérico. Aprendes el conjuro fuego feérico. Inteligencia, Sabiduría o Carisma es tu característica para lanzarlo (eliges al obtener esta dote). Puedes lanzarlo una vez sin gastar un espacio de conjuro, y recuperas este uso al finalizar un descanso largo. También puedes lanzarlo usando cualquier espacio de conjuro que tengas.\n\nCuando lanzas fuego feérico sin gastar un espacio de conjuro mediante este beneficio, recibir daño no puede romper tu concentración en el conjuro.",
    "prerequisite": null,
    "id": "feat_hijo_del_sol"
  },
  {
    "name": "Lanzador Gélido",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Inteligencia, Sabiduría o Carisma en 1, hasta un máximo de 20.\n\nTruco. Aprendes el truco rayo de escarcha. Si ya lo conoces, aprendes otro truco de mago de tu elección. La característica para lanzarlo es la aumentada por esta dote.\n\nMordedura gélida. Una vez por turno, cuando impactas a una criatura con una tirada de ataque e infliges daño de frío, puedes debilitar temporalmente sus defensas. La criatura resta 1d4 a la siguiente tirada de salvación que realice antes del final de tu siguiente turno.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_lanzador_gelido"
  },
  {
    "name": "Tramposo Feérico",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Destreza o Carisma en 1, hasta un máximo de 20.\n\nPaso feérico ágil. Cuando realizas la acción de retirarte en tu turno, el terreno difícil no te cuesta movimiento adicional durante el resto de ese turno.\n\nGolpe desconcertante. Cuando impactas a una criatura con una tirada de ataque, puedes intentar desconcertarla. El objetivo debe superar una tirada de salvación de Sabiduría (CD 8 + modificador de la característica aumentada por esta dote + tu bonificador por competencia) o tener desventaja en sus tiradas de salvación hasta el final de tu siguiente turno.\n\nPuedes usar este beneficio un número de veces igual a tu bonificador por competencia, y recuperas todos los usos gastados al finalizar un descanso largo.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_tramposo_feerico"
  },
  {
    "name": "Magia de Genio",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Inteligencia, Sabiduría o Carisma en 1, hasta un máximo de 20.\n\nMagia de deseo. Como acción mágica, puedes lanzar un conjuro de nivel 1 a tu elección de la lista de conjuros de hechicero que tenga un tiempo de lanzamiento de una acción. Una vez uses este beneficio, no puedes volver a usarlo hasta finalizar un descanso largo. La característica para lanzarlo es la aumentada por esta dote.\n\nCuando alcanzas el nivel 11, el conjuro que lanzas con esta dote se lanza como si usaras un espacio de conjuro de nivel 2. Cuando alcanzas el nivel 17, el conjuro se lanza como si usaras un espacio de conjuro de nivel 3.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_magia_de_genio"
  },
  {
    "name": "Tocado por el Mythal",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Inteligencia, Sabiduría o Carisma en 1, hasta un máximo de 20.\n\nProtección del mythal. Si un ataque de conjuro te impacta o fallas una tirada de salvación contra un conjuro, puedes usar tu reacción para tirar en la tabla de Magia del Tocado por el Mythal y crear un efecto mágico. Si un efecto requiere una tirada de salvación, la CD es igual a 8 + el modificador de la característica aumentada por esta dote + tu bonificador por competencia.\n\nPuedes usar este beneficio un número de veces igual a tu bonificador por competencia, y recuperas todos los usos gastados al finalizar un descanso largo.",
    "prerequisite": "Nivel 4 o más",
    "table": {
      "headers": [
        "1d20",
        "Efecto"
      ],
      "rows": [
        [
          "1-2",
          "Tú y cada criatura a 15 pies o menos de ti realizáis una tirada de salvación de Destreza, recibiendo daño de fuerza igual a 1d8 por nivel del conjuro desencadenante si falláis, o la mitad del daño si tenéis éxito."
        ],
        [
          "3-7",
          "Tú y el lanzador del conjuro desencadenante formáis un vínculo telepático durante 1 hora."
        ],
        [
          "8-10",
          "La gravedad se invierte en un cilindro de 15 pies de radio y 60 pies de altura centrado en ti durante 1 minuto, como en el conjuro invertir gravedad."
        ],
        [
          "11-13",
          "Tú y el lanzador del conjuro desencadenante realizáis una tirada de salvación de Constitución. Si falláis, la criatura queda aturdida hasta el final de su siguiente turno."
        ],
        [
          "14-17",
          "Obtienes un bonificador de +2 a la CA durante 1 minuto, pudiendo hacer que el conjuro desencadenante falle si era un ataque de conjuro."
        ],
        [
          "18-19",
          "Cualquier objeto inflamable no mágico a 10 pies o menos del lanzador del conjuro desencadenante que no esté siendo llevado o portado por otra criatura estalla en llamas, recibe 1d4 de daño de fuego y queda ardiendo."
        ],
        [
          "20",
          "El conjuro desencadenante se disipa sin efecto, y la acción, acción adicional o reacción usada para lanzarlo se pierde. Si el conjuro se lanzó usando un espacio de conjuro, este no se gasta."
        ]
      ]
    },
    "id": "feat_tocado_por_el_mythal"
  },
  {
    "name": "Adepto del Fuego Mágico",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Inteligencia, Sabiduría o Carisma en 1, hasta un máximo de 20.\n\nHechofuego potenciado. Una vez por turno, cuando un conjuro que lanzas inflige daño radiante, puedes gastar hasta dos dados de golpe, tirarlos y añadir el total obtenido a una de las tiradas de daño del conjuro.\n\nHechofuego abrasador. Cuando realizas una tirada de daño que inflige daño radiante, este ignora la resistencia al daño radiante.",
    "prerequisite": "Nivel 4 o más, rasgo Lanzamiento de conjuros o Magia del pacto",
    "id": "feat_adepto_del_fuego_magico"
  },
  {
    "name": "Agarre Experto",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Fuerza o Destreza en 1, hasta un máximo de 20.\n\nLlave de sujeción. Tus aliados tienen ventaja en las tiradas de ataque contra criaturas a las que tengas agarradas.\n\nNudo resistente. Cuando usas cadenas, grilletes o cuerda para inmovilizar a una criatura, añade tu bonificador por competencia a la CD para escapar o romper las cadenas, grilletes o cuerda.\n\nIntimidación firme. La actitud hostil de una criatura no impone desventaja a tus pruebas de Carisma (Intimidación) para influir sobre ella.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_agarre_experto"
  },
  {
    "name": "Sed de Sangre",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Fuerza, Destreza o Constitución en 1, hasta un máximo de 20.\n\nRecuperación poderosa. Cuando tiras un dado de golpe para recuperar puntos de golpe, puedes tratar cualquier resultado de 1 o 2 como un 3.\n\nFestín sanguíneo. Una vez por turno, cuando impactas con una tirada de ataque a una criatura ensangrentada que no sea un constructo ni un no muerto, puedes gastar un dado de golpe, tirarlo y recuperar una cantidad de puntos de golpe igual al resultado obtenido + tu modificador de Constitución.\n\nPuedes usar este rasgo un número de veces igual a tu bonificador por competencia, y recuperas todos los usos gastados al finalizar un descanso largo.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_sed_de_sangre"
  },
  {
    "name": "Bombardero",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Destreza en 1, hasta un máximo de 20.\n\nLanzamiento lejano. Cuando realizas la acción de atacar para lanzar un vial o frasco, puedes elegir como objetivo un objeto o criatura que puedas ver a 40 pies o menos de ti.\n\nTiros lejanos. Atacar a largo alcance no impone desventaja en tus tiradas de ataque con armas arrojadizas.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_bombardero"
  },
  {
    "name": "Niebla Asfixiante",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Inteligencia, Sabiduría o Carisma en 1, hasta un máximo de 20.\n\nAlzarse, niebla. Siempre tienes preparado el conjuro nube de niebla. Puedes lanzarlo una vez sin gastar un espacio de conjuro, y debes finalizar un descanso largo antes de poder hacerlo de nuevo de esta forma. También puedes lanzarlo usando espacios de conjuro apropiados que tengas. La característica para lanzarlo es la aumentada por esta dote.\n\nNiebla opresiva. Cada vez que lanzas nube de niebla, las llamas no mágicas dentro de la esfera del conjuro se extinguen, y las criaturas que no sean tú ni tus aliados tienen su velocidad reducida en 5 pies mientras estén dentro de la esfera.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_niebla_asfixiante"
  },
  {
    "name": "Dolor Delicioso",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta una puntuación de característica de tu elección en 1, hasta un máximo de 20.\n\nCarne endurecida. Inmediatamente después de recibir daño contundente, cortante o perforante, puedes usar tu reacción para obtener resistencia al daño contundente, cortante y perforante hasta el inicio de tu siguiente turno. Una vez uses este beneficio, no puedes volver a usarlo hasta finalizar un descanso corto o largo.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_dolor_delicioso"
  },
  {
    "name": "Portador de la Luz",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Inteligencia, Sabiduría o Carisma en 1, hasta un máximo de 20.\n\nMagia sagrada. Aprendes el conjuro luz y puedes lanzarlo sin componentes materiales. Si ya conoces este truco, aprendes otro truco de clérigo de tu elección. La característica para lanzarlo es la aumentada por esta dote.\n\nLuminiscencia solar. Cuando lanzas luz, puedes hacer que la luz del conjuro sea luz solar. Una vez uses este beneficio, no puedes volver a usarlo hasta finalizar un descanso largo.\n\nSanación del sol. Como acción adicional mientras estés bajo luz solar, puedes gastar uno de tus dados de golpe, tirarlo y recuperar una cantidad de puntos de golpe igual al resultado. Una vez uses este beneficio, no puedes volver a usarlo hasta finalizar un descanso corto o largo.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_portador_de_la_luz"
  },
  {
    "name": "Mordiscos de Amor",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta una puntuación de característica de tu elección en 1, hasta un máximo de 20.\n\nDolor encantador. Inmediatamente después de infligir daño a una criatura con un arma cuerpo a cuerpo o un ataque sin armas, puedes usar una acción adicional para imponerle la condición encantado hasta el inicio de tu siguiente turno o hasta que tú o tus aliados le inflijáis daño. Una vez uses este beneficio, no puedes volver a usarlo hasta finalizar un descanso corto o largo.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_mordiscos_de_amor"
  },
  {
    "name": "Putrefacción",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta una puntuación de característica de tu elección en 1, hasta un máximo de 20.\n\nNecrosis. Cuando realizas una tirada de daño que inflige daño necrótico, puedes hacer que una criatura que reciba ese daño sufra la condición envenenado hasta el inicio de tu siguiente turno. Una vez uses este beneficio, no puedes volver a usarlo hasta finalizar un descanso corto o largo.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_putrefaccion"
  },
  {
    "name": "Reprensión",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta una puntuación de característica de tu elección en 1, hasta un máximo de 20.\n\nGolpe radiante. Cuando realizas una tirada de daño que inflige daño radiante, puedes hacer que una criatura de tamaño Enorme o menor que reciba ese daño quede derribada. Una vez uses este beneficio, no puedes volver a usarlo hasta finalizar un descanso corto o largo.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_reprension"
  },
  {
    "name": "Encanto Traicionero",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Inteligencia, Sabiduría o Carisma en 1, hasta un máximo de 20.\n\nPresencia cautivadora. Siempre tienes preparado el conjuro encantar persona. Puedes lanzarlo una vez sin gastar un espacio de conjuro, y debes finalizar un descanso largo antes de poder hacerlo de nuevo de esta forma. También puedes lanzarlo usando espacios de conjuro apropiados que tengas. La característica para lanzarlo es la aumentada por esta dote.\n\nTraición inevitable. Tienes ventaja en las tiradas de ataque contra criaturas que estén bajo la condición encantado.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_encanto_traicionero"
  },
  {
    "name": "Tocado por el Vampiro",
    "category": "Dote general",
    "description": "Obtienes los siguientes beneficios:\n\nMejora de característica. Aumenta tu puntuación de Inteligencia, Sabiduría o Carisma en 1, hasta un máximo de 20.\n\nMagia vampírica. Elige un conjuro de nivel 1 de las escuelas de encantamiento o ilusión. Siempre tienes preparado ese conjuro y trepar cual arácnido. Puedes lanzar cada uno una vez sin gastar un espacio de conjuro, pero cuando lanzas trepar cual arácnido de esta forma, debes lanzarlo sobre ti mismo, y debes finalizar un descanso largo antes de poder lanzar cada conjuro de este modo de nuevo. También puedes lanzar cualquiera de los dos conjuros usando espacios de conjuro apropiados que tengas. La característica para lanzarlos es la aumentada por esta dote.",
    "prerequisite": "Nivel 4 o más",
    "id": "feat_tocado_por_el_vampiro"
  }
];
