window.MAGIC_ITEMS_DATA = [
  {
    "name": "ABALORIO DE NUTRICIÓN",
    "category": "Objeto maravilloso",
    "rarity": "Común",
    "attunement": "No",
    "description": "Mientras lleves puesto este abalorio, no necesitarás comer ni beber. Aún puedes ingerir comida y bebida si así lo deseas.",
    "id": "magic_abalorio_de_nutricion"
  },
  {
    "name": "ABANICO DEL VIENTO",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Mientras sostengas este abanico, puedes lanzar ráfaga de viento (CD de salvación 13) desde él. Cada vez siguiente que se utilice el abanico antes del próximo amanecer, existe una posibilidad acumulativa del 20 % de que no funcione y se desgarre en jirones inútiles y carentes de magia.",
    "id": "magic_abanico_del_viento"
  },
  {
    "name": "ACEITE DE AFILADO",
    "category": "Poción",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Un vial de este aceite puede recubrir un arma cuerpo a cuerpo o veinte unidades de munición, pero solo se verán afectadas las armas y munición no mágicas que causen daño cortante o perforante. Se tarda 1 minuto en aplicar el aceite, tras lo cual se filtra mágicamente en lo que recubra y convierte el arma en un arma +3 o la munición en munición +3. Este aceite transparente y gelatinoso brilla debido a las esquirlas de plata minúsculas y ultrafinas que contiene.",
    "id": "magic_aceite_de_afilado"
  },
  {
    "name": "ACEITE DE ETEREIDAD",
    "category": "Poción",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Un vial de este aceite puede cubrir a una criatura Mediana o más pequeña, así como el equipo que vista o lleve. Se necesita un vial extra por cada categoría de tamaño por encima de Mediano. Aplicar el aceite lleva 10 minutos. La criatura afectada obtiene el efecto del conjuro excursión etérea durante 1 hora. En el exterior de este recipiente se forman gotitas de un aceite turbio y gris que se evaporan rápidamente.",
    "id": "magic_aceite_de_etereidad"
  },
  {
    "name": "ACEITE ESCURRIDIZO",
    "category": "Poción",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Un vial de este aceite puede cubrir a una criatura Mediana o más pequeña, así como el equipo que vista o lleve. Se necesita un vial extra por cada categoría de tamaño por encima de Mediano. Aplicar el aceite lleva 10 minutos. La criatura afectada obtiene el efecto del conjuro libertad de movimiento durante 8 horas. De forma alternativa, el aceite se puede verter en el suelo como acción de magia y cubrirá un cuadrado de 10 pies de lado que duplicará el efecto del conjuro grasa en la zona durante 8 horas. Este ungüento negro y pegajoso parece denso y pesado, pero fluye rápidamente cuando se vierte.",
    "id": "magic_aceite_escurridizo"
  },
  {
    "name": "AGUJERO PORTÁTIL",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Esta delicada tela negra, suave como la seda, está doblada para tener las dimensiones de un pañuelo. Al desdoblarla, se convierte en una sábana circular de 6 pies de diámetro. Puedes usar una acción para extenderla y colocarla sobre una superficie sólida, creando un agujero extradimensional de 10 pies de profundidad. El interior es un cilindro de aproximadamente 282 pies cúbicos y no puede usarse para crear pasadizos. Las criaturas dentro tienen aire suficiente para 10 minutos, dividido entre ellas.",
    "id": "magic_agujero_portatil"
  },
  {
    "name": "AGUZADOR MENTAL",
    "category": "Anillo",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Este anillo tiene 4 cargas. Cuando falles una tirada de salvación de Constitución para mantener la concentración, puedes emplear una reacción y gastar 1 de las cargas del anillo para superar esa tirada en su lugar. El anillo recupera 1d4 cargas empleadas cada día, al amanecer.",
    "id": "magic_aguzador_mental"
  },
  {
    "name": "ALAS DE VUELO",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Mientras lleves puesta esta capa, puedes emplear una acción de magia para convertirla en un par de alas que se colocan en tu espalda. Las alas durarán 1 hora o hasta que pongas fin al efecto antes de tiempo como acción de magia. Las alas te otorgan una velocidad volando de 60 pies. Si estás en el aire cuando desaparezcan las alas, caerás. Cuando desaparezcan, no podrás usarlas de nuevo durante 1d12 horas.",
    "id": "magic_alas_de_vuelo"
  },
  {
    "name": "ALFOMBRA VOLADORA",
    "category": "Objeto maravilloso",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Puedes utilizar una acción de magia y usar la palabra de activación de esta alfombra para hacer que levite y vuele. Se moverá según las indicaciones que le des si estás a 30 pies o menos de ella. Existen cuatro tamaños de alfombra voladora. Tu GM elige el tamaño de la alfombra o lo determina al azar tirando en la tabla a continuación. La alfombra puede transportar hasta el doble del peso mostrado en la tabla, pero su velocidad volando se reduce a la mitad si transporta un peso superior a su capacidad normal.",
    "tables": [
      {
        "title": "Alfombra voladora",
        "columns": [
          "d100",
          "Tamaño",
          "Capacidad (lb)",
          "Velocidad volando (pies)"
        ],
        "rows": [
          [
            "01–20",
            "3 pies x 5 pies",
            200,
            80
          ],
          [
            "21–55",
            "4 pies x 6 pies",
            400,
            60
          ],
          [
            "56–80",
            "5 pies x 7 pies",
            600,
            40
          ],
          [
            "81–00",
            "6 pies x 9 pies",
            800,
            30
          ]
        ]
      }
    ],
    "id": "magic_alfombra_voladora"
  },
  {
    "name": "AMULETO A PRUEBA DE DETECCIÓN Y LOCALIZACIÓN",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Mientras lleves puesto este amuleto, no podrás ser objetivo de conjuros de adivinación ni ser percibido mediante sensores mágicos de escudriñamiento salvo que lo permitas.",
    "id": "magic_amuleto_a_prueba_de_deteccion_y_localizacion"
  },
  {
    "name": "AMULETO DE SALUD",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Tu Constitución es de 19 mientras llevas este amuleto. No te afecta si tu Constitución es de 19 o más sin él.",
    "id": "magic_amuleto_de_salud"
  },
  {
    "name": "ANILLO DE ALMACENAMIENTO DE CONJUROS",
    "category": "Anillo",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Este anillo almacena los conjuros que se lanzan sobre él y los conserva hasta que el portador sintonizado decida usarlos. El anillo puede guardar conjuros con un valor de hasta 5 niveles. Cuando lo encuentres, contendrá 1d6 − 1 niveles de conjuros almacenados, a elección de tu GM. Cualquier criatura puede lanzar un conjuro de niveles 1 a 5 sobre el anillo si lo toca mientras lanza el conjuro. El único efecto que tendrá el conjuro es que quedará almacenado en el anillo. Si el anillo no puede albergarlo, el conjuro se gastará sin efecto. El nivel del espacio utilizado para lanzar el conjuro determina cuánto espacio utiliza. Mientras lleves puesto este anillo, podrás lanzar cualquiera de los conjuros almacenados. El conjuro utiliza el nivel del espacio, la CD de salvación de conjuros, el bonificador de ataque de conjuros y la aptitud mágica del lanzador original, pero, por lo demás, funciona como si tú lo hubieses lanzado. El conjuro lanzado desde el anillo deja de estar almacenado en él, por lo que deja espacio libre.",
    "id": "magic_anillo_de_almacenamiento_de_conjuros"
  },
  {
    "name": "ANILLO DE CAÍDA DE PLUMA",
    "category": "Anillo",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Si caes mientras llevas puesto este anillo, descenderás 60 pies por asalto y no sufrirás daño por la caída.",
    "id": "magic_anillo_de_caida_de_pluma"
  },
  {
    "name": "ANILLO DE CALIDEZ",
    "category": "Anillo",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Si sufres daño de frío mientras lleves puesto este anillo, ese daño se reduce en 2d8. Además, las temperaturas de 0 °F o menos no os afectarán ni a ti ni a nada de lo que vistas o lleves.",
    "id": "magic_anillo_de_calidez"
  },
  {
    "name": "ANILLO DE CAMINAR SOBRE LAS AGUAS",
    "category": "Anillo",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Mientras lleves puesto este anillo, puedes lanzar caminar sobre el agua desde él eligiéndote como objetivo solo a ti.",
    "id": "magic_anillo_de_caminar_sobre_las_aguas"
  },
  {
    "name": "ANILLO DE COMANDAR ELEMENTALES",
    "category": "Anillo",
    "rarity": "Legendario",
    "attunement": "Sí",
    "description": "Todos los anillos de comandar elementales están vinculados a uno de los cuatro Planos Elementales; tu GM elige a cuál de ellos o lo determina al azar. Por ejemplo, un anillo de comandar elementales (aire) está vinculado al Plano Elemental del Aire.\n\nCada anillo de comandar elementales tiene las dos siguientes propiedades:\n\n• Compulsión elemental. Mientras lo lleves puesto, puedes emplear una acción de magia para intentar doblegar a un elemental que puedas ver a 60 pies o menos de ti. El elemental hace una tirada de salvación de Sabiduría con CD 18. Si la falla, tendrá el estado de hechizado hasta el principio de tu siguiente turno y tú decidirás qué hace con su movimiento y acción en su siguiente turno.\n• Perdición elemental. Mientras lo lleves puesto, tendrás ventaja en las tiradas de ataque contra elementales y ellos tendrán desventaja en las tiradas de ataque contra ti.\n• Concentración elemental. Mientras lleves puesto el anillo, te beneficias de las propiedades adicionales correspondientes al Plano Elemental vinculado al anillo:\n• Agua. Sabes hablar acuano, obtienes una velocidad nadando de 60 pies y puedes respirar bajo el agua.\n• Aire. Sabes hablar aurano, tienes resistencia al daño de relámpago y una velocidad volando igual a tu velocidad y puedes levitar.\n• Fuego. Sabes hablar ígneo y tienes inmunidad al daño de fuego.\n• Tierra. Sabes hablar terrano y tienes resistencia al daño de ácido. El terreno compuesto por escombros, rocas o tierra no cuenta como terreno difícil para ti. Además, puedes moverte a través de tierra sólida o roca como si estas superficies fueran terreno difícil sin alterar la materia que atraviesas. Si acabas tu turno en tierra sólida o roca, irás a parar al espacio sin ocupar más cercano en el que estuviste por última vez.\n• Lanzamiento de conjuros. El anillo tiene 5 cargas y recupera 1d4 + 1 cargas empleadas cada día, al amanecer. Mientras lleves puesto el anillo, puedes lanzar un conjuro desde él. Elige el conjuro de la lista de conjuros disponibles según el Plano Elemental vinculado al anillo, como se muestra en la tabla \"Plano elemental y conjuros (cargas)\". En ella se indica cuántas cargas debes gastar para lanzar el conjuro, que tiene una CD de salvación de 18.",
    "tables": [
      {
        "title": "Plano elemental y conjuros (cargas)",
        "columns": [
          "Plano",
          "Conjuros (cargas)"
        ],
        "rows": [
          [
            "Agua",
            "Caminar sobre el agua (2), crear o destruir agua (1), muro de hielo (3), tormenta de hielo (2), tsunami (5)"
          ],
          [
            "Aire",
            "Caída de pluma (0), muro de viento (1), ráfaga de viento (2), relámpago en cadena (3)"
          ],
          [
            "Fuego",
            "Bola de fuego (2), manos ardientes (1), muro de fuego (3), tormenta de fuego (4)"
          ],
          [
            "Tierra",
            "Moldear la piedra (2), muro de piedra (3), piel pétrea (3), terremoto (5)"
          ]
        ]
      }
    ],
    "id": "magic_anillo_de_comandar_elementales"
  },
  {
    "name": "ANILLO DE ESCUDO MENTAL",
    "category": "Anillo",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Mientras lleves puesto este anillo, serás inmune a la magia que permita a otras criaturas leer tus pensamientos, determinar si mientes, saber tu alineamiento o averiguar tu tipo de criatura. Otras criaturas solo podrán comunicarse telepáticamente contigo si se lo permites. Puedes emplear una acción de magia para que el anillo se vuelva imperceptible hasta que uses otra acción de magia para hacerlo perceptible, hasta que te lo quites o hasta que mueras. Si mueres mientras llevas puesto el anillo, tu alma entrará en él salvo que ya albergue otra alma. Puedes permanecer en el anillo o partir al más allá. Mientras tu alma se encuentre en el anillo, podrás comunicarte telepáticamente con cualquier criatura que lo lleve puesto. Quien lo utilice no podrá evitar esta comunicación telepática.",
    "id": "magic_anillo_de_escudo_mental"
  },
  {
    "name": "ANILLO DE ESTRELLAS FUGACES",
    "category": "Anillo",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Puedes lanzar luces danzantes o luz desde este anillo. El anillo tiene 6 cargas y recupera 1d6 cargas empleadas cada día, al amanecer. Puedes gastar las cargas para usar las propiedades a continuación.\n\n• Esferas de rayos. Como acción de magia, puedes gastar 2 cargas para crear hasta cuatro esferas de rayos con un diámetro de 3 pies. Cada esfera aparece en un espacio sin ocupar que puedas ver a 120 pies o menos de ti. Las esferas permanecerán mientras mantengas la concentración, hasta 1 minuto. Cada una emite luz tenue en un radio de 30 pies. Como acción adicional, puedes mover cada esfera hasta 30 pies, pero no más allá de 120 pies respecto a ti. La primera vez que la esfera se acerque a 5 pies o menos de una criatura distinta de ti que no esté tras cobertura completa, la esfera descargará un relámpago sobre ella y desaparecerá. Esa criatura hará una tirada de salvación de Destreza con CD 15. Si la falla, recibirá daño de relámpago según la cantidad de esferas que hayas creado, como se muestra en la tabla a continuación. Si la supera, recibirá la mitad de daño.\n• Estrellas fugaces. Como acción de magia, puedes gastar entre 1 y 3 cargas. Por cada carga que emplees, lanzarás una mota de luz brillante desde el anillo hacia un punto que puedas ver a 60 pies o menos de ti. A todas las criaturas situadas en un cubo de 15 pies de lado que parta de ese punto les caerá una lluvia de chispas y harán una tirada de salvación de Destreza con CD 15; sufrirán 5d4 de daño radiante si la fallan o la mitad del daño si la superan.\n• Fuego feérico. Puedes gastar 1 carga para lanzar fuego feérico desde el anillo.",
    "tables": [
      {
        "title": "Daño de relámpago (cantidad de esferas)",
        "columns": [
          "Esferas",
          "Daño"
        ],
        "rows": [
          [
            "1",
            "4d12"
          ],
          [
            "2",
            "5d4"
          ],
          [
            "3",
            "2d6"
          ],
          [
            "4",
            "2d4"
          ]
        ]
      }
    ],
    "id": "magic_anillo_de_estrellas_fugaces"
  },
  {
    "name": "ANILLO DE EVASIÓN",
    "category": "Anillo",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Este anillo tiene 3 cargas y recupera 1d3 cargas empleadas cada día, al amanecer. Cuando falles una tirada de salvación de Destreza mientras lo llevas puesto, puedes usar una reacción para gastar 1 carga y superar esa tirada.",
    "id": "magic_anillo_de_evasion"
  },
  {
    "name": "ANILLO DE INFLUENCIA ANIMAL",
    "category": "Anillo",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Este anillo tiene 3 cargas y recupera 1d3 cargas empleadas cada día, al amanecer.\n\nMientras lo lleves puesto, puedes gastar 1 carga para lanzar uno de los siguientes conjuros (CD de salvación 13) desde él:\n\n• Encantar animal\n• Hablar con los animales\n• Terror (solo afecta a bestias)",
    "id": "magic_anillo_de_influencia_animal"
  },
  {
    "name": "ANILLO DE INVISIBILIDAD",
    "category": "Anillo",
    "rarity": "Legendario",
    "attunement": "Sí",
    "description": "Mientras lleves puesto este anillo, puedes utilizar una acción de magia para otorgarte el estado de invisible. Permanecerás invisible hasta que te quites el anillo o hasta que emplees una acción adicional para volverte visible de nuevo.",
    "id": "magic_anillo_de_invisibilidad"
  },
  {
    "name": "ANILLO DE INVOCAR DJINNS",
    "category": "Anillo",
    "rarity": "Legendario",
    "attunement": "Sí",
    "description": "Mientras lleves puesto este anillo, podrás utilizar una acción de magia invocar a un determinado djinn del Plano Elemental del Aire. El djinn aparecerá en un espacio sin ocupar que elijas a 120 pies o menos de ti. Permanecerá mientras mantengas la concentración, hasta un máximo de 1 hora o hasta que sus puntos de golpe se reduzcan a 0. Mientras esté invocado, el djinn será amistoso contigo y tus aliados y obedecerá tus órdenes. Si no le das ninguna, el djinn se defenderá de los atacantes, pero no llevará a cabo ninguna otra acción. Una vez que se haya ido, no se podrá volver a invocarlo durante 24 horas. El anillo se volverá no mágico si el djinn muere. Los anillos de invocar djinns suelen ser obra de los propios djinns que invocan, que los entregan a los mortales como regalos de amistad o muestras de aprecio.",
    "id": "magic_anillo_de_invocar_djinns"
  },
  {
    "name": "ANILLO DE LIBERTAD DE ACCIÓN",
    "category": "Anillo",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Mientras lleves puesto este anillo, el terreno difícil no te costará movimiento adicional. Además, la magia no puede reducir ninguna de tus velocidades ni causar que tengas los estados de apresado o paralizado.",
    "id": "magic_anillo_de_libertad_de_accion"
  },
  {
    "name": "ANILLO DE LOS TRES DESEOS",
    "category": "Anillo",
    "rarity": "Legendario",
    "attunement": "No",
    "description": "Mientras lleves puesto este anillo, puedes gastar 1 de sus 3 cargas para lanzar deseo desde él. El anillo se volverá no mágico cuando utilices la última carga.",
    "id": "magic_anillo_de_los_tres_deseos"
  },
  {
    "name": "ANILLO DE NATACIÓN",
    "category": "Anillo",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Tienes una velocidad nadando de 40 pies mientras lleves puesto este anillo.",
    "id": "magic_anillo_de_natacion"
  },
  {
    "name": "ANILLO DE PROTECCIÓN",
    "category": "Anillo",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Recibes un bonificador de +1 a la clase de armadura y a las tiradas de salvación mientras lleves puesto este anillo.",
    "id": "magic_anillo_de_proteccion"
  },
  {
    "name": "ANILLO DE RECARGA DE CONJUROS",
    "category": "Anillo",
    "rarity": "Infrecuente",
    "attunement": "Sí (requiere sintonización con un lanzador de conjuros)",
    "description": "Mientras lleves puesto este anillo, puedes recuperar un espacio de conjuro gastado como acción adicional. El espacio recuperado puede ser de nivel 3 o inferior. Una vez usado, el anillo no puede volver a utilizarse hasta el siguiente amanecer.",
    "id": "magic_anillo_de_recarga_de_conjuros"
  },
  {
    "name": "ANILLO DE REGENERACIÓN",
    "category": "Anillo",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Mientras lleves puesto este anillo, recuperarás 1d6 puntos de golpe cada 10 minutos si tienes al menos 1 punto de golpe. Si pierdes una parte del cuerpo, el anillo hace que te vuelva a crecer y recupere su funcionalidad completa tras 1d6 + 1 días si te mantienes con al menos 1 punto de golpe durante todo ese tiempo.",
    "id": "magic_anillo_de_regeneracion"
  },
  {
    "name": "ANILLO DE RESISTENCIA",
    "category": "Anillo",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Mientras lleves puesto este anillo, tendrás resistencia a un tipo de daño. La piedra preciosa engastada indica el tipo, que tu GM elige o determina al azar tirando en la siguiente tabla.",
    "tables": [
      {
        "title": "Anillo de resistencia",
        "columns": [
          "1d10",
          "Tipo de daño",
          "Piedra preciosa"
        ],
        "rows": [
          [
            "1",
            "Ácido",
            "Perla"
          ],
          [
            "2",
            "Frío",
            "Turmalina"
          ],
          [
            "3",
            "Fuego",
            "Granate"
          ],
          [
            "4",
            "Fuerza",
            "Zafiro"
          ],
          [
            "5",
            "Necrótico",
            "Azabache"
          ],
          [
            "6",
            "Psíquico",
            "Jade"
          ],
          [
            "7",
            "Radiante",
            "Topacio"
          ],
          [
            "8",
            "Relámpago",
            "Citrino"
          ],
          [
            "9",
            "Trueno",
            "Espinela"
          ],
          [
            "10",
            "Veneno",
            "Amatista"
          ]
        ]
      }
    ],
    "id": "magic_anillo_de_resistencia"
  },
  {
    "name": "ANILLO DE RETORNO DE CONJUROS",
    "category": "Anillo",
    "rarity": "Legendario",
    "attunement": "Sí",
    "description": "Mientras lleves puesto este anillo, tienes ventaja en las tiradas de salvación contra conjuros. Si superas la tirada de un conjuro de nivel 7 o inferior, dicho conjuro no tendrá ningún efecto sobre ti. Si el conjuro solo te hacía objetivo a ti y no creó un área de efecto, puedes emplear una reacción para devolverle el conjuro al lanzador, que deberá hacer una tirada de salvación contra él usando su propia CD de salvación de conjuros.",
    "id": "magic_anillo_de_retorno_de_conjuros"
  },
  {
    "name": "ANILLO DE ROBLE",
    "category": "Anillo",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Este anillo de madera endurecida presenta vetas antiguas y un leve brillo verdoso. Mientras lleves puesto este anillo, cuando restaures puntos de golpe a una criatura mediante magia, esa criatura recupera puntos de golpe adicionales iguales a tu bonificador por competencia.",
    "id": "magic_anillo_de_roble"
  },
  {
    "name": "ANILLO DE SALTO",
    "category": "Anillo",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Mientras lleves puesto este anillo, puedes lanzar salto desde él, pero solo puedes hacerte objetivo a ti.",
    "id": "magic_anillo_de_salto"
  },
  {
    "name": "ANILLO DE TELEQUINESIS",
    "category": "Anillo",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Mientras lleves puesto este anillo, puedes lanzar telequinesis desde él.",
    "id": "magic_anillo_de_telequinesis"
  },
  {
    "name": "ANILLO DE VISIÓN DE RAYOS X",
    "category": "Anillo",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Mientras lleves puesto este anillo, puedes emplear una acción de magia para obtener visión de rayos X hasta 30 pies durante 1 minuto. Para ti, los objetos sólidos que haya dentro de ese radio se verán transparentes y no impedirán el paso de la luz. La visión puede atravesar 12 pulgadas de piedra, 1 pulgada de cualquier metal común o hasta 3 pies de madera o tierra. Una sustancia más gruesa o una lámina fina de plomo bloquearán la visión. Cada vez que vuelvas a usar el anillo antes de hacer un descanso largo, deberás superar una tirada de salvación de Constitución con CD 15 o sumarás 1 nivel de cansancio.",
    "id": "magic_anillo_de_vision_de_rayos_x"
  },
  {
    "name": "ANILLO DEL CARNERO",
    "category": "Anillo",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Este anillo tiene 3 cargas y recupera 1d3 cargas empleadas cada día, al amanecer. Mientras lo lleves puesto, puedes emplear una acción de magia para gastar entre 1 y 3 cargas y hacer un ataque de conjuro a distancia contra una criatura que puedas ver a 60 pies o menos de ti. El anillo producirá una cabeza de carnero espectral y hará su tirada de ataque con un bonificador de +7. Si acierta, por cada carga empleada, el objetivo sufrirá 2d10 de daño de fuerza y será empujado 5 pies respecto a ti. De forma alternativa, puedes gastar entre 1 y 3 de las cargas del anillo como acción de magia para tratar de romper un objeto no mágico que puedas ver a 60 pies o menos de ti que no lleve ni vista alguien. El anillo realizará una prueba de Fuerza con un bonificador de +5 por cada carga que emplees.",
    "id": "magic_anillo_del_carnero"
  },
  {
    "name": "ANTEOJOS DE ENCANTAMIENTO",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Estas lentes de cristal cubren los ojos y tienen 3 cargas. Mientras las lleves puestas, puedes gastar 1 o más cargas para lanzar hechizar persona (CD de salvación 13). Si empleas 1 carga, podrás lanzar la versión de nivel 1 del conjuro. Aumentarás el nivel del conjuro en 1 por cada carga adicional que emplees. Las lentes recuperan todas las cargas empleadas cada día, al amanecer.",
    "id": "magic_anteojos_de_encantamiento"
  },
  {
    "name": "ANTEOJOS DE LA NOCHE",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Mientras lleves estas lentes oscuras, tienes visión en la oscuridad hasta 60 pies. Si ya posees visión en la oscuridad, estos anteojos aumentan su alcance en 60 pies.",
    "id": "magic_anteojos_de_la_noche"
  },
  {
    "name": "ANTEOJOS DE VISIÓN MINUCIOSA",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Estas lentes de cristal cubren los ojos. Mientras las lleves puestas, podrás ver mucho mejor de lo normal hasta una distancia de 12 pulgadas: tendrás visión en la oscuridad hasta esa distancia y ventaja en las pruebas de Inteligencia (Investigación) para examinar algo a esa distancia o menos.",
    "id": "magic_anteojos_de_vision_minuciosa"
  },
  {
    "name": "ANTEOJOS DE VISTA DE ÁGUILA",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Estas lentes de cristal cubren los ojos. Mientras las lleves puestas, tendrás ventaja en las pruebas de Sabiduría (Percepción) que dependan de la vista. En condiciones de buena visibilidad, podrás ver detalles de criaturas y objetos muy lejanos de incluso 2 pies de diámetro.",
    "id": "magic_anteojos_de_vista_de_aguila"
  },
  {
    "name": "ARCO DE ENERGÍA",
    "category": "Arma",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Recibes un bonificador de +1 a las tiradas de ataque y de daño que hagas con esta arma mágica, que no tiene cuerda. Cada vez que armes el brazo para disparar, aparecerá una flecha mágica de energía dorada, encocada y lista para disparar. Al impactar, las flechas de esta arma causan daño de fuerza en lugar de daño perforante, y desaparecerán cuando acierten o fallen a su objetivo. Hasta que desaparezcan, las flechas emiten luz brillante en un radio de 20 pies y luz tenue 20 pies más allá.\n\nEl arma tiene las siguientes propiedades adicionales:\n\n• Escalera de energía. Como acción de magia, puedes disparar una ráfaga de flechas de energía desde esta arma hacia un muro a 60 pies o menos de ti. Las flechas se convierten en peldaños brillantes que sobresalen del muro y forman una escalera mágica de hasta 60 pies en él. La escalera durará 1 minuto y luego desaparecerá.\n• Flecha apresadora. Cuando uses esta arma para hacer un ataque a distancia contra una criatura, puedes intentar apresarla en lugar de infligirle daño. Si la flecha acierta, el objetivo deberá superar una tirada de salvación de Fuerza con CD 15 o tendrá el estado de apresada durante 1 minuto. Como acción, una criatura apresada por una flecha puede hacer una prueba de Fuerza (Atletismo) con CD 20 para intentar liberarse. Si tiene éxito, se librará del efecto.\n• Flecha transportadora. Como acción de magia, puedes disparar una flecha de energía desde esta arma hacia un objetivo que puedas ver a 60 pies o menos de ti. El objetivo puede ser una criatura voluntaria Mediana o más pequeña o un objeto que nadie vista o lleve, siempre y cuando sea lo bastante pequeño como para caber en un cubo de 5 pies de lado. La flecha teletransporta al objetivo a un espacio sin ocupar que puedas ver a 10 pies o menos de ti.",
    "subcategory": "Arma (arco corto o largo)",
    "id": "magic_arco_de_energia"
  },
  {
    "name": "ARCO JURAMENTADO",
    "category": "Arma",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Cuando coloques una flecha en este arco, susurrará en élfico: \"Pronta derrota para mis enemigos\". Siempre que uses esta arma para hacer un ataque a distancia, puedes decir o señar las palabras de activación \"pronta muerte a aquellos que me han perjudicado\". El objetivo de tu ataque se convertirá en tu enemigo jurado hasta que muera o hasta que amanezca 7 días después. Solo puedes tener un enemigo jurado a la vez. Cuando muera, podrás elegir otro después del siguiente amanecer. Cuando realices una tirada de ataque a distancia con esta arma contra tu enemigo jurado, tendrás ventaja. Asimismo, tu objetivo no obtendrá ningún beneficio de cobertura media o tres cuartos y tú no tendrás desventaja debido al alcance largo. Si el ataque acierta, tu enemigo jurado sufrirá 3d6 de daño perforante adicional. Mientras tu enemigo jurado esté vivo, tendrás desventaja en las tiradas de ataque con el resto de armas.",
    "subcategory": "Arma (arco corto o largo)",
    "id": "magic_arco_juramentado"
  },
  {
    "name": "ARMA +1",
    "category": "Arma",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Tienes un bonificador a las tiradas de ataque y de daño que hagas con esta arma mágica. El bonificador depende de la rareza del arma.",
    "subcategory": "Arma (cualquiera sencilla o marcial)",
    "id": "magic_arma_1"
  },
  {
    "name": "ARMA +2",
    "category": "Arma",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Tienes un bonificador a las tiradas de ataque y de daño que hagas con esta arma mágica. El bonificador depende de la rareza del arma.",
    "subcategory": "Arma (cualquiera sencilla o marcial)",
    "id": "magic_arma_2"
  },
  {
    "name": "ARMA +3",
    "category": "Arma",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Tienes un bonificador a las tiradas de ataque y de daño que hagas con esta arma mágica. El bonificador depende de la rareza del arma.",
    "subcategory": "Arma (cualquiera sencilla o marcial)",
    "id": "magic_arma_3"
  },
  {
    "name": "ARMA ADAMANTINA",
    "category": "Arma",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Esta arma o munición está hecha de adamantina, una de las sustancias más duras que existen. Cuando esta arma o munición acierte a un objeto, el golpe es un Crítico.",
    "subcategory": "Arma (cualquiera sencilla o marcial)",
    "id": "magic_arma_adamantina"
  },
  {
    "name": "ARMA DE ADVERTENCIA",
    "category": "Arma",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Mientras esta arma esté dentro de tu alcance y tengas sintonización con ella, tú y tus aliados a 30 pies o menos de ti obtenéis los siguientes beneficios:\n\n• Alarma. El arma despierta mágicamente a cada sujeto que esté durmiendo de forma normal cuando comience un combate. Este beneficio no despierta a los sujetos que duerman a causa de un sueño inducido mediante magia.\n• Preparación sobrenatural. Todos los sujetos tienen ventaja en sus tiradas de iniciativa.",
    "subcategory": "Arma (cualquiera sencilla o marcial)",
    "id": "magic_arma_de_advertencia"
  },
  {
    "name": "ARMA DE DISPARO REPETIDOR",
    "category": "Arma",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Esta arma mágica otorga un bonificador de +1 a las tiradas de ataque y de daño que hagas con ella cuando se use para realizar un ataque a distancia, e ignora la propiedad recarga si la tiene.\n\nSi el arma no tiene munición, produce la suya propia: crea automáticamente una unidad de munición mágica cuando quien la empuña realiza una tirada de ataque a distancia con ella. La munición creada por el arma desaparece inmediatamente después de acertar o fallar a un objetivo.",
    "subcategory": "Arma (cualquiera sencilla o marcial con la propiedad munición)",
    "id": "magic_disparo_repetidor"
  },
  {
    "name": "ARMA DE PLATA",
    "category": "Arma",
    "rarity": "Común",
    "attunement": "No",
    "description": "Un proceso alquímico ha unido plata a esta arma mágica. Cuando causes un golpe crítico con ella contra una criatura que ha cambiado de forma, el arma inflige un dado adicional de daño.",
    "subcategory": "Arma (cualquiera sencilla o marcial)",
    "id": "magic_arma_de_plata"
  },
  {
    "name": "ARMA DESLUMBRANTE",
    "category": "Arma",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Esta arma mágica otorga un bonificador de +1 a las tiradas de ataque y de daño que hagas con ella. Mientras la sostengas, puedes emplear una acción adicional para hacer que emita luz brillante en un radio de 30 pies y luz tenue 30 pies más allá. Puedes extinguir la luz como acción adicional.\n\nEl arma tiene 4 cargas. Puedes emplear una reacción inmediatamente después de que una tirada de ataque te acierte para gastar 1 de las cargas del arma y obligar al atacante a realizar una tirada de salvación de Constitución con CD 15. Si la falla, el atacante tendrá el estado de cegado hasta el final de su siguiente turno. El arma recupera 1d4 cargas empleadas cada día, al amanecer.",
    "subcategory": "Arma (cualquiera sencilla o marcial)",
    "id": "magic_arma_deslumbrante"
  },
  {
    "name": "ARMA FEROZ",
    "category": "Arma",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Esta arma mágica causa 2d6 de daño adicional a cualquier criatura a la que acierte. El daño adicional será del mismo tipo que el daño normal del arma.",
    "subcategory": "Arma (cualquiera sencilla o marcial)",
    "id": "magic_arma_feroz"
  },
  {
    "name": "ARMA RETORNANTE",
    "category": "Arma",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Esta arma mágica otorga un bonificador de +1 a las tiradas de ataque y de daño que hagas con ella, y regresa a tu mano inmediatamente después de que la uses para realizar una tirada de ataque a distancia.",
    "subcategory": "Arma (cualquiera sencilla o marcial con la propiedad arrojadiza)",
    "id": "magic_arma_retornante"
  },
  {
    "name": "ARMADURA +1",
    "category": "Armadura",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Obtienes un bonificador a la clase de armadura mientras lleves esta armadura. El bonificador depende de su rareza.",
    "subcategory": "Armadura (ligera, media o pesada)",
    "id": "magic_armadura_1"
  },
  {
    "name": "ARMADURA +2",
    "category": "Armadura",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Obtienes un bonificador a la clase de armadura mientras lleves esta armadura. El bonificador depende de su rareza.",
    "subcategory": "Armadura (ligera, media o pesada)",
    "id": "magic_armadura_2"
  },
  {
    "name": "ARMADURA +3",
    "category": "Armadura",
    "rarity": "Legendario",
    "attunement": "No",
    "description": "Obtienes un bonificador a la clase de armadura mientras lleves esta armadura. El bonificador depende de su rareza.",
    "subcategory": "Armadura (ligera, media o pesada)",
    "id": "magic_armadura_3"
  },
  {
    "name": "ARMADURA ADAMANTINA",
    "category": "Armadura",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Esta armadura viene reforzada con adamantina, una de las sustancias más duras que existen. Mientras la lleves puesta, cualquier crítico contra ti se convierte en un impacto normal.",
    "subcategory": "Cualquiera (armadura)",
    "id": "magic_armadura_adamantina"
  },
  {
    "name": "ARMADURA DE INVULNERABILIDAD",
    "category": "Armadura",
    "rarity": "Legendario",
    "attunement": "Sí",
    "description": "Tienes resistencia al daño contundente, cortante y perforante mientras lleves esta armadura.\n\n• Armazón de metal. Puedes emplear una acción de magia para concederte inmunidad al daño contundente, cortante y perforante durante 10 minutos o hasta que dejes de llevar esta armadura. Una vez utilizada, esta propiedad no puede volver a usarse hasta el siguiente amanecer.",
    "subcategory": "Armadura (armadura de placas)",
    "id": "magic_armadura_de_invulnerabilidad"
  },
  {
    "name": "ARMADURA DE MITHRAL",
    "category": "Armadura",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "El mithral es un metal flexible y ligero. Una armadura hecha de esta sustancia puede ponerse bajo ropajes normales. Si la armadura normalmente causa desventaja en pruebas de Destreza (Sigilo) o tiene un requisito de Fuerza, la versión de mithral no lo hace.",
    "subcategory": "Cualquiera (armadura)",
    "id": "magic_armadura_de_mithral"
  },
  {
    "name": "ARMADURA DE PLACAS DE ETEREIDAD",
    "category": "Armadura",
    "rarity": "Legendario",
    "attunement": "Sí",
    "description": "Mientras lleves esta armadura, puedes emplear una acción de magia y usar una palabra de activación para obtener los efectos del conjuro excursión etérea. El conjuro termina inmediatamente si te quitas la armadura o si empleas una acción de magia para repetir la palabra de activación. Esta propiedad de la armadura no puede volver a usarse hasta el siguiente amanecer.",
    "subcategory": "Armadura de placas",
    "id": "magic_armadura_de_placas_de_etereidad"
  },
  {
    "name": "ARMADURA DE PLACAS ENANA",
    "category": "Armadura",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Mientras lleves esta armadura, obtendrás un bonificador de +2 a la clase de armadura. Además, si cualquier efecto te desplaza por el suelo contra tu voluntad, puedes usar una reacción para reducir hasta 10 pies la distancia en que te mueves.",
    "subcategory": "Pesada (armadura de placas)",
    "id": "magic_armadura_de_placas_enana"
  },
  {
    "name": "ARMADURA DE RESISTENCIA",
    "category": "Armadura",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Tienes resistencia a un tipo de daño mientras lleves esta armadura. Tu GM elige el tipo o lo determina al azar tirando en la tabla a continuación.",
    "subcategory": "Armadura (ligera, media o pesada)",
    "tables": [
      {
        "title": "Tipo de daño",
        "columns": [
          "1d10",
          "Tipo de daño"
        ],
        "rows": [
          [
            "1",
            "Ácido"
          ],
          [
            "2",
            "Frío"
          ],
          [
            "3",
            "Fuego"
          ],
          [
            "4",
            "Fuerza"
          ],
          [
            "5",
            "Necrótico"
          ],
          [
            "6",
            "Psíquico"
          ],
          [
            "7",
            "Radiante"
          ],
          [
            "8",
            "Relámpago"
          ],
          [
            "9",
            "Trueno"
          ],
          [
            "10",
            "Veneno"
          ]
        ]
      }
    ],
    "id": "magic_armadura_de_resistencia"
  },
  {
    "name": "ARMADURA DE VULNERABILIDAD",
    "category": "Armadura",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Mientras lleves esta armadura, tienes resistencia a un tipo de daño de entre los siguientes: contundente, cortante o perforante. Tu GM elige el tipo o lo determina al azar.",
    "subcategory": "Armadura (ligera, media o pesada)",
    "maldicion": "Esta armadura está maldita, circunstancia que solo se revela cuando se lanza el conjuro identificar sobre ella o te sintonizas con ella.\n\nAl sintonizarte con la armadura, sufres la maldición hasta que seas el objetivo del conjuro levantar maldición u otro efecto mágico similar.\n\nQuitarse la armadura no pone fin a la maldición.\n\nMientras sufras la maldición, serás vulnerable a los otros dos tipos de daño de entre contundente, cortante y perforante (salvo al tipo al que tienes resistencia gracias a la armadura).",
    "id": "magic_armadura_de_vulnerabilidad"
  },
  {
    "name": "ARMADURA DEMONÍACA",
    "category": "Armadura",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Mientras lleves esta armadura, obtendrás un bonificador de +1 a la clase de armadura y conocerás el idioma abisal. Además, los guanteletes con garras de la armadura permiten que tus ataques sin armas causen 1d8 de daño cortante en lugar del daño contundente habitual, y obtienes un bonificador de +1 a las tiradas de ataque y de daño de tus ataques sin armas.",
    "subcategory": "Armadura (ligera, media o pesada)",
    "maldicion": "Una vez que te pones esta armadura, no puedes quitártela hasta que seas el objetivo de un conjuro levantar maldición u otro efecto mágico similar.\n\nMientras la lleves puesta, tendrás desventaja en las tiradas de ataque contra demonios y en las tiradas de salvación contra sus conjuros y capacidades especiales.",
    "id": "magic_armadura_demoniaca"
  },
  {
    "name": "BABUCHAS DE TREPAR CUAL ARÁCNIDO",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Mientras lleves puesto este calzado ligero, podrás moverte hacia arriba, hacia abajo y de lado por superficies verticales, así como por techos. Esta manera de moverse no requiere del uso de las manos, que quedan libres. Tienes una velocidad trepando igual a tu velocidad. No obstante, las babuchas no te permiten desplazarte de esta forma por una superficie resbaladiza, como una zona cubierta por hielo o aceite.",
    "id": "magic_babuchas_de_trepar_cual_aracnido"
  },
  {
    "name": "BANDAS DE HIERRO",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Esta esfera de hierro oxidada mide 3 pulgadas de diámetro y pesa 1 lb. Puedes emplear una acción de magia para lanzarla contra una criatura Enorme o más pequeña que puedas ver a 60 pies o menos de ti. En el recorrido del lanzamiento, la esfera se abre en una maraña de bandas de metal. Realiza una tirada de ataque a distancia con un bonificador de ataque igual a tu modificador por Destreza más tu bonificador por competencia. Si acierta, el objetivo tiene el estado de apresado hasta que utilices una acción adicional para dar una orden y liberarlo. Si haces esto o si el ataque yerra, las bandas se contraerán y volverán a convertirse en una esfera. Cualquier criatura que toque las bandas, incluida la que está apresada, puede emplear una acción para realizar una prueba de Fuerza (Atletismo) con CD 20 para romper las bandas de hierro. Si la supera, el objeto se destruye y la criatura apresada se libera. Si la falla, cualquier otro intento de romper las bandas por parte de la criatura fallará automáticamente hasta que hayan transcurrido 24 horas. Una vez que se utilizan las bandas, no podrán volver a usarse hasta el siguiente amanecer.",
    "peso": 1,
    "id": "magic_bandas_de_hierro"
  },
  {
    "name": "BANDAS DE HIERRO DE BILARRO",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Esta esfera de hierro oxidada mide 3 pulgadas de diámetro y pesa 2 lb. Puedes emplear una acción de magia para lanzarla contra una criatura Enorme o más pequeña que puedas ver a 60 pies o menos de ti. En el recorrido del lanzamiento, la esfera se abre en una maraña de bandas de metal. Realiza una tirada de ataque a distancia con un bonificador de ataque igual a tu modificador por Destreza más tu bonificador por competencia. Si acierta, el objetivo tiene el estado de apresado hasta que utilices una acción adicional para dar una orden y liberarlo. Si haces esto o si el ataque yerra, las bandas se contraerán y volverán a convertirse en una esfera. Cualquier criatura que toque las bandas, incluida la que está apresada, puede emplear una acción para realizar una prueba de Fuerza (Atletismo) con CD 20 para romper las bandas de hierro. Si la supera, el objeto se destruye y la criatura apresada se libera. Si la falla, cualquier otro intento de romper las bandas por parte de la criatura fallará automáticamente hasta que hayan transcurrido 24 horas. Una vez que se utilizan las bandas, no podrán volver a usarse hasta el siguiente amanecer.",
    "peso": 2,
    "id": "magic_bandas_de_hierro_de_bilarro"
  },
  {
    "name": "BARAJA DE ILUSIONES",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Esta caja contiene una baraja de cartas. Una baraja completa tiene 34 cartas: 32 de ellas muestran criaturas concretas y las otras 2 tienen una superficie espejada. A una baraja encontrada como tesoro le suelen faltar 1d20 − 1 cartas. La magia de la baraja solo funciona si las cartas se roban al azar. Puedes utilizar una acción de magia para robar una carta al azar de la baraja y tirarla al suelo, a un punto que esté a 30 pies o menos de ti. Una ilusión de una criatura, que se determina tirando en la tabla “Baraja de ilusiones”, se formará sobre la carta y permanecerá hasta que se disipe. La criatura ilusoria que crea la carta se parece a una criatura real de su tipo y se comporta como tal, excepto porque no puede hacer daño. Mientras estés a 120 pies o menos de una criatura ilusoria y puedas verla, podrás emplear una acción de magia para moverla a cualquier lugar situado a 30 pies o menos de la carta. Cualquier interacción física con la criatura ilusoria revelará que es falsa, ya que los objetos la atravesarán. Si una criatura emplea una acción de estudiar para inspeccionarla, identificará que es una ilusión si supera una prueba de Inteligencia (Investigación) con CD 15. La ilusión durará hasta que se disipe (mediante un conjuro disipar magia o un efecto similar) o hasta que alguien mueva la carta. Cuando la ilusión concluya, la imagen de la carta desaparecerá y esa carta no se podrá volver a usar.",
    "tables": [
      {
        "title": "Baraja de ilusiones",
        "columns": [
          "d100",
          "Ilusión creada"
        ],
        "rows": [
          [
            "01–03",
            "Archimago"
          ],
          [
            "04–06",
            "Asesino"
          ],
          [
            "07–09",
            "Basilisco"
          ],
          [
            "10–12",
            "Berserker"
          ],
          [
            "13–15",
            "Caballero"
          ],
          [
            "16–18",
            "Capitán bandido"
          ],
          [
            "19–21",
            "Dragón rojo adulto"
          ],
          [
            "22–24",
            "Druida"
          ],
          [
            "25–27",
            "Erinia"
          ],
          [
            "28–30",
            "Ettin"
          ],
          [
            "31–33",
            "Gigante de escarcha"
          ],
          [
            "34–36",
            "Gigante de fuego"
          ],
          [
            "37–39",
            "Gigante de las colinas"
          ],
          [
            "40–42",
            "Gigante de las nubes"
          ],
          [
            "43–45",
            "Gólem de hierro"
          ],
          [
            "46–48",
            "Guerrero gnoll"
          ],
          [
            "49–51",
            "Guerrero goblin"
          ],
          [
            "52–54",
            "Guerrero hobgoblin"
          ],
          [
            "55–57",
            "Guerrero kobold"
          ],
          [
            "58–60",
            "Guerrero osgo"
          ],
          [
            "61–63",
            "Guerrero veterano"
          ],
          [
            "64–66",
            "Guiverno"
          ],
          [
            "67–69",
            "Íncubo"
          ],
          [
            "70–72",
            "Liche"
          ],
          [
            "73–75",
            "Medusa"
          ],
          [
            "76–78",
            "Naga guardiana"
          ],
          [
            "79–81",
            "Ogro"
          ],
          [
            "82–84",
            "Oni"
          ],
          [
            "85–87",
            "Sacerdote"
          ],
          [
            "88–90",
            "Saga de la noche"
          ],
          [
            "91–93",
            "Súcubo"
          ],
          [
            "94–96",
            "Troll"
          ],
          [
            "97–00",
            "El dueño de la baraja"
          ]
        ],
        "notes": "Los perfiles de las criaturas (salvo el dueño de la baraja) aparecen en el Manual de los Monstruos."
      }
    ],
    "id": "magic_baraja_de_ilusiones"
  },
  {
    "name": "BARAJA DE MÚLTIPLES COSAS",
    "category": "Objeto maravilloso",
    "rarity": "Legendario",
    "attunement": "No",
    "description": "Esta baraja, que normalmente se encuentra dentro de una caja o bolsa, contiene cartas hechas de marfil o vitela. La mayoría (el 75 %) de estas barajas tienen trece cartas, aunque algunas tienen veintidós. Utiliza la columna correspondiente de la tabla “Baraja misteriosa” para determinar al azar las cartas que se roban de la baraja. Antes de robar una carta, debes declarar cuántas pretendes robar y, a continuación, robarlas al azar. Cualquier carta robada por encima de la cantidad declarada no tiene efecto. Por lo demás, en cuanto robes una carta de la baraja, su magia producirá el efecto que corresponda. Debes robar cada carta antes de que pase 1 hora desde el robo anterior. Si no robas la cantidad de cartas declaradas, las cartas restantes saldrán volando de la baraja por su cuenta y tendrán efecto a la vez. Cuando robas una carta, desaparece. A menos que sea el Loco o el Bufón, la carta volverá a la baraja, por lo que será posible robarla dos veces (cuando el Loco o el Bufón hayan dejado la baraja, tira de nuevo en la tabla si vuelve a salir una de ellas). Los efectos de cada carta se describen a continuación.\n\n• Bufón. Tienes ventaja en las pruebas con d20 durante las próximas 72 horas, o puedes robar dos cartas más de las que declaraste.\n• Caballero. Consigues los servicios de un caballero, que aparece mágicamente en un espacio sin ocupar de tu elección a 30 pies o menos de ti. El caballero tiene tu mismo alineamiento y te servirá con lealtad hasta la muerte, creyendo que el destino le ha llevado hasta ti. Habla con tu GM para darle un nombre y un trasfondo a este PNJ. Tu GM puede emplear un perfil distinto para el caballero, según considere.\n• Calabozo. Desapareces y quedas sepultado en un estado de animación suspendida en una esfera extradimensional. Todo lo que llevaras y vistieras desaparece contigo salvo los artefactos, que se quedan en el espacio que ocupabas cuando desapareciste. Permanecerás encarcelado hasta que te encuentren y te saquen de la esfera. No se te puede localizar mediante magia de adivinación, pero sí mediante un conjuro deseo. No robas más cartas.\n• Calavera. Un avatar de la muerte aparece en un espacio sin ocupar lo más cerca posible de ti. El avatar se muestra como un esqueleto fantasmal vestido con una raída túnica negra, porta una guadaña espectral y solo te atacará a ti. El avatar desaparecerá cuando sus puntos de golpe se reduzcan a 0 o cuando mueras. Si uno de tus aliados intenta hacerle daño, ese aliado invocará otro avatar de la muerte. El nuevo avatar aparecerá en un espacio sin ocupar lo más cerca posible de ese aliado y solo le atacará a él. Tus aliados y tú solo podéis invocar un avatar cada uno como consecuencia de este robo. Cualquier criatura que sucumba ante un avatar no puede revivir.\n• Canalla. Un PNJ a elección de tu GM se vuelve hostil hacia ti. No conoces la identidad de este personaje hasta que el PNJ u otra persona la revelen. Salvo un conjuro deseo o la intercesión divina, nada puede hacer que esta hostilidad cese.\n• Cometa. La próxima vez que entables combate contra una o más criaturas hostiles, puedes elegir a una como tu adversario cuando tires iniciativa. Si reduces a 0 los puntos de golpe de tu adversario durante el combate, tendrás ventaja en las tiradas de salvación contra muerte durante 1 año. Si alguien reduce a 0 los puntos de golpe de tu adversario elegido o si no eliges uno, esta carta no tendrá ningún efecto.\n• E. Vacío. Tu alma se extrae de tu cuerpo y va a parar al interior de un objeto situado en un lugar a elección de tu GM. Uno o más seres poderosos custodian ese sitio. Mientras tu alma esté atrapada de esta manera, tu cuerpo permanece inerte, deja de envejecer y no necesita comida, agua ni aire. Un conjuro deseo no puede devolver tu alma a tu cuerpo, pero revelará el paradero del objeto que la alberga. No robas más cartas.\n• Equilibrio. Puedes aumentar una de tus puntuaciones de característica en 2 hasta un máximo de 22, siempre y cuando reduzcas otra puntuación de característica en 2. No puedes reducir una característica con una puntuación de 5 o menos. Como alternativa, puedes decidir no ajustar tus puntuaciones de característica. En ese caso, esta carta no tendrá ningún efecto.\n• Erudito. En cualquier momento que quieras hasta un año después de robar esta carta, podrás hacer una pregunta mientras meditas y recibirás mentalmente una respuesta veraz a dicha cuestión.\n• Estrella. Aumenta en 2 una de tus puntuaciones de característica, hasta un máximo de 24.\n• Euríale. La cara de medusa de la carta te lanza una maldición. Recibes un penalizador de −2 a las tiradas de salvación mientras estés bajo su influjo. Solo un dios o la magia de la carta de los Hados pueden acabar con esta maldición.\n• Garras. Todos los objetos mágicos que vistas o lleves contigo se desintegran. Los artefactos que poseas se desvanecerán.\n• Gema. Aparecen a tus pies veinticinco joyas con un valor de 2000 po cada una o cincuenta gemas con un valor de 1000 po cada una.\n• Hados. El tejido del universo se desteje y se teje de nuevo, lo que te permite evitar o borrar un suceso, como si nunca hubiera ocurrido. Puedes usar esta magia tan pronto como robes la carta o en cualquier momento antes de morir.\n• Llamas. Un poderoso diablo se convierte en tu enemigo. Buscará tu ruina y te atormentará, además de regodearse con tu sufrimiento antes de intentar matarte. Esta enemistad dura hasta que el diablo o tú muráis.\n• Llave. Aparece en tus manos un arma mágica rara o de mayor rareza con la que eres competente. Tu GM elige el arma.\n• Loco. Tienes desventaja en las pruebas con d20 durante las próximas 72 horas. Roba otra carta, que no contará como uno de los robos declarados.\n• Luna. Obtienes la capacidad de lanzar el conjuro deseo 1d3 veces.\n• Rompecabezas. Tu Inteligencia o Sabiduría se reducen permanentemente en 1d4 + 1 (hasta un mínimo de 1). Puedes robar una carta más de las que declaraste.\n• Ruina. Pierdes todas las riquezas que lleves o poseas, excepto los objetos mágicos. Las propiedades que puedas llevar encima desaparecen. Pierdes todos los negocios, edificios y tierras que poseas de la manera que menos altere la realidad. Cualquier documento que pruebe que deberías poseer las riquezas perdidas por esta carta también desaparece.\n• Sol. Un objeto mágico (a elección de tu GM) aparece en tus manos. Además, hasta que mueras, obtienes 10 puntos de golpe temporales cada día, al amanecer.\n• Trono. Obtienes competencia y pericia en Historia, Intimidación, Perspicacia o Persuasión, a tu elección. Además, obtienes de pleno derecho la propiedad de una pequeña fortaleza en alguna parte del mundo. Sin embargo, la fortaleza es hogar de uno o más monstruos, que deberás expulsar antes de reclamarla como tuya.",
    "tables": [
      {
        "title": "Baraja de múltiples cosas",
        "columns": [
          "d100 (13 cartas)",
          "d100 (22 cartas)",
          "Carta"
        ],
        "rows": [
          [
            "01–08",
            "01–05",
            "Bufón"
          ],
          [
            "09–16",
            "06–10",
            "Caballero —"
          ],
          [
            "11–14",
            "Calabozo",
            "17–24"
          ],
          [
            "15–18",
            "Calavera",
            "25–32"
          ],
          [
            "19–22",
            "Canalla —",
            "23–27"
          ],
          [
            "Cometa",
            "33–36",
            "28–31"
          ],
          [
            "El Vacío —",
            "32–36",
            "Equilibrio —"
          ],
          [
            "37–41",
            "Erudito",
            "37–44"
          ],
          [
            "42–46",
            "Estrella",
            "45–52"
          ],
          [
            "47–50",
            "Euríale —",
            "51–54"
          ],
          [
            "Garras —",
            "55–59",
            "Gema —"
          ],
          [
            "60–64",
            "Hados",
            "53–60"
          ],
          [
            "65–68",
            "Llamas",
            "61–68"
          ],
          [
            "69–73",
            "Llave —",
            "74–77"
          ],
          [
            "Loco",
            "69–76",
            "78–82"
          ],
          [
            "Luna —",
            "83–86",
            "Rompecabezas"
          ],
          [
            "77–84",
            "87–90",
            "Ruina"
          ],
          [
            "85–92",
            "91–95",
            "Sol"
          ],
          [
            "93–00",
            "96–00",
            "Trono"
          ]
        ]
      }
    ],
    "id": "magic_baraja_de_multiples_cosas"
  },
  {
    "name": "BASTÓN DE ACRÓBATA",
    "category": "Arma",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Tienes un bonificador de +2 a las tiradas de ataque y de daño que hagas con esta arma mágica. Mientras la sostengas, puedes hacer que emita una luz tenue verde hasta 10 pies, ya sea como acción adicional o tras tirar iniciativa, o bien extinguir esa luz como acción adicional. Mientras sostengas el arma, puedes emplear una acción adicional para modificar su forma y convertirla en una vara de 6 pulgadas (para guardarla con facilidad) o una pértiga de 10 pies, o volver a transformarla en un bastón. La vara solo se desplegará si las dimensiones del entorno lo permiten.\n\nDependiendo de su forma, el arma tiene las siguientes propiedades adicionales:\n\n• Arma a distancia (solo en forma de bastón). Esta arma tiene la propiedad \"arrojadiza\", con un alcance normal de 30 pies y un alcance largo de 120 pies. Inmediatamente después de que hagas un ataque a distancia con el arma, regresará volando a tu mano. Ayuda acrobática (solo en forma de bastón o pértiga de 10 pies). Mientras sostienes esta arma, tienes ventaja en las pruebas de Destreza (Acrobacias).\n• Desviar ataque (solo en forma de bastón). Si te aciertan con un ataque mientras sostienes el arma, puedes emplear una reacción para girar el arma a tu alrededor, lo que te proporcionará un bonificador de +5 a la clase de armadura contra el ataque al que reaccionas, lo que podría hacer que falle. No podrás volver a usar esta propiedad hasta que finalices un descanso corto o largo.",
    "subcategory": "Arma (bastón)",
    "id": "magic_baston_de_acrobata"
  },
  {
    "name": "BASTÓN DE CURACIÓN",
    "category": "Bastón",
    "rarity": "Raro",
    "attunement": "Sí (requiere sintonización con un bardo, clérigo o druida)",
    "description": "Este bastón tiene 10 cargas. Mientras lo empuñes, puedes lanzar un conjuro de la tabla \"Conjuros (cargas)\" desde él empleando tu modificador por aptitud mágica. En ella se indica cuántas cargas debes gastar para lanzar el conjuro.\n\n• Recuperar cargas. El bastón recupera 1d6 + 4 cargas empleadas cada día, al amanecer. Si gastas la última carga, tira 1d20. Si el resultado es 1, el bastón se desvanece tras un destello y se pierde para siempre.",
    "tables": [
      {
        "title": "Conjuros (cargas)",
        "columns": [
          "Conjuro",
          "Coste en cargas"
        ],
        "rows": [
          [
            "Curar heridas",
            "1 carga por nivel del conjuro (máximo 4 para un conjuro de nivel 4)"
          ],
          [
            "Curar heridas en masa",
            "5"
          ],
          [
            "Restablecimiento menor",
            "2"
          ]
        ]
      }
    ],
    "id": "magic_baston_de_curacion"
  },
  {
    "name": "BASTÓN DE ENJAMBRE DE INSECTOS",
    "category": "Bastón",
    "rarity": "Raro",
    "attunement": "Sí (requiere sintonización con un bardo, brujo, clérigo, druida, hechicero o mago)",
    "description": "Este bastón tiene 10 cargas.\n\n• Nube de insectos. Mientras empuñes el bastón, puedes emplear una acción de magia y gastar 1 carga para hacer que un enjambre de insectos inofensivos llene una emanación de 30 pies que se origina en ti. Los insectos permanecerán durante 10 minutos y convertirán el área en una zona muy oscura para todas las criaturas menos para ti. Un viento fuerte (por ejemplo, el que crea ráfaga de viento) dispersará el enjambre y pondrá fin al efecto.\n• Conjuros. Mientras empuñes el bastón, puedes lanzar un conjuro de la tabla \"Conjuros (cargas)\" desde él empleando tu CD de salvación de conjuros y tu modificador de ataque de conjuros. En ella se indica cuántas cargas debes gastar para lanzar el conjuro.\n• Recuperar cargas. El bastón recupera 1d6 + 4 cargas empleadas cada día, al amanecer. Si gastas la última carga, tira 1d20. Si el resultado es 1, un enjambre de insectos engulle el bastón, lo destruye y luego se dispersa.",
    "tables": [
      {
        "title": "Conjuros (cargas)",
        "columns": [
          "Conjuro",
          "Coste en cargas"
        ],
        "rows": [
          [
            "Insecto gigante",
            "4"
          ],
          [
            "Plaga de insectos",
            "5"
          ]
        ]
      }
    ],
    "id": "magic_baston_de_enjambre_de_insectos"
  },
  {
    "name": "BASTÓN DE ESCARCHA",
    "category": "Bastón",
    "rarity": "Muy raro",
    "attunement": "Sí (requiere sintonización con un brujo, druida, hechicero o mago)",
    "description": "Mientras empuñes este bastón, tendrás resistencia al daño de frío.\n\n• Conjuros. El bastón tiene 10 cargas. Mientras lo empuñes, puedes lanzar un conjuro de la tabla \"Conjuros (cargas)\" desde él empleando tu CD de salvación de conjuros. En ella se indica cuántas cargas debes gastar para lanzar el conjuro.\n• Recuperar cargas. El bastón recupera 1d6 + 4 cargas empleadas cada día, al amanecer. Si gastas la última carga, tira 1d20. Si el resultado es 1, el bastón se convierte en agua y se destruye.",
    "tables": [
      {
        "title": "Conjuros (cargas)",
        "columns": [
          "Conjuro",
          "Coste en cargas"
        ],
        "rows": [
          [
            "Cono de frío",
            "5"
          ],
          [
            "Muro de hielo",
            "4"
          ],
          [
            "Nube de oscurecimiento",
            "1"
          ],
          [
            "Tormenta de hielo",
            "4"
          ]
        ]
      }
    ],
    "id": "magic_baston_de_escarcha"
  },
  {
    "name": "BASTÓN DE FUEGO",
    "category": "Bastón",
    "rarity": "Muy raro",
    "attunement": "Sí (requiere sintonización con un brujo, druida, hechicero o mago)",
    "description": "Mientras empuñes este bastón, tendrás resistencia al daño de fuego.\n\n• Conjuros. El bastón tiene 10 cargas. Mientras lo empuñes, puedes lanzar un conjuro de la tabla \"Conjuros (cargas)\" desde él empleando tu CD de salvación de conjuros. En ella se indica cuántas cargas debes gastar para lanzar el conjuro.\n• Recuperar cargas. El bastón recupera 1d6 + 4 cargas empleadas cada día, al amanecer. Si gastas la última carga, tira 1d20. Si el resultado es 1, el bastón se convierte en cenizas y se destruye.",
    "tables": [
      {
        "title": "Conjuros (cargas)",
        "columns": [
          "Conjuro",
          "Coste en cargas"
        ],
        "rows": [
          [
            "Bola de fuego",
            "3"
          ],
          [
            "Manos ardientes",
            "1"
          ],
          [
            "Muro de fuego",
            "4"
          ]
        ]
      }
    ],
    "id": "magic_baston_de_fuego"
  },
  {
    "name": "BASTÓN DE IMPACTO",
    "category": "Bastón",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Este bastón se puede usar a modo de bastón mágico que otorga un bonificador de +3 a las tiradas de ataque y de daño realizadas con él. El bastón tiene 10 cargas. Cuando aciertes con un ataque cuerpo a cuerpo con él, podrás gastar hasta 3 cargas. Por cada carga empleada, el objetivo recibirá 1d6 de daño de fuerza adicional.\n\n• Recuperar cargas. El bastón recupera 1d6 + 4 cargas empleadas cada día, al amanecer. Si gastas la última carga, tira 1d20. Si el resultado es 1, el bastón se convierte en un bastón no mágico.",
    "id": "magic_baston_de_impacto"
  },
  {
    "name": "BASTÓN DE LA PITÓN",
    "category": "Bastón",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Como acción de magia, puedes lanzar este bastón para que caiga en un espacio sin ocupar a 10 pies o menos de ti, lo que hará que se convierta en una serpiente constrictora gigante en ese espacio. La serpiente estará bajo tu control, compartirá tu orden de iniciativa y su turno irá justo después del tuyo. En tu turno, puedes dar órdenes mentales a la serpiente (no requiere acción) si se encuentra a 60 pies o menos de ti y no tienes el estado de incapacitado. Tú decides la acción que llevará a cabo la serpiente y adónde se desplazará durante su turno, o puedes darle una orden general, como atacar a tus enemigos o proteger un lugar. Si no le das ninguna, se defenderá. Como acción adicional, puedes hacer que la serpiente recupere su forma de bastón en el espacio en el que se encuentre, pero no podrás volver a usar esta propiedad durante 1 hora. Si los puntos de golpe de la serpiente se reducen a 0, morirá y recuperará su forma de bastón. Luego, el bastón se hará añicos y se destruirá. Si la serpiente recupera la forma de bastón antes de perder todos sus puntos de golpe, los recuperará todos.",
    "id": "magic_baston_de_la_piton"
  },
  {
    "name": "BASTÓN DE LOS BOSQUES",
    "category": "Bastón",
    "rarity": "Raro",
    "attunement": "Sí (requiere sintonización con un druida)",
    "description": "Este bastón tiene 6 cargas y se puede usar a modo de bastón mágico que otorga un bonificador de +2 a las tiradas de ataque y de daño realizadas con él. Mientras lo empuñes, obtendrás un bonificador de +2 a las tiradas de ataque de conjuro.\n\n• Conjuros. Mientras empuñes el bastón, puedes lanzar un conjuro de la tabla \"Conjuros (cargas)\" desde él empleando tu CD de salvación de conjuros. En ella se indica cuántas cargas debes gastar para lanzar el conjuro.\n• Recuperar cargas. El bastón recupera 1d6 cargas empleadas cada día, al amanecer. Si gastas la última carga, tira 1d20. Si el resultado es 1, el bastón pierde sus propiedades y se convierte en un bastón no mágico.",
    "tables": [
      {
        "title": "Conjuros (cargas)",
        "columns": [
          "Conjuro",
          "Coste en cargas"
        ],
        "rows": [
          [
            "Despertar",
            "5"
          ],
          [
            "Encantar animal",
            "1"
          ],
          [
            "Hablar con las plantas",
            "3"
          ],
          [
            "Hablar con los animales",
            "1"
          ],
          [
            "Localizar animales o plantas",
            "2"
          ],
          [
            "Muro de espinas",
            "6"
          ],
          [
            "Pasar sin rastro",
            "2"
          ],
          [
            "Piel robliza",
            "2"
          ]
        ]
      }
    ],
    "id": "magic_baston_de_los_bosques"
  },
  {
    "name": "BASTÓN DE LOS MAGOS",
    "category": "Bastón",
    "rarity": "Legendario",
    "attunement": "Sí (requiere sintonización con un brujo, mago o hechicero)",
    "description": "Este bastón tiene 50 cargas y se puede usar a modo de bastón mágico que otorga un bonificador de +2 a las tiradas de ataque y de daño realizadas con él. Mientras lo empuñes, obtendrás un bonificador de +2 a las tiradas de ataque de conjuro.\n\n• Absorción de conjuros. Mientras empuñes el bastón, tendrás ventaja en las tiradas de salvación contra conjuros. Además, puedes emplear una reacción cuando otra criatura lance un conjuro que solo te haga objetivo a ti. Si lo haces, el bastón absorberá la magia del conjuro, cancelará su efecto y obtendrá una cantidad de cargas igual al nivel del conjuro absorbido. No obstante, si esto hace que la cantidad total de cargas del bastón supere las 50, el bastón explotará como si hubieses activado su golpe vengador (consulta más adelante).\n• Conjuros. Mientras empuñes el bastón, puedes lanzar un conjuro de la tabla \"Conjuros (cargas)\" desde él empleando tu CD de salvación de conjuros. En ella se indica cuántas cargas debes gastar para lanzar el conjuro.\n• Recuperar cargas. El bastón recupera 4d6 + 2 cargas empleadas cada día, al amanecer. Si gastas la última carga, tira 1d20. Si el resultado es 20, el bastón recupera 1d12 + 1 cargas.",
    "tables": [
      {
        "title": "Conjuros (cargas)",
        "columns": [
          "Conjuro",
          "Coste en cargas"
        ],
        "rows": [
          [
            "Abrir",
            "2"
          ],
          [
            "Agrandar/reducir",
            "0"
          ],
          [
            "Bola de fuego (versión de nivel 7)",
            "7"
          ],
          [
            "Cerradura arcana",
            "0"
          ],
          [
            "Conjurar elemental",
            "7"
          ],
          [
            "Desplazamiento entre planos",
            "7"
          ],
          [
            "Detectar magia",
            "0"
          ],
          [
            "Disipar magia",
            "3"
          ],
          [
            "Esfera de llamas",
            "2"
          ],
          [
            "Invisibilidad",
            "2"
          ],
          [
            "Luz",
            "0"
          ],
          [
            "Mano de mago",
            "0"
          ],
          [
            "Muro de fuego",
            "4"
          ],
          [
            "Pasamuros",
            "5"
          ],
          [
            "Protección contra el bien y el mal",
            "0"
          ],
          [
            "Relámpago (versión de nivel 7)",
            "7"
          ],
          [
            "Telaraña",
            "2"
          ],
          [
            "Telequinesis",
            "5"
          ],
          [
            "Tormenta de hielo",
            "4"
          ]
        ]
      }
    ],
    "id": "magic_baston_de_los_magos"
  },
  {
    "name": "BASTÓN DE MARCHITAMIENTO",
    "category": "Bastón",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Este bastón tiene 3 cargas y recupera 1d3 cargas empleadas cada día, al amanecer. El bastón se puede usar a modo de bastón mágico. Si aciertas con él, causa daño como un bastón normal y puedes gastar 1 carga para infligir 2d10 de daño necrótico adicional al objetivo y obligarlo a hacer una tirada de salvación de Constitución con CD 15. Si la falla, tendrá desventaja durante 1 hora en cualquier prueba de característica o tirada de salvación que utilice la Fuerza o la Constitución.",
    "id": "magic_baston_de_marchitamiento"
  },
  {
    "name": "BASTÓN DE PODER",
    "category": "Bastón",
    "rarity": "Muy raro",
    "attunement": "Sí (requiere sintonización con un brujo, hechicero, o mago)",
    "description": "Este bastón tiene 20 cargas y se puede usar a modo de bastón mágico que otorga un bonificador de +2 a las tiradas de ataque y de daño realizadas con él. Mientras lo empuñes, obtendrás un bonificador de +2 a la clase de armadura, las tiradas de salvación y las tiradas de ataque de conjuro.\n\n• Conjuros. Mientras empuñes el bastón, puedes lanzar un conjuro de la tabla \"Conjuros (cargas)\" desde él empleando tu CD de salvación de conjuros. En ella se indica cuántas cargas debes gastar para lanzar el conjuro.\n• Recuperar cargas. El bastón recupera 2d8 + 4 cargas empleadas cada día, al amanecer. Si gastas la última carga, tira 1d20. Si el resultado es 1, el bastón conserva su bonificador de +2 a las tiradas de ataque y de daño, pero pierde sus otras propiedades. Si el resultado es 20, el bastón recupera 1d8 + 2 cargas.",
    "tables": [
      {
        "title": "Conjuros (cargas)",
        "columns": [
          "Conjuro",
          "Coste en cargas"
        ],
        "rows": [
          [
            "Bola de fuego (versión de nivel 5)",
            "5"
          ],
          [
            "Cono de frío",
            "5"
          ],
          [
            "Globo de invulnerabilidad",
            "6"
          ],
          [
            "Inmovilizar monstruo",
            "5"
          ],
          [
            "Levitar",
            "2"
          ],
          [
            "Muro de fuerza",
            "5"
          ],
          [
            "Proyectil mágico",
            "1"
          ],
          [
            "Rayo debilitador",
            "1"
          ],
          [
            "Relámpago (versión de nivel 5)",
            "5"
          ]
        ]
      }
    ],
    "id": "magic_baston_de_poder"
  },
  {
    "name": "BASTÓN DE TRUENOS Y RELÁMPAGOS",
    "category": "Bastón",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Este bastón se puede usar a modo de bastón mágico que otorga un bonificador de +2 a las tiradas de ataque y de daño realizadas con él. También tiene las propiedades adicionales que se mencionan a continuación. Cuando se utilice una de ellas, esa propiedad no podrá volver a usarse hasta el siguiente amanecer.\n\n• Golpe atronador. Cuando aciertes con un ataque cuerpo a cuerpo usando el bastón, podrás hacer que el bastón emita un chasquido atronador que se oiga a 300 pies de distancia (no requiere acción). El objetivo golpeado deberá superar una tirada de salvación de Constitución con CD 17 o tendrá el estado de aturdido hasta el final de tu siguiente turno.\n• Golpe relampagueante. Cuando aciertes con un ataque cuerpo a cuerpo usando el bastón, podrás hacer que el objetivo sufra 2d6 de daño de relámpago adicional (no requiere acción).\n• Relámpago. Puedes utilizar una acción de magia para que un relámpago surja de la punta del bastón en una línea de 5 pies de ancho y 120 pies de largo. Todas las criaturas situadas en la línea harán una tirada de salvación de Destreza con CD 17; sufrirán 9d6 de daño de relámpago si la fallan o la mitad del daño si la superan.\n• Trueno. Puedes emplear una acción de magia para hacer que el bastón emita un trueno ensordecedor audible a 600 pies de distancia. Todas las criaturas situadas en una emanación de 60 pies que se origina en ti harán una tirada de salvación de Constitución con CD 17. Si la fallan, sufrirán 2d6 de daño de trueno y tendrán el estado de ensordecidas durante 1 minuto. Si la superan, solo sufrirán la mitad de ese daño.\n• Truenos y relámpagos. Inmediatamente después de acertar con un ataque cuerpo a cuerpo usando el bastón, puedes emplear una acción adicional para utilizar a la vez las propiedades de golpe atronador y golpe relampagueante (consúltalas más arriba). Hacer esto no consume el uso diario de esas propiedades, solo de esta.",
    "id": "magic_baston_de_truenos_y_relampagos"
  },
  {
    "name": "BASTÓN DEL CAUTIVADOR",
    "category": "Bastón",
    "rarity": "Raro",
    "attunement": "Sí (requiere sintonización con un bardo, brujo, clérigo, druida, hechicero o mago)",
    "description": "Este bastón tiene 10 cargas. Mientras lo empuñes, puedes usar cualquiera de sus propiedades:\n\n• Lanzar conjuro. Puedes gastar 1 carga del bastón para lanzar entender idiomas, hechizar persona u orden imperiosa desde él usando tu CD de salvación de conjuros.\n• Reflejar encantamiento. Si superas una tirada de salvación contra un conjuro de encantamiento que solo te haga objetivo a ti, podrás utilizar una reacción y gastar 1 carga del bastón para volver el conjuro en contra de su lanzador como si tú lo hubieras lanzado.\n• Resistir encantamiento. Si fallas una tirada de salvación contra un conjuro de encantamiento que solo te haga objetivo a ti, podrás superar la tirada fallida en su lugar. No podrás volver a usar esta propiedad hasta el siguiente amanecer.\n• Recuperar cargas. El bastón recupera 1d8 + 2 cargas empleadas cada día, al amanecer. Si gastas la última carga, tira 1d20. Si el resultado es 1, el bastón se convierte en polvo y se destruye.",
    "id": "magic_baston_del_cautivador"
  },
  {
    "name": "BOLA DE CRISTAL",
    "category": "Objeto maravilloso",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Mientras tocas este orbe de cristal, puedes lanzar escudriñar (CD de salvación 17) desde él.",
    "id": "magic_bola_de_cristal"
  },
  {
    "name": "BOLA DE CRISTAL DE LEER MENTES",
    "category": "Objeto maravilloso",
    "rarity": "Legendario",
    "attunement": "Sí",
    "description": "Mientras tocas este orbe de cristal, puedes lanzar escudriñar (CD de salvación 17) desde él. Además, puedes lanzar detectar pensamientos (CD de salvación 17) haciendo objetivo a las criaturas que puedas ver a 30 pies o menos del sensor del conjuro. No tienes que concentrarte en este conjuro detectar pensamientos para mantenerlo mientras dura, pero acabará si escudriñar también lo hace.",
    "id": "magic_bola_de_cristal_de_leer_mentes"
  },
  {
    "name": "BOLA DE CRISTAL DE TELEPATÍA",
    "category": "Objeto maravilloso",
    "rarity": "Legendario",
    "attunement": "Sí",
    "description": "Mientras tocas este orbe de cristal, puedes lanzar escudriñar (CD de salvación 17) desde él. Además, puedes comunicarte telepáticamente con las criaturas que puedas ver a 30 pies o menos del sensor del conjuro. También puedes lanzar sugestión (CD de salvación 17) sobre una de esas criaturas a través del sensor. No tienes que concentrarte en este conjuro sugestión para mantenerlo mientras dura, pero acabará si escudriñar también lo hace. No podrás volver a lanzar sugestión de esta forma hasta el siguiente amanecer.",
    "id": "magic_bola_de_cristal_de_telepatia"
  },
  {
    "name": "BOLA DE CRISTAL DE VISIÓN VERAZ",
    "category": "Objeto maravilloso",
    "rarity": "Legendario",
    "attunement": "Sí",
    "description": "Mientras tocas este orbe de cristal, puedes lanzar escudriñar (CD de salvación 17) desde él. Además, tienes visión verdadera en un radio de 120 pies centrado en el sensor del conjuro.",
    "id": "magic_bola_de_cristal_de_vision_veraz"
  },
  {
    "name": "BOLSA DE CONTENCIÓN",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Esta bolsa posee un espacio interior considerablemente mayor que sus dimensiones exteriores: unos 2 pies de lado y 4 pies de profundidad en el interior. La bolsa puede contener hasta 500 lb, con un volumen máximo de 64 pies cúbicos. La bolsa pesa 15 lb, independientemente de su contenido. Para sacar un objeto de la bolsa es necesaria una acción de utilizar. Si se sobrecarga, perfora o rasga la bolsa, esta se destruye y su contenido se dispersa por el Plano Astral. Si se pone la bolsa del revés, su contenido se vuelca sin sufrir daño, pero la bolsa debe volver a ponerse del derecho antes de usarla de nuevo. La bolsa contiene aire suficiente para respirar durante 10 minutos, divididos entre el número de criaturas que necesiten respirar en su interior. Meter una bolsa de contención en el espacio extradimensional creado por un agujero portátil, un morral práctico o un objeto similar destruye instantáneamente ambos objetos y abre un portal al Plano Astral. El portal se crea en el sitio en el que un objeto se introdujo dentro del otro. El portal absorbe a todas las criaturas situadas en una esfera de 10 pies de radio centrada en él y las conduce a un lugar aleatorio del Plano Astral. Después, el portal se cierra. El portal funciona en un sentido y no puede volver a abrirse.",
    "peso": 15,
    "id": "magic_bolsa_de_contencion"
  },
  {
    "name": "BOLSA DE TRUCOS",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Esta bolsa hecha de tela de color gris, rojizo o marrón parece vacía. No obstante, meter la mano en su interior revela la presencia de un objeto pequeño y peludo. Puedes usar una acción de magia para sacar el objeto peludo de la bolsa y lanzarlo a 20 pies o menos de distancia. Cuando aterrice, se transformará en una criatura que determines al tirar en la tabla que corresponda al color de la bolsa. Consulta el capítulo “Monstruos” para conocer el perfil de la criatura. La criatura desaparecerá al siguiente amanecer o cuando sus puntos de golpe se reduzcan a 0. La criatura es amistosa contigo y tus aliados y actúa inmediatamente después de ti en tu orden de iniciativa. Puedes emplear una acción adicional para ordenarle cómo se mueve o qué acción realiza en su turno, como atacar a un enemigo. Si no recibe tales órdenes, se comportará conforme a su naturaleza. Una vez que se han extraído tres objetos peludos de la bolsa, no puede volver a utilizarse hasta el siguiente amanecer.",
    "tables": [
      {
        "title": "Bolsa de trucos gris",
        "columns": [
          "Clave",
          "Valor"
        ],
        "rows": [
          [
            "1",
            "Comadreja"
          ],
          [
            "2",
            "Rata gigante"
          ],
          [
            "3",
            "Tejón"
          ],
          [
            "4",
            "Jabalí"
          ],
          [
            "5",
            "Pantera"
          ],
          [
            "6",
            "Tejón gigante"
          ],
          [
            "7",
            "Lobo terrible"
          ],
          [
            "8",
            "Alce gigante"
          ]
        ]
      },
      {
        "title": "Bolsa de trucos rojiza",
        "columns": [
          "Clave",
          "Valor"
        ],
        "rows": [
          [
            "1",
            "Rata"
          ],
          [
            "2",
            "Búho"
          ],
          [
            "3",
            "Mastín"
          ],
          [
            "4",
            "Cabra"
          ],
          [
            "5",
            "Cabra gigante"
          ],
          [
            "6",
            "Jabalí gigante"
          ],
          [
            "7",
            "León"
          ],
          [
            "8",
            "Oso pardo"
          ]
        ]
      },
      {
        "title": "Bolsa de trucos marrón",
        "columns": [
          "Clave",
          "Valor"
        ],
        "rows": [
          [
            "1",
            "Chacal"
          ],
          [
            "2",
            "Simio"
          ],
          [
            "3",
            "Babuino"
          ],
          [
            "4",
            "Pico de hacha"
          ],
          [
            "5",
            "Oso negro"
          ],
          [
            "6",
            "Comadreja gigante"
          ],
          [
            "7",
            "Hiena gigante"
          ],
          [
            "8",
            "Tigre"
          ]
        ]
      }
    ],
    "id": "magic_bolsa_de_trucos"
  },
  {
    "name": "BOLSA DEVORADORA",
    "category": "Objeto maravilloso",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Esta bolsa se parece a una bolsa de contención, pero en realidad es el orificio de alimentación de una criatura extradimensional gigante. Poner la bolsa del revés cierra el orificio. La criatura extradimensional vinculada a la bolsa puede sentir cualquier cosa que se meta en su interior y devora cualquier materia animal o vegetal que se introduzca por completo. Esta materia se pierde para siempre. Cuando se introduce parte de una criatura viva en la bolsa, como cuando alguien mete la mano, hay un 50 % de probabilidad de que toda la criatura se vea arrastrada al interior. Una criatura dentro de la bolsa puede emplear una acción para intentar escapar superando una prueba de Fuerza (Atletismo) con CD 15. Otra criatura puede utilizar una acción para meter la mano en la bolsa con el fin de sacar a una criatura, lo que logrará si supera una prueba de Fuerza (Atletismo) con CD 20, siempre y cuando no vaya a parar ella también al interior de la bolsa primero. Cualquier criatura que comience su turno en el interior de la bolsa será devorada y su cuerpo será destruido. Se pueden guardar objetos inanimados en la bolsa, que puede albergar 0,03 pies cúbicos de dicho material. No obstante, una vez al día, la bolsa se traga cualquier objeto que contenga y lo escupe en otro plano de existencia. El momento y el plano los determina tu GM. Si se perfora o se rasga la bolsa, se destruye y cualquier cosa que contenga se transporta a un lugar aleatorio del Plano Astral.",
    "id": "magic_bolsa_devoradora"
  },
  {
    "name": "BOTAS ALADAS",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Estas botas tienen 4 cargas y recuperan 1d4 cargas empleadas cada día, al amanecer. Mientras las lleves puestas, puedes emplear una acción de magia para gastar 1 carga, lo que te proporciona una velocidad volando de 30 pies durante 1 hora. Si estás volando cuando concluya la duración, descenderás a una velocidad de 30 pies por asalto hasta que aterrices.",
    "id": "magic_botas_aladas"
  },
  {
    "name": "BOTAS DE LAS TIERRAS INVERNALES",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Estas botas forradas de pelaje son ceñidas y calentitas. Mientras las calces, obtienes los siguientes beneficios.\n\n• Caminante invernal. El terreno difícil creado por hielo o nieve no te afecta.\n• Resistencia al frío. Tienes resistencia al daño de frío y puedes aguantar temperaturas de 0 °F o menos sin más protección.",
    "id": "magic_botas_de_las_tierras_invernales"
  },
  {
    "name": "BOTAS DE LEVITACIÓN",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Mientras calces estas botas, puedes lanzar levitar sobre ti.",
    "id": "magic_botas_de_levitacion"
  },
  {
    "name": "BOTAS DE VELOCIDAD",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Mientras calces estas botas, podrás utilizar una acción adicional para entrechocar los talones. Si lo haces, las botas duplicarán tu velocidad y cualquier criatura que realice un ataque de oportunidad contra ti tendrá desventaja en la tirada de ataque. Si vuelves a entrechocar los talones, el efecto terminará. Cuando hayas usado esta propiedad de las botas durante un total de 10 minutos, la magia dejará de funcionar para ti hasta que finalices un descanso largo.",
    "id": "magic_botas_de_velocidad"
  },
  {
    "name": "BOTAS DE ZANCADAS Y BRINCOS",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Mientras calces estas botas, tu velocidad pasa a ser de 30 pies, salvo que normalmente sea superior, y no se reduce por superar tu capacidad de carga o por llevar puesta una armadura pesada. Una vez en cada uno de tus turnos, puedes saltar hasta 30 pies usando solo 10 pies de movimiento.",
    "id": "magic_botas_de_zancadas_y_brincos"
  },
  {
    "name": "BOTAS DEL CAMINO SERPENTEANTE",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Mientras calces estas botas, puedes emplear una acción adicional para teletransportarte hasta 15 pies a un espacio sin ocupar que puedas ver. Debes haber ocupado ese espacio en algún momento del turno actual.",
    "id": "magic_botas_del_camino_serpenteante"
  },
  {
    "name": "BOTAS DEL VELOCISTA",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Estas botas ligeras y reforzadas están diseñadas para favorecer un desplazamiento rápido y preciso. Mientras las lleves puestas, tu velocidad aumenta en 5 pies.",
    "id": "magic_botas_del_velocista"
  },
  {
    "name": "BOTAS ÉLFICAS",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Mientras calces estas botas, tus pasos no harán ruido, independientemente de la superficie que pises. También tendrás ventaja en las pruebas de Destreza (Sigilo).",
    "id": "magic_botas_elficas"
  },
  {
    "name": "BOTE PLEGABLE",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Este objeto parece una caja de madera que mide 12 pulgadas de largo, 6 pulgadas de ancho y 6 pulgadas de profundidad. Pesa 10 lb y flota. Puede abrirse para guardar objetos en su interior.\n\nEl objeto posee tres palabras de activación y cada una de ellas requiere una acción de magia para usarla:\n\n• Primera palabra de activación. La caja se despliega y forma un bote de remos.\n• Segunda palabra de activación. La caja se despliega y forma una barcaza.\n• Tercera palabra de activación. El bote plegable se convierte de nuevo en una caja, siempre que no haya criaturas a bordo. Cualquier objeto que contenga la embarcación y no quepa en la caja permanecerá fuera de ella cuando se pliegue. Los que sí quepan en la caja permanecerán dentro. Cuando la caja se convierte en una embarcación, adopta el peso de una embarcación de su tamaño y cualquier cosa que contuviera la caja permanece en su interior. Los parámetros del bote de remos y de la barcaza se muestran en eel Manual del Jugador. Si los puntos de golpe de cualquier embarcación se reducen a 0, el bote plegable queda destruido.",
    "peso": 10,
    "id": "magic_bote_plegable"
  },
  {
    "name": "BOTELLA DE IFRIT",
    "category": "Objeto maravilloso",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Cuando usas una acción de magia para quitar el tapón de esta botella de latón pintado, una nube de humo espeso sale de ella. Al final de tu turno, el humo desaparece con un fogonazo inofensivo y un ifrit se manifestará en un espacio sin ocupar a 30 pies o menos de ti. La primera vez que se abra la botella, tu GM tira en la siguiente tabla para determinar qué pasa.",
    "tables": [
      {
        "title": "Efecto",
        "columns": [
          "Clave",
          "Valor"
        ],
        "rows": [
          [
            "1",
            "El ifrit te ataca. Tras luchar durante 5 asaltos, el ifrit desaparecerá y la botella perderá su magia."
          ],
          [
            "2–9",
            "El ifrit entiende tus idiomas y obedece tus órdenes durante 1 hora, tras lo cual volverá a la botella y un nuevo tapón le impedirá salir. El tapón no se puede quitar durante 24 horas. Las dos siguientes veces que se abra la botella, ocurrirá el mismo efecto. Si la botella se abre una cuarta vez, el ifrit se escapará y desaparecerá, y la botella perderá su magia."
          ],
          [
            "10",
            "El ifrit entiende tus idiomas y puede lanzar deseo una vez para ti. Desaparecerá cuando conceda el deseo o después de 1 hora y la botella perderá su magia."
          ]
        ]
      }
    ],
    "id": "magic_botella_de_ifrit"
  },
  {
    "name": "BOTELLA SIEMPREHUMEANTE",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Como acción de magia, puedes abrir o cerrar esta botella. Abrirla provoca que una nube de denso humo salga de ella y llene una emanación de 60 pies que se origina en la botella. El área se considera muy oscura. Cada minuto que la botella permanezca abierta, el tamaño de la emanación aumenta en 10 pies, hasta que alcance su tamaño máximo de 120 pies. Cerrar la botella hace que la nube se quede en su sitio hasta que se disipe tras 10 minutos. Un viento fuerte (como el que crea el conjuro ráfaga de viento ) la disipará después de 1 minuto.",
    "id": "magic_botella_siemprehumeante"
  },
  {
    "name": "BRASERO PARA CONTROLAR ELEMENTALES DE FUEGO",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Mientras estés a 5 pies o menos de este brasero, puedes emplear una acción de magia para invocar un elemental de fuego. El elemental aparece en un espacio sin ocupar lo más cerca posible del brasero, entiende tus idiomas, obedece tus órdenes y juega su turno inmediatamente después de ti en tu orden de iniciativa. El elemental desaparecerá tras 1 hora, cuando muera o si lo desconvocas como acción adicional. El brasero no puede volver a emplearse de esta manera hasta el siguiente amanecer.",
    "id": "magic_brasero_para_controlar_elementales_de_fuego"
  },
  {
    "name": "BRAZALES DE ARQUERÍA",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Mientras lleves estos brazales, serás competente con arcos cortos y largos y obtendrás un bonificador de +2 a las tiradas de daño con estas armas.",
    "id": "magic_brazales_de_arqueria"
  },
  {
    "name": "BRAZALES DE DEFENSA",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Mientras lleves estos brazales, obtendrás un bonificador de +2 a la clase de armadura si no vistes ninguna armadura ni embrazas ningún escudo.",
    "id": "magic_brazales_de_defensa"
  },
  {
    "name": "BROCHE ESCUDO",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Mientras lleves prendido este broche, tendrás resistencia al daño de fuerza e inmunidad al daño infligido por el conjuro proyectil mágico.",
    "id": "magic_broche_escudo"
  },
  {
    "name": "CANICA DE FUERZA",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Esta pequeña esfera negra mide 1 pulgada de diámetro y pesa 1 lb. Normalmente, se encuentran 1d4 + 4 canicas de fuerza juntas. Puedes utilizar una acción de magia para lanzar la canica a 60 pies o menos de distancia. La canica explota en una esfera de 10 pies de radio al impactar y se destruye. Cada criatura que se encuentre en la esfera deberá superar una tirada de salvación de Destreza con CD 15 o recibirá 5d4 de daño de fuerza. Después, el área quedará encerrada en una esfera de fuerza transparente durante 1 minuto. Las criaturas que hayan fallado la tirada de salvación y estén dentro del área por completo quedarán atrapadas en el interior de la esfera. A las criaturas que hayan superado la tirada o que estén dentro del área solo parcialmente se las empujará lejos del centro de la esfera hasta que dejen de estar en su interior. A través de la pared de la esfera solo puede pasar el aire respirable; ningún ataque o efecto puede atravesarla. Una criatura encerrada puede emplear una acción de utilizar para empujar la pared de la esfera y hacerla moverse hasta la mitad de la velocidad de la criatura. La esfera se puede recoger y su magia hace que solo pese 2 lb, independientemente de lo que pesen las criaturas que contenga.",
    "peso": 1,
    "id": "magic_canica_de_fuerza"
  },
  {
    "name": "CAPA ARÁCNIDA",
    "category": "Objeto maravilloso",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Esta delicada prenda se ha fabricado con seda negra y tiene finas hebras plateadas entretejidas.\n\nMientras la lleves puesta, obtendrás los siguientes beneficios:\n\n• Caminar cual arácnido. No puedes quedar atrapado en ningún tipo de red o telaraña y podrás moverte por ellas como si fueran terreno difícil.\n• Resistencia al veneno. Tienes resistencia al daño de veneno.\n• Telaraña. Puedes lanzar telaraña (CD de salvación 13). La telaraña creada por este conjuro tiene el doble del tamaño normal. Una vez utilizada, esta propiedad no puede volver a usarse hasta el siguiente amanecer.\n• Trepar cual arácnido. Tienes una velocidad trepando igual a tu velocidad y puedes moverte hacia arriba, hacia abajo y de lado por superficies verticales y techos mientras mantienes las manos libres.",
    "id": "magic_capa_aracnida"
  },
  {
    "name": "CAPA DE CUERVO",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Esta capa oscura, confeccionada con plumas negras o con tela que imita su plumaje, parece agitarse con vida propia cuando acecha el peligro. Mientras la lleves puesta, puedes lanzar escudo desde ella. Una vez usada esta propiedad, no puede volver a utilizarse hasta que finalices un descanso largo.",
    "id": "magic_capa_de_cuervo"
  },
  {
    "name": "CAPA DE DESPLAZAMIENTO",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Mientras lleves esta capa, proyectará mágicamente una ilusión que hace que parezcas estar en un lugar cerca de tu ubicación real, lo que provoca que todas las criaturas tengan desventaja en las tiradas de ataque contra ti. Si recibes daño, la propiedad dejará de funcionar hasta el principio de tu siguiente turno. Esta propiedad quedará suprimida mientras tu velocidad sea de 0.",
    "id": "magic_capa_de_desplazamiento"
  },
  {
    "name": "CAPA DE INVISIBILIDAD",
    "category": "Objeto maravilloso",
    "rarity": "Legendario",
    "attunement": "Sí",
    "description": "Esta capa tiene 3 cargas y recupera 1d3 cargas empleadas cada día, al amanecer. Mientras la lleves puesta, puedes emplear una acción de magia para ponerte la capucha y gastar 1 carga para otorgarte el estado de invisible durante 1 hora. El efecto termina antes de tiempo si te quitas la capucha (no requiere acción) o dejas de llevar puesta la capa.",
    "id": "magic_capa_de_invisibilidad"
  },
  {
    "name": "CAPA DE LA MANTARRAYA",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Mientras lleves esta capa, podrás respirar bajo el agua y tendrás una velocidad nadando de 60 pies.",
    "id": "magic_capa_de_la_mantarraya"
  },
  {
    "name": "CAPA DE MURCIÉLAGO",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Mientras lleves esta capa, tendrás ventaja en las pruebas de Destreza (Sigilo). En una zona de luz tenue o de oscuridad, puedes agarrar los extremos de la capa y usarla para obtener una velocidad volando de 40 pies. Si sueltas los extremos de la capa mientras vuelas de esta forma o si ya no te encuentras bajo luz tenue u oscuridad, perderás esta velocidad volando. Mientras lleves puesta la capa en una zona de luz tenue u oscuridad, podrás lanzar polimorfar sobre ti y adoptar la forma de un murciélago. Mientras tengas esa forma, conservas tus puntuaciones de Inteligencia, Sabiduría y Carisma. La capa no puede volver a emplearse de esta manera hasta el siguiente amanecer.",
    "id": "magic_capa_de_murcielago"
  },
  {
    "name": "CAPA DE PROTECCIÓN",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Mientras lleves esta capa, obtienes un bonificador de +1 a la clase de armadura y a las tiradas de salvación.",
    "id": "magic_capa_de_proteccion"
  },
  {
    "name": "CAPA DEL CHARLATÁN",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Esta capa tiene un ligero aroma a azufre. Mientras la lleves puesta, puedes usarla para lanzar puerta dimensional como acción de magia. Esta propiedad no podrá volver a usarse hasta el siguiente amanecer. Si te teletransportas con este conjuro, dejas tras de ti una nube de humo. El espacio que abandonas está ligeramente oscurecido por el humo hasta el final de tu siguiente turno.",
    "id": "magic_capa_del_charlatan"
  },
  {
    "name": "CAPA ÉLFICA",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Mientras lleves esta capa, las pruebas de Sabiduría (Percepción) para percibirte se harán con desventaja y tú tendrás ventaja en las pruebas de Destreza (Sigilo).",
    "id": "magic_capa_elfica"
  },
  {
    "name": "CAPA ONDULANTE",
    "category": "Objeto maravilloso",
    "rarity": "Común",
    "attunement": "No",
    "description": "Mientras lleves esta capa, puedes tomar una acción bonus para hacerla ondear de una manera espectacular durante 1 minuto.",
    "id": "magic_capa_ondulante"
  },
  {
    "name": "CARCAJ DE EHLONNA",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Cada uno de los tres compartimentos de esta aljaba está conectado con un espacio extradimensional, lo que le permite contener muchos objetos sin pesar nunca más de 5 lb. El compartimento más pequeño puede albergar hasta 60 flechas, virotes u objetos similares. El compartimento intermedio puede contener hasta 18 jabalinas u objetos parecidos. En el compartimento más grande caben hasta 6 objetos largos, como arcos, bastones o lanzas. Puedes extraer cualquier objeto que contenga esta aljaba igual que lo harías con una aljaba o vaina normal.",
    "peso": 5,
    "id": "magic_carcaj_de_ehlonna"
  },
  {
    "name": "CARILLÓN DE APERTURA",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Este tubo de metal hueco mide alrededor de 12 pulgadas de largo y pesa 2 lb. Como acción de magia, puedes golpearlo para lanzar abrir. El sonido habitual del conjuro se sustituye por el tono prístino y resonante del carillón, que se puede oír a 300 pies de distancia. El carillón puede usarse hasta 10 veces. Tras el décimo uso, se resquebraja y se vuelve inútil.",
    "peso": 2,
    "id": "magic_carillon_de_apertura"
  },
  {
    "name": "CETRO DE MANDO",
    "category": "Vara",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Puedes utilizar una acción de magia para mostrar el cetro y exigir obediencia a todas las criaturas de tu elección que puedas ver a 120 pies o menos de ti. Cada objetivo deberá superar una tirada de salvación de Sabiduría con CD 15 o tendrá el estado de hechizado durante 8 horas. Mientras estén hechizadas de esta manera, las criaturas te considerarán su líder de confianza. Si tus aliados o tú les causáis daño o si se les ordena llevar a cabo algo contrario a su naturaleza, los objetivos dejarán de estar hechizados de esta forma. Una vez utilizada, esta propiedad no puede volver a usarse hasta el siguiente amanecer.",
    "id": "magic_cetro_de_mando"
  },
  {
    "name": "CETRO DE PODER SEÑORIAL",
    "category": "Vara",
    "rarity": "Legendario",
    "attunement": "Sí",
    "description": "Este cetro tiene una cabeza con reborde y funciona como una maza mágica que otorga un bonificador de +3 a las tiradas de ataque y de daño hechas con ella. Además, tiene propiedades asociadas a seis botones dispuestos en fila a lo largo de la empuñadura. También cuenta con otras tres propiedades, descritas a continuación.\n\n• Botones. Como acción adicional, puedes pulsar uno de los siguientes botones. El efecto del botón dura hasta que pulses un botón distinto o hasta que pulses de nuevo el mismo botón, lo que hace que el cetro recupere su forma normal.\n• Botón 1. Una hoja llameante surge del extremo opuesto a la cabeza rebordeada del cetro. Las llamas emiten luz brillante en un radio de 40 pies y luz tenue 40 pies más allá. La hoja funciona como una espada corta o una espada larga mágica (a tu elección) que causa 2d6 de daño de fuego adicional al acertar.\n• Botón 2. La cabeza rebordeada del cetro se pliega sobre sí misma y surgen dos hojas con forma de media luna en su lugar, lo que transforma el cetro en un hacha de guerra mágica que otorga un bonificador de +3 a las tiradas de ataque y de daño hechas con ella.\n• Botón 3. La cabeza rebordeada del cetro se pliega sobre sí misma, la punta de una lanza surge en su lugar y la empuñadura del cetro se alarga hasta medir 6 pies, lo que lo transforma en una lanza mágica que otorga un bonificador de +3 a las tiradas de ataque y de daño hechas con ella.\n• Botón 4. El cetro se transforma en una pértiga para escalar de hasta 50 pies de largo (tú decides la longitud), aunque los botones permanecen a tu alcance. En las superficies tan duras como el granito, aparecen una punta en la parte inferior y tres ganchos en la parte superior para fijar la pértiga. Además, en los laterales se despliegan unas barras horizontales de 3 pulgadas de largo con una separación de 12 pulgadas entre sí para formar una escalera. La pértiga puede soportar hasta 4000 lb. Si carga con más peso o si no tiene un anclaje sólido, el cetro recupera su forma normal.\n• Botón 5. El cetro se transforma en un ariete portátil y otorga a su usuario un bonificador de +10 las pruebas de Fuerza (Atletismo) realizadas para derribar puertas, barricadas u otro tipo de barrera.\n• Botón 6. El cetro adopta o recupera su forma normal e indica el norte magnético (no ocurrirá nada si esta función del cetro se utiliza en un lugar que carezca de norte magnético). El cetro también te permite saber tu profundidad aproximada bajo tierra o tu altitud si estás en la superficie.\n• Aterrorizar. Mientras empuñes el cetro, podrás utilizar una acción de magia para obligar a todas las criaturas que puedas ver a 30 pies o menos de ti a realizar una tirada de salvación de Sabiduría con CD 17. Si la fallan, los objetivos tendrán el estado de asustados durante 1 minuto. Los objetivos asustados repetirán la tirada de salvación al final de cada uno de sus turnos y, si tienen éxito, se librarán del efecto. Una vez utilizada, esta propiedad no puede volver a usarse hasta el siguiente amanecer.\n• Drenar vida. Cuando aciertes a una criatura con un ataque cuerpo a cuerpo usando el cetro, podrás obligar al objetivo a realizar una tirada de salvación de Constitución con CD 17. Si la falla, sufrirá 4d6 de daño necrótico adicional y tú recuperarás una cantidad de puntos de golpe igual a la mitad de ese daño necrótico. Una vez utilizada, esta propiedad no puede volver a usarse hasta el siguiente amanecer.\n• Paralizar. Cuando aciertes a una criatura con un ataque cuerpo a cuerpo usando el cetro, podrás obligar al objetivo a realizar una tirada de salvación de Constitución con CD 17. Si la falla, tendrá el estado de paralizado durante 1 minuto. El objetivo repetirá la tirada de salvación al final de cada uno de sus turnos y, si tiene éxito, se librará del efecto. Una vez utilizada, esta propiedad no puede volver a usarse hasta el siguiente amanecer.",
    "peso": 4409,
    "id": "magic_cetro_de_poder_senorial"
  },
  {
    "name": "CIMITARRA DE VELOCIDAD",
    "category": "Arma",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Recibes un bonificador de +2 a las tiradas de ataque y de daño que hagas con esta arma mágica. Además, puedes realizar un ataque con ella como acción adicional en cada uno de tus turnos.",
    "subcategory": "Arma (cimitarra)",
    "id": "magic_cimitarra_de_velocidad"
  },
  {
    "name": "CINDRAXION",
    "category": "Armadura",
    "rarity": "Artefacto",
    "attunement": "S? (no puedes desintonizarte)",
    "description": "Este escudo alberga una llama dracónica indómita. Forjado para la vanguardia, protege a su portador con fuego vivo y convierte su defensa en una embestida abrasadora.\n\n• Aliento de Cindraxion. Como acción, puedes liberar el aliento en un radio de 15 pies centrado en ti o en un cono de 15 pies. Las criaturas afectadas deben realizar una tirada de salvación de Destreza con CD 8 + tu bonificador por competencia + tu modificador de Fuerza. Si fallan, reciben 8d6 de daño de fuego; si tienen éxito, reciben la mitad. Esta propiedad solo puede usarse una vez por descanso largo.\n• Escudo/arma mágica. Obtienes un bonificador mágico de +2 a la clase de armadura mientras uses este escudo.\n• Ataque de escudo. Puedes usar el escudo para hacer ataques con Fuerza y eres competente con él. El ataque causa 1d6 de daño contundente más 1d6 de daño de fuego adicional. Además, posee la maestría Empujar.\n• Defensa ardiente. Tienes resistencia al daño de fuego. Además, cuando superas una tirada de salvación de Destreza para evitar daño de área, puedes usar tu reacción para moverte 15 pies sin provocar ataques de oportunidad. Si te interpones entre el origen del área y hasta tres aliados adyacentes a 5 pies de ti, esos aliados reciben la mitad del daño.",
    "subcategory": "Escudo",
    "id": "magic_cindraxion"
  },
  {
    "name": "CINTURÓN DE FUERZA DE GIGANTE (COLINAS)",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Mientras lleves puesto este cinturón, tu Fuerza cambia a 21. No tendrá ningún efecto si tu Fuerza sin el cinturón es igual o superior a 21.",
    "id": "magic_cinturon_de_fuerza_de_gigante_colinas"
  },
  {
    "name": "CINTURÓN DE FUERZA DE GIGANTE (ESCARCHA)",
    "category": "Objeto maravilloso",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Mientras lleves puesto este cinturón, tu Fuerza cambia a 23. No tendrá ningún efecto si tu Fuerza sin el cinturón es igual o superior a 23.",
    "id": "magic_cinturon_de_fuerza_de_gigante_escarcha"
  },
  {
    "name": "CINTURÓN DE FUERZA DE GIGANTE (FUEGO)",
    "category": "Objeto maravilloso",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Mientras lleves puesto este cinturón, tu Fuerza cambia a 25. No tendrá ningún efecto si tu Fuerza sin el cinturón es igual o superior a 25.",
    "id": "magic_cinturon_de_fuerza_de_gigante_fuego"
  },
  {
    "name": "CINTURÓN DE FUERZA DE GIGANTE (NUBES)",
    "category": "Objeto maravilloso",
    "rarity": "Legendario",
    "attunement": "Sí",
    "description": "Mientras lleves puesto este cinturón, tu Fuerza cambia a 27. No tendrá ningún efecto si tu Fuerza sin el cinturón es igual o superior a 27.",
    "id": "magic_cinturon_de_fuerza_de_gigante_nubes"
  },
  {
    "name": "CINTURÓN DE FUERZA DE GIGANTE (PIEDRA)",
    "category": "Objeto maravilloso",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Mientras lleves puesto este cinturón, tu Fuerza cambia a 23. No tendrá ningún efecto si tu Fuerza sin el cinturón es igual o superior a 23.",
    "id": "magic_cinturon_de_fuerza_de_gigante_piedra"
  },
  {
    "name": "CINTURÓN DE FUERZA DE GIGANTE (TORMENTAS)",
    "category": "Objeto maravilloso",
    "rarity": "Legendario",
    "attunement": "Sí",
    "description": "Mientras lleves puesto este cinturón, tu Fuerza cambia a 29. No tendrá ningún efecto si tu Fuerza sin el cinturón es igual o superior a 29.",
    "id": "magic_cinturon_de_fuerza_de_gigante_tormentas"
  },
  {
    "name": "CINTURÓN ENANO",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Mientras lleves puesto este cinturón, obtienes los siguientes beneficios:\n\n• Aguante. Tu Constitución aumenta en 2, hasta un máximo de 20.\n• Amistad con los enanos. Tienes ventaja en las pruebas de Carisma (Persuasión) en las que interactúes con enanos y duergars.\n• Idioma. Conoces el idioma enano. Además, mientras tengas sintonización con el cinturón, tendrás un 50 % de probabilidad de que cada día al amanecer te crezca una barba completa, si puedes tenerla. Si ya tienes una, se volverá más densa.\n\nSi no eres enano o duergar, obtendrás los siguientes beneficios adicionales mientras lleves puesto el cinturón:\n\n• Resistencia. Tienes resistencia al daño de veneno. También tienes ventaja en las tiradas de salvación para evitar o poner fin al estado de envenenado.\n• Visión en la oscuridad. Tienes visión en la oscuridad hasta 60 pies.",
    "id": "magic_cinturon_enano"
  },
  {
    "name": "COLGANTE DE INMUNIDAD AL VENENO",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Esta elegante cadena de plata tiene un colgante con una gema negra de talla brillante. Mientras lo lleves puesto, tendrás inmunidad al estado de envenenado y al daño de veneno.",
    "id": "magic_colgante_de_inmunidad_al_veneno"
  },
  {
    "name": "COLLAR DE ADAPTACIÓN",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Mientras lleves este collar, puedes respirar con normalidad en cualquier entorno y tienes ventaja en las tiradas de salvación para evitar o poner fin al estado de envenenado.",
    "id": "magic_collar_de_adaptacion"
  },
  {
    "name": "COLLAR DE BOLAS DE FUEGO",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "No",
    "description": "De este collar cuelgan 1d6 + 3 cuentas. Puedes emplear una acción de magia para tirar una de estas cuentas a un punto a 60 pies o menos de distancia. Cuando llegue al final de su trayectoria, la cuenta explotará como un conjuro bola de fuego de nivel 3 (CD de salvación 15). Puedes arrojar varias cuentas o incluso todo el collar a la vez. Si lo haces, aumenta el daño de la bola de fuego en 1d6 por cada cuenta lanzada tras la primera (máximo 12d6).",
    "id": "magic_collar_de_bolas_de_fuego"
  },
  {
    "name": "COLLAR DE PLEGARIAS",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "Sí (requiere sintonización con un clérigo, druida o paladín)",
    "description": "Este collar tiene 1d4 + 2 cuentas mágicas hechas de aguamarina, perla negra o topacio. También posee muchas cuentas no mágicas hechas de piedras como ámbar, citrino, coral, cuarzo, jade, perla o sanguino. Si se retira una cuenta mágica del collar, esta pierde su magia. Existen seis tipos de cuentas mágicas. Tu GM decide el tipo de cada cuenta o lo determina al azar tirando en la tabla a continuación. Un collar puede tener más de una cuenta del mismo tipo. Para usar una, debes llevar puesto el collar. Cada cuenta alberga un conjuro que puedes lanzar desde ella como acción adicional (usa tu CD de salvación de conjuros si fuera necesaria una tirada de salvación). Una vez que se lanza el conjuro de una cuenta mágica, esa cuenta no puede volver a usarse hasta el siguiente amanecer.",
    "tables": [
      {
        "title": "Cuenta Conjuro",
        "columns": [
          "Resultado",
          "Efecto"
        ],
        "rows": [
          [
            "1–2",
            "Cuenta castigadora Castigo brillante"
          ],
          [
            "3–8",
            "Cuenta curativa Curar heridas (versión de nivel 2)"
          ],
          [
            "9–14",
            "Cuenta de bendición Bendición 15 Cuenta de caminar vientos Viajar con el viento"
          ],
          [
            "16–19",
            "Cuenta de favor Restablecimiento mayor 20 Cuenta invocadora Guardián de la fe"
          ]
        ]
      }
    ],
    "id": "magic_collar_de_plegarias"
  },
  {
    "name": "COTA DE ESCAMAS DE DRAGÓN",
    "category": "Armadura",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Una cota de escamas de dragón está hecha con las escamas de un dragón de un tipo concreto. A veces, los dragones recogen las escamas que se les caen para regalarlas. Otras veces, un cazador preserva cuidadosamente la piel de un cadáver de dragón. En cualquier caso, una cota de escamas de dragón es muy valiosa. Mientras lleves esta armadura, obtendrás un bonificador de +1 a la clase de armadura, tendrás ventaja en tiradas de salvación contra los ataques de aliento de los dragones y tendrás resistencia contra un tipo de daño determinado por el dragón que proporcionó las escamas (consulta la tabla a continuación). Además, puedes concentrar tus sentidos como acción de magia y discernir la distancia y la dirección del dragón más cercano que esté a 30 mi o menos de ti y sea del mismo tipo que la armadura. Esta acción no puede volver a emplearse hasta el siguiente amanecer.",
    "subcategory": "Armadura (cota de escamas)",
    "tables": [
      {
        "title": "Cota de escamas de dragón",
        "columns": [
          "Dragón",
          "Resistencia"
        ],
        "rows": [
          [
            "Azul",
            "Relámpago"
          ],
          [
            "Blanco",
            "Frío"
          ],
          [
            "Bronce",
            "Relámpago"
          ],
          [
            "Cobre",
            "Ácido"
          ],
          [
            "Negro",
            "Ácido"
          ],
          [
            "Oro",
            "Fuego"
          ],
          [
            "Oropel",
            "Fuego"
          ],
          [
            "Plata",
            "Frío"
          ],
          [
            "Rojo",
            "Fuego"
          ],
          [
            "Verde",
            "Veneno"
          ]
        ]
      }
    ],
    "id": "magic_cota_de_escamas_de_dragon"
  },
  {
    "name": "CUBO DE FUERZA",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Este cubo mide aproximadamente 1 pulgada de lado. Cada cara tiene un signo específico. Puedes pulsar una de las caras del cubo y gastar el número correspondiente de cargas para lanzar el conjuro asociado a ella (CD de salvación 17), como se muestra en la tabla. El cubo comienza con 10 cargas y recupera 1d6 cargas empleadas cada día, al amanecer.",
    "tables": [
      {
        "title": "Conjuros del cubo de fuerza",
        "columns": [
          "Clave",
          "Valor"
        ],
        "rows": [
          [
            "Armadura de mago",
            "1"
          ],
          [
            "Escudo",
            "1"
          ],
          [
            "Pequeña choza",
            "3"
          ],
          [
            "Esfera elástica",
            "4"
          ],
          [
            "Sanctasanctórum privado",
            "4"
          ],
          [
            "Muro de fuerza",
            "5"
          ]
        ]
      }
    ],
    "id": "magic_cubo_de_fuerza"
  },
  {
    "name": "CUENCO PARA CONTROLAR ELEMENTALES DE AGUA",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Mientras este cuenco esté lleno de agua y estés a 5 pies o menos de él, puedes emplear una acción de magia para invocar un elemental de agua. El elemental aparece en un espacio sin ocupar lo más cerca posible del cuenco, entiende tus idiomas, obedece tus órdenes y juega su turno inmediatamente después de ti en tu orden de iniciativa. El elemental desaparecerá tras 1 hora, cuando muera o si lo desconvocas como acción adicional. El cuenco no puede volver a emplearse de esta manera hasta el siguiente amanecer. El cuenco tiene aproximadamente 12 pulgadas de diámetro, la mitad de profundidad y puede contener unos 3,2 gal de líquido.",
    "id": "magic_cuenco_para_controlar_elementales_de_agua"
  },
  {
    "name": "CUERDA DE ESCALADA",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Esta cuerda de 60 pies puede soportar hasta 3000 lb de peso. Mientras sujetas un extremo de la cuerda, puedes emplear una acción de magia para ordenarle al otro extremo que cobre vida y avance hacia un destino de tu elección situado a una distancia máxima de ti igual a la longitud de la cuerda. Ese extremo se moverá 10 pies en tu turno cuando le des la orden por primera vez y 10 pies al principio de cada uno de tus siguientes turnos hasta que llegue a su destino o hasta que le mandes parar. También puedes ordenar a la cuerda que se ate de forma segura a un objeto, se desate, se anude o se desanude, o se enrolle para transportarla. Si le ordenas que se anude, se formarán unos nudos grandes en intervalos de 12 pulgadas a lo largo de la cuerda. Mientras esté anudada, la cuerda reduce su longitud a 50 pies y otorga ventaja en las pruebas de característica que se realicen para escalarla. La cuerda tiene una CA de 20, 20 pg e inmunidad al daño psíquico y de veneno. Recupera 1 punto de golpe cada 5 minutos mientras tenga al menos 1 punto de golpe. Si los puntos de golpe de la cuerda se reducen a 0, se destruye.",
    "peso": 3307,
    "id": "magic_cuerda_de_escalada"
  },
  {
    "name": "CUERDA ENREDADORA",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Esta cuerda mide 30 pies de largo. Mientras sujetas uno de los extremos, puedes emplear una acción de magia para ordenarle al otro que salga volando y enrede a una criatura que puedas ver a 20 pies o menos de ti. El objetivo deberá superar una tirada de salvación de Destreza con CD 15 o tendrá el estado de apresado. Puedes liberar al objetivo soltando tu extremo de la cuerda, lo que hará que se enrolle en el espacio del objetivo, o usando una acción adicional para repetir la orden, lo que hará que la cuerda se enrolle en tu mano. Un objetivo apresado por la cuerda puede usar una acción para hacer una prueba de Fuerza (Atletismo) o de Destreza (Acrobacias) con CD 15, a su elección. Si la supera, el objetivo dejará de estar apresado por la cuerda. Si todavía sostienes la cuerda cuando un objetivo se zafe de ella, podrás emplear una reacción para ordenarle a la cuerda que se enrolle en tu mano. Si no lo haces, se enrollará en el espacio del objetivo. La cuerda tiene una CA de 20, 20 pg e inmunidad al daño psíquico y de veneno. Recupera 1 punto de golpe cada 5 minutos mientras tenga al menos 1 punto de golpe. Si los puntos de golpe de la cuerda se reducen a 0, se destruye.",
    "id": "magic_cuerda_enredadora"
  },
  {
    "name": "CUERNO DE ESTALLIDO",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Puedes emplear una acción de magia para soplar este cuerno, que emitirá un estallido estruendoso en un cono de 30 pies audible a 600 pies de distancia. Todas las criaturas situadas en el cono harán una tirada de salvación de Constitución con CD 15. Si la fallan, sufrirán 5d8 de daño de trueno y tendrán el estado de ensordecidas durante 1 minuto. Si la superan, solo sufrirán la mitad de ese daño. Los objetos de cristal o de vidrio que nadie vista o lleve en el cono recibirán 10d8 de daño de trueno. Cada uso de la magia del cuerno tiene un 20 % de probabilidad de hacerlo explotar. La explosión inflige 10d6 de daño de fuerza a quien lo utiliza y destruye el cuerno.",
    "id": "magic_cuerno_de_estallido"
  },
  {
    "name": "CUERNO DEL VALHALLA",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Puedes emplear una acción de magia para soplar este cuerno. Acudiendo a tu llamada, varios espíritus guerreros del plano de Ysgard aparecerán en espacios sin ocupar a 60 pies o menos de ti. Todos emplean el perfil del berserker y vuelven a Ysgard después de 1 hora o cuando sus puntos de golpe se reduzcan a 0. Los espíritus parecen guerreros vivos de verdad y tienen inmunidad a los estados de asustados y hechizados. Una vez que utilices el cuerno, no podrás volver a usarlo hasta que hayan pasado 7 días. Se conoce la existencia de cuatro tipos de cuerno del Valhalla, cada uno hecho de un metal distinto. El tipo de cuerno determina cuántos espíritus responden a su llamada, así como el requisito para utilizarlo. Tu GM elige el tipo de cuerno o lo determina al azar tirando en la tabla a continuación. Si soplas el cuerno sin cumplir su requisito, los espíritus invocados te atacarán. Si cumples el requisito, serán amistosos contigo y tus aliados y seguirán tus órdenes.",
    "tables": [
      {
        "title": "Tipo de cuerno Espíritus Requisito",
        "columns": [
          "Resultado",
          "Efecto"
        ],
        "rows": [
          [
            "01–40",
            "Plata 2 Ninguno"
          ],
          [
            "41–75",
            "Latón 3 Competencia con todas las armas sencillas"
          ],
          [
            "76–90",
            "Bronce 4 Entrenamiento con todas las armaduras medias"
          ],
          [
            "91–00",
            "Hierro 5 Competencia con todas las armas marciales"
          ]
        ]
      }
    ],
    "id": "magic_cuerno_del_valhalla"
  },
  {
    "name": "CUERO TACHONADO ENCANTADO",
    "category": "Armadura",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Mientras lleves esta armadura, obtendrás un bonificador de +1 a la clase de armadura. También puedes usar una acción adicional para hacer que la armadura adopte el aspecto de una vestimenta normal o de otro tipo de armadura. Tú decides su apariencia, incluidos el color, estilo y accesorios, pero la armadura mantiene su peso y tamaño normales. La apariencia ilusoria dura hasta que emplees esta propiedad de nuevo o te quites la armadura.",
    "subcategory": "Cualquiera (armadura)",
    "id": "magic_cuero_tachonado_encantado"
  },
  {
    "name": "DAGA DE LA PONZOÑA",
    "category": "Arma",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Recibes un bonificador de +1 a las tiradas de ataque y de daño que hagas con esta arma mágica. Puedes usar una acción adicional para que un veneno cubra mágicamente la hoja. El veneno permanecerá durante 1 minuto o hasta que un ataque con esta arma acierte a una criatura. Esa criatura deberá superar una tirada de salvación de Constitución con CD 15 o recibirá 2d10 de daño de veneno y tendrá el estado de envenenada durante 1 minuto. El arma no puede volver a emplearse de esta manera hasta el siguiente amanecer.",
    "subcategory": "Arma (daga)",
    "id": "magic_daga_de_la_ponzona"
  },
  {
    "name": "DAGA DE LAS SOMBRAS LATENTES",
    "category": "Arma",
    "rarity": "Muy rara",
    "attunement": "Sí",
    "description": "Esta daga mágica +2 está envuelta en una penumbra tenue que se arremolina en torno a su hoja. Recibes un bonificador de +2 a las tiradas de ataque y de daño que hagas con ella. Esta arma causa 1d6 de daño perforante al impactar, más 1d6 de daño necrótico adicional. Además, si realizas la tirada de ataque con ventaja, el objetivo recibe 1d6 adicional del daño del arma al acertar.",
    "subcategory": "Arma (daga)",
    "id": "magic_daga_de_las_sombras_latentes"
  },
  {
    "name": "DECANTADOR DE AGUA INTERMINABLE",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Este frasco con tapón suena cuando se agita, como si tuviera agua dentro. Pesa 5 lb. Puedes utilizar una acción de magia para retirar el tapón y pronunciar una de las tres palabras de activación. A continuación, cierta cantidad de agua dulce o salada (a tu elección) saldrá del frasco. El agua dejará de salir al principio de tu siguiente turno.\n\nElige una de las siguientes palabras de activación:\n\n• Salpicadura. El decantador produce 1,1 gal de agua.\n• Fuente. El decantador produce 5,3 gal de agua.\n• Géiser. El decantador produce 31,7 gal de agua que salen disparados en una línea de 30 pies de largo y 12 pulgadas de ancho. Si sostienes el decantador, puedes apuntar el géiser en una dirección (no requiere acción). Una criatura de tu elección en esa línea deberá superar una tirada de salvación de Fuerza con CD 13 o sufrirá 1d4 de daño contundente y tendrá el estado de derribada. En vez de una criatura, puedes apuntar a un objeto en esa línea que no lleve ni vista nadie y que no pese más de 200 lb. El géiser derribará ese objeto.",
    "peso": 5,
    "id": "magic_decantador_de_agua_interminable"
  },
  {
    "name": "DEFENSORA",
    "category": "Arma",
    "rarity": "Legendario",
    "attunement": "Sí",
    "description": "Recibes un bonificador de +3 a las tiradas de ataque y de daño que hagas con esta arma mágica. La primera vez que ataques con el arma en cada uno de tus turnos, puedes transferir total o parcialmente su bonificador a tu clase de armadura. Por ejemplo, puedes reducir el bonificador a tus tiradas de ataque y de daño a +1 y obtener un bonificador de +2 a la clase de armadura. Los bonificadores ajustados permanecen en vigor hasta el principio de tu siguiente turno, aunque debes empuñar el arma para aprovechar el bonificador a la CA que confiere.",
    "subcategory": "Arma (cualquier arma cuerpo a cuerpo)",
    "id": "magic_defensora"
  },
  {
    "name": "DIADEMA DE ESTALLIDOS",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Mientras lleves puesta esta diadema, puedes lanzar rayo abrasador desde ella (+5 a acertar). La diadema no podrá volver a lanzar este conjuro hasta el siguiente amanecer.",
    "id": "magic_diadema_de_estallidos"
  },
  {
    "name": "DIADEMA DE INTELECTO",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Tu Inteligencia es de 19 mientras lleves esta diadema. No tiene efecto si tu Inteligencia es de 19 o más sin ella.",
    "id": "magic_diadema_de_intelecto"
  },
  {
    "name": "DISOLVENTE UNIVERSAL",
    "category": "Objeto maravilloso",
    "rarity": "Legendario",
    "attunement": "No",
    "description": "Este tubo contiene un líquido lechoso con un fuerte olor a alcohol. En el momento de encontrar el tubo, contendrá 1 lb + 1d6 × 1 lb. Puedes emplear una acción de utilizar para verter 1 lb o más de disolvente en una superficie dentro del alcance. Con cada 1 lb se disolverán de manera instantánea hasta 1,1 pie cuadrado de adhesivo que toque, incluido el pegamento soberano.",
    "id": "magic_disolvente_universal"
  },
  {
    "name": "ECO DE SERYNDRA",
    "category": "Objeto maravilloso",
    "rarity": "Artefacto",
    "attunement": "S? (no puedes desintonizarte)",
    "description": "Un antiguo legado arcano ligado a la conciencia de Seryndra. Su presencia se manifiesta como una mente espectral que guía, protege y canaliza magia a través de un eco elevado entre lo incorpóreo y lo tangible.\n\n• Ascender eco. Como acción adicional, puedes ascender el eco de Seryndra a una forma corpórea durante 1 minuto o puedes usar otra acción adicional para terminar su efecto y devolverlo a su forma incorpórea. Esta transformación puede usarse tantas veces como tu bonificador por competencia y recupera 1d4 usos cada día. El eco tiene una CA igual a 10 + tu bonificador por competencia y una cantidad de puntos de golpe igual a 5 por tu nivel. Si sus puntos de golpe llegan a 0, el eco desaparecerá, al igual que tu Manifestar mente. Durante esta transformación, puedes usar tu acción adicional para mover al eco y usar su reacción. Si no le das órdenes, el eco se pondrá en modo defensivo. El eco tiene una velocidad volando de 60 pies, es inmune a los estados de envenenado, hechizado y asustado, y cualquier tirada que haga usa tus características. Mientras está ascendido, el eco puede usar las siguientes reacciones: Lanzar truco, que te permite lanzar un truco a través del eco; y Repartir daño, que te permite, al recibir daño, transferir la mitad al eco. Repartir daño solo puede usarse una vez por descanso corto. Además, puedes lanzar Jaula de fuerza sin necesidad de componentes una vez por descanso largo.\n• Grimorio arcano. Obtienes un bonificador mágico de +1 a la CD de salvación de tus conjuros.\n• Eco de Seryndra. Tu Manifestar mente pasa a ser la mente de Seryndra. Mientras esté invocado, tienes ventaja en tus tiradas de Percepción y puedes hablar a través de él.",
    "id": "magic_eco_de_seryndra"
  },
  {
    "name": "ELIXIR DE SALUD",
    "category": "Poción",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Cuando bebes esta poción, te curas de cualquier enfermedad mágica. Además, dejarás de sufrir los estados de cegado, ensordecido, envenenado y paralizado. El líquido rojo claro tiene pequeñas burbujas de luz.",
    "id": "magic_elixir_de_salud"
  },
  {
    "name": "ESCARABAJO PROTECTOR",
    "category": "Objeto maravilloso",
    "rarity": "Legendario",
    "attunement": "Sí",
    "description": "Este medallón con forma de escarabajo proporciona tres beneficios mientras lo lleves contigo.\n\n• Defensa. Recibes un bonificador de +1 a la clase de armadura.\n• Preservación. El escarabajo tiene 12 cargas. Si fallas una tirada de salvación contra un conjuro de nigromancia o un efecto dañino de un muerto viviente, podrás utilizar una reacción y emplear 1 carga para superar la tirada de salvación. El escarabajo se convertirá en polvo y se destruirá cuando se haya empleado la última carga.\n• Resistencia a conjuros. Tienes ventaja en las tiradas de salvación contra conjuros.",
    "id": "magic_escarabajo_protector"
  },
  {
    "name": "ESCOBA VOLADORA",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Esta escoba de madera funcionará como una escoba normal hasta que te montes en ella y emplees una acción de magia para hacerla levitar. En ese momento, podrás utilizarla para viajar por el aire. Tiene una velocidad volando de 50 pies. Puede transportar hasta 400 lb, pero su velocidad volando se reduce a 30 pies si transporta más de 200 lb. La escoba deja de levitar cuando aterrizas o cuando dejes de montar en ella. Como acción de magia, puedes ordenarle que viaje por sí misma a un lugar que esté a 1 mi o menos de ti si nombras el lugar y conoces el sitio en cuestión. Si sigue estando a 1 mi o menos de ti, la escoba volverá si empleas otra acción de magia y pronuncias una palabra de activación.",
    "id": "magic_escoba_voladora"
  },
  {
    "name": "ESCUDO +1",
    "category": "Armadura",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Mientras lleves embrazado este escudo, obtienes un bonificador de +1 a la CA, además del bonificador a la CA normal del escudo.",
    "subcategory": "Escudo",
    "id": "magic_escudo_1"
  },
  {
    "name": "ESCUDO +2",
    "category": "Armadura",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Mientras lleves embrazado este escudo, obtienes un bonificador de +2 a la CA, además del bonificador a la CA normal del escudo.",
    "subcategory": "Escudo",
    "id": "magic_escudo_2"
  },
  {
    "name": "ESCUDO +3",
    "category": "Armadura",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Mientras lleves embrazado este escudo, obtienes un bonificador de +3 a la CA, además del bonificador a la CA normal del escudo.",
    "subcategory": "Escudo",
    "id": "magic_escudo_3"
  },
  {
    "name": "ESCUDO ANIMADO",
    "category": "Armadura",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Mientras lleves embrazado este escudo, puedes emplear una acción adicional para darle vida. El escudo saltará de tu mano y levitará en tu espacio para protegerte como si lo embrazaras, pero dejará tus manos libres. Permanecerá animado durante 1 minuto, hasta que utilices una acción adicional para poner fin a este efecto o hasta que tengas el estado de incapacitado o mueras, momento en el que el escudo caerá al suelo o en tu mano si tienes una libre.",
    "subcategory": "Escudo",
    "id": "magic_escudo_animado"
  },
  {
    "name": "ESCUDO ATRAPAFLECHAS",
    "category": "Armadura",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Mientras embraces este escudo, obtienes un bonificador de +2 a la clase de armadura contra las tiradas de ataque a distancia. Este bonificador se suma al bonificador a la CA normal del escudo. Cuando una criatura realice una tirada de ataque a distancia contra un objetivo que esté a 5 pies o menos de ti, podrás usar una reacción para convertirte en el objetivo del ataque.",
    "subcategory": "Escudo",
    "id": "magic_escudo_atrapaflechas"
  },
  {
    "name": "ESCUDO CENTINELA",
    "category": "Armadura",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Mientras lleves embrazado este escudo, tienes ventaja en las tiradas de iniciativa y en las pruebas de Sabiduría (Percepción). El blasón que lo adorna posee el símbolo de un ojo.",
    "subcategory": "Escudo",
    "id": "magic_escudo_centinela"
  },
  {
    "name": "ESCUDO DE ATRAER PROYECTILES",
    "category": "Armadura",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Mientras empuñes este escudo, tienes resistencia al daño de los ataques a distancia con armas.",
    "subcategory": "Escudo",
    "maldicion": "Este escudo está maldito. Esta maldición solo se revela cuando se lanza el conjuro identificar sobre el escudo o te sintonizas con él. Al sintonizarte con el escudo, no puedes dejar de empuñarlo hasta que seas el objetivo del conjuro levantar maldición u otro efecto mágico similar. Mientras estés maldito, los ataques a distancia con armas dirigidos contra criaturas a 10 pies o menos de ti te tendrán como objetivo en su lugar.",
    "id": "magic_escudo_de_atraer_proyectiles"
  },
  {
    "name": "ESCUDO DE CABALLERO",
    "category": "Armadura",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Mientras lleves embrazado este escudo, tendrás un bonificador de +2 a la clase de armadura. Este bonificador se suma al bonificador a la CA normal del escudo. El escudo tiene las siguientes propiedades adicionales que puedes usar mientras lo lleves embrazado.\n\n• Campo protector. Como reacción, cuando tú o un aliado que puedas ver a 5 pies o menos de ti seáis el objetivo de un ataque o hagáis una tirada de salvación contra un área de efecto, puedes usar el escudo para crear una emanación inmóvil de 5 pies que se origina en ti. Cuando aparezca la emanación, las criaturas u objetos que no estén completamente en su interior se verán empujados a los espacios sin ocupar más cercanos fuera de ella. El ataque o área de efecto que provocó la reacción no tendrá efecto sobre las criaturas y objetos dentro de la emanación, que durará mientras mantengas la concentración, hasta 1 minuto. Nada puede entrar ni salir de la emanación. Una criatura o un objeto en su interior no puede sufrir daño por ataques o efectos que se originen en el exterior y tampoco puede dañar a nada que haya fuera de la emanación. Una vez utilizada, esta propiedad no puede volver a usarse hasta el siguiente amanecer.\n• Golpe contundente. Cuando emplees la acción de atacar, puedes hacer una de las tiradas de ataque usando el escudo contra un objetivo a 5 pies o menos de ti. Aplica tu bonificador por competencia y modificador por Fuerza a la tirada de ataque. Si acierta, el escudo causa una cantidad de daño de fuerza al objetivo igual a 2d6 + 2 más tu modificador por Fuerza y, si el objetivo es una criatura, puedes empujarla hasta 10 pies respecto a ti. Si la criatura es de tu tamaño o más pequeña, también puedes imponerle el estado de derribada.",
    "subcategory": "Escudo",
    "id": "magic_escudo_de_caballero"
  },
  {
    "name": "ESCUDO DE GUARDA CONTRA CONJUROS",
    "category": "Armadura",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Mientras lleves embrazado este escudo, tendrás ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos, y las tiradas de ataque de conjuro tendrán desventaja contra ti.",
    "subcategory": "Escudo",
    "id": "magic_escudo_de_guarda_contra_conjuros"
  },
  {
    "name": "ESCUDO DE REPULSIÓN",
    "category": "Armadura",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Mientras lleves embrazado este escudo, obtienes un bonificador de +1 a la clase de armadura.\n\nEl escudo tiene 4 cargas. Mientras lo sostengas, cuando una criatura Grande o más pequeña a 5 pies o menos de ti te acierte con una tirada de ataque cuerpo a cuerpo, puedes emplear una reacción para gastar 1 de las cargas del escudo y empujar al atacante hasta 15 pies en línea recta alejándolo de ti. El escudo recupera 1d4 cargas empleadas cada día, al amanecer.",
    "subcategory": "Escudo",
    "id": "magic_escudo_de_repulsion"
  },
  {
    "name": "ESFERA DE ANIQUILACIÓN",
    "category": "Objeto maravilloso",
    "rarity": "Legendario",
    "attunement": "No",
    "description": "Esta esfera negra de 2 pies de diámetro es un agujero en el multiverso que levita en el espacio y que permanece estabilizado gracias a un campo mágico que lo rodea. La esfera aniquila toda la materia que atraviesa y que la atraviesa. La única excepción son los artefactos, que la atravesarán intactos salvo que sean susceptibles al daño de una esfera de aniquilación. Cualquier otra cosa que toque la esfera sin ser completamente absorbida y aniquilada por ella sufrirá 8d10 de daño de fuerza. Controlar la esfera. Una esfera de aniquilación permanece inmóvil hasta que alguien tome el control sobre ella. Si estás a 60 pies o menos de una esfera, podrás utilizar una acción de magia para realizar una prueba de Inteligencia (Conocimiento arcano) con CD 25. Si la superas, controlarás la esfera hasta el principio de tu siguiente turno, y si estaba bajo el control de otra criatura, esa criatura dejará de controlarla. Si fallas la prueba, la esfera se moverá 10 pies hacia ti en línea recta. Mientras controles la esfera, puedes emplear una acción adicional para hacer que se mueva en la dirección que elijas hasta una cantidad de pies igual a 5 × tu modificador por Inteligencia (mínimo 5 pies). Si la esfera entra en el espacio de una criatura, esta deberá superar una tirada de salvación de Destreza con CD 19 o la esfera la tocará y le infligirá 8d10 de daño de fuerza. Una criatura cuyos puntos de golpe se reduzcan a 0 por este daño será aniquilada, dejando atrás únicamente sus posesiones. Interacciones de la esfera. Si la esfera entra en contacto con un portal interplanar, como el que crea un conjuro portal, o un espacio extradimensional, como el que contiene un agujero portátil, tu GM determinará al azar lo que ocurrirá usando la siguiente tabla.",
    "tables": [
      {
        "title": "Resultado",
        "columns": [
          "Resultado",
          "Efecto"
        ],
        "rows": [
          [
            "01–50",
            "La esfera se destruye."
          ],
          [
            "51–85",
            "La esfera atraviesa el portal o entra en el espacio extradimensional."
          ],
          [
            "86–00",
            "Una grieta en el espacio envía la esfera y a todas las criaturas y objetos que se encuentren a 180 pies o menos de ella a un plano de existencia aleatorio."
          ]
        ]
      }
    ],
    "id": "magic_esfera_de_aniquilacion"
  },
  {
    "name": "ESPADA DANZARINA",
    "category": "Arma",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Puedes emplear una acción adicional para lanzar esta arma mágica al aire. Cuando lo hagas, el arma comenzará a levitar, volará hasta 30 pies y atacará a una criatura de tu elección que esté a 5 pies o menos de ella. El arma utiliza tu tirada de ataque y añade tu modificador por característica a las tiradas de daño. Mientras el arma esté levitando, podrás emplear una acción adicional para que vuele hasta 30 pies hacia otro lugar situado a 30 pies o menos de ti. Como parte de la misma acción adicional, podrás hacer que el arma ataque a una criatura situada a 5 pies o menos de ella. Después de que el arma flotante ataque por cuarta vez, volará hacia ti e intentará volver a tu mano. Si no tienes ninguna mano libre, caerá al suelo a tus pies. Si el arma tiene vía libre hasta ti, se te acercará todo lo que pueda y después caerá al suelo. También dejará de levitar si la agarras o si te alejas más de 30 pies de ella.",
    "subcategory": "Arma (cualquiera sencilla o marcial)",
    "id": "magic_espada_danzarina"
  },
  {
    "name": "ESPADA DE HOJA AFILADA",
    "category": "Arma",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Cuando ataques a un objeto con esta arma mágica y aciertes, toma el resultado máximo de los dados de daño del arma contra el objetivo. Cuando ataques a una criatura con esta arma y saques un 20 en la tirada de ataque con el d20, el objetivo sufrirá 14 de daño cortante adicional y sumará 1 nivel de cansancio.",
    "subcategory": "Arma (cimitarra, espada larga, espadón o guja)",
    "id": "magic_espada_de_hoja_afilada"
  },
  {
    "name": "ESPADA HIRIENTE",
    "category": "Arma",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Cuando aciertes a una criatura con un ataque usando esta arma mágica, el objetivo recibirá 2d6 de daño necrótico adicional y deberá superar una tirada de salvación de Constitución con CD 15 o no podrá recuperar puntos de golpe durante 1 hora. El objetivo repetirá la tirada de salvación al final de cada uno de sus turnos y, si tiene éxito, se librará del efecto.",
    "subcategory": "Arma (cimitarra, espada corta, espada larga, espadón, estoque o guja)",
    "id": "magic_espada_hiriente"
  },
  {
    "name": "ESPADA LADRONA DE VIDA",
    "category": "Arma",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Cuando ataques a una criatura con esta arma mágica y saques un 20 en la tirada de ataque con el d20, el objetivo sufrirá 15 de daño necrótico adicional si no es un autómata o un muerto viviente. Además, tú obtendrás una cantidad de puntos de golpe temporales igual al daño necrótico causado.",
    "subcategory": "Arma (cimitarra, espada corta, espada larga, espadón, estoque o guja)",
    "id": "magic_espada_ladrona_de_vida"
  },
  {
    "name": "ESPADA SOLAR",
    "category": "Arma",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Este objeto parece una empuñadura de espada.\n\n• Hoja de resplandor. Mientras la agarras, puedes usar una acción adicional para hacer que brote o desaparezca de ella una hoja de puro resplandor. Mientras la hoja exista, esta arma mágica funciona como una espada larga con la propiedad \"sutil\". Si eres competente con espadas cortas o largas, serás competente con la espada solar. Recibes un bonificador de +2 a las tiradas de ataque y de daño realizadas con esta arma, que causa daño radiante en vez de daño cortante. Cuando aciertes a un muerto viviente con ella, el objetivo recibirá 1d8 de daño radiante adicional.\n• Luz solar. La hoja luminosa de la espada emite luz brillante en un radio de 15 pies y luz tenue 15 pies más allá. Esta luz es luz solar. Mientras esté la hoja, podrás emplear una acción de magia para ampliar o reducir el radio de la luz brillante y tenue en 5 pies respectivamente, hasta un máximo de 30 pies o un mínimo de 10 pies cada una.",
    "subcategory": "Arma (espada larga)",
    "id": "magic_espada_solar"
  },
  {
    "name": "ESPADA VORPAL",
    "category": "Arma",
    "rarity": "Legendario",
    "attunement": "Sí",
    "description": "Recibes un bonificador de +3 a las tiradas de ataque y de daño que hagas con esta arma mágica. Además, el arma ignora la resistencia al daño cortante. Cuando uses esta arma para atacar a una criatura que tenga al menos una cabeza y saques un 20 en la tirada de ataque con el d20, cortarás una de las cabezas de esa criatura. La criatura muere si no puede sobrevivir sin la cabeza perdida. Una criatura es inmune a este efecto si tiene inmunidad al daño cortante, si no tiene o no necesita una cabeza o si tu GM decide que la criatura es demasiado grande como para que esta arma le corte la cabeza. En su lugar, una criatura así recibirá 30 de daño cortante adicional por el ataque. Si la criatura tiene el atributo Resistencia legendaria, puede gastar un uso diario para evitar perder la cabeza y, en vez de eso, recibir el daño adicional.",
    "subcategory": "Arma (cualquiera sencilla o marcial)",
    "id": "magic_espada_vorpal"
  },
  {
    "name": "ESPEJO ATRAPAVIDAS",
    "category": "Objeto maravilloso",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Cuando se mira de forma indirecta este espejo de 4 pies de altura y 2 pies de ancho, su superficie muestra imágenes tenues de criaturas. El espejo pesa 55 lb y tiene una CA de 11, 10 pg, inmunidad al daño psíquico y de veneno y vulnerabilidad al daño contundente. Se hace pedazos y se destruye cuando sus puntos de golpe se reducen a 0. Si el espejo cuelga de una superficie vertical y estás a 5 pies o menos de él, puedes emplear una acción de magia y usar una palabra de activación. Permanecerá activo hasta que emplees una acción de magia y repitas la palabra de activación para desactivarlo. Si una criatura distinta de ti ve su reflejo en el espejo activado a 30 pies o menos de él, deberá superar una tirada de salvación de Carisma con CD 15 o quedará atrapada, junto con todo lo que vista o lleve, en una de las doce celdas extradimensionales del espejo. Una criatura que conozca la naturaleza del espejo hará la tirada con ventaja y los autómatas la superarán automáticamente. Una celda extradimensional es una extensión infinita cubierta por una espesa niebla que impide ver a más de 10 pies de distancia. Las criaturas atrapadas en las celdas del espejo no envejecen y no necesitan ni comer ni beber ni dormir. Pueden escapar de la celda si utilizan magia que les permita viajar entre planos. De lo contrario, quedarán confinadas en la celda hasta que las liberen. Si el espejo atrapa a una criatura, pero sus doce celdas extradimensionales están ya ocupadas, liberará a una criatura atrapada al azar para alojar al nuevo prisionero. La criatura liberada aparecerá en un espacio sin ocupar a la vista del espejo, pero de espaldas a él. Si se destruye el espejo, todas las criaturas que contenga se liberarán y aparecerán en espacios sin ocupar cerca de él. Mientras te encuentres a 5 pies o menos del espejo, podrás emplear una acción de magia nombrar a una criatura atrapada o el número de una celda concreta. La criatura mencionada o la que contenga la celda nombrada aparecerá como una imagen en la superficie del espejo. La criatura y tú os podréis comunicar. De forma similar, puedes emplear una acción de magia y usar una segunda palabra de activación para liberar a una criatura atrapada en el espejo. La criatura liberada aparecerá junto a sus posesiones en el espacio sin ocupar más cercano al espejo, pero de espaldas a él. Meter el espejo en el espacio extradimensional creado por un agujero portátil, una bolsa de contención o un objeto similar destruye instantáneamente ambos objetos y abre un portal al Plano Astral. El portal se crea en el sitio en el que un objeto se introdujo dentro del otro. El portal absorbe a todas las criaturas situadas a 10 pies o menos de él y que no estén tras cobertura completa, y las conduce a un lugar aleatorio del Plano Astral. Después, el portal se cierra. El portal solo funciona en un sentido y no puede volver a abrirse.",
    "peso": 55,
    "id": "magic_espejo_atrapavidas"
  },
  {
    "name": "ESTOQUE DE MORTIA",
    "category": "Arma",
    "rarity": "Artefacto",
    "attunement": "Sí",
    "description": "Este fino estoque de plata brilla con una luz solemne y severa. Consagrado contra la oscuridad, hiere a los impuros con poder radiante y delata la cercanía de los no-muertos.\n\n• Luz diurna. Como acción adicional, haces que el estoque irradie luz solar hasta 10 pies. Tienes una cantidad de cargas igual a tu bonificador por competencia y todas las cargas se restauran al finalizar un descanso largo.\n• Arma mágica de plata. Recibes un bonificador mágico de +2 a las tiradas de ataque y de daño que hagas con esta arma mágica de plata.\n• Bendita. Tus ataques cuerpo a cuerpo con el estoque causan 1d6 de daño radiante adicional. Además, sientes la presencia de cualquier criatura no muerta que se encuentre a 60 pies de ti.",
    "subcategory": "Arma (estoque)",
    "id": "magic_estoque_de_mortia"
  },
  {
    "name": "FICHA DE PLUMA DE QUAAL",
    "category": "Objeto maravilloso",
    "rarity": "Rareza Variable",
    "attunement": "No",
    "description": "Este objeto parece una pluma. Existen diferentes tipos de fichas de pluma, cada uno con un efecto diferente de un solo uso. Tu GM elige el tipo de ficha o lo determina al azar tirando en la tabla. El tipo de ficha determina su rareza. Aabanico (infrecuente). Si te encuentras en un bote o barco, puedes emplear una acción de magia para tirar la ficha al aire hasta 10 pies de altura. La ficha desaparecerá y un abanico gigante en movimiento ocupará su lugar. El abanico flotará y creará un viento fuerte, que podrá henchir las velas de un barco y aumentar su velocidad en 5 mi/h durante 8 horas. Puedes desconvocar el abanico como acción de magia. Ancla (infrecuente). Puedes emplear una acción de magia para tocar un bote o barco con la ficha. Durante las próximas 24 horas, la embarcación no podrá moverse de ninguna manera. Volver a tocarla con la ficha pone fin al efecto. Cuando acabe el efecto, la ficha desaparece. Árbol (infrecuente). Debes estar al aire libre para poder usar esta ficha. Puedes emplear una acción de magia para tocar con la ficha un espacio sin ocupar del suelo. La ficha desaparecerá y un roble no mágico ocupará su lugar. El árbol mide 60 pies de alto, el diámetro de su tronco es de 5 pies y las ramas de su copa cubren un radio de 20 pies. Bote cisne (rara). Puedes emplear una acción de magia para tocar con la ficha una masa de agua de al menos 60 pies de diámetro. La ficha desaparecerá y un bote de 50 pies de largo y 20 pies de ancho con la forma de un cisne ocupará su lugar. El bote se autopropulsa y se desplaza por el agua a una velocidad de 6 mi/h. Puedes emplear una acción de magia mientras te encuentres en el bote para ordenarle moverse o girar hasta 90 grados. El bote permanece durante 24 horas y después desaparece. Puedes desconvocar el bote como acción de magia. Látigo (rara). Puedes emplear una acción de magia para tirar la ficha a 10 pies o menos de ti. La ficha desaparecerá y un látigo flotante ocupará su lugar. A continuación, podrás utilizar una acción adicional para realizar un ataque de conjuro cuerpo a cuerpo contra una criatura que esté a 10 pies o menos del látigo, con un bonificador de ataque de +9. Si acierta, el objetivo recibe 1d6 + 5 de daño de fuerza. Como acción adicional, puedes mover el látigo hasta 20 pies y repetir el ataque contra una criatura que se encuentre a 10 pies o menos de él. El látigo desaparecerá tras 1 hora, cuando emplees una acción de magia para desconvocarlo, cuando mueras o cuando tengas el estado de incapacitado. Pájaro (rara). Puedes emplear una acción de magia para tirar la ficha al aire a 5 pies de altura. La ficha desaparecerá y un enorme pájaro multicolor ocupará su lugar. El pájaro tiene el perfil de un roc, pero no puede atacar. Obedece tus órdenes sencillas y puede transportar hasta 500 lb mientras vuela a su velocidad máxima o 1000 lb a la mitad de esa velocidad. El ave desaparece tras volar su distancia máxima durante un día o si sus puntos de golpe se reducen a 0. Puedes desconvocar al pájaro como acción de magia.",
    "tables": [
      {
        "title": "Símbolo Rareza",
        "columns": [
          "Resultado",
          "Efecto"
        ],
        "rows": [
          [
            "01–15",
            "Aabanico Infrecuente"
          ],
          [
            "16–35",
            "Ancla Infrecuente"
          ],
          [
            "36–60",
            "Árbol Infrecuente"
          ],
          [
            "61–75",
            "Bote cisne Rara"
          ],
          [
            "76–85",
            "Látigo Rara"
          ],
          [
            "86–00",
            "Pájaro Rara"
          ]
        ]
      }
    ],
    "id": "magic_ficha_de_pluma_de_quaal"
  },
  {
    "name": "FILO DE LA FORTUNA",
    "category": "Arma",
    "rarity": "Legendario",
    "attunement": "Sí",
    "description": "Recibes un bonificador de +1 a las tiradas de ataque y de daño que hagas con esta arma mágica. Mientras la lleves contigo, también obtendrás un bonificador de +1 a las tiradas de salvación.\n\n• Deseo. El arma tiene 1d3 cargas. Si la estás empuñando, puedes gastar 1 carga y lanzar deseo desde ella. Una vez utilizada, esta propiedad no puede volver a usarse hasta el siguiente amanecer. El arma pierde esta propiedad si no le quedan cargas.\n• Fortuna. Si llevas el arma contigo y si no tienes el estado de incapacitado, puedes recurrir a su fortuna (no requiere acción) para repetir una prueba con d20 fallida. Deberás usar el nuevo resultado. Una vez utilizada, esta propiedad no puede volver a usarse hasta el siguiente amanecer.",
    "subcategory": "Arma (cualquiera sencilla o marcial)",
    "id": "magic_filo_de_la_fortuna"
  },
  {
    "name": "FILTRO DE AMOR",
    "category": "Poción",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "La próxima vez que veas a una criatura en los 10 minutos posteriores a beber este filtro, quedarás embelesado por ella y tendrás el estado de hechizado durante 1 hora. El líquido efervescente y de tonalidad rosa contiene una burbuja, fácil de pasar por alto, con forma de corazón.",
    "id": "magic_filtro_de_amor"
  },
  {
    "name": "FLAUTA DE LA APARICIÓN",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Esta flauta tiene 3 cargas y recupera 1d3 cargas empleadas cada día, al amanecer. Puedes utilizar una acción de magia para tocarla y gastar 1 carga para crear una melodía inquietante a la vez que fascinante. Todas las criaturas de tu elección a 30 pies o menos de ti deberán superar una tirada de salvación de Sabiduría con CD 15 o tendrán el estado de asustadas durante 1 minuto. Las criaturas que fallen la tirada de salvación la repetirán al final de cada uno de sus turnos y, si la superan, se librarán del efecto. Las criaturas que superen la tirada serán inmunes al efecto de esta flauta durante 24 horas.",
    "id": "magic_flauta_de_la_aparicion"
  },
  {
    "name": "FLAUTA DE LAS CLOACAS",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Mientras lleves la flauta contigo, las ratas normales y las gigantes se mostrarán indiferentes hacia ti y no te atacarán a menos que las dañes o las amenaces. La flauta tiene 3 cargas y recupera 1d3 cargas empleadas cada día, al amanecer. Si empleas una acción de magia para tocarla, podrás utilizar una acción adicional y gastar entre 1 y 3 cargas para convocar siempre que haya suficientes ratas a 2460 pies o menos de ti para que las convoques de esta manera (según decida tu GM). Si no hay ratas suficientes para formar un enjambre, la carga se desperdiciará. Los enjambres convocados irán hacia la música por el camino más corto disponible, pero, por lo demás, no estarán bajo tu control. Cuando un enjambre de ratas que no esté bajo el control de otra criatura se acerque a 30 pies o menos de ti mientras estés tocando la flauta, el enjambre hará una tirada de salvación de Sabiduría con CD 15. Si la supera, el enjambre se comportará de forma normal y no caerá bajo el influjo de la música de la flauta durante las siguientes 24 horas. Si la falla, el enjambre caerá bajo el influjo de la música de la flauta y se volverá amistoso hacia tus aliados y tú mientras sigas tocando la flauta cada asalto como acción de magia. Un enjambre amistoso obedece tus órdenes. Si no le das ninguna orden a un enjambre amistoso, se defenderá, pero no realizará ninguna otra acción. Si un enjambre amistoso comienza su turno a más de 30 pies de ti, se acabará tu control sobre el enjambre, este se comportará de forma normal y no podrá caer bajo el influjo de la música de la flauta durante las siguientes 24 horas.",
    "id": "magic_flauta_de_las_cloacas"
  },
  {
    "name": "FORTALEZA INSTANTÁNEA DE DAERN",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Como acción de magia, puedes colocar esta estatuilla de adamantina de 1 pulgada en el suelo y pronunciar una palabra de activación para hacer que crezca rápidamente hasta convertirse en una torre cuadrada de adamantina. Si repites la palabra de activación, la torre volverá a convertirse en estatuilla, lo cual solo funciona si está vacía. Todas las criaturas en la zona donde aparece la torre son empujadas a un espacio sin ocupar junto a la torre, fuera de ella. Los objetos dentro del área que no lleve o vista nadie también se verán empujados de esta forma. La torre mide 20 pies de lado y 30 pies de altura, con aspilleras en todos los lados y almenas en la parte superior. Su interior se divide en dos plantas conectadas mediante unas escaleras, una escalera de mano o una rampa (a tu elección). Estas escaleras o rampa llevan hasta una trampilla que da al techo. Cuando se crea, la torre tiene una sola puerta en la planta baja en el lado frente a ti. La puerta se abre solo bajo tus órdenes, que puedes dar como acción adicional. Es inmune al conjuro abrir o efectos mágicos similares. La magia impide que se derribe la torre. El techo, la puerta y los muros poseen cada uno una CA de 20, 100 pg, inmunidad al daño contundente, cortante y perforante salvo que se haga con equipo de asedio, y resistencia a todo el resto de daño. Devolver la torre a su forma de estatuilla no repara el daño que haya recibido. Solo un conjuro deseo puede reparar la torre (este uso cuenta como replicar un conjuro de nivel 8 o inferior). Cada vez que se lance deseo, la torre recupera todos sus puntos de golpe.",
    "id": "magic_fortaleza_instantanea_de_daern"
  },
  {
    "name": "FRASCO DE HIERRO",
    "category": "Objeto maravilloso",
    "rarity": "Legendario",
    "attunement": "No",
    "description": "Mientras sostengas este recipiente de hierro con tapón de latón, puedes emplear una acción de magia para hacer objetivo a una criatura que puedas ver a 60 pies o menos de ti. Si el frasco está vacío y el objetivo pertenece a un plano de existencia distinto al actual, deberá superar una tirada de salvación de Sabiduría con CD 17 o quedará atrapado en el frasco. Si el objetivo ya ha estado encerrado antes en el frasco, tendrá ventaja en la tirada. Una vez atrapada, la criatura permanecerá en el frasco hasta que sea liberada. El frasco solo puede contener a una criatura a la vez. Una criatura atrapada en el frasco no necesita respirar ni comer ni beber, y no envejece. Puedes emplear una acción de magia para quitar el tapón del frasco y liberar a la criatura contenida. Esta obedecerá tus órdenes durante 1 hora y las comprenderá aunque se las des en un idioma que no entienda. Si no le das ninguna orden o le das una orden que probablemente desemboque en su muerte o cautiverio, se defenderá, pero no realizará ninguna otra acción. Al final de la duración, la criatura actuará conforme a su carácter y alineamiento normales. Un conjuro identificar revela si el frasco contiene una criatura, pero la única forma de saber de qué criatura se trata es abrirlo. Un frasco de hierro recién descubierto podría contener una criatura a elección de tu GM.",
    "id": "magic_frasco_de_hierro"
  },
  {
    "name": "GARROTE GRANDE ATRONADOR",
    "category": "Arma",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Mientras tengas sintonización con esta arma mágica, tu Fuerza será de 20 salvo que ya sea igual o superior. El arma causa 1d8 de daño de trueno adicional a cualquier criatura a la que acierte y 3d8 de daño de trueno adicional a los objetos a los que acierte que no vista o lleve nadie.\n\nEl arma tiene las siguientes propiedades adicionales:\n\n• Estallido de trueno. Como acción de magia, puedes golpear el arma contra una superficie dura, lo que producirá un tronido audible a 300 pies de distancia. También crearás un cono de 30 pies de energía atronadora. Todas las criaturas situadas en el cono deberán superar una tirada de salvación de Fuerza con CD 15 o tendrán el estado de derribadas. Los objetos no mágicos que nadie vista o lleve en el cono recibirán 3d8 de daño de trueno.\n• Terremoto. Como acción de magia, puedes golpear el arma contra el suelo para crear una perturbación sísmica intensa en un círculo de 50 pies de radio centrado en el punto del impacto. Las estructuras en contacto con el suelo en esa zona sufrirán 50 de daño contundente, y las criaturas que haya en ella y estén en el suelo deberán superar una tirada de salvación de Destreza con CD 20 o tendrán el estado de derribadas. Si alguna de esas criaturas se está concentrando, deberá superar una tirada de salvación de Constitución con CD 20 o perderá la concentración. Además, puedes hacer que se abra una grieta de 30 pies de profundidad y 10 pies de ancho en cualquier punto del suelo dentro del área. Cualquier criatura que esté en un punto en el que se abra la grieta deberá hacer una tirada de salvación de Destreza con CD 20; si la falla, caerá en la grieta, y si la supera, se moverá a la vez que se abre el borde de la grieta. Cualquier estructura que esté en un punto en el que se abra la grieta se hundirá dentro de ella. Una vez utilizada, esta propiedad no puede volver a usarse hasta el siguiente amanecer.",
    "subcategory": "Arma (garrote grande)",
    "id": "magic_garrote_grande_atronador"
  },
  {
    "name": "GEMA DE VISIÓN",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Esta joya tiene 3 cargas. Como acción de magia, puedes gastar 1 carga. Durante los siguientes 10 minutos, tendrás visión verdadera hasta 120 pies si miras a través de la gema. La gema recupera 1d3 cargas empleadas cada día, al amanecer.",
    "id": "magic_gema_de_vision"
  },
  {
    "name": "GEMA DEL RESPLANDOR",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Este prisma tiene 50 cargas. Mientras lo sujetas, puedes usar una acción de magia y pronunciar una de las tres palabras de activación para causar uno de los siguientes efectos:\n\n• Primera palabra de activación. La gema emite luz brillante en un radio de 30 pies y luz tenue 30 pies más allá. Este efecto no gasta una carga. Dura hasta que utilices una acción adicional para repetir la palabra de activación o hasta que emplees otra función de la gema.\n• Segunda palabra de activación. Gastas 1 carga para que la gema dispare un rayo brillante de luz contra una criatura que puedas ver a 60 pies o menos de ti. La criatura deberá superar una tirada de salvación de Constitución con CD 15 o tendrá el estado de cegada durante 1 minuto. La criatura repetirá la tirada de salvación al final de cada uno de sus turnos y, si tiene éxito, se librará del efecto.\n• Tercera palabra de activación. Gastas 5 cargas para que la gema refulja con una luz intensa en un cono de 30 pies. Todas las criaturas situadas en el cono harán una tirada de salvación como si les hubiera afectado el rayo creado por la segunda palabra de activación. Cuando todas las cargas de la gema se gasten, se convertirá en una joya no mágica con un valor de 50 po.",
    "id": "magic_gema_del_resplandor"
  },
  {
    "name": "GEMA ELEMENTAL",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Esta gema contiene vestigios de energía elemental. Cuando emplees una acción de utilizar para romperla, invocarás un elemental (ver el Manual de los Monstruos ) y la gema dejará de ser mágica. El elemental aparece en un espacio sin ocupar lo más cerca posible de la gema rota, entiende tus idiomas, obedece tus órdenes y juega su turno inmediatamente después de ti en tu orden de iniciativa. El elemental desaparecerá tras 1 hora, cuando muera o si lo desconvocas como acción adicional. El tipo de gema determina el elemental invocado, como se muestra en la siguiente tabla.",
    "tables": [
      {
        "title": "Gema elemental",
        "columns": [
          "Clave",
          "Valor"
        ],
        "rows": [
          [
            "Corindón rojo",
            "Elemental de fuego"
          ],
          [
            "Diamante amarillo",
            "Elemental de tierra"
          ],
          [
            "Esmeralda",
            "Elemental de agua"
          ],
          [
            "Zafiro azul",
            "Elemental de aire"
          ]
        ]
      }
    ],
    "id": "magic_gema_elemental"
  },
  {
    "name": "GRILLETES DIMENSIONALES",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Puedes emplear una acción de utilizar para poner estos grilletes a una criatura que tenga el estado de incapacitada. Se ajustan a criaturas de tamaños Pequeño a Grande. Los grilletes impiden que la criatura utilice cualquier método de movimiento extradimensional, incluidos la teletransportación o los viajes a otro plano de existencia. No impiden que la criatura atraviese un portal interdimensional. Tú y cualquier criatura que designes al usar los grilletes podéis emplear una acción de utilizar para quitarlos. Una vez cada 30 días, la criatura esposada podrá realizar una prueba de Fuerza (Atletismo) con CD 30. Si la supera, se liberará y destruirá los grilletes.",
    "id": "magic_grilletes_dimensionales"
  },
  {
    "name": "GUANTELETES DE FUERZA DE OGRO",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Tu Fuerza es de 19 mientras lleves estos guanteletes. No tienen efecto si tu Fuerza es de 19 o más sin ellos.",
    "id": "magic_guanteletes_de_fuerza_de_ogro"
  },
  {
    "name": "GUANTES ATRAPAFLECHAS",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Cuando te acierte una tirada de ataque realizada con un arma a distancia o arrojadiza mientras lleves puestos estos guantes, podrás emplear una reacción para reducir el daño en 1d10 más tu modificador por Destreza, siempre y cuando tengas una mano libre. Si reduces el daño a 0, podrás atrapar la unidad de munición o el arma si es lo bastante pequeña como para sujetarla con esa mano.",
    "id": "magic_guantes_atrapaflechas"
  },
  {
    "name": "GUANTES DE LADRÓN",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Estos guantes son imperceptibles mientras los lleves puestos. Si los vistes, ganas un bonificador de +5 a las pruebas de Destreza (Juego de manos).",
    "id": "magic_guantes_de_ladron"
  },
  {
    "name": "GUANTES DE NATACIÓN Y ESCALADA",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Mientras lleves estos guantes, tienes una velocidad nadando y una velocidad trepando iguales a tu velocidad. Además, obtienes un bonificador de +5 a las pruebas de Fuerza (Atletismo) para nadar o trepar.",
    "id": "magic_guantes_de_natacion_y_escalada"
  },
  {
    "name": "HACHA BERSERKER",
    "category": "Arma",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Obtienes un bonificador de +1 a las tiradas de ataque y de daño que hagas con esta arma mágica. Además, mientras estés en combate, si recibes daño, debes superar una tirada de salvación de Sabiduría con CD 15 o entrarás en furia hasta el final de tu siguiente turno. Mientras estés en furia, debes usar tu acción en cada uno de tus turnos para atacar a la criatura más cercana que puedas ver.",
    "subcategory": "Arma (cualquiera sencilla o marcial)",
    "maldicion": "Esta hacha está maldita y su maldición solo se revela cuando se lanza el conjuro identificar sobre ella o te sintonizas con ella.\n\nAl sintonizarte con el hacha, no puedes dejar de empuñarla a menos que seas el objetivo del conjuro levantar maldición u otro efecto mágico similar.",
    "id": "magic_hacha_berserker"
  },
  {
    "name": "HERRADURAS DE VELOCIDAD",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Estas herraduras vienen de cuatro en cuatro. Como acción de magia, puedes tocar el casco de un caballo o de una criatura similar con una de las herraduras para que se quede fijada en él. Quitar una herradura también requiere una acción de magia. Mientras cuatro de ellas estén fijadas a la misma criatura, su velocidad aumenta en 30 pies.",
    "id": "magic_herraduras_de_velocidad"
  },
  {
    "name": "HERRADURAS DEL CÉFIRO",
    "category": "Objeto maravilloso",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Estas herraduras vienen de cuatro en cuatro. Como acción de magia, puedes tocar el casco de un caballo o de una criatura similar con una de las herraduras para que se quede fijada en él. Quitar una herradura también requiere una acción de magia. Mientras cuatro de ellas estén fijadas a los cascos de un caballo o de una criatura similar, le permitirán moverse con normalidad mientras flota 4 pulgadas por encima de una superficie. Este efecto implica que la criatura puede cruzar o permanecer sobre superficies no sólidas o inestables, como agua y lava. Además, no deja huellas e ignora el terreno difícil. Por último, podrá viajar hasta 12 horas al día sin sumar niveles de cansancio por hacer viajes largos.",
    "id": "magic_herraduras_del_cefiro"
  },
  {
    "name": "HERRAMIENTA MULTIFORMA",
    "category": "Objeto maravilloso",
    "rarity": "Común",
    "attunement": "Sí",
    "description": "Esta herramienta adopta la forma de una llave inglesa, un destornillador u otra herramienta básica. Como acción de magia, puedes tocar el objeto y transformarlo en un tipo de herramientas de artesano de tu elección. Sea cual sea la forma que adopte la herramienta, tienes competencia con ella cuando la uses.",
    "id": "magic_herramienta_multiforme"
  },
  {
    "name": "HIERRO DE ESCARCHA",
    "category": "Arma",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Cuando aciertes con una tirada de ataque usando esta arma mágica, el objetivo recibirá 1d6 de daño de frío adicional. Además, mientras empuñes el arma, tendrás resistencia al daño de fuego. En temperaturas bajo cero, el arma emite luz brillante en un radio de 10 pies y luz tenue 10 pies más allá. Cuando desenvainas esta arma, puedes extinguir todas las llamas no mágicas que haya a 30 pies o menos de ti. Una vez utilizada, esta propiedad no puede volver a usarse en 1 hora.",
    "subcategory": "Arma (cualquiera sencilla o marcial)",
    "id": "magic_hierro_de_escarcha"
  },
  {
    "name": "INCENSARIO DE CONTROLAR ELEMENTALES DE AIRE",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Puedes emplear una acción de magia mientras balanceas con suavidad este incensario para invocar un elemental de aire. El elemental aparece en un espacio sin ocupar lo más cerca posible del incensario, entiende tus idiomas, obedece tus órdenes y juega su turno inmediatamente después de ti en tu orden de iniciativa. El elemental desaparecerá tras 1 hora, cuando muera o si lo desconvocas como acción adicional. El incensario no puede volver a emplearse de esta manera hasta el siguiente amanecer.",
    "id": "magic_incensario_de_controlar_elementales_de_aire"
  },
  {
    "name": "JABALINA DEL RELÁMPAGO",
    "category": "Arma",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Cada vez que hagas una tirada de ataque con esta arma mágica y aciertes, puedes hacer que cause daño de relámpago en lugar de daño perforante.\n\n• Relámpago. Cuando arrojes esta arma contra un objetivo a 120 pies o menos de ti, puedes renunciar a hacer una tirada de ataque a distancia y convertirla en un relámpago. El relámpago forma una línea de 5 pies de ancho entre el objetivo y tú. Dicho objetivo y las demás criaturas situadas en la línea (excepto tú) harán una tirada de salvación de Destreza con CD 13; sufrirán 4d6 de daño de relámpago si la fallan o la mitad del daño si la superan. Inmediatamente después de causar daño, el arma vuelve a aparecer en tu mano. Esta propiedad no podrá volver a usarse hasta el siguiente amanecer.",
    "subcategory": "Arma (jabalina)",
    "id": "magic_jabalina_del_relampago"
  },
  {
    "name": "JARRA DE SOBRIEDAD",
    "category": "Objeto maravilloso",
    "rarity": "Común",
    "attunement": "No",
    "description": "Esta jarra tiene una cara severa esculpida en un lado. Puedes beber cerveza, vino o cualquier otra bebida alcohólica no mágica servida en ella sin embriagarte. La jarra no tiene efecto sobre líquidos mágicos o sustancias dañinas como el veneno.",
    "id": "magic_jarra_de_sobriedad"
  },
  {
    "name": "LADRONA DE NUEVE VIDAS",
    "category": "Arma",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Recibes un bonificador de +2 a las tiradas de ataque y de daño que hagas con esta arma mágica.\n\n• Robo de vida. El arma tiene 1d8 + 1 cargas. Cuando ataques a una criatura que tenga menos de 100 puntos de golpe con esta arma y saques un 20 en el d20 al hacer la tirada de ataque, la criatura deberá superar una tirada de salvación de Constitución con CD 15 o morirá al instante, ya que el arma arrancará la fuerza vital de su cuerpo. Los autómatas y muertos vivientes superarán la tirada de salvación automáticamente. El arma pierde 1 carga si la criatura muere. Cuando no le queden cargas, el arma perderá esta propiedad.",
    "subcategory": "Arma (cualquiera sencilla o marcial)",
    "id": "magic_ladrona_de_nueve_vidas"
  },
  {
    "name": "LENGUA DE FUEGO",
    "category": "Arma",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Mientras sostengas esta arma mágica, puedes emplear una acción adicional y pronunciar una palabra de activación para hacer que el arma se cubra de llamas en la parte usada para herir. Estas llamas emiten luz brillante en un radio de 40 pies y luz tenue 40 pies más allá. Mientras el arma esté en llamas, causa 2d6 de daño de fuego adicional al acertar. Las llamas permanecen hasta que emplees una acción adicional para pronunciar la palabra de activación de nuevo o hasta que sueltes, guardes o envaines el arma.",
    "subcategory": "Arma (cualquier arma cuerpo a cuerpo)",
    "id": "magic_lengua_de_fuego"
  },
  {
    "name": "LINTERNA DE REVELACIÓN",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Mientras esté encendida, esta linterna sorda luce durante 6 horas con 0,1 gal de aceite e ilumina un radio de 30 pies con luz brillante y otros 30 pies con luz tenue. Las criaturas y objetos invisibles serán visibles mientras permanezcan iluminados por la luz brillante de la linterna. Puedes emplear una acción de utilizar para cubrir la abertura de la linterna con la tapa y hacer que solo emita luz tenue en un radio de 5 pies.",
    "id": "magic_linterna_de_revelacion"
  },
  {
    "name": "MALLA DE IFRIT",
    "category": "Armadura",
    "rarity": "Legendario",
    "attunement": "Sí",
    "description": "Mientras lleves esta armadura, obtendrás un bonificador de +3 a la clase de armadura, tendrás inmunidad al daño de fuego y conocerás el idioma primordial. Además, puedes estar de pie y andar sobre roca fundida como si fuera terreno firme.",
    "subcategory": "Cualquiera (armadura)",
    "id": "magic_malla_de_ifrit"
  },
  {
    "name": "MALLA ÉLFICA",
    "category": "Armadura",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Mientras lleves esta armadura, obtendrás un bonificador de +1 a la clase de armadura. Se considera que tienes entrenamiento con esta armadura aunque normalmente no lo tuvieras con armaduras medias o pesadas.",
    "subcategory": "Armadura (camisa de malla o cota de malla)",
    "id": "magic_malla_elfica"
  },
  {
    "name": "MANTO DE RESISTENCIA A CONJUROS",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Mientras lleves esta capa, tendrás ventaja en las tiradas de salvación contra conjuros.",
    "id": "magic_manto_de_resistencia_a_conjuros"
  },
  {
    "name": "MANUAL DE GÓLEMS",
    "category": "Objeto maravilloso",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Este tomo contiene la información y los ensalmos necesarios para crear un tipo concreto de gólem. Tu GM elige el tipo o lo determina al azar tirando en la tabla a continuación. Para descifrar y usar el manual, debes ser un lanzador de conjuros con al menos dos espacios de conjuro de nivel 5. Si una criatura no puede usar un manual de gólems y trata de leerlo, sufrirá 6d6 de daño psíquico. Para crear un gólem, debes dedicar el tiempo mostrado en la tabla, trabajar sin interrupciones con el manual a mano y no descansar durante más de 8 horas al día. También debes pagar el precio especificado para comprar los suministros. En cuanto hayas acabado de crear al gólem, el libro arderá en llamas sobrenaturales. El gólem cobrará vida cuando se esparzan sobre él las cenizas del manual. Consulta el \"Manual de los Monstruos\" para conocer el perfil del gólem. Estará bajo tu control, entenderá tus órdenes y las obedecerá.",
    "tables": [
      {
        "title": "Manual de gólems",
        "columns": [
          "Columna 1",
          "Columna 2",
          "Columna 3",
          "Columna 4"
        ],
        "rows": [
          [
            "1–5",
            "Gólem de arcilla",
            "30 días",
            "65 000 po"
          ],
          [
            "6–17",
            "Gólem de carne",
            "60 días",
            "50 000 po"
          ],
          [
            "18",
            "Gólem de hierro",
            "120 días",
            "100 000 po"
          ],
          [
            "19–20",
            "Gólem de piedra",
            "90 días",
            "80 000 po"
          ]
        ]
      }
    ],
    "id": "magic_manual_de_golems"
  },
  {
    "name": "MANUAL DE LA SALUD CORPORAL",
    "category": "Objeto maravilloso",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Este libro contiene consejos de salud y nutrición, y sus palabras están impregnadas de magia. Si dedicas 48 horas durante un periodo de 6 días, como mucho, a estudiar el contenido del libro y poner en práctica sus indicaciones, tu Constitución aumenta rá en 2, hasta un máximo de 30. Después, el manual perderá su magia, pero la recuperará cuando pase un siglo.",
    "id": "magic_manual_de_la_salud_corporal"
  },
  {
    "name": "MANUAL DE RAPIDEZ DE ACCIÓN",
    "category": "Objeto maravilloso",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Este libro contiene ejercicios de coordinación y equilibrio, y sus palabras están impregnadas de magia. Si dedicas 48 horas durante un periodo de 6 días, como mucho, a estudiar el contenido del libro y poner en práctica sus indicaciones, tu Destreza aumentará en 2, hasta un máximo de 30. Después, el manual perderá su magia, pero la recuperará cuando pase un siglo.",
    "id": "magic_manual_de_rapidez_de_accion"
  },
  {
    "name": "MANUAL DEL EJERCICIO BENEFICIOSO",
    "category": "Objeto maravilloso",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Este libro describe diferentes ejercicios para mantenerse en forma y sus palabras están impregnadas de magia. Si dedicas 48 horas durante un periodo de 6 días, como mucho, a estudiar el contenido del libro y poner en práctica sus indicaciones, tu Fuerza aumentará en 2, hasta un máximo de 30. Después, el manual perderá su magia, pero la recuperará cuando pase un siglo.",
    "id": "magic_manual_del_ejercicio_beneficioso"
  },
  {
    "name": "MARAVILLOSOS PIGMENTOS DE NOLZUR",
    "category": "Objeto maravilloso",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Esta elegante caja de madera contiene 1d4 botecitos de pigmento y un pincel (peso total de 2 lb). Si usas un pincel y gastas 1 botecito de pigmento, puedes pintar cualquier cantidad de objetos tridimensionales y elementos de terreno (como muros, puertas, árboles, flores, armas, telarañas o pozos), siempre y cuando quepan todos en un cubo de 20 pies de lado. Esta tarea requiere concentración, te llevará 10 minutos (independientemente de la cantidad de objetos que crees) y durante ese tiempo deberás permanecer dentro del cubo. Si pierdes la concentración o sales del cubo antes de terminar, todos los elementos pintados se desvanecerán y el botecito de pigmento se desperdiciará. Cuando termines de pintar, todos los objetos y elementos de terreno se volverán reales. Por tanto, si pintas una puerta en una pared, crearás una puerta real que pueda abrirse para acceder al otro lado. Si pintas un pozo, crearás un hoyo de verdad, cuya profundidad deberá caber en el cubo de 20 pies. Ninguna creación de los pigmentos puede tener un valor superior a 25 po, y el valor total de todos los objetos que crea un botecito no puede superar las 500 po. Si pintas objetos de mayor valor, como un montón de oro, parecerán auténticos, pero una inspección detallada revela que están hechos de pasta, galleta u otro material sin valor. Si dibujas algún tipo de energía, como fuego o un relámpago, se esfumará inmediatamente al completar el dibujo, sin causar daños.",
    "peso": 2,
    "id": "magic_maravillosos_pigmentos_de_nolzur"
  },
  {
    "name": "MARTILLO ARROJADIZO ENANO",
    "category": "Arma",
    "rarity": "Muy raro",
    "attunement": "Sí (requiere sintonización con un enano o una criatura sintonizada con un Cinturón enano)",
    "description": "Recibes un bonificador de +3 a las tiradas de ataque y de daño que hagas con esta arma mágica. Tiene la propiedad \"arrojadiza\", con un alcance normal de 20 pies y un alcance largo de 60 pies. Cuando aciertes un ataque a distancia con esta arma, causa 1d8 de daño de fuerza adicional o 2d8 de daño de fuerza adicional si el objetivo es un gigante. Inmediatamente después de acertar o fallar, el arma regresa volando a tu mano.",
    "subcategory": "Arma (martillo de guerra)",
    "id": "magic_martillo_arrojadizo_enano"
  },
  {
    "name": "MARTILLO DE RAYOS",
    "category": "Arma",
    "rarity": "Legendario",
    "attunement": "Sí",
    "description": "Recibes un bonificador de +1 a las tiradas de ataque y de daño que hagas con esta arma mágica. El arma tiene 5 cargas. Puedes gastar 1 carga y hacer un ataque a distancia con el arma lanzándola como si tuviera la propiedad \"arrojadiza\", con un alcance normal de 20 pies y un alcance largo de 60 pies. Si el ataque acierta, el arma suelta un trueno audible a 300 pies. El objetivo y todas las criaturas (excepto tú) que estén a 30 pies o menos de él deberán superar una tirada de salvación de Constitución con CD 17 o tendrán el estado de aturdidas hasta el final de tu siguiente turno. Inmediatamente después de acertar o fallar, el arma regresa volando a tu mano. El arma recupera 1d4 + 1 cargas empleadas cada día, al amanecer.\n\n• Matagigantes. Mientras tengas sintonización con esta arma y lleves un cinturón de fuerza de gigante o unos guanteletes de fuerza de ogro con los que también te hayas sintonizado, obtienes los siguientes beneficios:\n• Azote de gigantes. Si sacas un 20 en el d20 en una tirada de ataque con esta arma contra un gigante, este deberá superar una tirada de salvación de Constitución con CD 17 o morirá.\n• Fuerza de gigantes. La puntuación de Fuerza que te otorgan el cinturón de fuerza de gigante o los guanteletes de fuerza de ogro aumenta en 4, hasta un máximo de 30.",
    "subcategory": "Arma (cualquiera sencilla o marcial)",
    "id": "magic_martillo_de_rayos"
  },
  {
    "name": "MATADRAGONES",
    "category": "Arma",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Recibes un bonificador de +1 a las tiradas de ataque y de daño que hagas con esta arma mágica. Si el objetivo es un dragón, el arma causa 3d6 de daño adicional del tipo del arma.",
    "subcategory": "Arma (cualquiera sencilla o marcial)",
    "id": "magic_matadragones"
  },
  {
    "name": "MATAGIGANTES",
    "category": "Arma",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Recibes un bonificador de +1 a las tiradas de ataque y de daño que hagas con esta arma mágica. Cuando aciertes a un gigante con ella, el gigante sufrirá 2d6 de daño adicional del tipo del arma y deberá superar una tirada de salvación de Fuerza con CD 15 o tendrá el estado de derribado.",
    "subcategory": "Arma (cualquiera sencilla o marcial)",
    "id": "magic_matagigantes"
  },
  {
    "name": "MAZA CASTIGADORA",
    "category": "Arma",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Recibes un bonificador de +1 a las tiradas de ataque y de daño que hagas con esta arma mágica. El bonificador aumenta a +3 cuando usas el arma para atacar a un autómata. Si sacas un 20 en una tirada de ataque con esta arma, el objetivo sufrirá 7 de daño contundente adicional o 14 si es un autómata. Si a un autómata le quedan 25 puntos de golpe o menos tras sufrir este daño, será destruido.",
    "subcategory": "Arma (maza)",
    "id": "magic_maza_castigadora"
  },
  {
    "name": "MAZA DEL TERROR",
    "category": "Arma",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Esta arma mágica tiene 3 cargas y recupera 1d3 cargas empleadas cada día, al amanecer. Mientras sostienes el arma, puedes emplear una acción de magia y gastar 1 carga para desatar una ola de terror desde ella. Todas las criaturas de tu elección a 30 pies o menos de ti deberán superar una tirada de salvación de Sabiduría con CD 15 o tendrán el estado de asustadas durante 1 minuto. Una criatura asustada de esta manera deberá dedicar sus turnos a tratar de alejarse de ti todo lo que pueda y no podrá hacer ataques de oportunidad. Tan solo podrá realizar la acción de correr o intentar escapar de un efecto que le impida moverse. Si no tiene adónde ir, la criatura podrá usar la acción de esquivar. Al final de cada uno de sus turnos, la criatura repetirá la tirada de salvación y, si tiene éxito, se librará del efecto.",
    "subcategory": "Arma (maza)",
    "id": "magic_maza_del_terror"
  },
  {
    "name": "MAZA DISRUPTIVA",
    "category": "Arma",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Cuando aciertes a un infernal o muerto viviente con esta arma mágica, esa criatura recibirá 2d6 de daño radiante adicional. Si al objetivo le quedan 25 puntos de golpe o menos tras sufrir este daño, deberá superar una tirada de salvación de Sabiduría con CD 15 o será destruido. Si la supera, tendrá el estado de asustado hasta el final de tu siguiente turno.\n\n• Luz. Mientras empuñes esta arma, emitirá luz brillante en un radio de 20 pies y luz tenue 20 pies más allá.",
    "subcategory": "Arma (maza)",
    "id": "magic_maza_disruptiva"
  },
  {
    "name": "MEDALLÓN DE LOS PENSAMIENTOS",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "El medallón tiene 5 cargas. Mientras lo lleves, puedes gastar 1 carga para lanzar detectar pensamientos (CD de salvación 13) desde él. El medallón recupera 1d4 cargas empleadas cada día, al amanecer.",
    "id": "magic_medallon_de_los_pensamientos"
  },
  {
    "name": "MONEDA DE TEMPUS",
    "category": "Objeto maravilloso",
    "rarity": "Artefacto",
    "attunement": "Sí",
    "description": "Una moneda de dos caras imbuida con la voluntad de Tempus. En ella residen el azar del combate, la bendición de la guerra y el poder de torcer el destino en el instante decisivo.\n\n• Moneda de dos caras. Ganas 3 cargas de Torcer el destino. Cada vez que fallas una tirada de ataque, salvación o habilidad, puedes gastar 1 carga para repetir la tirada y quedarte con el resultado más alto. Las cargas se recuperan al completar un descanso largo. Además, cuando gastas una carga para repetir una tirada de salvación, un aliado adyacente a 5 pies de ti obtiene el mismo beneficio hasta el comienzo de tu próximo turno para su próxima tirada de salvación fallida.\n• Plegaria. Como acción, invocas el poder de Tempus con una plegaria. Tú y todos los aliados que puedas ver en un radio de 60 pies obtenéis puntos de golpe temporales iguales a tu nivel + tu modificador de Sabiduría. Si alguno de esos aliados está moribundo, se levanta inmediatamente con 1 punto de golpe más los puntos de golpe temporales otorgados. Esta propiedad solo puede usarse una vez por descanso corto.\n• Listo para la guerra. Como acción, puedes concentrarte en la moneda durante 10 minutos. Al hacerlo, una esfera de luz radiante de 20 pies de radio se forma centrada en ti. Toda criatura que permanezca dentro de esta área durante los 10 minutos completa un descanso largo. Si esta propiedad se usa más de una vez en el mismo día, todas las criaturas que reciban un descanso largo adicional deben superar una tirada de salvación de Constitución contra tu CD de conjuros o ganar 1 nivel de cansancio.",
    "id": "magic_moneda_de_tempus"
  },
  {
    "name": "MORRAL PRÁCTICO DE HEWARD",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Esta mochila posee un bolsillo central y dos laterales, cada uno de los cuales es un espacio extradimensional. Sacar un objeto del morral requiere una acción de utilizar o una acción adicional, a tu elección. Cuando metes la mano para extraer un objeto concreto, la magia hará que siempre se encuentre arriba del todo. Si se sobrecarga, perfora o rasga algún bolsillo, el morral se romperá y quedará destruido. Si se destruye, su contenido se perderá para siempre, aunque los artefactos siempre volverán a aparecer en alguna parte. Si se pone el morral del revés, su contenido se vuelca sin sufrir daño y el morral debe volver a ponerse del derecho antes de usarlo de nuevo. Cada bolsillo del morral contiene aire suficiente para respirar durante 10 minutos, divididos entre el número de criaturas que necesiten respirar en su interior. Meter el morral en el espacio extradimensional creado por un agujero portátil, una bolsa de contención o un objeto similar destruye instantáneamente ambos objetos y abre un portal al Plano Astral. El portal se crea en el sitio en el que un objeto se introdujo dentro del otro. El portal absorbe a todas las criaturas situadas a 10 pies o menos de él y que no estén tras cobertura completa, y las conduce a un lugar aleatorio del Plano Astral. Después, el portal se cierra. El portal solo funciona en un sentido y no puede volver a abrirse.\n\n• Capacidad. El morral pesa 5 lb, independientemente de su contenido. Tiene un compartimento central y dos bolsillos laterales, cada uno de los cuales es un espacio extradimensional. Cada bolsillo lateral puede contener hasta 20 lb y 2 pies cúbicos. El compartimento central puede contener hasta 80 lb y 8 pies cúbicos. En total, el morral puede contener hasta 120 lb.",
    "peso": 5,
    "id": "magic_morral_practico_de_heward"
  },
  {
    "name": "MUNICIÓN +1",
    "category": "Arma",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Tienes un bonificador a las tiradas de ataque y de daño que hagas con esta unidad de munición mágica. El bonificador depende de la rareza de la munición. Una vez que acierte a un objetivo, la munición dejará de ser mágica. La munición suele encontrarse o venderse en conjuntos de diez o veinte unidades. El valor de diez unidades de esta munición equivale a una poción de la misma rareza.",
    "subcategory": "Arma (cualquiera sencilla o marcial)",
    "id": "magic_municion_1"
  },
  {
    "name": "MUNICIÓN +2",
    "category": "Arma",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Tienes un bonificador a las tiradas de ataque y de daño que hagas con esta unidad de munición mágica. El bonificador depende de la rareza de la munición. Una vez que acierte a un objetivo, la munición dejará de ser mágica. La munición suele encontrarse o venderse en conjuntos de diez o veinte unidades. El valor de diez unidades de esta munición equivale a una poción de la misma rareza.",
    "subcategory": "Arma (cualquiera sencilla o marcial)",
    "id": "magic_municion_2"
  },
  {
    "name": "MUNICIÓN +3",
    "category": "Arma",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Tienes un bonificador a las tiradas de ataque y de daño que hagas con esta unidad de munición mágica. El bonificador depende de la rareza de la munición. Una vez que acierte a un objetivo, la munición dejará de ser mágica. La munición suele encontrarse o venderse en conjuntos de diez o veinte unidades. El valor de diez unidades de esta munición equivale a una poción de la misma rareza.",
    "subcategory": "Arma (cualquiera sencilla o marcial)",
    "id": "magic_municion_3"
  },
  {
    "name": "MUNICIÓN ASESINA",
    "category": "Arma",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Esta munición mágica está pensada para matar criaturas de un tipo concreto, que tu GM elige o determina al azar tirando en la tabla a continuación. Si una criatura de ese tipo recibe daño de esta munición, hace una tirada de salvación de Constitución con CD 17; sufrirá 6d10 de daño de fuerza adicional si la falla o la mitad del daño adicional si la supera. En cuanto inflige daño adicional a una criatura, la munición se vuelve no mágica.",
    "subcategory": "Arma (cualquier munición)",
    "tables": [
      {
        "title": "Tipo de criatura (Munición asesina)",
        "columns": [
          "Resultado",
          "Efecto"
        ],
        "rows": [
          [
            "01–10",
            "Aberraciones"
          ],
          [
            "11–15",
            "Autómatas"
          ],
          [
            "16–20",
            "Bestias"
          ],
          [
            "21–25",
            "Celestiales"
          ],
          [
            "26–30",
            "Cienos"
          ],
          [
            "31–40",
            "Dragones"
          ],
          [
            "41–50",
            "Elementales"
          ],
          [
            "51–60",
            "Feéricos"
          ],
          [
            "61–65",
            "Gigantes"
          ],
          [
            "66–70",
            "Humanoides"
          ],
          [
            "71–80",
            "Infernales"
          ],
          [
            "81–85",
            "Monstruosidades"
          ],
          [
            "86–95",
            "Muertos vivientes"
          ],
          [
            "96–00",
            "Plantas"
          ]
        ]
      }
    ],
    "id": "magic_municion_asesina"
  },
  {
    "name": "ORBE DRAGONTINO",
    "category": "Objeto maravilloso",
    "rarity": "Artefacto",
    "attunement": "Sí",
    "description": "Un orbe es un globo de cristal grabado de unos 10 pulgadas de diámetro. Cuando se usa, se expande hasta alcanzar los 20 pulgadas de diámetro y una bruma se arremolina en su interior. Mientras tengas sintonización con el orbe, puedes emplear una acción de magia para mirar en sus profundidades. Después, tendrás que hacer una tirada de salvación de Carisma con CD 15. Si la superas, controlarás el orbe mientras permanezcas en sintonía con él. Si la fallas, el orbe te impondrá el estado de hechizado mientras permanezcas en sintonía con él. Mientras estés hechizado por el orbe, no podrás acabar voluntariamente la sintonización y el orbe te lanzará sugestión a voluntad (CD de salvación 18) para incitarte a que cumplas sus malvados deseos.\n\n• Conjuros. El orbe tiene 7 cargas y recupera 1d4 + 3 cargas empleadas cada día, al amanecer. Si controlas el orbe, puedes lanzar un conjuro desde él, gastando cargas (consulta la tabla \"Conjuros (cargas)\").\n• Llamar a los dragones. Mientras controles el orbe, podrás utilizar una acción de magia para que el orbe emita una llamada telepática que se extienda en todas direcciones en un radio de 40 mi.",
    "tables": [
      {
        "title": "Conjuros (cargas)",
        "columns": [
          "Conjuro",
          "Coste en cargas"
        ],
        "rows": [
          [
            "Curar heridas (versión de nivel 9)",
            "4"
          ],
          [
            "Detectar magia",
            "0"
          ],
          [
            "Escudriñar (CD de salvación 18)",
            "3"
          ],
          [
            "Guarda contra la muerte",
            "2"
          ],
          [
            "Luz del día",
            "1"
          ]
        ]
      }
    ],
    "id": "magic_orbe_dragontino"
  },
  {
    "name": "PEGAMENTO SOBERANO",
    "category": "Objeto maravilloso",
    "rarity": "Legendario",
    "attunement": "No",
    "description": "Esta sustancia viscosa y blanca como la leche puede crear un vínculo adhesivo permanente entre dos objetos cualesquiera. Debe almacenarse en un bote o frasco que se haya untado con aceite escurridizo. En el momento de encontrar el recipiente, contendrá 1 lb + 1d6 × 1 lb. 1 lb de pegamento pueden cubrir una superficie cuadrada de 12 pulgadas de lado. Para aplicar 1 lb de pegamento soberano es necesaria una acción de utilizar, y tarda 1 minuto en asentarse. En cuanto lo haga, el vínculo que crea solo se puede romper si se aplica un disolvente universal o un aceite de etereidad o con un conjuro deseo.",
    "id": "magic_pegamento_soberano"
  },
  {
    "name": "PERGAMINO DE CONJURO",
    "category": "Pergamino",
    "attunement": "No",
    "description": "Un pergamino de conjuro contiene las palabras de un único conjuro, escritas en un código místico. Si el conjuro está en tu lista de conjuros, puedes leerlo y lanzarlo sin componentes materiales. De lo contrario, el pergamino es ininteligible. Lanzar el conjuro leyendo el pergamino requiere el tiempo de lanzamiento normal. Una vez lanzado, el pergamino se convierte en polvo. Si se interrumpe el lanzamiento, el pergamino no se pierde. Si el conjuro está en tu lista de conjuros, pero es de un nivel superior al que puedes lanzar normalmente, realizas una prueba de característica usando tu aptitud mágica para determinar si lo puedes lanzar. La CD es igual a 10 más el nivel del conjuro. Si la fallas, el conjuro desaparece del pergamino sin ningún otro efecto. El nivel del conjuro del pergamino determina la CD de la tirada de salvación y el bonificador de ataque del conjuro, así como la rareza del conjuro, como se muestra en la siguiente tabla.\n\n• Copiar un pergamino a un libro de conjuros. Un conjuro de mago en un pergamino de conjuro puede copiarse a un libro de conjuros. Para copiar un conjuro de esta forma, quien lo copia debe superar una prueba de Inteligencia (Arcano) con una CD igual a 10 más el nivel del conjuro. Si la supera, el conjuro se copia. Independientemente de que la prueba tenga éxito o falle, el pergamino de conjuro se destruye.",
    "tables": [
      {
        "title": "Rareza y CD del pergamino de conjuro",
        "columns": [
          "Nivel",
          "Rareza",
          "CD",
          "Bonificador de ataque"
        ],
        "rows": [
          [
            "Truco",
            "Común",
            "13",
            "+5"
          ],
          [
            "1",
            "Común",
            "13",
            "+5"
          ],
          [
            "2",
            "Infrecuente",
            "13",
            "+5"
          ],
          [
            "3",
            "Infrecuente",
            "15",
            "+7"
          ],
          [
            "4",
            "Raro",
            "15",
            "+7"
          ],
          [
            "5",
            "Raro",
            "17",
            "+9"
          ],
          [
            "6",
            "Muy raro",
            "17",
            "+9"
          ],
          [
            "7",
            "Muy raro",
            "18",
            "+10"
          ],
          [
            "8",
            "Muy raro",
            "18",
            "+10"
          ],
          [
            "9",
            "Legendario",
            "19",
            "+11"
          ]
        ]
      }
    ],
    "id": "magic_pergamino_de_conjuro"
  },
  {
    "name": "PERLA DE PODER",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Mientras lleves esta perla contigo, puedes emplear una acción de magia para recuperar un espacio de conjuro gastado de nivel 3 o inferior. Una vez que utilices la perla, no podrás volver a emplearla hasta el siguiente amanecer.",
    "id": "magic_perla_de_poder"
  },
  {
    "name": "PIEDRA DE CONTROLAR ELEMENTALES DE TIERRA",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Si esta piedra de 12 lb está tocando el suelo, puedes emplear una acción de magia para invocar un elemental de tierra. Aparecerá en un espacio sin ocupar de tu elección a 30 pies o menos de ti, obedece tus órdenes y juega su turno inmediatamente después de ti en tu orden de iniciativa. El elemental desaparecerá tras 1 hora, cuando muera o si lo desconvocas como acción adicional. La piedra no puede volver a emplearse de esta manera hasta el siguiente amanecer.",
    "peso": 12,
    "id": "magic_piedra_de_controlar_elementales_de_tierra"
  },
  {
    "name": "PIEDRA DE LA BUENA FORTUNA",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Mientras lleves esta ágata pulida contigo, recibirás un bonificador de +1 a las pruebas de característica y las tiradas de salvación.",
    "id": "magic_piedra_de_la_buena_fortuna"
  },
  {
    "name": "PIEDRA IOUN",
    "category": "Objeto maravilloso",
    "rarity": "Rareza Variable",
    "attunement": "Sí",
    "description": "Las piedras Ioun son aproximadamente del tamaño de una cuenta y se llaman así por Ioun, un dios del conocimiento y la profecía adorado en algunos mundos. Existen muchos tipos de piedras Ioun, cada uno de ellos con una combinación distinta de forma y color. Si empleas una acción de magia para lanzar una piedra Ioun al aire, orbitará alrededor de tu cabeza a una distancia de 1d3 × 12 pulgadas y te proporcionará un beneficio. Puedes tener hasta tres piedras Ioun orbitando activas a la vez. Cada piedra Ioun que orbite a tu alrededor se considera un objeto que llevas puesto. Evitará el contacto con otras criaturas y objetos y modificará su órbita para prevenir colisiones y frustrar los intentos de otras criaturas de atacarlas o agarrarlas. Como acción de utilizar, puedes tomar y guardar cualquier cantidad de piedras Ioun que orbiten alrededor de tu cabeza. Si tu sintonización con una de ellas termina mientras está orbitando, la piedra caerá como si la hubieras soltado. El tipo de piedra determina su rareza y efectos.\n\n• Absorción (muy rara). Mientras este elipsoide de color lila claro gire alrededor de tu cabeza, podrás emplear una reacción para cancelar un conjuro de nivel 4 o inferior lanzado por una criatura que puedas ver. Un conjuro cancelado no tendrá efecto y se perderán los recursos empleados para lanzarlo. En cuanto la piedra haya cancelado 20 niveles de conjuros, se volverá gris y perderá su magia.\n• Absorción mayor (legendaria). Mientras este elipsoide jaspeado en tonos lilas y verdes gire alrededor de tu cabeza, podrás emplear una reacción para cancelar un conjuro de nivel 8 o inferior lanzado por una criatura que puedas ver. Un conjuro cancelado no tendrá efecto y se perderán los recursos empleados para lanzarlo. En cuanto la piedra haya cancelado 20 niveles de conjuros, se volverá gris y perderá su magia.\n• Agilidad (muy rara). Mientras esta esfera de color rojo intenso gire alrededor de tu cabeza, tu Destreza aumenta en 2, hasta un máximo de 20.\n• Consciencia (rara). Mientras este romboide azul oscuro gire alrededor de tu cabeza, tienes ventaja en las tiradas de iniciativa y en las prueba de Sabiduría (Percepción).\n• Fortaleza (muy rara). Mientras este romboide rosa gire alrededor de tu cabeza, tu Constitución aumenta en 2, hasta un máximo de 20.\n• Fuerza (muy rara). Mientras este romboide azul pálido gire alrededor de tu cabeza, tu Fuerza aumenta en 2, hasta un máximo de 20.\n• Intelecto (muy rara). Mientras esta esfera jaspeada en tonos rojos y azules gire alrededor de tu cabeza, tu Inteligencia aumenta en 2, hasta un máximo de 20.\n• Liderazgo (muy rara). Mientras esta esfera jaspeada en tonos rosas y verdes gire alrededor de tu cabeza, tu Carisma aumenta en 2, hasta un máximo de 20.\n• Maestría (legendaria). Mientras este prisma verde pálido gire alrededor de tu cabeza, tu bonificador por competencia aumenta en 1.\n• Perspicacia (muy rara). Mientras esta esfera de color azul incandescente gire alrededor de tu cabeza, tu Sabiduría aumenta en 2, hasta un máximo de 20.\n• Protección (rara). Mientras este prisma de color rosa polvoriento gire alrededor de tu cabeza, obtienes un bonificador de +1 a la clase de armadura.\n• Regeneración (legendaria). Recuperas 15 puntos de golpe al final de cada hora que este huso de color blanco nacarado gire alrededor de tu cabeza si tienes al menos 1 punto de golpe.\n• Reserva (rara). Este prisma de color morado intenso almacena los conjuros que se lanzan sobre él hasta que quieras utilizarlos. La piedra puede guardar hasta 4 niveles de conjuros. Cuando la encuentres, contendrá 1d4 niveles de conjuros almacenados, a elección de tu GM. Cualquier criatura puede lanzar un conjuro de niveles 1 a 4 sobre la piedra si la toca mientras lanza el conjuro. El único efecto que tendrá el conjuro es que quedará almacenado en la piedra. Si la piedra no puede albergarlo, el conjuro se gastará sin efecto. El nivel del espacio utilizado para lanzar el conjuro determina cuánto espacio utiliza. Mientras esta piedra gire alrededor de tu cabeza, podrás lanzar cualquiera de los conjuros almacenados. El conjuro utiliza el nivel del espacio, la CD de salvación de conjuros, el bonificador de ataque de conjuros y la aptitud mágica del lanzador original, pero, por lo demás, funciona como si tú lo hubieses lanzado. El conjuro lanzado desde la piedra deja de estar almacenado en ella, por lo que deja espacio libre.\n• Sustento (rara). No necesitas comer ni beber mientras este huso transparente gire alrededor de tu cabeza.",
    "id": "magic_piedra_ioun"
  },
  {
    "name": "PIEDRAS MENSAJERAS",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Las piedras mensajeras vienen de dos en dos y cada una de ellas está tallada de forma que su pareja sea fácilmente identificable. Mientras tocas una piedra, puedes lanzar recado desde ella. El objetivo es el portador de la otra piedra. Si no hay nadie portándola, lo sabrás en cuanto emplees la tuya y no llegarás a lanzar el conjuro. En cuanto se lance recado desde una de las dos piedras, no podrán volver a usarse hasta el siguiente amanecer. Si se destruye una de las piedras de la pareja, la otra deja de ser mágica.",
    "id": "magic_piedras_mensajeras"
  },
  {
    "name": "POCIÓN DE AMISTAD ANIMAL",
    "category": "Poción",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Cuando bebas esta poción, podrás lanzar la versión de nivel 3 del conjuro encantar animal (CD de salvación 13). Si agitas esta turbia poción, verás pequeños fragmentos: una escama de un pez, una pluma de colibrí, la garra de un gato o el pelo de una ardilla.",
    "id": "magic_pocion_de_amistad_animal"
  },
  {
    "name": "POCIÓN DE CLARIVIDENCIA",
    "category": "Poción",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Cuando bebas esta poción, obtendrás el efecto del conjuro clarividencia (no requiere concentración). En este líquido amarillento flota un globo ocular, pero desaparece en cuanto se abre la poción.",
    "id": "magic_pocion_de_clarividencia"
  },
  {
    "name": "POCIÓN DE CRECIMIENTO",
    "category": "Poción",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Cuando bebas esta poción, obtendrás el efecto de \"agrandar\" del conjuro agrandar/reducir durante 10 minutos (no requiere concentración). El color rojo del líquido de la poción se expande continuamente a partir de una gota diminuta para teñir el líquido transparente que la rodea. A continuación, se vuelve a contraer. Si agitas la botella, no se interrumpirá el proceso.",
    "id": "magic_pocion_de_crecimiento"
  },
  {
    "name": "POCIÓN DE ENCOGER",
    "category": "Poción",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Cuando bebas esta poción, obtendrás el efecto de \"reducir\" del conjuro agrandar/reducir durante 1d4 horas (no requiere concentración). El color rojo del líquido de la poción se contrae continuamente hasta quedar reducido a una gota diminuta y, a continuación, se expande para teñir el líquido transparente que la rodea. Si agitas la botella, no se interrumpirá el proceso.",
    "id": "magic_pocion_de_encoger"
  },
  {
    "name": "POCIÓN DE FORMA GASEOSA",
    "category": "Poción",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Cuando bebas esta poción, obtendrás el efecto del conjuro forma gaseosa durante 1 hora (no requiere concentración) o hasta que pongas fin al efecto como acción adicional. El frasco de esta poción parece contener una niebla que se mueve y se derrama como si fuese agua.",
    "id": "magic_pocion_de_forma_gaseosa"
  },
  {
    "name": "POCIÓN DE FUERZA DE GIGANTE (COLINAS)",
    "category": "Poción",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Cuando bebas esta poción, tu puntuación de Fuerza cambia a 21 durante 1 hora. La poción no tendrá ningún efecto si tu Fuerza es igual o superior a esa puntuación. En el líquido transparente de la poción flota un fragmento de luz que parece la uña de un gigante.",
    "id": "magic_pocion_de_fuerza_de_gigante_colinas"
  },
  {
    "name": "POCIÓN DE FUERZA DE GIGANTE (ESCARCHA)",
    "category": "Poción",
    "rarity": "Rara",
    "attunement": "No",
    "description": "Cuando bebas esta poción, tu puntuación de Fuerza cambia a 23 durante 1 hora. La poción no tendrá ningún efecto si tu Fuerza es igual o superior a esa puntuación. En el líquido transparente de la poción flota un fragmento de luz que parece la uña de un gigante.",
    "id": "magic_pocion_de_fuerza_de_gigante_escarcha"
  },
  {
    "name": "POCIÓN DE FUERZA DE GIGANTE (FUEGO)",
    "category": "Poción",
    "rarity": "Rara",
    "attunement": "No",
    "description": "Cuando bebas esta poción, tu puntuación de Fuerza cambia a 25 durante 1 hora. La poción no tendrá ningún efecto si tu Fuerza es igual o superior a esa puntuación. En el líquido transparente de la poción flota un fragmento de luz que parece la uña de un gigante.",
    "id": "magic_pocion_de_fuerza_de_gigante_fuego"
  },
  {
    "name": "POCIÓN DE FUERZA DE GIGANTE (NUBES)",
    "category": "Poción",
    "rarity": "Muy rara",
    "attunement": "No",
    "description": "Cuando bebas esta poción, tu puntuación de Fuerza cambia a 27 durante 1 hora. La poción no tendrá ningún efecto si tu Fuerza es igual o superior a esa puntuación. En el líquido transparente de la poción flota un fragmento de luz que parece la uña de un gigante.",
    "id": "magic_pocion_de_fuerza_de_gigante_nubes"
  },
  {
    "name": "POCIÓN DE FUERZA DE GIGANTE (PIEDRA)",
    "category": "Poción",
    "rarity": "Rara",
    "attunement": "No",
    "description": "Cuando bebas esta poción, tu puntuación de Fuerza cambia a 23 durante 1 hora. La poción no tendrá ningún efecto si tu Fuerza es igual o superior a esa puntuación. En el líquido transparente de la poción flota un fragmento de luz que parece la uña de un gigante.",
    "id": "magic_pocion_de_fuerza_de_gigante_piedra"
  },
  {
    "name": "POCIÓN DE FUERZA DE GIGANTE (TORMENTAS)",
    "category": "Poción",
    "rarity": "Legendaria",
    "attunement": "No",
    "description": "Cuando bebas esta poción, tu puntuación de Fuerza cambia a 29 durante 1 hora. La poción no tendrá ningún efecto si tu Fuerza es igual o superior a esa puntuación. En el líquido transparente de la poción flota un fragmento de luz que parece la uña de un gigante.",
    "id": "magic_pocion_de_fuerza_de_gigante_tormentas"
  },
  {
    "name": "POCIÓN DE HEROÍSMO",
    "category": "Poción",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Cuando bebas esta poción, obtendrás 10 puntos de golpe temporales que durarán 1 hora. Durante ese periodo, te encontrarás bajo el efecto del conjuro bendición (no requiere concentración). El líquido azul de la poción borbotea y echa humo, como si estuviera hirviendo.",
    "id": "magic_pocion_de_heroismo"
  },
  {
    "name": "POCIÓN DE INVISIBILIDAD",
    "category": "Poción",
    "rarity": "Raro",
    "attunement": "No",
    "description": "El frasco de esta poción parece vacío, pero, al mismo tiempo, da la impresión de contener líquido. Cuando bebas esta poción, obtendrás el estado de invisible durante 1 hora. El efecto termina antes de tiempo si haces una tirada de ataque, causas daño o lanzas un conjuro.",
    "id": "magic_pocion_de_invisibilidad"
  },
  {
    "name": "POCIÓN DE INVULNERABILIDAD",
    "category": "Poción",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Durante 1 minuto después de beber esta poción, tienes resistencia a todo el daño. Esta poción, espesa como el sirope, parece hierro líquido.",
    "id": "magic_pocion_de_invulnerabilidad"
  },
  {
    "name": "POCIÓN DE LEER MENTES",
    "category": "Poción",
    "rarity": "Raro",
    "attunement": "No",
    "description": "Cuando bebas esta poción, obtendrás el efecto del conjuro detectar pensamientos (CD de salvación 13) durante 10 minutos (no requiere concentración). En el líquido denso y morado de esta poción flota una nube rosa ovoide.",
    "id": "magic_pocion_de_leer_mentes"
  },
  {
    "name": "POCIÓN DE LONGEVIDAD",
    "category": "Poción",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Cuando bebas esta poción, tu edad física se reduce en 1d6 + 6 años, hasta un mínimo de 13 años. Cada vez que tomes una poción de longevidad después de la primera, existe una probabilidad acumulativa del 10 % de que envejezcas 1d6 + 6 años. Suspendido en el líquido ámbar hay un corazón diminuto que, contra todo pronóstico, todavía late. Este ingrediente desaparece cuando se abre la poción.",
    "id": "magic_pocion_de_longevidad"
  },
  {
    "name": "POCIÓN DE RESISTENCIA",
    "category": "Poción",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Cuando bebas esta poción, tendrás resistencia a un tipo de daño durante 1 hora. Tu GM elige el tipo o lo determina al azar tirando en la tabla a continuación.",
    "tables": [
      {
        "title": "Tipo de daño",
        "columns": [
          "1d10",
          "Tipo de daño"
        ],
        "rows": [
          [
            "1",
            "Ácido"
          ],
          [
            "2",
            "Frío"
          ],
          [
            "3",
            "Fuego"
          ],
          [
            "4",
            "Fuerza"
          ],
          [
            "5",
            "Necrótico"
          ],
          [
            "6",
            "Psíquico"
          ],
          [
            "7",
            "Radiante"
          ],
          [
            "8",
            "Relámpago"
          ],
          [
            "9",
            "Trueno"
          ],
          [
            "10",
            "Veneno"
          ]
        ]
      }
    ],
    "id": "magic_pocion_de_resistencia"
  },
  {
    "name": "POCIÓN DE RESPIRAR BAJO EL AGUA",
    "category": "Poción",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Puedes respirar debajo del agua durante 24 horas tras beber esta poción. Su líquido verde turbio huele a mar y en él flota una burbuja con aspecto de medusa.",
    "id": "magic_pocion_de_respirar_bajo_el_agua"
  },
  {
    "name": "POCIÓN DE TREPAR",
    "category": "Poción",
    "rarity": "Común",
    "attunement": "No",
    "description": "Cuando bebas esta poción, obtendrás una velocidad trepando igual a tu velocidad durante 1 hora. Durante ese tiempo, tendrás ventaja en las pruebas de Fuerza (Atletismo) para trepar. Esta poción se separa en tres capas (marrón, plateada y gris) que parecen los estratos de una roca. Si agitas la botella, los colores no se mezclan.",
    "id": "magic_pocion_de_trepar"
  },
  {
    "name": "POCIÓN DE VELOCIDAD",
    "category": "Poción",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Cuando bebas esta poción, obtendrás el efecto del conjuro acelerar durante 1 minuto (no requiere concentración) sin sufrir la ola de somnolencia que suele ocurrir cuando termina el efecto. El líquido amarillo de este brebaje tiene vetas negras y forma remolinos.",
    "id": "magic_pocion_de_velocidad"
  },
  {
    "name": "POCIÓN DE VENENO",
    "category": "Poción",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Este mejunje parece, huele y sabe como una poción de curación u otra poción beneficiosa. Sin embargo, en realidad es un veneno enmascarado con magia de ilusionismo. Un conjuro identificar revelará su verdadera naturaleza. Si la bebes, sufrirás 4d6 de daño de veneno y deberás superar una tirada de salvación de Constitución con CD 13 o tendrás el estado de envenenado durante 1 hora.",
    "id": "magic_pocion_de_veneno"
  },
  {
    "name": "POCIÓN DE VITALIDAD",
    "category": "Poción",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Cuando bebas esta poción, eliminará todos los niveles de cansancio que tengas y el estado de envenenado sobre ti. Durante las siguientes 24 horas, recuperas la cantidad máxima de puntos de golpe de cualquier dado de puntos de golpe que utilices. El líquido carmesí de este brebaje palpita regularmente con una luz apagada, recordando a un corazón.",
    "id": "magic_pocion_de_vitalidad"
  },
  {
    "name": "POCIÓN DE VUELO",
    "category": "Poción",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Cuando bebas esta poción, obtendrás una velocidad volando igual a tu velocidad durante 1 hora y podrás levitar. Si te encuentras en pleno vuelo cuando el efecto de la poción termine, te caerás salvo que cuentes con otros medios que te mantengan en el aire. El líquido transparente de esta poción flota en la parte superior del frasco y tiene impurezas blancas con forma de nube.",
    "id": "magic_pocion_de_vuelo"
  },
  {
    "name": "POCIONES DE CURACIÓN",
    "category": "Poción",
    "rarity": "Rareza Variable",
    "attunement": "No",
    "description": "Recuperas puntos de golpe al beber esta poción. La cantidad de puntos de golpe depende de la rareza de la poción, como se muestra en la tabla a continuación. Sea cual sea su potencia, el líquido rojo de la poción brilla al agitarlo.",
    "tables": [
      {
        "title": "Pociones de curación",
        "columns": [
          "Columna 1",
          "Columna 2",
          "Columna 3"
        ],
        "rows": [
          [
            "Poción de curación",
            "2d4+2",
            "Común"
          ],
          [
            "Poción de curación (mayor)",
            "4d4+4",
            "Infrecuente"
          ]
        ]
      }
    ],
    "id": "magic_pociones_de_curacion"
  },
  {
    "name": "POLVO DE DESAPARICIÓN",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Este polvo parece arena muy fina y hay suficiente para un solo uso. Cuando empleas una acción de utilizar para esparcir el polvo en el aire, tú y cada criatura y objeto que se encuentre en una emanación de 10 pies o menos que se origina en ti tendréis el estado de invisibles durante 2d4 minutos. La duración es la misma para todos los afectados y el polvo se consume cuando la magia tiene efecto. Inmediatamente después de que una criatura afectada lleve a cabo una tirada de ataque, inflija daño o lance un conjuro, el estado de invisible terminará para ella.",
    "id": "magic_polvo_de_desaparicion"
  },
  {
    "name": "POLVO DE ESTORNUDAR Y ATRAGANTARSE",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Este polvo, que se encuentra en un pequeño recipiente, parece ser polvo de desaparición, y un conjuro identificar lo reconocerá como tal. Hay suficiente para un solo uso. Como acción de utilizar, puedes esparcir el polvo en el aire y obligar a todas las criaturas en una emanación de 30 pies originada en ti (la cual te incluye a ti) a hacer una tirada de salvación de Constitución con CD 15. Los autómatas, cienos, elementales, muertos vivientes y plantas superarán la tirada de salvación automáticamente. Si la falla, una criatura empezará a estornudar de forma incontrolada: tendrá el estado de incapacitada y sufrirá asfixia. La criatura repetirá la tirada de salvación al final de cada uno de sus turnos y, si tiene éxito, se librará del efecto. El conjuro restablecimiento menor también puede poner fin a este efecto sobre una criatura.",
    "id": "magic_polvo_de_estornudar_y_atragantarse"
  },
  {
    "name": "POLVO DE SEQUEDAD",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Este pequeño paquete contiene 1d6 + 4 pizcas de polvo. Como acción de utilizar, puedes echar una pizca sobre agua. El polvo convertirá un cubo de agua de 15 pies de lado en una bolita del tamaño de una canica, que quedará flotando o en reposo cerca de donde se esparció el polvo. El peso de la bolita es insignificante. Una criatura puede emplear una acción de utilizar para golpear la bolita contra una superficie dura, lo que hará añicos la bolita y liberará el agua que absorbió el polvo. Hacer esto acaba con la magia de la bolita. Como acción de utilizar, puedes echar una pizca de polvo sobre un elemental compuesto principalmente de agua (como un elemental de agua) que esté a 5 pies o menos de ti. Esa criatura deberá realizar una tirada de salvación de Constitución con CD 13; sufrirá 10d6 de daño necrótico si la falla o la mitad del daño si la supera.",
    "id": "magic_polvo_de_sequedad"
  },
  {
    "name": "PORTAL CÚBICO",
    "category": "Objeto maravilloso",
    "rarity": "Legendario",
    "attunement": "No",
    "description": "Este cubo mide 3 pulgadas de lado e irradia una energía mágica palpable. Cada una de las seis caras del cubo está conectada con un plano de existencia diferente, entre ellos el Plano Material. El resto de planos los determina tu GM. El cubo tiene 3 cargas y recupera 1d3 cargas empleadas cada día, al amanecer. Como acción de magia, puedes gastar 1 de las cargas del cubo para lanzar uno de los siguientes conjuros usando el cubo.\n\n• Desplazamiento entre planos. Al pulsar dos veces una cara del cubo, lanzas desplazamiento entre planos y transportas a los objetivos al plano de existencia conectado con esa cara.\n• Portal. Al pulsar una cara del cubo, lanzas portal abriendo un acceso al plano de existencia conectado con esa cara.",
    "id": "magic_portal_cubico"
  },
  {
    "name": "POZO DE LOS MUCHOS MUNDOS",
    "category": "Objeto maravilloso",
    "rarity": "Legendario",
    "attunement": "No",
    "description": "Esta delicada tela negra, suave como la seda, está doblada para tener las dimensiones de un pañuelo. Al desdoblarla, se convierte en una sábana circular de 6 pies de diámetro. Puedes emplear una acción de magia para extender el pozo de los muchos mundos y colocarlo sobre una superficie sólida, donde creará un portal de 6 pies de diámetro hacia otro plano de existencia que funciona en ambos sentidos. Cada vez que el objeto abra un portal, tu GM decidirá adónde conduce. El portal permanece abierto hasta que una criatura a 5 pies o menos de él use una acción de magia para cerrarlo agarrando los bordes de la tela y plegándola. En cuanto el pozo de los muchos mundos haya abierto un portal, no podrá volver a hacerlo durante 1d8 horas.",
    "id": "magic_pozo_de_los_muchos_mundos"
  },
  {
    "name": "SOMBRERO DE DISFRAZ",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Mientras lleves este sombrero, puedes lanzar el conjuro disfrazarse. El conjuro termina si te quitas el sombrero.",
    "id": "magic_sombrero_de_disfraz"
  },
  {
    "name": "SOMBRERO DE MÚLTIPLES CONJUROS",
    "category": "Objeto maravilloso",
    "rarity": "Muy raro",
    "attunement": "Sí (requiere sintonización con un mago)",
    "description": "Este sombrero puntiagudo tiene las siguientes propiedades.\n\n• Canalizador mágico. Mientras sujetas el sombrero, puedes usarlo como canalizador mágico para tus conjuros de mago. Cualquier conjuro que lances mediante el sombrero tendrá un componente somático especial: debes meter la mano en el sombrero y “sacar” el conjuro de él.\n• Conjuro desconocido. Mientras sujetas el sombrero, puedes intentar lanzar un conjuro de nivel 1 o superior que no conoces. El conjuro debe estar en la lista de conjuros de mago, debe ser de un nivel que puedas lanzar y no puede tener componentes materiales que cuesten más de 1000 po. Cuando hayas decidido el conjuro, deberás gastar un espacio de conjuro del nivel correspondiente. A continuacióncontinuación, para determinar si lo lanzas, haz una prueba de Inteligencia (Conocimiento arcano) (CD 10 más el nivel del conjuro). Si la superas, lanzarás el conjuro con su tiempo de lanzamiento normal y no podrás volver a utilizar esta propiedad hasta que finalices un descanso corto o largo. Si la fallas, el conjuro no se lanzará y en su lugar se producirá un efecto aleatorio. Tira en la tabla a continuación para determinarlo. Los conjuros que lances desde el sombrero emplean tu CD de salvación de conjuros y tu bonificador de ataque de conjuros. 01–50 Lanzas un conjuro aleatorio que determinas tirando 1d10: si el resultado es 1, agrandar/reducir (efecto de agrandar); si es 2, agrandar/reducir (efecto de reducir); si es 3, bola de fuego; si es 4, fuego feérico; si es 5, fuerza fantasmal; si es 6, invisibilidad (sobre ti); si es 7, nube apestosa; si es 8, polimorfar; si es 9, ráfaga de viento; si es 10, relámpago.",
    "tables": [
      {
        "title": "Efecto",
        "columns": [
          "Resultado",
          "Efecto"
        ],
        "rows": [
          [
            "51–55",
            "Creerás que ha sucedido algo asombroso y tendrás el estado de aturdido hasta el final de tu siguiente turno."
          ],
          [
            "56–60",
            "Un enjambre inofensivo de mariposas llena un cubo de 10 pies de lado a 30 pies o menos de ti. El enjambre se dispersa pasado 1 minuto."
          ],
          [
            "61–65",
            "Sacas un objeto no mágico del sombrero. Tira 1d4 para determinar el objeto: si el resultado es 1, un vial de ácido; si es 2, una antorcha encendida; si es 3, un frasco de fuego de alquimista; si es 4, una palanqueta."
          ],
          [
            "66–70",
            "Sufres unas “náuseas mágicas” y tienes el estado de envenenado durante 1 hora."
          ],
          [
            "71–75",
            "Tienes el estado de petrificado hasta el final de tu siguiente turno."
          ],
          [
            "76–80",
            "Sacas un objeto no mágico del sombrero. Tira 1d4 para determinar el objeto: si el resultado es 1, una bolsa de abrojos; si es 2, una cuerda con un garfio de escalada atado en un extremo; si es 3, una daga; si es 4, una gema valorada en 50 po."
          ],
          [
            "81–85",
            "Una criatura aparece en un espacio sin ocupar lo más cerca posible de ti. El animal no se encuentra bajo tu control, actúa con normalidad y desaparece tras 1 hora o cuando sus puntos de golpe se reduzcan a 0. Tira 1d4 para determinar la criatura: si el resultado es 1, un camello; si es 2, un elefante; si es 3, una mula; si es 4, una serpiente constrictora."
          ],
          [
            "86–90",
            "Un enjambre de murciélagos hostil surge del sombrero, ocupa tu espacio y te ataca."
          ],
          [
            "91–95",
            "Un portal bidireccional y vertical de 10 pies de diámetro que conduce a otro plano de existencia se abre en un espacio sin ocupar a 30 pies o menos de ti y permanece abierto hasta el final de tu siguiente turno. Tu GM establece adónde lleva."
          ],
          [
            "96–00",
            "Sacas un objeto mágico del sombrero. Tira 1d6 para determinar la rareza del objeto: si el resultado es 1–3, común; si es 4–5, infrecuente; si es 6, raro. Tu GM elige el objeto, que desaparecerá tras 1 hora si no se consume o destruye antes."
          ]
        ]
      }
    ],
    "id": "magic_sombrero_de_multiples_conjuros"
  },
  {
    "name": "TALISMÁN DE CERRAR HERIDAS",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Mientras lleves puesto este colgante, obtienes los siguientes beneficios:\n\n• Curación natural mejorada. Cuando tires un dado de puntos de golpe para recuperar puntos de golpe, se duplicará la cantidad de puntos de golpe que recuperas.\n• Preservar la vida. Cuando hagas una tirada de salvación contra muerte, puedes cambiar un resultado fallido de 9 o menos por 10, lo que te permite superar la tirada.",
    "id": "magic_talisman_de_cerrar_heridas"
  },
  {
    "name": "TALISMÁN DE LA ESFERA",
    "category": "Objeto maravilloso",
    "rarity": "Legendario",
    "attunement": "Sí",
    "description": "Mientras sostengas o lleves puesto este talismán, tendrás ventaja en cualquier prueba de Inteligencia (Conocimiento arcano) para controlar una esfera de aniquilación. Además, siempre que comiences tu turno controlando una esfera de aniquilación, puedes emplear una acción de magia para moverla 10 pies más una cantidad de pies adicionales igual a 10 × tu modificador por Inteligencia. Este movimiento no tiene por qué ser en línea recta.",
    "id": "magic_talisman_de_la_esfera"
  },
  {
    "name": "TALISMÁN DE SALUD",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Mientras lleves este colgante, puedes emplear una acción de magia para recuperar 2d4 + 2 puntos de golpe. Una vez utilizada, esta propiedad no puede volver a usarse hasta el siguiente amanecer. Además, tienes ventaja en las tiradas de salvación para evitar o poner fin al estado de envenenado mientras lleves puesto el colgante.",
    "id": "magic_talisman_de_salud"
  },
  {
    "name": "TALISMÁN DEL BIEN PURO",
    "category": "Objeto maravilloso",
    "rarity": "Legendario",
    "attunement": "Sí (requiere sintonización con un clerigo o paladín)",
    "description": "Este talismán es un poderoso símbolo del bien. Un infernal o muerto viviente que toque el talismán sufre 8d6 de daño radiante y sufrirá el daño de nuevo cada vez que sostenga o lleve puesto el talismán al terminar su turno.\n\n• Represalia pura. El talismán tiene 7 cargas. Mientras lo lleves puesto o lo sostengas, puedes emplear una acción de magia para gastar 1 carga y hacer bjetivo a una criatura que puedas ver en el suelo a 120 pies o menos de ti. Una grieta ardiente se abrirá bajo el objetivo, que hará una tirada de salvación de Destreza con CD 20. Si el objetivo es un infernal o un muerto viviente, tendrá desventaja en la tirada. Si la falla, caerá en la grieta y será destruido, sin dejar restos. Si la supera, no caerá en la grieta, pero sufrirá 4d6 de daño psíquico debido a la terrible experiencia. En cualquier caso, la grieta se cerrará y no quedará huella de su existencia. Cuando gastes la última carga, el talismán se diseminará en unas motas de luz dorada y se destruirá.\n• Símbolo sagrado. Puedes emplear el talismán como símbolo sagrado. Obtendrás un bonificador de +2 a las tiradas de ataque de conjuro mientras lo lleves puesto o lo sostengas.",
    "id": "magic_talisman_del_bien_puro"
  },
  {
    "name": "TALISMÁN DEL MAL DEFINITIVO",
    "category": "Objeto maravilloso",
    "rarity": "Legendario",
    "attunement": "Sí",
    "description": "Este objeto simboliza el mal impenitente. Una criatura que no sea infernal o muerto viviente que toque el talismán sufre 8d6 de daño necrótico y sufrirá el daño de nuevo cada vez que sostenga o lleve puesto el talismán al terminar su turno.\n\n• Final definitivo. El talismán tiene 6 cargas. Mientras lo lleves puesto o lo sostengas, puedes emplear una acción de magia para gastar 1 carga y hacer objetivo a una criatura que puedas ver en el suelo a 120 pies o menos de ti. Una grieta ardiente se abrirá bajo el objetivo, que hará una tirada de salvación de Destreza con CD 20. Si el objetivo es un celestial, tendrá desventaja en la tirada. Si la falla, caerá en la grieta y será destruido, sin dejar restos. Si la supera, no caerá en la grieta, pero sufrirá 4d6 de daño psíquico debido a la terrible experiencia. En cualquier caso, la grieta se cerrará y no quedará huella de su existencia. Cuando gastes la última carga, el talismán se disolverá en un limo apestoso y se destruirá.\n• Símbolo sagrado. Puedes emplear el talismán como símbolo sagrado. Obtendrás un bonificador de +2 a las tiradas de ataque de conjuro mientras lo lleves puesto o lo sostengas.",
    "id": "magic_talisman_del_mal_definitivo"
  },
  {
    "name": "TOMO DE ENTENDIMIENTO",
    "category": "Objeto maravilloso",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Este libro contiene ejercicios de intuición y perspicacia, y sus palabras están impregnadas de magia. Si dedicas 48 horas durante un periodo de 6 días, como mucho, a estudiar el contenido del libro y poner en práctica sus indicaciones, tu Sabiduría aumentará en 2, hasta un máximo de 30. Después, el manual perderá su magia, pero la recuperará cuando pase un siglo.",
    "id": "magic_tomo_de_entendimiento"
  },
  {
    "name": "TOMO DE LIDERAZGO E INFLUENCIA",
    "category": "Objeto maravilloso",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Este libro contiene indicaciones para influir y embelesar a los demás, y sus palabras están impregnadas de magia. Si dedicas 48 horas durante un periodo de 6 días, como mucho, a estudiar el contenido del libro y poner en práctica sus indicaciones, tu Carisma aumentará en 2, hasta un máximo de 30. Después, el manual perderá su magia, pero la recuperará cuando pase un siglo.",
    "id": "magic_tomo_de_liderazgo_e_influencia"
  },
  {
    "name": "TOMO DE PENSAMIENTO CLARO",
    "category": "Objeto maravilloso",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Este libro contiene ejercicios de lógica y memoria, y sus palabras están impregnadas de magia. Si dedicas 48 horas durante un periodo de 6 días, como mucho, a estudiar el contenido del libro y poner en práctica sus indicaciones, tu Inteligencia aumentará en 2, hasta un máximo de 30. Después, el manual perderá su magia, pero la recuperará cuando pase un siglo.",
    "id": "magic_tomo_de_pensamiento_claro"
  },
  {
    "name": "TRIDENTE DE COMANDAR PECES",
    "category": "Arma",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Esta arma mágica tiene 3 cargas y recupera 1d3 cargas empleadas cada día, al amanecer. Mientras la lleves contigo, podrás gastar 1 carga para lanzar dominar bestia (CD de salvación 15) desde ella sobre una bestia que tenga una velocidad nadando.",
    "subcategory": "Arma (tridente)",
    "id": "magic_tridente_de_comandar_peces"
  },
  {
    "name": "TÚNICA DE COLORES HIPNÓTICOS",
    "category": "Objeto maravilloso",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Esta túnica tiene 3 cargas y recupera 1d3 cargas empleadas cada día, al amanecer. Mientras la lleves puesta, podrás utilizar una acción de magia y gastar 1 carga para hacer que la prenda muestre un patrón cambiante de tonos y formas deslumbrantes hasta el final de tu siguiente turno. Durante este tiempo, la túnica emite luz brillante en un radio de 30 pies y luz tenue 30 pies más allá, y las criaturas que puedan verte tendrán desventaja en las tiradas de ataque contra ti. Cualquier criatura que esté bajo la luz brillante y pueda verte cuando el poder de la túnica esté activo deberá superar una tirada de salvación de Sabiduría con CD 15 o tendrá el estado de aturdida hasta que termine el efecto.",
    "id": "magic_tunica_de_colores_hipnoticos"
  },
  {
    "name": "TÚNICA DE LAS ESTRELLAS",
    "category": "Objeto maravilloso",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Esta túnica negra o azul oscura lleva bordadas pequeñas estrellas blancas o plateadas. Mientras la lleves puesta, recibirás un bonificador de +1 a las tiradas de salvación. Seis de las estrellas, situadas en la parte superior delantera de la túnica, son especialmente grandes. Mientras lleves puesta la túnica, puedes emplear una acción de magia para arrancar una de las estrellas y gastarla para lanzar la versión de nivel 5 de proyectil mágico. Cada día al amanecer, 1d6 estrellas arrancadas reaparecerán en la túnica. Mientras lleves puesta la túnica, podrás utilizar una acción de magia para entrar en el Plano Astral junto con todo lo que vistas o lleves. Permanecerás allí hasta que utilices una acción de magia para volver al plano en el que estabas. Reaparecerás en el último espacio que ocupabas o, si el espacio ya está ocupado, en el espacio sin ocupar más cercano.",
    "id": "magic_tunica_de_las_estrellas"
  },
  {
    "name": "TÚNICA DE LOS OJOS",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Esta túnica está decorada con un estampado de ojos. Mientras la lleves puesta, obtendrás los siguientes beneficios:\n\n• Sentidos especiales. Tienes visión en la oscuridad y visión verdadera hasta 120 pies.\n• Visión total. La túnica te otorga ventaja en las pruebas de Sabiduría (Percepción) que dependan de la vista.\n• Inconvenientes. Si se lanza un conjuro luz sobre la túnica o un conjuro luz del día a 5 pies o menos de ella, tendrás el estado de cegado durante 1 minuto. Al final de cada uno de tus turnos, harás una tirada de salvación de Constitución (con CD 11 para luz o CD 15 para luz del día) y, si la superas, pondrás fin al estado.",
    "id": "magic_tunica_de_los_ojos"
  },
  {
    "name": "TÚNICA DE OBJETOS ÚTILES",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Esta túnica está cubierta de parches de tela de diversas formas y colores. Mientras la lleves puesta, podrás utilizar una acción de magia para quitar uno de los parches y hacer que se convierta en el objeto o criatura que representa. En cuanto hayas quitado el último parche, la túnica se volverá una prenda normal y corriente.\n\nLa túnica tiene dos de cada uno de los siguientes parches:\n\n• Cuerda (enrollada)\n• Daga\n• Espejo\n• Linterna de ojo de buey (llena y encendida)\n• Saco\n• Vara\n\nAdemás, la túnica tiene otros 4d4 parches. Tu GM los elige o los determina al azar tirando en la tabla a continuación.",
    "tables": [
      {
        "title": "Parche",
        "columns": [
          "Resultado",
          "Efecto"
        ],
        "rows": [
          [
            "01–08",
            "Bolsa con 100 po"
          ],
          [
            "09–15",
            "Cofre de plata (12 pulgadas de largo, 6 pulgadas de ancho y de alto) con un valor de 500 po"
          ],
          [
            "16–22",
            "Puerta de hierro (hasta 10 pies de ancho y 3 de alto, atrancada por el lado que elijas), que puedes colocar en una abertura que esté a tu alcance; se adecuará al tamaño de la abertura y se instalará y afianzará ella sola"
          ],
          [
            "23–30",
            "10 gemas con un valor de 100 po cada una"
          ],
          [
            "31–44",
            "Escalera de madera (25 pies de largo)"
          ],
          [
            "45–51",
            "Caballo de monta ensillado"
          ],
          [
            "52–59",
            "Pozo abierto (cubo de 10 pies de lado), que puedes colocar en el suelo a 10 pies o menos de ti"
          ],
          [
            "60–68",
            "4 pociones de curación"
          ],
          [
            "69–75",
            "Bote de remos (10 pies de largo)"
          ],
          [
            "76–83",
            "Pergamino de conjuro que contiene un conjuro de nivel 1, 2 o 3 (a tu elección)"
          ],
          [
            "84–90",
            "2 mastines"
          ],
          [
            "91–96",
            "Ventana (2 pies por 4 pies, con una profundidad de hasta 2 pies), que puedes colocar en una superficie vertical que esté a tu alcance"
          ],
          [
            "97–00",
            "Ariete portátil"
          ]
        ]
      }
    ],
    "id": "magic_tunica_de_objetos_utiles"
  },
  {
    "name": "TÚNICA DEL ARCHIMAGO",
    "category": "Objeto maravilloso",
    "rarity": "Legendario",
    "attunement": "Sí (requiere sintonización con un brujo, mago o hechicero)",
    "description": "Esta elegante prenda está hecha de una tela exquisita y adornada con runas. Mientras lleves puesta la túnica, obtendrás los siguientes beneficios.\n\n• Armadura. Si no llevas armadura, tu clase de armadura base será de 15 más tu modificador por Destreza.\n• Magia de guerra. Tu CD de salvación de conjuros y tu bonificador de ataque de conjuros aumentan en 2.\n• Resistencia mágica. Tienes ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos.",
    "id": "magic_tunica_del_archimago"
  },
  {
    "name": "TÚNICA INFERNAL",
    "category": "Objeto maravilloso",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Esta túnica roja, adornada con elaborados detalles dorados, desprende una presencia regia e inquietante. Mientras la lleves puesta, obtienes un bonificador de +2 a la clase de armadura, tienes resistencia al daño de fuego y puedes hablar y entender infernal.",
    "id": "magic_tunica_infernal"
  },
  {
    "name": "VARA DE LA ABSORCIÓN",
    "category": "Vara",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Mientras empuñes esta vara, podrás utilizar una reacción para absorber un conjuro que solo te haga objetivo a ti y no cree un área de efecto. El efecto del conjuro absorbido se cancelará y la energía del conjuro (no el conjuro en sí) se almacenará en la vara. La energía tiene el mismo nivel que el conjuro cuando se lanzó. Un conjuro cancelado se disipará sin efecto y se perderán los recursos empleados para lanzarlo. La vara puede absorber y almacenar hasta 50 niveles de energía a lo largo de su existencia. En cuanto la vara absorba 50 niveles de energía, no podrá absorber más. Si eres el objetivo de un conjuro que la vara no puede almacenar, esta no tendrá efecto sobre ese conjuro. Cuando te sintonizas con la vara, sabes cuántos niveles de energía ha absorbido a lo largo de su existencia y cuántos niveles de energía de conjuro están almacenados en ella en ese momento. Si eres un lanzador de conjuros y empuñas esta vara, podrás convertir la energía almacenada en ella en espacios de conjuro para lanzar conjuros que hayas preparado o conozcas. Solamente puedes crear espacios de conjuro de un nivel igual o inferior al mayor de tus espacios de conjuro, como máximo de nivel 5. Puedes utilizar los niveles almacenados en lugar de tus espacios de conjuro, pero, por lo demás, lanzarás el conjuro de forma normal. Por ejemplo, puedes utilizar 3 niveles almacenados en la vara como un espacio de conjuro de nivel 3. Una vara recién encontrada suele tener 1d10 niveles de energía de conjuros almacenados. Una vara que ya no pueda absorber la energía de los conjuros y a la que no le quede nada de energía almacenada se volverá no mágica.",
    "id": "magic_vara_de_la_absorcion"
  },
  {
    "name": "VARA DE LA ALERTA",
    "category": "Vara",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Esta vara tiene las siguientes propiedades.\n\n• Alerta. Mientras empuñes la vara, tendrás ventaja en las pruebas de Sabiduría (Percepción) y en las tiradas de iniciativa.\n• Conjuros. Mientras empuñes la vara, puedes lanzar los siguientes conjuros desde ella:\n\n• Detectar el bien y el mal\n• Detectar magia\n• Detectar venenos y enfermedades\n• Ver invisibilidad\n\n• Aura protectora. Como acción de magia, puedes clavar el extremo de la empuñadura en el suelo, tras lo cual la cabeza de la vara emitirá luz brillante en un radio de 60 pies y luz tenue 60 pies más allá. Mientras os encontréis en esa luz brillante, tus aliados y tú obtendréis un bonificador de +1 a la clase de armadura y a las tiradas de salvación. Además, podréis sentir la ubicación de cualquier criatura invisible que también esté bajo la luz brillante. La cabeza de la vara dejará de brillar y el efecto terminará después de 10 minutos o cuando una criatura utilice una acción de magia para sacar la vara del suelo. Una vez utilizada, esta propiedad no puede volver a usarse hasta el siguiente amanecer.",
    "id": "magic_vara_de_la_alerta"
  },
  {
    "name": "VARA DE LA RESURRECCIÓN",
    "category": "Vara",
    "rarity": "Legendario",
    "attunement": "Sí",
    "description": "Esta vara tiene 5 cargas. Mientras la empuñas, puedes lanzar uno de los siguientes conjuros desde ella: curar (gasta 1 carga) o resurrección (gasta 5 cargas). La vara recupera 1 carga empleada cada día, al amanecer. Si gastas la última carga, tira 1d20. Si el resultado es 1, la vara desaparecerá en un estallido de luz inofensivo.",
    "id": "magic_vara_de_la_resurreccion"
  },
  {
    "name": "VARA DE LA SEGURIDAD",
    "category": "Vara",
    "rarity": "Muy raro",
    "attunement": "No",
    "description": "Mientras empuñes esta vara, puedes emplear una acción de magia para activarla. Os transportará instantáneamente a ti y hasta otras 199 criaturas voluntarias que puedas ver a un semiplano. Tú eliges la forma que toma el semiplano. Podría ser un tranquilo jardín, una taberna alegre, un enorme palacio, una isla tropical, una feria fantástica o cualquier cosa que te imagines. Independientemente de su naturaleza, el semiplano contiene suficiente agua y comida para sustentar a sus visitantes, y su entorno no podrá hacer daño a quienes lo visiten. Cualquier otra cosa con la que se pueda interactuar allí solo podrá existir dentro de él. Por ejemplo, una flor recogida de un jardín de allí desaparece si se saca fuera del semiplano. Por cada hora que un visitante pase en el semiplano, recuperará tantos puntos de golpe como si hubiera gastado 1 dado de puntos de golpe. Además, las criaturas no envejecen allí, a pesar de que el tiempo pasa con normalidad. Los visitantes pueden permanecer en el semiplano hasta 200 días divididos entre el número de criaturas que haya en él (redondeando hacia abajo). Cuando el tiempo se agote o utilices una acción de magia para finalizar el efecto, todos los visitantes reaparecerán en el lugar que ocupaban cuando activaste la vara o en el espacio sin ocupar más cercano a ese lugar. Una vez usada, esta propiedad no podrá volver a emplearse hasta pasados 10 días.",
    "id": "magic_vara_de_la_seguridad"
  },
  {
    "name": "VARA INAMOVIBLE",
    "category": "Vara",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Esta vara de hierro posee un botón en uno de sus extremos. Puedes emplear una acción de utilizar para pulsar el botón y hacer que la vara se fije mágicamente en el sitio. Hasta que otra criatura o tú empleéis una acción de utilizar para pulsar de nuevo el botón, la vara no se moverá, desafiando a la gravedad si es necesario. Puede aguantar hasta 8000 lb de peso; una cantidad mayor provocará que se desactive y caiga. Una criatura puede emplear una acción de utilizar para realizar una prueba de Fuerza (Atletismo) con CD 30. Si tiene éxito, moverá la vara hasta 10 pies.",
    "peso": 8818,
    "id": "magic_vara_inamovible"
  },
  {
    "name": "VARITA DE ATADURA",
    "category": "Varita",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Esta varita tiene 7 cargas.\n\n• Conjuros. Mientras sostengas la varita, puedes lanzar desde ella un conjuro (CD de salvación 17) de la tabla \"Conjuros (cargas)\". En ella se indica cuántas cargas debes gastar para lanzar el conjuro.\n• Recuperar cargas. La varita recupera 1d6 + 1 cargas empleadas cada día, al amanecer. Si gastas la última carga de la varita, tira 1d20. Si el resultado es 1, la varita se convierte en cenizas y se destruye.",
    "tables": [
      {
        "title": "Conjuros (cargas)",
        "columns": [
          "Conjuro",
          "Coste en cargas"
        ],
        "rows": [
          [
            "Inmovilizar monstruo",
            "5"
          ],
          [
            "Inmovilizar persona",
            "2"
          ]
        ]
      }
    ],
    "id": "magic_varita_de_atadura"
  },
  {
    "name": "VARITA DE BOLAS DE FUEGO",
    "category": "Varita",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Esta varita tiene 7 cargas. Mientras la sostengas, puedes gastar hasta 3 cargas para lanzar bola de fuego (CD de salvación 15) desde ella. Si empleas 1 carga, podrás lanzar la versión de nivel 3 del conjuro. Puedes aumentar el nivel del conjuro en 1 por cada carga adicional que emplees.\n\n• Recuperar cargas. La varita recupera 1d6 + 1 cargas empleadas cada día, al amanecer. Si gastas la última carga de la varita, tira 1d20. Si el resultado es 1, la varita se convierte en cenizas y se destruye.",
    "id": "magic_varita_de_bolas_de_fuego"
  },
  {
    "name": "VARITA DE DETECCIÓN MÁGICA",
    "category": "Varita",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Esta varita tiene 3 cargas. Mientras la sostengas, puedes gastar 1 carga para lanzar detectar magia desde ella. La varita recupera 1d3 cargas empleadas cada día, al amanecer.",
    "id": "magic_varita_de_deteccion_magica"
  },
  {
    "name": "VARITA DE DETECTAR ENEMIGOS",
    "category": "Varita",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Esta varita tiene 7 cargas. Mientras la sostengas, puedes emplear una acción de magia para gastar 1 carga. Durante 1 minuto, conocerás la dirección en la que se encuentra la criatura hostil más cercana a ti que esté a 60 pies o menos, pero no la distancia exacta. La varita puede percibir la presencia de criaturas hostiles que sean etéreas o invisibles o estén disfrazadas o escondidas, así como las que se detecten a simple vista. El efecto acaba si dejas de sostener la varita.",
    "id": "magic_varita_de_detectar_enemigos"
  },
  {
    "name": "VARITA DE LAS MARAVILLAS",
    "category": "Varita",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Esta varita tiene 7 cargas. Mientras la sostengas, puedes emplear una acción de magia para gastar 1 carga y elegir un punto a 120 pies o menos de ti. Ese espacio se convertirá en el punto de origen de un conjuro u otro efecto mágico que se determina tirando en la tabla “Efectos de la varita de las maravillas”. Los conjuros lanzados desde la varita tienen una CD de salvación de 15. Si el alcance máximo habitual de un conjuro es menor de 120 pies, pasará a ser de 120 pies cuando se lanza desde la varita. Si un efecto tiene varios objetivos posibles, tu GM determina al azar cuáles de ellos se ven afectados.\n\n• Recuperar cargas. La varita recupera 1d6 + 1 cargas empleadas cada día, al amanecer. Si gastas la última carga de la varita, tira 1d20. Si el resultado es 1, la varita se convierte en polvo y se destruye.",
    "tables": [
      {
        "title": "Efecto",
        "columns": [
          "Resultado",
          "Efecto"
        ],
        "rows": [
          [
            "01–20",
            "Lanzas un conjuro que se origina en el punto elegido. Tira 1d10 para determinar el conjuro: si el resultado es 1–2, bola de fuego; si es 3–4, fuego feérico; si es 5–6, nube apestosa; si es 7–8, oscuridad; si es 9–10, ralentiza."
          ],
          [
            "21–25",
            "No sucede nada en el punto de origen elegido. En vez de eso, creerás que ha sucedido algo asombroso y tendrás el estado de aturdido hasta el principio de tu siguiente turno."
          ],
          [
            "26–30",
            "Lanzas ráfaga de viento. La línea que crea el conjuro se extiende desde ti hacia el punto de origen elegido."
          ],
          [
            "31–35",
            "No sucede nada en el punto de origen elegido. En vez de eso, recibes 1d6 de daño psíquico."
          ],
          [
            "36–40",
            "Una lluvia intensa cae durante 1 minuto en un cilindro de 120 pies de alto y 60 pies de radio centrado en el punto de origen elegido. Durante ese tiempo, el área de efecto se considera ligeramente oscura."
          ],
          [
            "41–45",
            "Una nube de 600 mariposas de gran tamaño llena un cilindro de 60 pies de alto y 30 pies de radio centrado en el punto de origen elegido. Las mariposas permanecen 10 minutos. Durante ese tiempo, el área de efecto se considera muy oscura."
          ],
          [
            "46–50",
            "Lanzas relámpago. La línea que crea el conjuro se extiende desde ti hacia el punto de origen elegido."
          ],
          [
            "51–55",
            "La criatura más cercana al punto de origen aumenta de tamaño como si hubieras lanzado agrandar/reducir sobre ella. Si el objetivo no eres tú y no puede verse afectado por el conjuro, tú te conviertes en el objetivo."
          ],
          [
            "56–60",
            "Una criatura creada mediante magia aparece en un espacio sin ocupar lo más cercano posible al punto de origen elegido. La criatura no se encuentra bajo tu control, actúa con normalidad y desaparece tras 1 hora o cuando sus puntos de golpe se reduzcan a 0. Tira 1d4 para determinar qué criatura aparece. Si el resultado es 1, un elefante; si es 2–3, una rata, y si es 4, un rinoceronte."
          ],
          [
            "61–64",
            "Crece hierba en el suelo en un círculo de 60 pies de radio cuyo centro estará lo más cerca posible del punto de origen elegido. Si ya había hierba allí, crecerá hasta diez veces su tamaño normal y tendrá ese tamaño durante 1 minuto."
          ],
          [
            "65–68",
            "Un objeto a elección de tu GM desaparece en el Plano Etéreo. El objeto no puede medir más de 10 pies en ninguna dimensión, debe encontrarse a 120 pies o menos del punto de origen elegido y nadie puede vestirlo o llevarlo. Si no hay objetos así dentro del alcance, no sucederá nada."
          ],
          [
            "69–72",
            "No sucede nada en el punto de origen elegido. En vez de eso, encoges como si hubieras lanzado agrandar/reducir sobre ti y permaneces así durante 1 minuto."
          ],
          [
            "73–77",
            "Crecen hojas en la criatura más cercana al punto de origen elegido. Salvo que se arranquen, las hojas se volverán marrones y caerán tras 24 horas."
          ],
          [
            "78–82",
            "No sucede nada en el punto de origen elegido. En vez de eso, una explosión de luz resplandeciente y colorida se extiende desde ti en una emanación de 30 pies. Todas las criaturas situadas en la zona deberán superar una tirada de salvación de Constitución con CD 15 o tendrán el estado de cegadas durante 1 minuto. Las criaturas repetirán la tirada de salvación al final de cada uno de sus turnos y, si tienen éxito, se librarán del efecto."
          ],
          [
            "83–87",
            "No sucede nada en el punto de origen elegido. En vez de eso, lanzas invisibilidad sobre ti."
          ],
          [
            "88–92",
            "No sucede nada en el punto de origen elegido. En vez de eso, una ráfaga de 1d4 x 10 gemas, cada una con un valor de 1 po, sale disparada de la punta de la varita en una línea de 30 pies de largo y 5 pies de ancho hacia el punto de origen elegido. Cada gema hace 1 de daño contundente y el total de daño de las gemas se divide a partes iguales entre todas las criaturas situadas en la línea."
          ],
          [
            "93–97",
            "Lanzas polimorfar haciendo objetivo a la criatura más cercana al punto de origen elegido."
          ]
        ]
      }
    ],
    "id": "magic_varita_de_las_maravillas"
  },
  {
    "name": "VARITA DE PARÁLISIS",
    "category": "Varita",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Esta varita tiene 7 cargas. Mientras la sostengas, puedes emplear una acción de magia y gastar 1 carga para conjurar un delgado rayo azul que serpenteará desde la punta de la varita hacia una criatura que puedas ver a 60 pies o menos de ti. El objetivo deberá superar una tirada de salvación de Constitución con CD 15 o tendrá el estado de paralizado durante 1 minuto. Al final de cada uno de sus turnos, el objetivo repetirá la tirada de salvación y, si tiene éxito, se librará del efecto.\n\n• Recuperar cargas. La varita recupera 1d6 + 1 cargas empleadas cada día, al amanecer. Si gastas la última carga de la varita, tira 1d20. Si el resultado es 1, la varita se convierte en cenizas y se destruye.",
    "id": "magic_varita_de_paralisis"
  },
  {
    "name": "VARITA DE POLIMORFAR",
    "category": "Varita",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Esta varita tiene 7 cargas. Mientras la sostengas, puedes gastar 1 carga para lanzar polimorfar (CD de salvación 15) desde ella.\n\n• Recuperar cargas. La varita recupera 1d6 + 1 cargas empleadas cada día, al amanecer. Si gastas la última carga de la varita, tira 1d20. Si el resultado es 1, la varita se convierte en cenizas y se destruye.",
    "id": "magic_varita_de_polimorfar"
  },
  {
    "name": "VARITA DE PROYECTILES MÁGICOS",
    "category": "Varita",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Esta varita tiene 7 cargas. Mientras la sostengas, puedes gastar hasta 3 cargas para lanzar proyectil mágico desde ella. Si empleas 1 carga, podrás lanzar la versión de nivel 1 del conjuro. Puedes aumentar el nivel del conjuro en 1 por cada carga adicional que emplees.\n\n• Recuperar cargas. La varita recupera 1d6 + 1 cargas empleadas cada día, al amanecer. Si gastas la última carga de la varita, tira 1d20. Si el resultado es 1, la varita se convierte en cenizas y se destruye.",
    "id": "magic_varita_de_proyectiles_magicos"
  },
  {
    "name": "VARITA DE RELÁMPAGOS",
    "category": "Varita",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Esta varita tiene 7 cargas. Mientras la sostengas, puedes gastar hasta 3 cargas para lanzar relámpago (CD de salvación 15) desde ella. Si empleas 1 carga, podrás lanzar la versión de nivel 3 del conjuro. Puedes aumentar el nivel del conjuro en 1 por cada carga adicional que emplees.\n\n• Recuperar cargas. La varita recupera 1d6 + 1 cargas empleadas cada día, al amanecer. Si gastas la última carga de la varita, tira 1d20. Si el resultado es 1, la varita se convierte en cenizas y se destruye.",
    "id": "magic_varita_de_relampagos"
  },
  {
    "name": "VARITA DE SECRETOS",
    "category": "Varita",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Esta varita tiene 3 cargas y recupera 1d3 cargas empleadas cada día, al amanecer. Mientras la sostengas, puedes emplear una acción de magia para gastar 1 carga y, si hay alguna trampa o puerta secreta situada a 60 pies o menos de ti, la varita vibrará y apuntará a la más cercana.",
    "id": "magic_varita_de_secretos"
  },
  {
    "name": "VARITA DE TELARAÑA",
    "category": "Varita",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Esta varita tiene 7 cargas. Mientras la sostengas, puedes gastar 1 carga para lanzar telaraña (CD de salvación 13) desde ella.\n\n• Recuperar cargas. La varita recupera 1d6 + 1 cargas empleadas cada día, al amanecer. Si gastas la última carga de la varita, tira 1d20. Si el resultado es 1, la varita se convierte en cenizas y se destruye.",
    "id": "magic_varita_de_telarana"
  },
  {
    "name": "VARITA DEL MAGO DE GUERRA +1",
    "category": "Varita",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Mientras sostengas esta varita, obtendrás un bonificador a las tiradas de ataque de conjuro determinado por la rareza de la varita. Además, ignorarás la cobertura media cuando realices una tirada de ataque de conjuro.",
    "id": "magic_varita_del_mago_de_guerra_1"
  },
  {
    "name": "VARITA DEL MAGO DE GUERRA +2",
    "category": "Varita",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Mientras sostengas esta varita, obtendrás un bonificador a las tiradas de ataque de conjuro determinado por la rareza de la varita. Además, ignorarás la cobertura media cuando realices una tirada de ataque de conjuro.",
    "id": "magic_varita_del_mago_de_guerra_2"
  },
  {
    "name": "VARITA DEL MAGO DE GUERRA +3",
    "category": "Varita",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Mientras sostengas esta varita, obtendrás un bonificador a las tiradas de ataque de conjuro determinado por la rareza de la varita. Además, ignorarás la cobertura media cuando realices una tirada de ataque de conjuro.",
    "id": "magic_varita_del_mago_de_guerra_3"
  },
  {
    "name": "VARITA DEL TERROR",
    "category": "Varita",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Esta varita tiene 7 cargas.\n\n• Conjuros. Mientras sostengas la varita, puedes lanzar desde ella un conjuro (CD de salvación 15) de la tabla \"Conjuros (cargas)\". En ella se indica cuántas cargas debes gastar para lanzar el conjuro.\n• Recuperar cargas. La varita recupera 1d6 + 1 cargas empleadas cada día, al amanecer. Si gastas la última carga de la varita, tira 1d20. Si el resultado es 1, la varita se convierte en cenizas y se destruye.",
    "tables": [
      {
        "title": "Conjuros (cargas)",
        "columns": [
          "Conjuro",
          "Coste en cargas"
        ],
        "rows": [
          [
            "Orden imperiosa (solo \"huye\" o \"póstrate\")",
            "1"
          ],
          [
            "Terror (cono de 60 pies)",
            "3"
          ]
        ]
      }
    ],
    "id": "magic_varita_del_terror"
  },
  {
    "name": "VELA DE INVOCACIÓN",
    "category": "Objeto maravilloso",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "La magia de esta vela se activa al encenderla, lo que requiere una acción de magia. Después de arder durante 4 horas, la vela se destruye. Puedes apagarla antes de que pase ese tiempo para seguir usándola después. Resta el tiempo que ha ardido del total, en intervalos de 1 minuto. Mientras permanezca encendida, la vela emitirá luz tenue en un radio de 30 pies. Mientras estés dentro de esa luz, tienes ventaja en las pruebas con d20. Además, un clérigo o druida dentro de la luz puede lanzar conjuros de nivel 1 que tenga preparados sin gastar espacios de conjuro. Como alternativa, la primera vez que enciendas la vela, podrás utilizarla para lanzar el conjuro portal. Hacer esto destruirá la vela. El portal que crea el conjuro estará unido a un Plano Exterior en concreto a elección de tu GM o determinado por una tirada en la siguiente tabla.",
    "tables": [
      {
        "title": "Plano Exterior",
        "columns": [
          "Resultado",
          "Efecto"
        ],
        "rows": [
          [
            "01–05",
            "Abismo"
          ],
          [
            "06–10",
            "Aqueronte"
          ],
          [
            "11–17",
            "Arbórea"
          ],
          [
            "18–25",
            "Arcadia"
          ],
          [
            "26–33",
            "Bitopía"
          ],
          [
            "34–38",
            "Carceri"
          ],
          [
            "39–46",
            "Elíseo"
          ],
          [
            "47–51",
            "Gehenna"
          ],
          [
            "52–56",
            "Hades"
          ],
          [
            "57–61",
            "Limbo"
          ],
          [
            "62–69",
            "Mechanus"
          ],
          [
            "70–77",
            "Monte Celestia"
          ],
          [
            "78–82",
            "Nueve Infiernos"
          ],
          [
            "83–87",
            "Pandemónium"
          ],
          [
            "88–95",
            "Tierras de las Bestias"
          ],
          [
            "96–00",
            "Ysgard"
          ]
        ]
      }
    ],
    "id": "magic_vela_de_invocacion"
  },
  {
    "name": "VENGADORA SAGRADA",
    "category": "Arma",
    "rarity": "Legendario",
    "attunement": "Sí (requiere sintonización con un paladín)",
    "description": "Recibes un bonificador de +3 a las tiradas de ataque y de daño que hagas con esta arma mágica. Cuando aciertes a un infernal o muerto viviente con ella, esa criatura recibirá 2d10 de daño radiante adicional. Mientras empuñes el arma desenvainada, esta crea una emanación de 10 pies que se origina en ti. Tú y todas las criaturas amistosas contigo dentro de la emanación tendréis ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos. Si tienes 17 o más niveles en la clase paladín, el tamaño de la emanación aumentará a 30 pies.",
    "subcategory": "Arma (cualquiera sencilla o marcial)",
    "id": "magic_vengadora_sagrada"
  },
  {
    "name": "YELMO DE ALERTA",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Mientras lleves puesto este yelmo, tienes ventaja en las tiradas de iniciativa.",
    "id": "magic_yelmo_de_alerta"
  },
  {
    "name": "YELMO DE ENTENDER IDIOMAS",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "No",
    "description": "Mientras lleves este yelmo, puedes lanzar entender idiomas desde él.",
    "id": "magic_yelmo_de_entender_idiomas"
  },
  {
    "name": "YELMO DE FULGOR",
    "category": "Objeto maravilloso",
    "rarity": "Muy raro",
    "attunement": "Sí",
    "description": "Este yelmo tiene incrustados 1d10 diamantes, 2d10 rubíes, 3d10 ópalos de fuego y 4d10 ópalos. Cualquier gema que se retire del yelmo se convierte en polvo. Si se retiran o se destruyen todas las gemas, el yelmo pierde su magia.\n\nMientras lo lleves puesto, obtienes los siguientes beneficios:\n\n• Conjuros. Puedes lanzar uno de los siguientes conjuros (CD de salvación 18) utilizando una de las gemas del tipo especificado como componente: bola de fuego (ópalo de fuego), luz del día (ópalo), muro de fuego (rubí) o rociada prismática (diamante). La gema se destruye cuando el conjuro se lanza, por lo que desaparecerá del yelmo.\n• Llamas de ópalo de fuego. Mientras quede al menos un ópalo de fuego en el yelmo, podrás emplear una acción de magia para hacer que un arma que estés empuñando se envuelva en llamas. Las llamas emitirán luz brillante en un radio de 10 pies y luz tenue 10 pies más allá. Las llamas son inofensivas para ti y el arma. Cuando aciertes un ataque usando el arma llameante, el objetivo recibirá 1d6 de daño de fuego adicional. Las llamas permanecen hasta que emplees una acción adicional para extinguirlas o hasta que sueltes o guardes el arma.\n• Luz de diamante. Mientras quede al menos un diamante, el yelmo emitirá una emanación de 30 pies. Si hay algún muerto viviente en esa zona, la emanación se llena de luz tenue. Cualquier muerto viviente que comience su turno en la zona sufrirá 1d6 de daño radiante.\n• Recibir daño de fuego. Tira 1d20 si llevas el yelmo puesto y sufres daño de fuego por haber fallado una tirada de salvación contra un conjuro. Si sacas un 1, las gemas restantes emitirán rayos de luz y el yelmo se destruirá. Todas las criaturas entro de una emanación de 60 pies que se origina en el yelmo deberán superar una tirada de salvación de Destreza con CD 17 o un rayo las alcanzará y sufrirán una cantidad de daño radiante igual al número de gemas del yelmo.\n• Resistencia de rubí. Mientras quede al menos un rubí en el yelmo, tendrás resistencia al daño de fuego.",
    "id": "magic_yelmo_de_fulgor"
  },
  {
    "name": "YELMO DE TELEPATÍA",
    "category": "Objeto maravilloso",
    "rarity": "Infrecuente",
    "attunement": "Sí",
    "description": "Mientras lleves este yelmo, tienes telepatía hasta 30 pies y puedes lanzar detectar pensamientos o sugestión (CD de salvación 13) desde él. Cuando lances cualquiera de estos conjuros desde el yelmo, no podrás volver a lanzar ese conjuro desde él hasta el siguiente amanecer.",
    "id": "magic_yelmo_de_telepatia"
  },
  {
    "name": "YELMO DE TELETRANSPORTE",
    "category": "Objeto maravilloso",
    "rarity": "Raro",
    "attunement": "Sí",
    "description": "Este yelmo tiene 3 cargas. Mientras lo lleves, puedes gastar 1 carga para lanzar teletransporte desde él. El yelmo recupera 1d3 cargas empleadas cada día, al amanecer.",
    "id": "magic_yelmo_de_teletransporte"
  }
];
