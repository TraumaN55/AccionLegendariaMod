window.SPELLS_DATA = [
  {
    "name": "ABRIR",
    "level": 2,
    "school": "Transmutación",
    "classes": [
      "bardo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Elige un objeto que puedas ver dentro del alcance. Puede ser una puerta, una caja, un cofre, unas esposas, un candado o cualquier otro objeto que posea alguna manera mágica o mundana de impedir el acceso. Un objetivo que esté cerrado mediante una cerradura normal o que esté atascado o atrancado se abre, desatasca o desatranca.\n\nSi el objeto tiene varios cerrojos, solo se desbloquea uno de ellos. Si el objetivo está cerrado mediante cerradura arcana, ese conjuro quedará anulado durante 10 minutos y, durante ese tiempo, el objeto se podrá abrir y cerrar. Cuando lanzas el conjuro, se escucha un fuerte golpe surgir del objetivo, que es audible a una distancia de 300 pies.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ACELERAR",
    "level": 3,
    "school": "Transmutación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una viruta de raíz de regaliz"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Elige a una criatura voluntaria que puedas ver dentro del alcance. Hasta que el conjuro termine, la velocidad del objetivo se duplica, gana un bonificador de +2 a su clase de armadura, tiene ventaja en tiradas de salvación de Destreza y consigue una segunda acción en cada uno de sus turnos.\n\nSolo puede utilizar esta acción para llevar a cabo una acción de atacar (solo un ataque), correr, destrabarse, esconderse o utilizar.\n\nCuando el conjuro termine, el objetivo tendrá el estado de incapacitado y una velocidad de 0 hasta el final de su siguiente turno, debido a una ola de somnolencia que lo afecta.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ADIVINACIÓN",
    "level": 4,
    "school": "Adivinación",
    "classes": [
      "clerigo",
      "druida",
      "mago"
    ],
    "casting_time": "Acción o ritual",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "incienso que valga al menos 25 po, que se consume como parte del conjuro"
    },
    "duration": "Instantáneo",
    "ritual": true,
    "concentration": false,
    "description": "Este conjuro te pone en contacto con un dios o sus sirvientes. Puedes hacer una pregunta sobre un objetivo, un suceso o una actividad específicos que ocurrirán en los próximos 7 días. Tu DM te dará una respuesta verdadera, que puede ser una frase corta o una rima críptica.\n\nEl conjuro no tiene en cuenta ninguna circunstancia que pueda alterar la respuesta, como por ejemplo el lanzamiento de otros. Si lanzas el conjuro más de una vez antes de finalizar un descanso largo, hay una posibilidad acumulativa del 25 % por cada lanzamiento después del primero de que no recibas ninguna respuesta.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "AGARRE ELECTRIZANTE",
    "level": 0,
    "school": "Evocación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Una descarga eléctrica surge de tu mano hacia una criatura que intentas tocar. Haz un ataque de conjuro cuerpo a cuerpo contra el objetivo. Si acierta, el objetivo recibirá 1d8 de daño de relámpago y no podrá realizar ataques de oportunidad hasta el principio de su siguiente turno.",
    "tables": [],
    "sections": [
      {
        "title": "Mejora de truco",
        "text": "El daño aumenta en 1d8 cuando alcanzas los niveles 5 (2d8), 11 (3d8) y 17 (4d8)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "AGRANDAR/REDUCIR",
    "level": 2,
    "school": "Transmutación",
    "classes": [
      "bardo",
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una pizca hierro en polvo"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Hasta que el conjuro termine, aumenta o reduce el tamaño de una criatura u objeto que puedas ver dentro del alcance (consulta el efecto elegido a continuación). Si el objetivo es un objeto, no puede estar llevándolo ni vistiéndolo nadie. Si es una criatura no voluntaria, puede hacer una tirada de salvación de Constitución y, si la supera, el conjuro no tiene efecto. Todo lo que vista y lleve una criatura objetivo cambiará de tamaño con ella y cualquier objeto que suelte volverá a su tamaño normal de inmediato. Un arma arrojadiza o un proyectil recuperará su tamaño normal justo después de acertar a un objetivo o fallar.\n\n• Agrandar. El tamaño del objetivo aumenta en una categoría; por ejemplo, de Mediano a Grande. El objetivo también tendrá ventaja en las pruebas de Fuerza y en las tiradas de salvación de Fuerza. Además, sus ataques con armas agrandadas o sin armas causan 1d4 de daño adicional al acertar.\n\n• Reducir. El tamaño del objetivo se reduce en una categoría; por ejemplo, de Mediano a Pequeño. El objetivo también tendrá desventaja en las pruebas de Fuerza y en las tiradas de salvación de Fuerza. Los ataques que haga con armas reducidas o sin armas causan 1d4 menos de daño al acertar (esto no puede reducir el daño a menos de 1).",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ALARMA",
    "level": 1,
    "school": "Abjuración",
    "classes": [
      "explorador",
      "mago"
    ],
    "casting_time": "1 minuto o un ritual",
    "range": "30 pies / 20 pies de cubo",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una campana e hilo de plata"
    },
    "duration": "8 horas",
    "ritual": true,
    "concentration": false,
    "description": "Preparas una alarma contra los intrusos. Elige una puerta, una ventana o una zona dentro del alcance que no sea mayor que un cubo de 20 pies de lado. Hasta que el conjuro termine, una alarma te alertará siempre que una criatura toque la zona vigilada o entre en ella.\n\nAl lanzar el conjuro, puedes designar qué criaturas no activarán la alarma, que puede ser mental o sonora:\n\n• Alarma mental. La alarma te avisará con un sonido dentro de tu mente si estás a 1 milla o menos de la zona vigilada. Si estás durmiendo, te despertará.\n\n• Alarma sonora. La alarma producirá el sonido de una campanilla durante 10 segundos, que será audible a 60 pies o menos de la zona vigilada.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "cube",
      "sizeFt": 20
    }
  },
  {
    "name": "ALIADO PLANAR",
    "level": 6,
    "school": "Conjuración",
    "classes": [
      "clerigo"
    ],
    "casting_time": "10 minutos",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Suplicas la ayuda de una entidad de otro mundo, la cual debe resultarte conocida: un dios, un príncipe demonio u otro ser con poder cósmico. Esa entidad enviará a un celestial, un elemental o un infernal que le sea leal para ayudarte, criatura que aparecerá en un espacio sin ocupar dentro del alcance.\n\nSi sabes el nombre de una criatura específica, puedes pronunciarlo cuando lances el conjuro para solicitar a esa criatura, aunque igualmente podría aparecer otra (a elección de tu DM). Cuando la criatura aparece, no se siente forzada a comportarse de ningún modo concreto. Puedes pedirle que realice un servicio a cambio de un pago, pero no está obligada a hacerlo.\n\nLa tarea solicitada podría ser muy sencilla (\"ayúdanos a cruzar esta sima volando\" o \"échanos una mano en la batalla\") o algo más complicado (\"espía a nuestros enemigos\" o \"protégenos mientras exploramos la mazmorra\"). Para negociar por los servicios de la criatura, debes poder comunicarte con ella. El pago puede adoptar una gran variedad de formas.\n\nUn celestial podría solicitar una importante donación de oro u objetos mágicos a un templo aliado, mientras que un infernal podría exigir el sacrificio de un ser vivo o un regalo de un tesoro. Algunas criaturas podrían solicitar que lleves a cabo alguna misión a cambio de sus servicios. Una tarea que pueda medirse en minutos requiere un pago equivalente a 100 po por minuto.\n\nUna tarea que se mida en horas requiere 1000 po por hora, y una tarea que se mida en días (hasta 10 días) requiere 10 000 po por día. Tu DM puede adaptar los pagos en función de las circunstancias en las que lances el conjuro. Si la tarea está en sintonía con los valores de la criatura, el pago podría reducirse a la mitad o incluso no ser necesario.\n\nLas tareas que no implican peligro suelen exigir solo la mitad del pago sugerido, mientras que las que son especialmente peligrosas podrían requerir una donación aún mayor. Raramente una criatura aceptará una tarea que parezca suicida.\n\nUna vez que la criatura complete su tarea o cuando finalice el tiempo de servicio acordado, volverá a su plano natal tras informarte de ello si es posible.\n\nSi no eres capaz de llegar a un acuerdo sobre el precio del servicio de la criatura, esta regresará a su plano natal de inmediato.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ALIENTO DE DRAGÓN",
    "level": 2,
    "school": "Transmutación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción adicional",
    "range": "Toque / 15 pies de cono",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una guindilla"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Tocas a una criatura voluntaria y eliges ácido, frío, fuego, relámpago o veneno. Hasta que el conjuro termine, el objetivo puede usar una acción de magia para exhalar en un cono de 15 pies. Todas las criaturas situadas en la zona hacen una tirada de salvación de Destreza; sufrirán 3d6 de daño del tipo elegido si la fallan o la mitad del daño si la superan.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d6 por cada nivel por encima de 2 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "cone",
      "sizeFt": 15
    }
  },
  {
    "name": "ALTERAR EL PROPIO ASPECTO",
    "level": 2,
    "school": "Transmutación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Modificas tu forma física.\n\nAl lanzar el conjuro, eliges una de las siguientes opciones. Los efectos duran hasta que el conjuro termine.\n\nMientras dure, puedes usar una acción de magia para sustituir la opción elegida por otra distinta.\n\n• **Adaptación acuática** Te salen branquias y te crecen membranas entre los dedos. Puedes respirar bajo el agua y obtienes una velocidad de nado igual a tu velocidad.\n\n• **Armas naturales** Te crecen cascos (daño contundente), colmillos (daño perforante), cuernos (daño perforante) o garras (daño cortante). Cuando realizas un ataque sin armas para causar daño con uno de estos nuevos apéndices, el ataque inflige 1d6 de daño del tipo indicado, en lugar del daño normal de tu ataque sin armas. Además, utilizas tu modificador por aptitud mágica para las tiradas de ataque y de daño en lugar de tu modificador de Fuerza.\n\n• **Cambiar de aspecto** Alteras tu apariencia física. Decide cómo luces, incluyendo tu altura, peso, rasgos faciales, timbre de voz, longitud del cabello, tono de piel y cualquier otro rasgo distintivo. Puedes presentarte como un miembro de otra especie, pero esto no modifica tu perfil de juego. No puedes adoptar el aspecto de una criatura de un tamaño diferente y conservas tu forma básica (por ejemplo, una criatura bípeda no puede convertirse en cuadrúpeda mediante este conjuro). Mientras dure el conjuro, puedes usar una acción de magia para volver a cambiar tu aspecto.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ALTERAR LOS RECUERDOS",
    "level": 5,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Intentas modificar los recuerdos de otra criatura. Una criatura que puedas ver dentro del alcance realiza una tirada de salvación de Sabiduría. Si estás luchando contra ella, tendrá ventaja en la tirada. Si la falla, tendrá el estado de hechizada hasta que termine el conjuro. Mientras esté hechizado de esta manera, el objetivo también tiene el estado de incapacitado y no es consciente de su entorno, aunque puede oírte. Si recibe cualquier daño o es el objetivo de otro conjuro, este conjuro termina y no se modifica ninguno de sus recuerdos. Mientras dure este sortilegio, puedes afectar al recuerdo de un suceso que haya vivido el objetivo durante las últimas 24 horas y que no haya durado más de 10 minutos. Puedes eliminar permanentemente todo recuerdo del suceso, permitir que lo recuerde con claridad perfecta, cambiar cómo recuerda los detalles o crear un recuerdo de otro suceso. Debes hablarle al objetivo para describir cómo se ven afectados sus recuerdos y este debe poder comprender tu idioma para que los recuerdos modificados se asienten. Su mente llenará cualquier hueco que falte en los detalles de tu descripción. Si el conjuro termina antes de que acabes de describir los recuerdos modificados, la memoria de la criatura no se verá afectada. De lo contrario, los recuerdos modificados ocuparán el lugar de los reales en cuanto el conjuro termine. Un recuerdo modificado no tiene por qué afectar al comportamiento de una criatura, en especial si contradice sus inclinaciones naturales, su alineamiento o sus creencias. Un recuerdo modificado que no sea lógico, como cuánto disfrutó bañándose en ácido, se difuminará y la criatura lo considerará un mal sueño. Tu DM podría considerar que un recuerdo modificado es demasiado ilógico como para afectar a una criatura. Un conjuro levantar maldición o restablecimiento mayor lanzado sobre el objetivo restaurará los recuerdos auténticos de la criatura.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Puedes alterar recuerdos del objetivo de un suceso que ocurrió hace 7 días (espacio de nivel 6), 30 días (espacio de nivel 7), 365 días (espacio de nivel 8) o en cualquier momento del pasado de la criatura (espacio de nivel 9)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ALZAR A LOS MUERTOS",
    "level": 5,
    "school": "Nigromancia",
    "classes": [
      "bardo",
      "clerigo",
      "paladin"
    ],
    "casting_time": "1 hora",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un diamante que valga al menos 500 po y que se consume como parte del conjuro"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Con un toque, revives a una criatura que no lleve más de 10 días muerta y que no fuera un muerto viviente cuando falleció. La criatura vuelve a la vida con 1 punto de golpe. El conjuro también neutraliza cualquier veneno que afectase a la criatura en el momento de su muerte.\n\nEste conjuro cierra todas las heridas mortales, pero no devuelve las partes del cuerpo que faltan. Si a la criatura le faltan partes del cuerpo u órganos fundamentales para que sobreviva (por ejemplo, la cabeza), el conjuro falla automáticamente. Regresar de entre los muertos es una experiencia complicada.\n\nEl objetivo tendrá un penalizador de -4 a las pruebas con d20. Cada vez que finalice un descanso largo, el penalizador se reduce en 1 hasta desaparecer.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "AMISTAD",
    "level": 0,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "10 pies",
    "components": {
      "v": false,
      "s": true,
      "m": true,
      "material": "un poco de maquillaje"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Emanas mágicamente un sentimiento de amistad hacia una criatura que puedas ver dentro del alcance. El objetivo deberá superar una tirada de salvación de Sabiduría o tendrá el estado de hechizado hasta que termine el conjuro. El objetivo la superará automáticamente si no es un humanoide, si estás luchando contra él o si le has lanzado este conjuro en las últimas 24 horas. El conjuro termina antes de tiempo si el objetivo recibe daño o si haces una tirada de ataque, causas daño u obligas a cualquier criatura a hacer una tirada de salvación.\n\nCuando el conjuro termine, el objetivo sabrá que lo hechizaste.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ANIMAR A LOS MUERTOS",
    "level": 3,
    "school": "Nigromancia",
    "classes": [
      "clerigo",
      "mago"
    ],
    "casting_time": "1 minuto",
    "range": "10 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una gota de sangre, un pedazo de carne y una pizca de polvo de hueso"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Elige un montón de huesos o un cadáver de un humanoide Mediano o Pequeño dentro del alcance.\n\nEl objetivo se convierte en una criatura muerta viviente: un esqueleto si eliges un montón de huesos o un zombi si eliges un cadáver (consulta los perfiles de las criaturas en el apéndice B).\n\nEn cada uno de tus turnos, puedes usar una acción adicional para dar órdenes mentalmente a cada criatura que hayas creado con el conjuro que esté a 60 pies o menos de ti (si controlas a varias criaturas, puedes dar órdenes a cualesquiera de ellas a la vez transmitiéndole la misma orden a cada una).\n\nTú decides qué acción llevará a cabo la criatura y adónde se moverá en su siguiente turno, o puedes dar una orden general, como proteger una cámara o un pasadizo. Si no das ninguna orden, la criatura hace la acción de esquivar y solo se mueve para evitar peligros. En cuanto se le dé una orden, la criatura la cumplirá hasta completar su tarea.\n\nLa criatura estará bajo tu control durante 24 horas, tras las cuales dejará de obedecer cualquier orden que le hayas dado. Para mantener el control sobre ella otras 24 horas, deberás volver a lanzarle este conjuro antes de que acabe el periodo actual de 24 horas. Este uso del conjuro refuerza tu control sobre hasta cuatro criaturas que hayas animado con él y no anima una nueva criatura.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Animas o refuerzas el control sobre dos criaturas muertas vivientes adicionales por cada nivel de conjuro por encima de 3 que tenga el espacio. Cada una de las criaturas debe proceder de un cadáver o un montón de huesos distinto."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ANIMAR OBJETOS",
    "level": 5,
    "school": "Transmutación",
    "classes": [
      "bardo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Tus órdenes hacen que los objetos cobren vida. Elige una cantidad de objetos no mágicos dentro del alcance que no vista ni lleve nadie, que no estén fijos en una superficie y que no sean Gargantuescos.\n\nLa cantidad máxima de objetos es igual a tu modificador por aptitud mágica.\n\nA estos efectos, un objetivo Mediano o más pequeño cuenta como un objeto, un objetivo Grande cuenta como dos y un objetivo Enorme cuenta como tres.\n\nCada objetivo se animará, le crecerán patas, se convertirá en un autómata que emplea el perfil de un objeto animado y permanecerá bajo tu control hasta que el conjuro termine o hasta que sus puntos de golpe se reduzcan a 0.\n\nCada criatura que crees con este conjuro se considera una aliada para tus aliados y para ti. En combate, comparte tu orden de iniciativa y su turno va justo después del tuyo.\n\nHasta que el conjuro termine, puedes usar una acción adicional para dar órdenes mentalmente a cada criatura que hayas creado con el conjuro que esté a 120 pies o menos de ti (si controlas a varias criaturas, puedes dar órdenes a cualesquiera de ellas a la vez transmitiéndole la misma orden a cada una). Si no das ninguna orden, la criatura hace la acción de esquivar y solo se mueve para evitar peligros.\n\nCuando los puntos de golpe de la criatura se reduzcan a 0, recuperará su forma de objeto y cualquier daño sobrante se aplicará a esa forma.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño del golpe de la criatura aumenta en 1d4 (Mediana o más pequeña), 1d6 (Grande) o 1d12 (Enorme) por cada nivel por encima de 5 que tenga el espacio. Objeto animado Autómata Enorme o más pequeño, sin alineamiento."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ANTIPATÍA/SIMPATÍA",
    "level": 8,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "druida",
      "mago"
    ],
    "casting_time": "1 hora",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una mezcla de vinagre y miel"
    },
    "duration": "10 días",
    "ritual": false,
    "concentration": false,
    "description": "Mientras lanzas el conjuro, elige si crea antipatía o simpatía y haz objetivo a una criatura u objeto de tamaño Enorme o menor.\n\nA continuación, selecciona un tipo de criatura, como dragones rojos, goblins o vampiros. Las criaturas del tipo elegido deberán realizar una tirada de salvación de Sabiduría cuando se acerquen a 120 pies o menos del objetivo. La elección de antipatía o simpatía determina lo que le sucede a una criatura si falla la salvación:\n\n• Antipatía. La criatura obtiene el estado de asustada y deberá usar su movimiento en cada uno de sus turnos para alejarse lo máximo posible del objetivo por la ruta más segura.\n\n• Simpatía. La criatura obtiene el estado de hechizada y deberá usar su movimiento en cada uno de sus turnos para acercarse lo máximo posible al objetivo por la ruta más segura. Si la criatura se encuentra a 5 pies o menos del objetivo, no podrá alejarse de él voluntariamente. Si el objetivo daña a la criatura hechizada, esta podrá realizar una tirada de salvación de Sabiduría para poner fin al efecto, como se describe a continuación.\n\n• Poner fin al efecto. Si la criatura asustada o hechizada termina su turno a más de 120 pies del objetivo, deberá realizar una tirada de salvación de Sabiduría. Si la supera, deja de verse afectada por el objetivo. Las criaturas que superen la tirada de salvación contra este efecto serán inmunes a él durante 1 minuto; pasado ese tiempo, podrán verse afectadas de nuevo.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "APARIENCIA",
    "level": 5,
    "school": "Ilusionismo",
    "classes": [
      "bardo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "8 horas",
    "ritual": false,
    "concentration": false,
    "description": "Le das una apariencia ilusoria a cada criatura de tu elección que puedas ver dentro del alcance. Un objetivo no voluntario puede hacer una tirada de salvación de Carisma y, si la supera, el conjuro no le afectará. Puedes dar la misma apariencia o una distinta a cada objetivo, así como cambiar el aspecto de sus cuerpos y equipo. Puedes hacer que cada criatura parezca 1 pie más alta o más baja, y de complexión más pesada o más ligera. Un nuevo aspecto debe tener la misma configuración básica de miembros que el objetivo, aunque en el resto de aspectos la ilusión queda a tu elección y permanecerá hasta que el conjuro termine. Los cambios realizados por este conjuro pueden descubrirse mediante una inspección física. Por ejemplo, si usas este conjuro para añadir un sombrero a la vestimenta de una criatura, los objetos atravesarán el sombrero. Si una criatura emplea la acción de Estudiar para examinar a un objetivo, podrá realizar una prueba de Inteligencia (Investigación) contra tu CD de salvación de conjuros.\n\nSi la supera, sabrá que el objetivo está disfrazado.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ARMA ELEMENTAL",
    "level": 3,
    "school": "Transmutación",
    "classes": [
      "druida",
      "explorador",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Un arma no mágica que toques se convierte en mágica. Elige uno de los siguientes tipos de daño: ácido, frío, fuego, relámpago o trueno. Mientras dure el conjuro, el arma tiene un bonificador de +1 a las tiradas de ataque y causa 1d4 de daño adicional del tipo elegido cuando acierte.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Si usas un espacio de conjuro de niveles 5 o 6, el bonificador a las tiradas de ataque aumenta en +2 y el daño adicional aumenta a 2d4. Si usas un espacio de conjuro de nivel 7 o superior, el bonificador aumenta a +3 y el daño adicional aumenta a 3d4."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ARMA ESPIRITUAL",
    "level": 2,
    "school": "Evocación",
    "classes": [
      "clerigo"
    ],
    "casting_time": "Acción adicional",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Creas una fuerza espectral flotante con el aspecto de un arma de tu elección que permanece hasta que termine el conjuro. La fuerza aparece dentro del alcance en un espacio de tu elección y puedes hacer inmediatamente un ataque de conjuro cuerpo a cuerpo contra una criatura que esté a 5 pies o menos de ella. Si acierta, el objetivo recibe una cantidad de daño de fuerza igual a 1d8 más tu modificador por aptitud mágica. Como acción adicional en tus siguientes turnos, puedes mover la fuerza hasta 20 pies y repetir el ataque contra una criatura que esté a 5 pies o menos de ella.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d8 por cada nivel por encima de 2 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ARMA MÁGICA",
    "level": 2,
    "school": "Transmutación",
    "classes": [
      "explorador",
      "hechicero",
      "mago",
      "paladin"
    ],
    "casting_time": "Acción adicional",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Tocas un arma no mágica.\n\nHasta que el conjuro termine, esa arma se convierte en un arma mágica con un bonificador de +1 a las tiradas de ataque y de daño. El conjuro termina antes si lo vuelves a lanzar.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El bonificador aumenta a +2 si utilizas un espacio de niveles 3 a 5.\n\nEl bonificador aumenta a +3 si utilizas un espacio de nivel 6 o superior."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ARMADURA DE AGATHYS",
    "level": 1,
    "school": "Abjuración",
    "classes": [
      "brujo"
    ],
    "casting_time": "Acción adicional",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un trozo de vidrio azul"
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Una escarcha mágica protectora te rodea y ganas 5 puntos de golpe temporales. Si una criatura te acierta con una tirada de ataque cuerpo a cuerpo antes de que el conjuro termine, dicha criatura sufre 5 de daño de frío. El conjuro termina antes de tiempo si no tienes puntos de golpe temporales.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Los puntos de golpe temporales y el daño de frío aumentan en 5 por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ARMADURA DE MAGO",
    "level": 1,
    "school": "Abjuración",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un trozo de piel curtida"
    },
    "duration": "8 horas",
    "ritual": false,
    "concentration": false,
    "description": "Tocas a una criatura voluntaria que no lleve armadura. Hasta que el conjuro termine, la CA base del objetivo pasa a ser de 13 más su modificador por Destreza. El conjuro termina antes si el objetivo se pone una armadura.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ARMADURA DE MUERTE",
    "level": 2,
    "school": "Nigromancia",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un ónice valorado en 50 po, que el conjuro consume"
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Durante la duración, un aura oscura y aceitosa rodea a una criatura que toques. El objetivo tiene Ventaja en las tiradas de salvación contra la muerte.\n\nAdemás, una vez por turno, cuando una criatura que se encuentre a 5 pies del objetivo le impacta con un ataque cuerpo a cuerpo, el atacante recibe 2d4 de daño necrótico.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ASESINO FANTASMAL",
    "level": 4,
    "school": "Ilusionismo",
    "classes": [
      "bardo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Accedes a las pesadillas de una criatura a la que puedas ver dentro del alcance y creas una ilusión de sus miedos más profundos que solo ella puede ver. El objetivo hace una tirada de salvación de Sabiduría. Si la falla, sufrirá 4d10 de daño psíquico y tendrá desventaja en las pruebas de característica y en las tiradas de ataque hasta que termine el conjuro. Si la supera, sufrirá la mitad de ese daño y el conjuro terminará.\n\nAdemás, hasta que termine el conjuro, el objetivo hará una tirada de salvación de Sabiduría al final de cada uno de sus turnos. Si la falla, volverá a sufrir el daño psíquico. Si la supera, el conjuro terminará.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d10 por cada nivel por encima de 4 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ASPECTOS ANIMALES",
    "level": 8,
    "school": "Transmutación",
    "classes": [
      "druida"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "24 horas",
    "ritual": false,
    "concentration": false,
    "description": "Elige cualquier cantidad de criaturas voluntarias que puedas ver dentro del alcance. Todos los objetivos cambian de forma y adoptan la de una bestia Grande o más pequeña con un valor de desafío de 4 o menos. Puedes elegir una forma distinta para cada objetivo.\n\nEn los siguientes turnos, puedes usar una acción de magia para transformar de nuevo a los objetivos. El perfil de un objetivo se sustituye por el de la bestia elegida, pero conserva su tipo de criatura, sus puntos de golpe, sus dados de puntos de golpe, su alineamiento, su capacidad para comunicarse y sus puntuaciones de Inteligencia, Sabiduría y Carisma.\n\nLas acciones del objetivo se ven limitadas por la anatomía de la forma de bestia y no puede lanzar conjuros. El equipo del objetivo se funde con su nueva forma y no podrá usarlo mientras esté en dicha forma. El objetivo obtiene una cantidad de puntos de golpe temporales igual a los puntos de golpe de la primera forma que adopte.\n\nEstos puntos de golpe temporales se desvanecerán si conserva alguno cuando el conjuro termine. La transformación dura hasta que el conjuro termine o hasta que el objetivo le ponga fin como acción adicional.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ATADURA PLANAR",
    "level": 5,
    "school": "Abjuración",
    "classes": [
      "bardo",
      "brujo",
      "clerigo",
      "druida",
      "mago"
    ],
    "casting_time": "1 hora",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una joya que valga al menos 1000 po y que se consume como parte del conjuro"
    },
    "duration": "24 horas",
    "ritual": false,
    "concentration": false,
    "description": "Intentas obligar a un celestial, un elemental, un feérico o un infernal a servirte. La criatura debe estar dentro del alcance durante todo el tiempo de lanzamiento del conjuro (por lo general, primero se invoca a la criatura en el centro de un conjuro círculo mágico invertido para atraparla mientras se lanza el conjuro). Al finalizar el lanzamiento, el objetivo deberá superar una tirada de salvación de Carisma o se verá obligado a servirte hasta que termine el conjuro. Si la criatura se ha invocado o creado mediante otro conjuro, la duración de dicho conjuro se amplía hasta ser igual que la de este. Una criatura obligada deberá seguir tus órdenes lo mejor que pueda. Puedes ordenarle que te acompañe en una aventura, que proteja un lugar o que entregue un mensaje. Si la criatura es hostil, hará lo posible para retorcer el significado de tus órdenes y así lograr sus propios objetivos. Si la criatura lleva a cabo tus órdenes en su totalidad antes de que termine el conjuro, viajará hasta ti para comunicártelo si estáis en el mismo plano de existencia. Si estás en un plano distinto, regresará al lugar en el que la ataste y permanecerá allí hasta que el conjuro termine.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "La duración aumenta con un espacio de nivel 6 (10 días), 7 (30 días), 8 (180 días) y 9 (366 días)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "AUGURIO",
    "level": 2,
    "school": "Adivinación",
    "classes": [
      "clerigo",
      "druida",
      "mago"
    ],
    "casting_time": "1 minuto o un ritual",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "palitos, huesos, cartas u otros abalorios marcados de forma especial que valgan al menos 25 po"
    },
    "duration": "Instantáneo",
    "ritual": true,
    "concentration": false,
    "description": "Obtienes un presagio de una entidad de otro mundo sobre los resultados de un curso de acción que planees llevar a cabo en los próximos 30 minutos. Tu DM determina el presagio apropiado según las circunstancias. El conjuro no tiene en cuenta las circunstancias que puedan alterar los resultados, como lanzar otros conjuros.\n\nSi lanzas el conjuro más de una vez antes de finalizar un descanso largo, hay una posibilidad acumulativa del 25 % por cada lanzamiento después del primero de que no recibas ninguna respuesta.",
    "tables": [
      {
        "title": "Presagios",
        "columns": [
          "Presagio",
          "Para los resultados que sean..."
        ],
        "rows": [
          [
            "Fortuna",
            "Buenos"
          ],
          [
            "Desdicha",
            "Malos"
          ],
          [
            "Fortuna y desdicha",
            "Buenos y malos"
          ],
          [
            "Indiferencia",
            "Ni buenos ni malos"
          ]
        ]
      }
    ],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "AURA DE PUREZA",
    "level": 4,
    "school": "Abjuración",
    "classes": [
      "clerigo",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "Personal / 30 pies de emanación",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Un aura surge de ti en una emanación de 30 pies hasta que el conjuro termine. Mientras permanezcáis dentro, tus aliados y tú tenéis resistencia al daño de veneno y ventaja en las tiradas de salvación para evitar o poner fin a efectos que provoquen los estados de asustado, aturdido, cegado, ensordecido, envenenado, hechizado o paralizado.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 30,
      "measure": "radius"
    }
  },
  {
    "name": "AURA DE VIDA",
    "level": 4,
    "school": "Abjuración",
    "classes": [
      "clerigo",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "Personal / 30 pies de emanación",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Un aura surge de ti en una emanación de 30 pies hasta que el conjuro termine. Mientras permanezcáis dentro, tus aliados y tú tenéis resistencia al daño necrótico y no se podrán reducir vuestros puntos de golpe máximos. Si un aliado con 0 puntos de golpe comienza su turno en el aura, recupera 1 punto de golpe.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 30,
      "measure": "radius"
    }
  },
  {
    "name": "AURA DE VITALIDAD",
    "level": 3,
    "school": "Abjuración",
    "classes": [
      "clerigo",
      "druida",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "Personal / 30 pies de emanación",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Un aura surge de ti en una emanación de 30 pies hasta que el conjuro termine. Cuando creas el aura y al principio de cada uno de tus turnos mientras dure, puedes restaurar 2d6 puntos de golpe a una criatura en su interior.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 30,
      "measure": "radius"
    }
  },
  {
    "name": "AURA MÁGICA DE NYSTUL",
    "level": 2,
    "school": "Ilusionismo",
    "classes": [
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un pequeño cuadrado de seda"
    },
    "duration": "24 horas",
    "ritual": false,
    "concentration": false,
    "description": "Con un toque, aplicas una ilusión a una criatura voluntaria o un objeto que no lleve ni vista nadie. Las criaturas obtienen el efecto de enmascarar y los objetos, el efecto de aura falsa, ambos descritos a continuación. El efecto durará hasta que termine el conjuro.\n\nSi lanzas el conjuro a diario sobre el mismo objetivo durante 30 días, la ilusión permanece hasta que sea disipada.\n\n• Enmascarar (criaturas). Elige un tipo de criatura que no sea el auténtico del objetivo. Los conjuros y otros efectos mágicos tratan al objetivo como si fuese una criatura del tipo elegido.\n\n• Aura falsa (objetos). Cambias la forma en la que el objetivo se revela ante conjuros y efectos mágicos que detectan las auras mágicas, como el de detectar magia. Puedes hacer que un objeto no mágico parezca mágico, que un objeto mágico parezca no mágico o cambiar el aura de un objeto para que parezca pertenecer a una escuela mágica de tu elección.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "AURA SAGRADA",
    "level": 8,
    "school": "Abjuración",
    "classes": [
      "clerigo"
    ],
    "casting_time": "Acción",
    "range": "Personal / 30 pies de emanación",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un relicario que valga al menos 1000 po"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Hasta que termine el conjuro, emites un aura en una emanación de 30 pies. Mientras permanezcan dentro, las criaturas de tu elección tienen ventaja en todas las tiradas de salvación y otras criaturas tienen desventaja en las tiradas de ataque contra ellas.\n\nAdemás, cuando un infernal o un muerto viviente acierte a una criatura afectada con una tirada de ataque cuerpo a cuerpo, el atacante deberá superar una tirada de salvación de Constitución o tendrá el estado de cegado hasta el final de su siguiente turno.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 30,
      "measure": "radius"
    }
  },
  {
    "name": "AUXILIO",
    "level": 2,
    "school": "Abjuración",
    "classes": [
      "bardo",
      "clerigo",
      "druida",
      "explorador",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una tira de tela blanca"
    },
    "duration": "8 horas",
    "ritual": false,
    "concentration": false,
    "description": "Elige hasta tres criaturas dentro del alcance. Los puntos de golpe máximos y actuales de cada objetivo aumentan en 5 hasta que termine el conjuro.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Los puntos de golpe de cada objetivo aumentan en 5 adicionales por cada nivel por encima de 2 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "BAILE IRRESISTIBLE DE OTTO",
    "level": 6,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Una criatura que puedas ver dentro del alcance debe hacer una tirada de salvación de Sabiduría.\n\nSi la supera, el objetivo bailará de forma cómica hasta el final de su siguiente turno y utilizará todo su movimiento para bailar en el sitio.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "BARRERA DE CUCHILLAS",
    "level": 6,
    "school": "Evocación",
    "classes": [
      "clerigo"
    ],
    "casting_time": "Acción",
    "range": "90 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Creas un muro de cuchillas giratorias hechas de energía mágica, que aparecerá dentro del alcance y durará hasta que termine el conjuro. Creas un muro recto de hasta 100 pies de longitud, 20 pies de altura y 5 pies de grosor o un muro circular de hasta 60 pies de diámetro, 20 pies de altura y 5 pies de grosor. El muro proporciona cobertura tres cuartos y su espacio es terreno difícil. Cualquier criatura situada en el espacio del muro deberá hacer una tirada de salvación de Destreza; sufrirá 6d10 de daño de fuerza si la falla o la mitad del daño si la supera. Una criatura también deberá hacer la tirada si entra en el espacio del muro o termina su turno en él. Cada criatura solo hace esta tirada una vez por turno.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "BENDICIÓN",
    "level": 1,
    "school": "Encantamiento",
    "classes": [
      "clerigo",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un símbolo sagrado que valga al menos 5 po"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Bendices hasta tres criaturas dentro del alcance. Siempre que un objetivo haga una tirada de ataque o de salvación antes de que termine el conjuro, sumará 1d4 al resultado de dicha tirada.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Puedes hacer objetivo a una criatura adicional por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "BOCA MÁGICA",
    "level": 2,
    "school": "Ilusionismo",
    "classes": [
      "bardo",
      "mago"
    ],
    "casting_time": "1 minuto o un ritual",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "polvo de jade que valga al menos 10 po, que se consume como parte del conjuro"
    },
    "duration": "Hasta que sea disipado",
    "ritual": true,
    "concentration": false,
    "description": "Implantas un mensaje en un objeto dentro del alcance que se pronunciará en voz alta cuando se cumpla la condición de activación. Elige un objeto que puedas ver y que no lleve ni vista nadie.\n\nLuego, di el mensaje, que debe tener 25 palabras o menos, aunque puede transmitirse en un intervalo de hasta 10 minutos.\n\nPor último, determina la circunstancia que activará el conjuro para que transmita tu mensaje. Cuando se produzca esa circunstancia, en el objeto aparecerá una boca mágica que recitará el mensaje con tu voz y al mismo volumen en el que lo dijiste tú.\n\nSi el objeto elegido tiene boca o algo que se le parezca (por ejemplo, la boca de una estatua), la boca mágica se formará allí, de modo que las palabras parecerán salir de ella. Cuando lanzas este conjuro, puedes hacer que el efecto termine después de que transmita el mensaje o que permanezca y repita dicho mensaje siempre que se produzca la condición de activación.\n\nLa condición puede ser tan genérica o detallada como quieras, aunque debe basarse en fenómenos visuales o audibles que se produzcan a 30 pies o menos del objeto. Por ejemplo, podrías indicar que la boca hable cuando cualquier criatura se acerque a 30 pies o menos del objeto o cuando una campana de plata suene a 30 pies o menos de él.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "BOLA DE FUEGO",
    "level": 3,
    "school": "Evocación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "150 pies / 20 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una pelota de guano de murciélago y azufre"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Una ráfaga brillante surge de ti hacia un punto de tu elección dentro del alcance y luego estalla con un rugido sordo en una explosión ardiente. Todas las criaturas situadas en una esfera de 20 pies de radio centrada en ese punto harán una tirada de salvación de Destreza; sufrirán 8d6 de daño de fuego si la fallan o la mitad del daño si la superan. Los objetos inflamables dentro del área que no lleve o vista nadie empezarán a arder.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d6 por cada nivel por encima de 3 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 20,
      "measure": "radius"
    }
  },
  {
    "name": "BOLA DE FUEGO DE EXPLOSIÓN RETARDADA",
    "level": 7,
    "school": "Evocación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "150 pies / 20 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una pelota de guano de murciélago y azufre"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Un rayo de luz amarilla surge de ti y se condensa en un punto elegido dentro del alcance en forma de una cuenta brillante hasta que termine el conjuro. Cuando el conjuro termina, la cuenta explota y todas las criaturas en una esfera de 20 pies de radio centrada en ese punto hacen una tirada de salvación de Destreza. Sufrirán una cantidad de daño de fuego igual al daño total acumulado si fallan la tirada o la mitad del daño si la superan. El daño base del conjuro es 12d6 y aumenta en 1d6 siempre que termine tu turno si el conjuro aún no ha terminado. Si una criatura toca la cuenta brillante antes de que el conjuro termine, esa criatura hará una tirada de salvación de Destreza. Si la falla, el conjuro terminará y la cuenta explotará. Si la supera, podrá lanzar la cuenta a una distancia de 40 pies o menos. Si la cuenta lanzada entra en el espacio de una criatura o choca con un objeto sólido, el conjuro termina y la cuenta explota. Cuando estalle, todos los objetos inflamables dentro de la explosión que no lleve o vista nadie empezarán a arder.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño base aumenta en 1d6 por cada nivel por encima de 7 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 20,
      "measure": "radius"
    }
  },
  {
    "name": "BRAZOS DE HADAR",
    "level": 1,
    "school": "Conjuración",
    "classes": [
      "brujo"
    ],
    "casting_time": "Acción",
    "range": "Personal / 10 pies de emanación",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Invocas a Hadar y unas extremidades surgen de ti. Todas las criaturas en una emanación de 10 pies que se origina en ti deben hacer una tirada de salvación de Fuerza. Si la fallan, sufrirán 2d6 de daño necrótico y no podrán llevar a cabo reacciones hasta el principio de su siguiente turno. Si la superan, solamente recibirán la mitad de ese daño.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d6 por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 10,
      "measure": "radius"
    }
  },
  {
    "name": "BUENAS BAYAS",
    "level": 1,
    "school": "Conjuración",
    "classes": [
      "druida",
      "explorador"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una rama de muérdago"
    },
    "duration": "24 horas",
    "ritual": false,
    "concentration": false,
    "description": "En tu mano aparecen diez bayas, que están impregnadas de magia hasta que termine el conjuro. Una criatura puede usar una acción adicional para comerse una, lo que le permite recuperar 1 punto de golpe.\n\nAdemás, la baya proporciona alimento suficiente como para mantener a una criatura durante 1 día.\n\nLas bayas que no se consuman desaparecen cuando el conjuro termine.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "BURLA DAÑINA",
    "level": 0,
    "school": "Encantamiento",
    "classes": [
      "bardo"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Profieres una sarta de improperios mezclados con encantamientos sutiles hacia una criatura que puedas ver u oír dentro del alcance. El objetivo deberá superar una tirada de salvación de Sabiduría o recibirá 1d6 de daño psíquico y tendrá desventaja en la próxima tirada de ataque que realice antes de que acabe su siguiente turno.",
    "tables": [],
    "sections": [
      {
        "title": "Mejora de truco",
        "text": "El daño aumenta en 1d6 cuando alcanzas los niveles 5 (2d6), 11 (3d6) y 17 (4d6)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CALDERO BURBUJEANTE DE TASHA",
    "level": 6,
    "school": "Conjuración",
    "classes": [
      "brujo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "5 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un cucharón bañado en oro que valga al menos 500 po"
    },
    "duration": "10 minutos",
    "ritual": false,
    "concentration": false,
    "description": "Conjuras un caldero con patas de garra y lleno de un líquido burbujeante, que aparecerá en un espacio sin ocupar en el suelo a 5 pies de ti y permanecerá hasta que termine el conjuro. El caldero no se puede mover y desaparece cuando termine el conjuro junto con el líquido que contiene. El líquido del caldero copia las propiedades de una poción común o infrecuente que elijas (por ejemplo, de una poción de curación).\n\nComo acción adicional, un aliado o tú podéis meter la mano en el caldero y extraer una poción de ese tipo. La poción viene en un vial que desaparece tras consumirla. El caldero puede producir una cantidad de pociones de ese tipo igual a tu modificador por aptitud mágica (mínimo 1).\n\nCuando se extrae la última poción del caldero, este desaparece y el conjuro termina. Las pociones obtenidas del caldero que no se consuman desaparecerán cuando vuelvas a lanzar el conjuro.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CALENTAR METAL",
    "level": 2,
    "school": "Transmutación",
    "classes": [
      "bardo",
      "druida"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un trozo de hierro y una llama"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Elige un objeto metálico fabricado que puedas ver dentro del alcance, como un arma de metal o una armadura metálica media o pesada. Haces que el objeto se ponga al rojo vivo. Cualquier criatura que esté en contacto físico con el objeto recibirá 2d8 de daño de fuego cuando lances el conjuro. Hasta que el conjuro termine, puedes usar una acción adicional en cada uno de tus turnos posteriores para volver a causar este daño si el objeto está dentro del alcance. Si una criatura sostiene o lleva puesto el objeto y recibe el daño de este, deberá superar una tirada de salvación de Constitución o dejará caer el objeto si puede. Si no lo deja caer, tendrá desventaja en las tiradas de ataque y las pruebas de característica hasta el principio de tu siguiente turno.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d8 por cada nivel por encima de 2 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CALMAR EMOCIONES",
    "level": 2,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "clerigo"
    ],
    "casting_time": "Acción",
    "range": "60 pies / 20 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Cada humanoide en una esfera de 20 pies de radio centrada en un punto que elijas dentro del alcance deberá superar una tirada de salvación de Carisma o se verá afectado por uno de los siguientes efectos (elige uno por cada criatura):\n\n• La criatura tiene inmunidad a los estados de asustada y hechizada hasta que el conjuro termine. Si la criatura ya estaba asustada o hechizada, se suprimen esos estados hasta que el conjuro termine.\n\n• La criatura se vuelve indiferente hacia las criaturas de tu elección hacia las que sea hostil. Esta indiferencia termina si el objetivo recibe daño o si observa cómo alguno de sus aliados resulta dañado. Cuando el conjuro termine, la actitud de la criatura volverá a la normalidad.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 20,
      "measure": "radius"
    }
  },
  {
    "name": "CAMBIAR DE FORMA",
    "level": 9,
    "school": "Transmutación",
    "classes": [
      "druida",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una diadema de jade que valga al menos 1500 po"
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Asumes la forma de otra criatura hasta que termine el conjuro o hasta que uses una acción de magia para adoptar otra forma para la que cumplas los requisitos. La nueva forma debe ser la de una criatura con un valor de desafío igual o menor a tu nivel o valor de desafío. Tienes que haber visto alguna criatura de ese tipo y no puede ser un autómata ni un muerto viviente.\n\nCuando lanzas el conjuro, obtienes una cantidad de puntos de golpe temporales igual a los puntos de golpe de la primera forma que adoptes. Estos puntos de golpe temporales se desvanecerán si conservas alguno cuando el conjuro termine.\n\nTu perfil se sustituye por el de la forma elegida, pero conservarás tu tipo de criatura, alineamiento, personalidad, puntuaciones de Inteligencia, Sabiduría y Carisma, puntos de golpe, dados de puntos de golpe, competencias y capacidad para comunicarte. También conservas el rasgo Lanzamiento de conjuros si lo tienes.\n\nAl cambiar de forma, eliges si tu equipo cae al suelo o cambia de tamaño y forma para adaptarse a tu nuevo aspecto mientras lo adoptes.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CAMINAR SOBRE EL AGUA",
    "level": 3,
    "school": "Transmutación",
    "classes": [
      "clerigo",
      "druida",
      "explorador",
      "hechicero"
    ],
    "casting_time": "Acción o ritual",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un trozo de corcho"
    },
    "duration": "1 hora",
    "ritual": true,
    "concentration": false,
    "description": "Este conjuro concede la capacidad de moverse por encima de cualquier superficie líquida, como agua, ácido, barro, nieve, arenas movedizas o lava, como si se tratara de un suelo sólido inofensivo (aunque las criaturas que crucen lava derretida pueden seguir sufriendo daño por el calor). Hasta diez criaturas voluntarias que elijas dentro del alcance obtienen esta capacidad hasta que termine el conjuro.\n\nLos objetivos afectados deben emplear una acción adicional para pasar de la superficie del líquido al propio líquido y viceversa, pero si caen en él, pasarán a través de la superficie al líquido que hay debajo.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CAMPO ANTIMAGIA",
    "level": 8,
    "school": "Abjuración",
    "classes": [
      "clerigo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal / 10 pies de emanación",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "virutas de hierro"
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Un aura de antimagia te envuelve en una emanación de 10 pies. Dentro de ella nadie puede lanzar conjuros, emplear acciones de magia o crear otros efectos mágicos, y estos efectos no pueden hacer objetivo o afectar a nada de su interior. Las propiedades mágicas de los objetos mágicos no funcionan dentro del aura ni afectan a nada que esté en su interior.\n\nLas áreas de efecto que crean los conjuros u otro tipo de magia no pueden penetrar en el aura y nadie puede teletransportarse ni usar el viaje interplanar para entrar o salir de ella. Los portales se cierran de forma temporal mientras estén dentro del aura. Los conjuros activos se suprimen en la zona, salvo los que lancen un artefacto o deidad.\n\nMientras un efecto está suprimido, no funciona, pero el tiempo que pasa suprimido cuenta para su duración. Disipar magia no tiene efecto en el aura, y las auras creadas por distintos conjuros de campo antimagia no se anulan entre sí.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 10,
      "measure": "radius"
    }
  },
  {
    "name": "CANTO FÚNEBRE",
    "level": 6,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "clerigo"
    ],
    "casting_time": "Acción",
    "range": "Personal / 60 pies de emanación",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Un poder mortífero emana de ti en una emanación de 60 pies durante la duración del conjuro. Cuando lanzas este conjuro, puedes designar criaturas para que no se vean afectadas por él. Cualquier otra criatura que recupere puntos de golpe dentro de la emanación no recupera ningún punto de golpe.\n\nSiempre que la emanación entre en el espacio de una criatura, o cuando una criatura entre o termine su turno dentro de la emanación, esa criatura deberá realizar una tirada de salvación de Constitución. Si falla, recibirá 3d10 de daño necrótico y quedará derribada. Si la supera, recibirá la mitad del daño y no quedará derribada.\n\nUna criatura solo puede recibir este daño una vez por turno.\n\n**Lanzamiento como Conjuro de Círculo.**\nLanzar este conjuro como conjuro de círculo requiere un mínimo de dos lanzadores secundarios. Si se lanza de este modo, la duración pasa a ser Concentración, hasta 10 minutos. Una criatura que falle su tirada de salvación contra este conjuro obtiene 1 nivel de Agotamiento. Mientras la criatura tenga niveles de Agotamiento, finalizar un Descanso Largo no restaura puntos de golpe perdidos ni reduce el Agotamiento. Cuando se lanza el conjuro, cada lanzador secundario debe gastar un espacio de conjuro de nivel 4 o superior, o el conjuro falla.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 60,
      "measure": "radius"
    }
  },
  {
    "name": "CAPA LUNAR DE ALUSTRIEL",
    "level": 5,
    "school": "Abjuración",
    "classes": [
      "bardo",
      "druida",
      "explorador",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal / 20 pies de emanación",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una piedra lunar valorada en 50 po"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Durante la duración del conjuro, una luz lunar emana de ti en una emanación de 20 pies, iluminando el área con luz tenue. Mientras permanezcáis dentro de esta área, tú y tus aliados obtenéis Cobertura Media y resistencia al daño frío, relámpago y radiante.\n\nMientras el conjuro esté activo, puedes elegir una de las siguientes opciones, lo que finaliza el conjuro inmediatamente:\n\n• Liberación. Tú o un aliado dentro del área evita o termina las condiciones Aterrorizado, Agarrado o Restringido. Si el efecto requiere una tirada de salvación, puedes usar tu Reacción para superarla automáticamente.\n\n• Reprisa. Como Acción Mágica, cualquier aliado dentro del área recupera 4d10 + tu modificador de característica de conjuro puntos de golpe.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 20,
      "measure": "radius"
    }
  },
  {
    "name": "CAPARAZÓN ANTIVIDA",
    "level": 5,
    "school": "Abjuración",
    "classes": [
      "druida"
    ],
    "casting_time": "Acción",
    "range": "Personal / 10 pies de emanación",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Un aura se extiende alrededor de ti en una emanación de 10 pies hasta que el conjuro termine. El aura impide que las criaturas que no sean autómatas o muertos vivientes penetren total o parcialmente en ella, pero sí que pueden lanzar conjuros o realizar ataques con armas a distancia o de gran alcance a través de la barrera. Si tu movimiento obliga a que una criatura afectada atraviese la barrera, el conjuro termina.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 10,
      "measure": "radius"
    }
  },
  {
    "name": "CARCAJ VELOZ",
    "level": 5,
    "school": "Transmutación",
    "classes": [
      "explorador"
    ],
    "casting_time": "Acción adicional",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una aljaba que valga al menos 1 po"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Cuando lances el conjuro y como acción adicional hasta que termine, puedes realizar dos ataques con un arma que use flechas o virotes, como un arco largo o una ballesta ligera. El conjuro crea mágicamente la munición necesaria para cada ataque. Cada flecha o virote que cree el conjuro inflige daño como si fuera munición no mágica de su tipo y se desintegra inmediatamente después de acertar o fallar.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CASTIGO ABRASADOR",
    "level": 1,
    "school": "Evocación",
    "classes": [
      "paladin"
    ],
    "casting_time": "Acción adicional",
    "range": "Personal",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "1 minuto",
    "ritual": false,
    "concentration": false,
    "description": "Lanzas este conjuro como acción adicional que realizas de inmediato tras acertar a un objetivo con un arma cuerpo a cuerpo o un ataque sin armas. Al golpear al objetivo, sufre 1d6 de daño de fuego adicional del ataque. Al principio de cada uno de sus turnos hasta que el conjuro termine, el objetivo sufrirá 1d6 de daño de fuego y luego hará una tirada de salvación de Constitución. Si la falla, el conjuro seguirá activo. Si la supera, el conjuro terminará.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Todo el daño aumenta en 1d6 por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CASTIGO ABRUMADOR",
    "level": 4,
    "school": "Encantamiento",
    "classes": [
      "paladin"
    ],
    "casting_time": "Acción adicional",
    "range": "Personal",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Lanzas este conjuro como acción adicional que realizas de inmediato tras acertar a un objetivo con un arma cuerpo a cuerpo o un ataque sin armas. El objetivo recibirá 4d6 de daño psíquico adicional del ataque y deberá superar una tirada de salvación de Sabiduría o tendrá el estado de aturdido hasta el final de tu siguiente turno.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño adicional aumenta en 1d6 por cada nivel por encima de 4 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CASTIGO ATRONADOR",
    "level": 1,
    "school": "Evocación",
    "classes": [
      "paladin"
    ],
    "casting_time": "Acción adicional",
    "range": "Personal",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Lanzas este conjuro como acción adicional que realizas de inmediato tras acertar a un objetivo con un arma cuerpo a cuerpo o un ataque sin armas. Tu golpe resuena con un trueno audible a 300 pies de ti y el objetivo sufre 2d6 de daño de trueno adicional del ataque.\n\nAdemás, si el objetivo es una criatura, deberá superar una tirada de salvación de Fuerza o será empujada 10 pies lejos de ti y tendrá el estado de derribada.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño adicional aumenta en 1d6 por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CASTIGO BRILLANTE",
    "level": 2,
    "school": "Transmutación",
    "classes": [
      "paladin"
    ],
    "casting_time": "Acción adicional",
    "range": "Personal / 5 pies de radio",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Lanzas este conjuro como acción adicional que realizas de inmediato tras acertar a una criatura con un arma cuerpo a cuerpo o un ataque sin armas. El objetivo del golpe recibe 2d6 de daño radiante adicional del ataque. Hasta que el conjuro termine, el objetivo emitirá luz brillante en un radio de 5 pies, las tiradas de ataque contra él tendrán ventaja y no podrá beneficiarse del estado de invisibilidad.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d6 por cada nivel por encima de 2 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 5,
      "measure": "radius"
    }
  },
  {
    "name": "CASTIGO CEGADOR",
    "level": 3,
    "school": "Evocación",
    "classes": [
      "paladin"
    ],
    "casting_time": "Acción adicional",
    "range": "Personal",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "1 minuto",
    "ritual": false,
    "concentration": false,
    "description": "Lanzas este conjuro como acción adicional que realizas de inmediato tras acertar a un objetivo con un arma cuerpo a cuerpo o un ataque sin armas. El objetivo del golpe sufrirá 3d8 de daño radiante adicional del ataque y tendrá el estado de cegado hasta que el conjuro termine. Al final de cada uno de sus turnos, el objetivo cegado hará una tirada de salvación de Constitución y, si tiene éxito, se librará del conjuro.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño adicional aumenta en 1d8 por cada nivel por encima de 3 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CASTIGO DESTERRADOR",
    "level": 5,
    "school": "Conjuración",
    "classes": [
      "paladin"
    ],
    "casting_time": "Acción adicional",
    "range": "Personal",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Lanzas este conjuro como acción adicional que realizas de inmediato tras acertar a un objetivo con un arma cuerpo a cuerpo o un ataque sin armas. El objetivo de la tirada de ataque recibe 5d10 de daño de fuerza adicional del ataque. Si el ataque reduce los puntos de golpe del objetivo a 50 o menos, deberá superar una tirada de salvación de Carisma o se teletransportará a un semiplano inofensivo hasta que termine el conjuro. Mientras permanezca allí, tendrá el estado de incapacitado.\n\nCuando el conjuro termine, el objetivo reaparecerá en el espacio que abandonó o en el espacio sin ocupar más cercano si dicho espacio está ocupado.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CASTIGO DIVINO",
    "level": 1,
    "school": "Evocación",
    "classes": [
      "paladin"
    ],
    "casting_time": "Acción adicional",
    "range": "Personal",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Lanzas este conjuro como acción adicional que realizas de inmediato tras acertar a un objetivo con un arma cuerpo a cuerpo o un ataque sin armas. El objetivo sufre 2d8 de daño radiante adicional del ataque. Este daño aumenta en 1d8 si el objetivo es un infernal o un muerto viviente.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d8 por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CASTIGO FURIOSO",
    "level": 1,
    "school": "Nigromancia",
    "classes": [
      "paladin"
    ],
    "casting_time": "Acción adicional",
    "range": "Personal",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "1 minuto",
    "ritual": false,
    "concentration": false,
    "description": "Lanzas este conjuro como acción adicional que realizas de inmediato tras acertar a un objetivo con un arma cuerpo a cuerpo o un ataque sin armas. El objetivo sufrirá 1d6 de daño necrótico adicional del ataque y deberá superar una tirada de salvación de Sabiduría o tendrá el estado de asustado hasta que el conjuro termine. Al final de cada uno de sus turnos, el objetivo asustado repite la tirada de salvación y, si tiene éxito, se librará del conjuro.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d6 por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CAUTIVERIO",
    "level": 9,
    "school": "Abjuración",
    "classes": [
      "brujo",
      "mago"
    ],
    "casting_time": "1 minuto",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una estatuilla del objetivo que valga al menos 5000 po"
    },
    "duration": "Hasta que sea disipado",
    "ritual": false,
    "concentration": false,
    "description": "Creas una restricción mágica para apresar a una criatura que puedas ver dentro del alcance. El objetivo deberá hacer una tirada de salvación de Sabiduría. Si la supera, el conjuro no le afectará y será inmune a él durante las próximas 24 horas. Si la falla, quedará aprisionado. Mientras esté aprisionado, el objetivo no necesitará respirar, comer ni beber, y tampoco envejecerá. Los conjuros de adivinación no podrán localizar ni percibir al objetivo, que tampoco podrá teletransportarse.\n\nHasta que el conjuro termine, el objetivo también se verá afectado por uno de los siguientes efectos, a tu elección:\n\n• **Contención mínima.**\nEl objetivo queda reducido a una altura de 1 pulgada y atrapado dentro de una gema u otro objeto similar, que es indestructible. La luz puede atravesar la piedra preciosa, lo que permite que el objetivo vea lo que hay fuera y que las demás criaturas vean lo que hay dentro, pero nada más puede atravesarla de ninguna forma.\n\n• **Encadenamiento.**\nUnas cadenas firmemente ancladas al suelo retienen al objetivo. El objetivo tiene el estado de apresado y no hay ninguna forma de moverlo.\n\n• **Entierro.**\nEl objetivo queda sepultado bajo tierra en un globo hueco de fuerza mágica con un tamaño justo como para contenerlo. Nada puede entrar ni salir del globo.\n\n• **Presidio cercado.**\nEl objetivo queda atrapado en un semiplano protegido contra la teletransportación y el viaje interplanar. El semiplano puede ser un laberinto, una jaula, una torre o una estructura similar.\n\n• **Sueño.**\nEl objetivo tiene el estado de inconsciente y no se le puede despertar.\n\n• **Poner fin al conjuro.**\nCuando lances el conjuro, especifica una condición que le ponga fin. Puede ser tan sencilla o complicada como quieras, aunque tu DM debe estar de acuerdo en que tenga una alta probabilidad de llegar a ocurrir en la próxima década. La condición debe ser una acción observable, como que alguien haga una ofrenda concreta en el templo de tu dios, salve a tu amor verdadero o derrote a un monstruo concreto.\n\nUn conjuro de Disipar magia puede poner fin al conjuro solamente si se lanza con un espacio de conjuro de nivel 9 y hace objetivo a la prisión o al componente usado para crearla.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CAÍDA DE PLUMA",
    "level": 1,
    "school": "Transmutación",
    "classes": [
      "bardo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Reacción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": false,
      "m": true,
      "material": "una pluma pequeña o un poco de plumón"
    },
    "duration": "1 minuto",
    "ritual": false,
    "concentration": false,
    "description": "Lanzas este conjuro como reacción que llevas a cabo cuando tú y una criatura que puedas ver a 60 pies o menos de ti caigáis.\n\nElige hasta cinco criaturas dentro del alcance que estén cayendo. La velocidad de descenso de cada objetivo se reduce a 60 pies por asalto hasta que el conjuro termine. Si una criatura aterriza antes de que el conjuro termine, no sufrirá daño por la caída y el conjuro terminará para esa criatura.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CERRADURA ARCANA",
    "level": 2,
    "school": "Abjuración",
    "classes": [
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "polvo de oro que valga al menos 25 po, que se consume como parte del conjuro"
    },
    "duration": "Hasta que sea disipado",
    "ritual": false,
    "concentration": false,
    "description": "Tocas una puerta, ventana, portón, recipiente o trampilla cerrados y se cierra mágicamente como con llave hasta que el conjuro termine. Esta cerradura no puede abrirse por medios no mágicos, pero tú y las criaturas que designes cuando lanzas el conjuro podéis abrir y cerrar el objeto a pesar de esta cerradura.\n\nTambién puedes elegir una contraseña que, dicha en voz alta a 5 pies o menos del objeto, lo desbloquea durante 1 minuto.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CLARIVIDENCIA",
    "level": 3,
    "school": "Adivinación",
    "classes": [
      "bardo",
      "clerigo",
      "hechicero",
      "mago"
    ],
    "casting_time": "10 minutos",
    "range": "1 milla",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un canalizador que valga al menos 100 po puede ser una trompetilla enjoyada o un ojo de cristal"
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Creas un sensor invisible dentro del alcance en un lugar que conozcas (que hayas visitado o visto antes) o en un lugar obvio, aunque no lo conozcas (por ejemplo, tras una puerta, al girar una esquina o en una arboleda). Este sensor intangible e invulnerable permanecerá allí hasta que el conjuro termine. Cuando lances el conjuro, elige la vista o el oído.\n\nPodrás usar el sentido elegido como si estuvieras en el espacio del sensor.\n\nComo acción adicional, puedes cambiar entre la vista y el oído. Cualquier criatura que pueda percibir el sensor (por ejemplo, que se esté beneficiando del conjuro ver invisibilidad o que tenga visión verdadera) verá un orbe luminoso del tamaño aproximado de tu puño.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CLAVO MENTAL",
    "level": 2,
    "school": "Adivinación",
    "classes": [
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": false,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Introduces una púa de energía psiónica en la mente de una criatura que puedas ver dentro del alcance. El objetivo hace una tirada de salvación de Sabiduría; sufrirá 3d8 de daño psíquico si la falla o la mitad del daño si la supera.\n\nAdemás, si falla la tirada, conocerás en todo momento la ubicación del objetivo hasta que el conjuro termine, pero solo mientras los dos estéis en el mismo plano de existencia. Mientras tengas este conocimiento, la criatura no podrá ocultarse de ti y, si tiene el estado de invisible, no se beneficiará de dicho estado contra ti.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d8 por cada nivel por encima de 2 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CLON",
    "level": 8,
    "school": "Nigromancia",
    "classes": [
      "mago"
    ],
    "casting_time": "1 hora",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un diamante que valga al menos 1000 po, que se consume como parte del conjuro, y un recipiente sellable que valga al menos 2000 po y sea lo bastante grande como para alojar a la criatura que se clone"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Tocas a una criatura o al menos un cubo de su carne de 1 pulgada. Dentro del recipiente empleado para lanzar el conjuro se crea un duplicado inerte de la criatura que alcanza la madurez en 120 días; tú decides si el clon terminado tiene la misma edad que la criatura o si es más joven. El clon permanecerá inerte y durará indefinidamente, siempre que su recipiente se mantenga intacto.\n\nSi la criatura original muere después de que el clon haya madurado, su alma se transferirá al clon si el alma es libre y desea regresar. El clon es físicamente idéntico al original, al igual que su personalidad, sus recuerdos y sus capacidades, pero no posee nada de su equipo original.\n\nLos restos mortales de la criatura original, si existen, se volverán inertes y no podrán ser devueltos a la vida, ya que el alma de la criatura está en otra parte.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "COFRE OCULTO DE LEOMUND",
    "level": 4,
    "school": "Conjuración",
    "classes": [
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un cofre de con unas dimensiones de 3 pies por 2 pies por 2 pies, construido de materiales raros que valgan al menos 5000 po, así como una réplica Diminuta hecha de los mismos materiales y que valga al menos 50 po"
    },
    "duration": "Hasta que sea disipado",
    "ritual": false,
    "concentration": false,
    "description": "Ocultas un cofre y todo su contenido en el Plano Etéreo.\n\nDebes tocar el cofre y la réplica en miniatura que sirve como componente material del conjuro. El cofre puede contener hasta 12 pies cúbicos de material inerte (3 pies por 2 pies por 2 pies).\n\nMientras el cofre permanezca en el Plano Etéreo, puedes usar una acción de magia y tocar la réplica para recuperar dicho cofre, que aparecerá en un espacio sin ocupar en el suelo a 5 pies de ti. Puedes enviar el cofre de regreso al Plano Etéreo usando una acción de magia para tocar el cofre y la réplica.\n\nDespués de 60 días, existe una probabilidad acumulativa del 5 % al final de cada día de que el efecto del conjuro termine. El conjuro también termina si vuelves a lanzarlo o si se destruye la réplica diminuta del cofre. Si el conjuro termina y el cofre grande está en el Plano Etéreo, permanecerá allí hasta que tú u otra persona lo encontréis.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "COMPULSIÓN",
    "level": 4,
    "school": "Encantamiento",
    "classes": [
      "bardo"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Todas las criaturas de tu elección que puedas ver dentro del alcance deberán superar una tirada de salvación de Sabiduría o tendrán el estado de hechizadas hasta que el conjuro termine. Mientras dure, puedes usar una acción adicional para designar una dirección horizontal respecto a ti. Cada criatura hechizada deberá usar todo el movimiento que pueda para avanzar en esa dirección por la ruta más segura durante su próximo turno. Tras moverse de este modo, un objetivo repite la tirada de salvación y, si tiene éxito, se librará del conjuro.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "COMUNIÓN",
    "level": 5,
    "school": "Adivinación",
    "classes": [
      "clerigo"
    ],
    "casting_time": "1 minuto o un ritual",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "incienso"
    },
    "duration": "1 minuto",
    "ritual": true,
    "concentration": false,
    "description": "Te pones en contacto con una deidad o con un representante divino y le haces hasta tres preguntas que se puedan responder con sí o no. Tienes que realizar las preguntas antes de que el conjuro termine y recibirás una respuesta correcta a cada una de ellas. Los seres divinos no tienen por qué ser omniscientes, por lo que si la deidad no tiene información sobre lo que le preguntas, puede responderte \"ambiguo\".\n\nEn caso de que una respuesta de una sola palabra pudiera inducir a error o ser contraria a los intereses de la deidad, tu DM podría ofrecer en su lugar una frase corta. Si lanzas el conjuro más de una vez antes de finalizar un descanso largo, hay una posibilidad acumulativa del 25 % por cada lanzamiento después del primero de que no recibas ninguna respuesta.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "COMUNIÓN CON LA NATURALEZA",
    "level": 5,
    "school": "Adivinación",
    "classes": [
      "druida",
      "explorador"
    ],
    "casting_time": "1 minuto o un ritual",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": true,
    "concentration": false,
    "description": "Comulgas con espíritus de la naturaleza y obtienes información sobre la zona circundante. En exteriores, el conjuro te proporciona información de la zona a 3 millas a tu alrededor. En cavernas y otros entornos naturales subterráneos, el radio se ve limitado a 300 pies.\n\nEl conjuro no funciona en lugares en los que la naturaleza ha sido sustituida por construcciones, como castillos y asentamientos.\n\nElige tres de los siguientes hechos, que aprenderás según corresponda a la zona del conjuro:\n\n• Ubicaciones de asentamientos.\n\n• Ubicaciones de portales a otros planos de existencia.\n\n• La ubicación de una criatura con un valor de desafío de 10 o más (a elección de tu DM) que sea celestial, elemental, feérico, infernal o muerto viviente.\n\n• El tipo de planta, mineral o bestia más frecuente (tú decides cuál).\n\n• Ubicaciones de masas de agua. Por ejemplo, podrías determinar el paradero de un monstruo poderoso en la zona y la ubicación de masas de agua y de cualquier pueblo cercano.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CONFUSIÓN",
    "level": 4,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "90 pies / 10 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "tres cáscaras de nuez"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Cada criatura en una esfera de 10 pies de radio centrada en un punto de tu elección dentro del alcance debe hacer una tirada de salvación de Sabiduría. Si la falla, no podrá realizar reacciones y deberá tirar en la tabla de Confusión al comienzo de cada uno de sus turnos para determinar su comportamiento. Al final de cada uno de sus turnos, puede repetir la tirada de salvación y, si la supera, el conjuro termina para ella.",
    "tables": [
      {
        "title": "1d10",
        "columns": [
          "1d10",
          "Comportamiento del turno"
        ],
        "rows": [
          [
            "1",
            "El objetivo no usa ninguna acción y emplea todo su movimiento para desplazarse. Para determinar la dirección, tira 1d4: con un 1, se moverá al norte; con un 2, al este; con un 3, al sur; con un 4, al oeste."
          ],
          [
            "2–6",
            "El objetivo no se mueve ni realiza acciones."
          ],
          [
            "7–8",
            "El objetivo no se mueve y emplea la acción de atacar para hacer un ataque cuerpo a cuerpo contra una criatura aleatoria dentro de su alcance. Si no hay ninguna dentro de su alcance, el objetivo no hace ninguna acción."
          ],
          [
            "9–10",
            "El objetivo elige su comportamiento."
          ]
        ]
      }
    ],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El radio de la esfera aumenta en 5 pies por cada nivel por encima de 4 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 10,
      "measure": "radius"
    }
  },
  {
    "name": "CONJURAR ANIMALES",
    "level": 3,
    "school": "Conjuración",
    "classes": [
      "druida",
      "explorador"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Conjuras espíritus de la naturaleza que aparecen como una manada Grande de animales espectrales e intangibles en un espacio sin ocupar que puedas ver dentro del alcance. La manada permanecerá hasta que el conjuro termine y puedes elegir la forma animal de los espíritus, como lobos, serpientes o aves. Tienes ventaja en las tiradas de salvación de Fuerza mientras estés a 5 pies o menos de la manada.\n\nAdemás, cuando te muevas en tu turno, también podrás mover a la manada hasta 30 pies a un espacio sin ocupar que puedas ver. Siempre que la manada se mueva a 10 pies o menos de una criatura que puedas ver y siempre que una criatura que puedas ver entre en un espacio a 10 pies o menos de la manada o termine su turno allí, puedes obligar a la criatura a hacer una tirada de salvación de Destreza. Si la falla, recibirá 3d10 de daño cortante. Una criatura solo hace esta tirada una vez por turno.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d10 por cada nivel por encima de 3 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CONJURAR CELESTIAL",
    "level": 7,
    "school": "Conjuración",
    "classes": [
      "clerigo"
    ],
    "casting_time": "Acción",
    "range": "90 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Conjuras un espíritu de los Planos Superiores, que se manifiesta como un pilar de luz de 10 pies de radio y 40 pies de alto centrado en un punto dentro del alcance. Por cada criatura que puedas ver en el cilindro, elige qué tipo de luz brilla sobre ella:\n\n• Luz abrasadora. El objetivo hace una tirada de salvación de Destreza; sufrirá 6d12 de daño radiante si la falla o la mitad del daño si la supera.\n\n• Luz sanadora. El objetivo recupera una cantidad de puntos de golpe igual a 4d12 más tu modificador por aptitud mágica. Hasta que el conjuro termine, una luz brillante llena el cilindro y, cuando te muevas en tu turno, también puedes mover el cilindro hasta 30 pies. Siempre que el cilindro entre en el espacio de una criatura que puedas ver y siempre que una criatura que puedas ver entre en el cilindro o termine su turno en él, puedes bañar a la criatura con una de las luces. Una criatura puede verse afectada por este conjuro solo una vez por turno.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño y la curación aumentan en 1d12 por cada nivel por encima de 7 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CONJURAR CONSTRUCTOS",
    "level": 3,
    "school": "Conjuración",
    "classes": [
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un engranaje de latón"
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Invocas un grupo de espíritus ordenados que aparecen como constructos Medianos, como modrones u otros constructos similares, en un espacio desocupado que puedas ver dentro del alcance. Como Acción Mágica en turnos posteriores, puedes ordenar a los espíritus que afecten a una criatura u objeto a 5 pies de ellos con uno de los siguientes efectos:\n\n• Fuerza Mecánica. El objetivo realiza una tirada de salvación de Destreza. Si falla, recibe 3d6 de daño de fuerza, o la mitad con un éxito.\n\n• Guardia Ordenada. El objetivo obtiene Puntos de Golpe Temporales iguales a 1d6 + tu modificador de característica de conjuro. En tu turno, puedes mover a los espíritus hasta 30 pies a un espacio desocupado que puedas ver.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CONJURAR DESCARGA DE PROYECTILES",
    "level": 3,
    "school": "Conjuración",
    "classes": [
      "explorador"
    ],
    "casting_time": "Acción",
    "range": "Personal / 60 pies de cono",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un arma cuerpo a cuerpo o a distancia que valga al menos 1 pc"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Blandes el arma utilizada para lanzar el conjuro e invocas versiones espectrales parecidas (o munición para el tipo de arma correspondiente) que salen disparadas hacia adelante y luego desaparecen. Todas las criaturas de tu elección que puedas ver en un cono de 60 pies hacen una tirada de salvación de Destreza; sufrirán 5d8 de daño de fuerza si la fallan o la mitad del daño si la superan.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d8 por cada nivel por encima de 3 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "cone",
      "sizeFt": 60
    }
  },
  {
    "name": "CONJURAR ELEMENTAL",
    "level": 5,
    "school": "Conjuración",
    "classes": [
      "druida",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Invocas un espíritu Grande e intangible de los Planos Elementales, que aparece en un espacio sin ocupar dentro. del alcance. Elige el elemento del espíritu, que determina su tipo de daño: agua (frío), aire (relámpago), fuego (fuego) o tierra (trueno). El espíritu permanece hasta que el conjuro termine. Siempre que una criatura que puedas ver entre en el espacio del espíritu o empiece su turno a 5 pies o menos de él, puedes obligarla a hacer una tirada de salvación de Destreza si el espíritu no tiene ninguna criatura apresada. Si la falla, el objetivo sufrirá 8d8 de daño del tipo del espíritu y tendrá el estado de apresado hasta que el conjuro termine. Al principio de cada uno de sus turnos, el objetivo apresado repite la tirada de salvación. Si la falla, sufrirá 4d8 de daño del tipo del espíritu. Si la supera, dejará de estar apresado por él.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d8 por cada nivel por encima de 5 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CONJURAR ELEMENTALES MENORES",
    "level": 4,
    "school": "Conjuración",
    "classes": [
      "druida",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal / 15 pies de emanación",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Conjuras espíritus de los Planos Elementales que revolotean a tu alrededor en una emanación de 15 pies mientras dure el conjuro. Hasta que el conjuro termine, cualquier ataque que hagas causará 2d8 de daño adicional cuando aciertes a una criatura dentro de la emanación. Ese daño será de ácido, frío, fuego o relámpago (a tu elección cuando ataques).\n\nAdemás, el suelo incluido en la emanación se considerará terreno difícil para tus enemigos.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d8 por cada nivel por encima de 4 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 15,
      "measure": "radius"
    }
  },
  {
    "name": "CONJURAR FEÉRICO",
    "level": 6,
    "school": "Conjuración",
    "classes": [
      "druida"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Conjuras un espíritu Mediano de los Parajes Feéricos en un espacio sin ocupar que puedas ver dentro del alcance. El espíritu dura hasta que termine el conjuro y toma la forma de una criatura feérica de tu elección.\n\nCuando aparezca, puedes hacer un ataque de conjuro cuerpo a cuerpo contra una criatura a 5 pies o menos de él.\n\nSi acierta, el objetivo sufrirá una cantidad de daño psíquico igual a 3d12 más tu modificador por aptitud mágica y tendrá el estado de asustado hasta el principio de tu siguiente turno, y tanto el espíritu como tú seréis el origen de su miedo.\n\nComo acción adicional en tus siguientes turnos, puedes teletransportar el espíritu a un espacio sin ocupar que puedas ver a 30 pies o menos del espacio que ocupaba antes y hacer el ataque contra una criatura a 5 pies o menos de él.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d12 por cada nivel por encima de 6 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CONJURAR LLUVIA DE FLECHAS",
    "level": 5,
    "school": "Conjuración",
    "classes": [
      "explorador"
    ],
    "casting_time": "Acción",
    "range": "150 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un arma cuerpo a cuerpo o a distancia que valga al menos 1 pc"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Blandes el arma utilizada para lanzar el conjuro y eliges un punto dentro del alcance. Cientos de duplicados espectrales del arma (o munición para el tipo de arma correspondiente) caen en una lluvia y luego desaparecen. Todas las criaturas de tu elección que puedas ver dentro de un cilindro de 40 pies de radio y 20 pies de altura centrado en ese punto hacen una tirada de salvación de Destreza. Sufrirán 8d8 de daño de fuerza si la fallan o la mitad del daño si la superan.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CONJURAR SERES DEL BOSQUE",
    "level": 4,
    "school": "Conjuración",
    "classes": [
      "druida",
      "explorador"
    ],
    "casting_time": "Acción",
    "range": "Personal / 10 pies de emanación",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Conjuras espíritus de la naturaleza que revolotean a tu alrededor en una emanación de 10 pies hasta que el conjuro termine. Siempre que la emanación entre en el espacio de una criatura que puedas ver y siempre que una criatura que puedas ver entre en la emanación o termine su turno allí, puedes obligar a la criatura a hacer una tirada de salvación de Sabiduría. Sufrirá 5d8 de daño de fuerza si la falla o la mitad del daño si la supera. Una criatura solo hace esta tirada una vez por turno.\n\nAdemás, hasta que termine el conjuro, puedes llevar a cabo la acción de destrabarse como acción adicional.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d8 por cada nivel por encima de 4 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 10,
      "measure": "radius"
    }
  },
  {
    "name": "CONO DE FRÍO",
    "level": 5,
    "school": "Evocación",
    "classes": [
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal / 60 pies de cono",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un cono pequeño de cristal o vidrio"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Emites una ráfaga de aire helado. Todas las criaturas situadas en un cono de 60 pies que se origina en ti hacen una tirada de salvación de Constitución; sufrirán 8d8 de daño de frío si la fallan o la mitad de daño si la superan. Si una criatura muere a causa de este conjuro, se convertirá en una estatua congelada hasta que se descongele.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d8 por cada nivel por encima de 5 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "cone",
      "sizeFt": 60
    }
  },
  {
    "name": "CONOCER LAS LEYENDAS",
    "level": 5,
    "school": "Adivinación",
    "classes": [
      "bardo",
      "clerigo",
      "mago"
    ],
    "casting_time": "10 minutos",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "incienso que valga al menos 250 po, que se consume como parte del conjuro, y cuatro tiras de marfil que valgan al menos 50 po"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Nombra o describe a una persona, un lugar o un objeto famosos. El conjuro traerá a tu mente un breve resumen de la información relevante sobre lo nombrado, que describe tu DM.\n\nEsta información pueden ser detalles importantes, revelaciones simpáticas o incluso conocimiento secreto que no es de dominio público.\n\nCuanta más información tengas ya sobre esa cosa, más precisa y detallada será la que consigas. La información será cierta, pero puede estar disimulada bajo un lenguaje metafórico o poético, a discreción de tu DM.\n\nSi lo que has nombrado no es famoso, en su lugar escucharás una musiquilla triste tocada con un trombón y el conjuro fallará.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CONSAGRAR",
    "level": 5,
    "school": "Abjuración",
    "classes": [
      "clerigo"
    ],
    "casting_time": "24 horas",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "incienso que valga al menos 1000 po, que se consume como parte del conjuro"
    },
    "duration": "Hasta que sea disipado",
    "ritual": false,
    "concentration": false,
    "description": "Tocas un punto e impregnas la zona a su alrededor con poder sagrado o impío. El área puede tener un radio de hasta 60 pies. El conjuro falla si el área incluye cualquier zona que ya esté bajo el efecto de consagrar.\n\nLa zona afectada queda sujeta a los siguientes efectos.\n\n• **Protección sagrada** Elige uno o más de los siguientes tipos de criatura: aberración, celestial, elemental, feérico, infernal o muerto viviente. Las criaturas de los tipos elegidos no pueden entrar voluntariamente en la zona. Además, cualquier criatura que esté poseída, asustada o hechizada por una criatura de esos tipos deja de estarlo mientras permanezca dentro de la zona.\n\n**Efecto adicional**\n\nVinculas a la zona uno de los siguientes efectos adicionales:\n\n• **Coraje.** Las criaturas de los tipos que elijas no pueden obtener el estado de asustado mientras se encuentren dentro de la zona.\n\n• **Descanso plácido.** Los cadáveres enterrados en la zona no pueden convertirse en muertos vivientes.\n\n• **Don de lenguas.** Las criaturas de los tipos que elijas pueden comunicarse con cualquier otra criatura dentro de la zona, aunque no compartan un idioma común.\n\n• **Intromisión extradimensional.** Las criaturas de los tipos que elijas no pueden entrar ni salir de la zona mediante teletransporte o viaje interplanar.\n\n• **Luz del día.** La zona se llena de luz brillante. La oscuridad mágica creada por conjuros de nivel inferior al de este conjuro no puede extinguir esta luz.\n\n• **Oscuridad.** La zona se llena de oscuridad. La luz normal y la luz mágica creada por conjuros de nivel inferior al de este conjuro no pueden iluminar la zona.\n\n• **Resistencia.** Las criaturas de los tipos que elijas tienen resistencia a un tipo de daño de tu elección mientras permanezcan dentro de la zona.\n\n• **Silencio.** Ningún sonido puede salir de la zona ni penetrar en ella.\n\n• **Terror.** Las criaturas de los tipos que elijas quedan asustadas mientras se encuentren dentro de la zona.\n\n• **Vulnerabilidad.** Las criaturas de los tipos que elijas tienen vulnerabilidad a un tipo de daño de tu elección mientras permanezcan dentro de la zona.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CONTACTAR CON OTRO PLANO",
    "level": 5,
    "school": "Adivinación",
    "classes": [
      "brujo",
      "mago"
    ],
    "casting_time": "1 minuto o un ritual",
    "range": "Personal",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "1 minuto",
    "ritual": true,
    "concentration": false,
    "description": "Contactas mentalmente con un semidiós, el espíritu de un erudito muerto hace tiempo o cualquier otra entidad ilustrada de otro plano. Contactar con esta inteligencia sobrenatural puede hacer añicos tu mente. Cuando lances este conjuro, haz una tirada de salvación de Inteligencia con CD 15.\n\nSi superas la tirada, puedes hacerle a la entidad hasta cinco preguntas, que debes realizar antes de que el conjuro termine. Tu DM responderá a cada pregunta con una sola palabra, como \"sí\", \"no\", \"puede\", \"nunca\", \"irrelevante\" o \"ambiguo\" (si la entidad no conoce la respuesta a la pregunta). Si una respuesta de una sola palabra pudiera inducir a error, tu DM podría ofrecer en su lugar una frase corta.\n\nSi fallas la tirada, sufrirás 6d6 de daño psíquico y tendrás el estado de incapacitado hasta que finalices un descanso largo. Si te lanzan un conjuro restablecimiento mayor, el efecto acabará.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CONTAGIO",
    "level": 5,
    "school": "Nigromancia",
    "classes": [
      "clerigo",
      "druida"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "7 días",
    "ritual": false,
    "concentration": false,
    "description": "Tu toque causa un contagio mágico. El objetivo debe superar una tirada de salvación de Constitución o sufrirá 11d8 de daño necrótico y tendrá el estado de envenenado.\n\nAdemás, elige una característica cuando lances el conjuro. Mientras esté envenenado, el objetivo tendrá desventaja en las tiradas de salvación que haga con la característica elegida. El objetivo deberá repetir la tirada de salvación al final de cada uno de sus turnos hasta que la supere o la falle tres veces. Si supera tres de estas tiradas, el conjuro terminará para el objetivo, pero si falla tres tiradas, el conjuro le durará 7 días. Cuando el objetivo envenenado reciba un efecto que fuera a poner fin al estado de envenenado, deberá superar una tirada de salvación de Constitución o el estado de envenenado no terminará.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CONTINGENCIA",
    "level": 6,
    "school": "Abjuración",
    "classes": [
      "mago"
    ],
    "casting_time": "10 minutos",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una estatuilla de ti tallada y decorada con gemas que valga al menos 1500 po"
    },
    "duration": "10 días",
    "ritual": false,
    "concentration": false,
    "description": "Elige un conjuro de nivel 5 o inferior que puedas lanzar, que tenga un tiempo de lanzamiento de una acción y que te permita elegirte como objetivo. Lanzas el conjuro (llamado \"conjuro contingente\") como parte del lanzamiento de contingencia y gastas los espacios de conjuro de ambos, pero el conjuro contingente no tiene efecto en ese momento, sino que se activa cuando se produce una condición determinada.\n\nDescribes esa condición cuando lanzas los dos conjuros. Por ejemplo, si lanzas contingencia junto a respirar bajo el agua, podrías decir que respirar bajo el agua tenga efecto cuando te sumerjas en agua o en un líquido similar.\n\nEl conjuro contingente tiene efecto inmediatamente después de que se produzca la condición por primera vez, tanto si quieres como si no, y después termina el conjuro contingencia.\n\nEl conjuro contingente solo tiene efecto sobre ti, aunque normalmente pudieras elegir como objetivo a otros. Solo puedes tener un conjuro contingencia activo al mismo tiempo. Si vuelves a lanzarlo, terminará el efecto de cualquier otro conjuro contingencia que tengas.\n\nAsimismo, contingencia termina si dejas de tener contigo su componente material.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CONTORNO BORROSO",
    "level": 2,
    "school": "Ilusionismo",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Tu cuerpo se vuelve borroso. Hasta que termine el conjuro, todas las criaturas tendrán desventaja en las tiradas de ataque contra ti. Un atacante es inmune a este efecto si te percibe mediante visión ciega o visión verdadera.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CONTRAHECHIZO",
    "level": 3,
    "school": "Abjuración",
    "classes": [
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Reacción",
    "range": "60 pies",
    "components": {
      "v": false,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Lanzas este conjuro como reacción que llevas a cabo.\n\nIntentas interrumpir a una criatura que esté lanzando un conjuro. La criatura hace una tirada de salvación de Constitución. Si la falla, el conjuro se disipa sin causar efecto alguno y la acción, acción adicional o reacción empleada para lanzarlo se desperdiciará. Si ese conjuro se lanzó con un espacio de conjuro, dicho espacio no se gastará.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CONTROLAR AGUA",
    "level": 4,
    "school": "Transmutación",
    "classes": [
      "clerigo",
      "druida",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "300 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una mezcla de agua y polvo"
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Hasta que el conjuro termine, controlas cualquier masa de agua que esté en un área de tu elección con forma de cubo de hasta 100 pies de lado, y usas uno de los siguientes efectos. Como acción de magia en tus siguientes turnos, puedes repetir el mismo efecto o elegir uno distinto.\n\n• **Abrir las aguas.**\nHaces que las aguas de la zona se separen y creen un canal que se extiende a lo largo de toda el área del conjuro, con las aguas apartadas formando un muro a ambos lados. El canal se mantendrá hasta que el conjuro termine o hasta que elijas un efecto distinto. Posteriormente, el agua irá llenando el canal lentamente durante el siguiente asalto, hasta recuperar su nivel normal.\n\n• **Inundación.**\nHaces que el nivel del agua estancada de la zona aumente hasta 20 pies. Si eliges una zona en una masa de agua grande, en vez de eso creas una ola de 20 pies de altura que se desplaza de un lado de esa zona al otro y luego rompe. Cualquier vehículo Enorme o más pequeño que esté en el recorrido de la ola será transportado hasta el otro lado y también tendrá un 25 % de probabilidades de volcar.\n\nEl nivel del agua permanecerá elevado hasta que el conjuro termine o hasta que elijas un efecto distinto. Si este efecto ha producido una ola, esta se repetirá al principio de tu siguiente turno mientras dure el efecto de la inundación.\n\n• **Redirigir caudal.**\nHaces que un caudal de agua en la zona se mueva en la dirección que elijas, incluso si tiene que fluir por encima de obstáculos, subir muros o tomar otros rumbos extraños. El agua de la zona se moverá según tus instrucciones, pero, una vez salga del área del conjuro, volverá a fluir de forma normal en función del terreno. El agua seguirá moviéndose en la dirección que hayas elegido hasta que el conjuro termine o hasta que elijas un efecto distinto.\n\n• **Remolino.**\nProvocas que se forme un remolino en el centro del área, que debe ser un cuadrado de al menos 50 pies de lado y 25 pies de profundidad. El remolino permanece hasta que elijas un efecto distinto o termine el conjuro. El remolino tiene 5 pies de ancho en su base y hasta 50 pies en la parte superior, con una altura de 25 pies. Cualquier criatura que esté en el agua a 25 pies o menos del remolino será atraída 10 pies hacia él.\n\nCuando una criatura entre en el remolino por primera vez en un turno o termine su turno allí, deberá hacer una tirada de salvación de Fuerza. Si falla, recibirá 2d8 de daño contundente. Si la supera, recibirá la mitad del daño.\n\nUna criatura solo puede alejarse nadando del remolino si primero usa una acción para apartarse y supera una prueba de Fuerza (Atletismo) contra tu CD de salvación de conjuros.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CONTROLAR EL CLIMA",
    "level": 8,
    "school": "Transmutación",
    "classes": [
      "clerigo",
      "druida",
      "mago"
    ],
    "casting_time": "10 minutos",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "incienso para quemar"
    },
    "duration": "hasta 8 horas",
    "ritual": false,
    "concentration": true,
    "description": "Hasta que termine el conjuro, asumes el control del clima a 5 millas o menos de ti. Debes estar al aire libre para lanzar este conjuro y terminará antes de tiempo si entras en una zona cubierta. Cuando lanzas el conjuro, cambias las condiciones climatológicas actuales, que determinará tu DM.\n\nPuedes cambiar las precipitaciones, la temperatura y el viento. Se tardan 1d4 x 10 minutos en que las nuevas condiciones surtan efecto. En cuanto lo hagan, puedes volver a cambiarlas.\n\nCuando el conjuro termine, el clima volverá poco a poco a su estado normal. Cuando cambies las condiciones meteorológicas, busca un estado en las tablas siguientes y modifica su nivel en uno, arriba o abajo. Si cambias el viento, también puedes alterar su dirección.",
    "tables": [
      {
        "title": "Precipitaciones",
        "columns": [
          "Nivel",
          "Estado"
        ],
        "rows": [
          [
            "1",
            "Despejado"
          ],
          [
            "2",
            "Nubes escasas"
          ],
          [
            "3",
            "Cielo cubierto o niebla de superficie"
          ],
          [
            "4",
            "Lluvia, granizo o nieve"
          ],
          [
            "5",
            "Lluvia torrencial, tormenta de granizo o ventisca"
          ]
        ]
      },
      {
        "title": "Temperatura",
        "columns": [
          "Nivel",
          "Estado"
        ],
        "rows": [
          [
            "1",
            "Ola de calor"
          ],
          [
            "2",
            "Caliente"
          ],
          [
            "3",
            "Templado"
          ],
          [
            "4",
            "Fresco"
          ],
          [
            "5",
            "Frío"
          ],
          [
            "6",
            "Frío extremo"
          ]
        ]
      },
      {
        "title": "Viento",
        "columns": [
          "Nivel",
          "Estado"
        ],
        "rows": [
          [
            "1",
            "Calmo"
          ],
          [
            "2",
            "Viento moderado"
          ],
          [
            "3",
            "Viento fuerte"
          ],
          [
            "4",
            "Galerna"
          ],
          [
            "5",
            "Tempestad"
          ]
        ]
      }
    ],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CORCEL FANTASMA",
    "level": 3,
    "school": "Ilusionismo",
    "classes": [
      "mago"
    ],
    "casting_time": "1 minuto o un ritual",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "1 hora",
    "ritual": true,
    "concentration": false,
    "description": "Una criatura equina cuasi real de tamaño Grande aparece en un espacio sin ocupar de tu elección dentro del alcance. Tú decides su aspecto y estará equipada con una silla, bocado y bridas. Cualquier equipo creado por el conjuro se desvanecerá en una bocanada de humo si se lleva a más de 10 pies de la montura.\n\nHasta que termine el conjuro, tú o una criatura de tu elección podéis montar el corcel. El corcel utiliza el perfil del caballo de monta (consulta el apéndice B), excepto que tiene una velocidad de 100 pies y puede desplazarse a 13 millas por hora. Cuando el conjuro termina, el corcel se desvanece gradualmente, lo que da al jinete 1 minuto para desmontar.\n\nEl conjuro termina antes si el corcel recibe daño.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CORDÓN DE FLECHAS",
    "level": 2,
    "school": "Transmutación",
    "classes": [
      "explorador"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una trenza ornamental"
    },
    "duration": "8 horas",
    "ritual": false,
    "concentration": false,
    "description": "Tocas hasta cuatro flechas o virotes no mágicos y los clavas en el suelo dentro de tu espacio. Hasta que el conjuro termine, la munición no podrá extraerse por la fuerza, y siempre que una criatura que no seas tú entre en un espacio a 30 pies o menos de la munición por primera vez en un turno o termine su turno allí, uno de los proyectiles saldrá volando para atacarla. La criatura deberá superar una tirada de salvación de Destreza o sufrirá 2d4 de daño perforante.\n\nA continuación, el proyectil se destruye. El conjuro termina cuando no quede munición clavada en el suelo. Cuando lanzas este conjuro, puedes designar criaturas de tu elección para que el conjuro las ignore.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CORONA DE LA LOCURA",
    "level": 2,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Una criatura que puedas ver dentro del alcance deberá superar una tirada de salvación de Sabiduría o tendrá el estado de hechizada hasta que termine el conjuro. Si no es humanoide, la criatura tiene éxito automáticamente. Una corona espectral aparece sobre la cabeza del objetivo hechizado, que debe usar su acción antes de moverse cada turno para realizar un ataque cuerpo a cuerpo contra una criatura que elijas mentalmente y que no sea él mismo. El objetivo puede actuar con normalidad en su turno si no eliges ninguna criatura o no tiene ninguna a su alcance. El objetivo repetirá la tirada de salvación al final de cada uno de sus turnos y, si tiene éxito, se librará del conjuro. En tus siguientes turnos, debes realizar la acción de magia para mantener el control sobre el objetivo o el conjuro terminará.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CREACIÓN",
    "level": 5,
    "school": "Ilusionismo",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "1 minuto",
    "range": "30 pies / 5 pies de cubo",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un pincel"
    },
    "duration": "Especial",
    "ritual": false,
    "concentration": false,
    "description": "Extraes hebras de material sombrío del Shadowfell para crear dentro del alcance un objeto no vivo y no mágico. El objeto no puede medir más de 5 pies de lado y su forma debe ser una que hayas visto antes. El material del objeto y la duración de este se determinan según la tabla.",
    "tables": [
      {
        "title": "Materiales",
        "columns": [
          "Material",
          "Duración"
        ],
        "rows": [
          [
            "Materia vegetal",
            "24 horas"
          ],
          [
            "Piedra o cristal",
            "12 horas"
          ],
          [
            "Metales preciosos",
            "1 hora"
          ],
          [
            "Gemas",
            "10 minutos"
          ]
        ]
      }
    ],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El tamaño del cubo aumenta en 5 pies por cada nivel por encima de 5 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "cube",
      "sizeFt": 5
    }
  },
  {
    "name": "CREAR COMIDA Y AGUA",
    "level": 3,
    "school": "Conjuración",
    "classes": [
      "clerigo",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Creas 45 libras de comida y 30 galones de agua potable en el suelo o en recipientes dentro del alcance, ideales para evitar los peligros de la desnutrición y la deshidratación. La comida es sosa pero nutritiva y tiene el aspecto de una comida de tu elección, mientras que el agua está limpia. La comida se estropea si no se consume en 24 horas.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CREAR LLAMA",
    "level": 0,
    "school": "Conjuración",
    "classes": [
      "druida"
    ],
    "casting_time": "Acción adicional",
    "range": "Personal / 20 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "10 minutos",
    "ritual": false,
    "concentration": false,
    "description": "En tu mano aparece una llama titilante, que permanece hasta que termine el conjuro. En tu mano, la llama no genera calor, no puede quemar nada y emite una luz brillante en un radio de 20 pies y luz tenue 20 pies más allá. El conjuro termina si lo vuelves a lanzar. Hasta que el conjuro termine, puedes usar una acción de magia para arrojar la llama a una criatura u objeto a 60 pies o menos de ti. Haz un ataque de conjuro a distancia. Si acierta, el objetivo recibe 1d8 de daño de fuego.",
    "tables": [],
    "sections": [
      {
        "title": "Mejora de truco",
        "text": "El daño aumenta en 1d8 cuando alcanzas los niveles 5 (2d8), 11 (3d8) y 17 (4d8)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 20,
      "measure": "radius"
    }
  },
  {
    "name": "CREAR MUERTO VIVIENTE",
    "level": 6,
    "school": "Nigromancia",
    "classes": [
      "brujo",
      "clerigo",
      "mago"
    ],
    "casting_time": "1 minuto",
    "range": "10 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un ónice negro que valga al menos 150 po por cada cadáver"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Solo puedes lanzar este conjuro por la noche. Elige hasta tres cadáveres de humanoides de tamaño Mediano o Pequeño dentro del alcance.\n\nCada uno se convierte en un gul bajo tu control (consulta su perfil en el Manual de monstruos).\n\nComo acción adicional en cada uno de tus turnos, puedes dar órdenes mentalmente a cada criatura que hayas animado con el conjuro que esté a 120 pies o menos de ti (si controlas a varias criaturas, puedes dar órdenes a cualesquiera de ellas a la vez transmitiéndole la misma orden a cada una).\n\nTú decides qué acción llevará a cabo la criatura y adónde se moverá en su siguiente turno, o puedes dar una orden general, como proteger un lugar en concreto. Si no das ninguna orden, la criatura hace la acción de esquivar y solo se mueve para evitar peligros. En cuanto se le dé una orden, la criatura la cumplirá hasta completar su tarea.\n\nLa criatura estará bajo tu control durante 24 horas, tras las cuales dejará de obedecer cualquier orden que le hayas dado. Para mantener el control sobre ella otras 24 horas, deberás volver a lanzarle este conjuro antes de que acabe el periodo actual de 24 horas. Este uso del conjuro refuerza tu control sobre hasta tres criaturas que hayas animado con él y no anima nuevas criaturas.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CREAR O DESTRUIR AGUA",
    "level": 1,
    "school": "Transmutación",
    "classes": [
      "clerigo",
      "druida"
    ],
    "casting_time": "Acción",
    "range": "30 pies / 30 pies de cubo",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una mezcla de agua y arena"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Elige uno de los siguientes efectos:\n\n• **Crear agua.** Creas hasta 10 galones de agua limpia dentro del alcance en un recipiente abierto. Como alternativa, el agua cae en forma de lluvia dentro de un cubo de 30 pies de lado dentro del alcance, apagando las llamas desprotegidas en el área.\n\n• **Destruir agua.** Destruyes hasta 10 galones de agua dentro del alcance en un recipiente abierto. Como alternativa, puedes destruir la niebla en un cubo de 30 pies de lado dentro del alcance.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Creas o destruyes 10 galones más de agua o el tamaño del cubo aumenta en 5 pies por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "cube",
      "sizeFt": 30
    }
  },
  {
    "name": "CRECIMIENTO ESPINOSO",
    "level": 2,
    "school": "Transmutación",
    "classes": [
      "druida",
      "explorador"
    ],
    "casting_time": "Acción",
    "range": "150 pies / 20 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "siete espinas"
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Del suelo en una esfera de 20 pies de radio centrada en un punto dentro del alcance brotan espinas y pinchos. La zona se vuelve terreno difícil hasta que termine el conjuro. Cuando una criatura entra en la zona o se desplaza por ella, recibe 2d4 de daño perforante por cada 5 pies que avanza. La transformación del suelo se camufla, de forma que parece natural. Cualquier criatura que no pueda ver la zona cuando se lanza el conjuro deberá emplear una acción de buscar y superar una prueba de Sabiduría (Percepción o Supervivencia) contra tu CD de salvación de conjuros para reconocer que el terreno es peligroso antes de adentrarse en él.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 20,
      "measure": "radius"
    }
  },
  {
    "name": "CRECIMIENTO VEGETAL",
    "level": 3,
    "school": "Transmutación",
    "classes": [
      "bardo",
      "druida",
      "explorador"
    ],
    "casting_time": "Acción (sobrecrecimiento)",
    "range": "150 pies / 100 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Este conjuro infunde vitalidad en las plantas. El tiempo de lanzamiento que uses determina si el conjuro tiene un efecto de sobrecrecimiento o de enriquecimiento, descritos a continuación.\n\n• Sobrecrecimiento. Elige un punto dentro del alcance. Todas las plantas en una esfera de 100 pies de radio centrada en ese punto se volverán gruesas y frondosas. Una criatura que atraviese esa área deberá gastar 4 pies de movimiento por cada 1 pie que se mueva. Puedes excluir una o más zonas de cualquier tamaño dentro del área del conjuro para que no se vean afectadas.\n\n• Fertilización. Todas las plantas en un radio de 2460 pies centrado en un punto dentro del alcance estarán fertilizadas durante 365 días y producirán el doble de comida al recolectarlas. Solo podrán beneficiarse de un crecimiento vegetal cada año.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 100,
      "measure": "radius"
    }
  },
  {
    "name": "CUCHILLO DE HIELO",
    "level": 1,
    "school": "Conjuración",
    "classes": [
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": false,
      "s": true,
      "m": true,
      "material": "una gota de agua o un trozo de hielo"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Creas una esquirla de hielo y se la lanzas a una criatura dentro del alcance. Haz un ataque de conjuro a distancia contra el objetivo. Si acierta, el objetivo recibe 1d10 de daño perforante. Acierte o falle, el fragmento explotará. El objetivo y todas las criaturas a 5 pies menos de él deberán superar una tirada de salvación de Destreza orecibirán 2d6 de daño de frío.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño de frío aumenta en 1d6 por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CURAR",
    "level": 6,
    "school": "Abjuración",
    "classes": [
      "clerigo",
      "druida"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Elige a una criatura que puedas ver dentro del alcance. Una energía positiva la recorre y hace que recupere 70 puntos de golpe. El conjuro también elimina los estados de cegado, ensordecido y envenenado del objetivo.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "La curación aumenta en 10 por cada nivel por encima de 6 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CURAR EN MASA",
    "level": 9,
    "school": "Abjuración",
    "classes": [
      "clerigo"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "De ti brota una oleada de energía curativa que envuelve a las criaturas que te rodean. Haces recuperar hasta 700 puntos de golpe, repartidos como tú escojas entre cualquier cantidad de criaturas que puedas ver dentro del alcance. Las criaturas sanadas con este conjuro también se libran de los estados de cegadas, ensordecidas y envenenadas.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CURAR HERIDAS",
    "level": 1,
    "school": "Abjuración",
    "classes": [
      "bardo",
      "clerigo",
      "druida",
      "paladin",
      "explorador"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Una criatura a la que toques recupera una cantidad de puntos de golpe igual a 2d8 más tu modificador por aptitud mágica.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "La curación aumenta en 2d8 por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CURAR HERIDAS EN MASA",
    "level": 5,
    "school": "Abjuración",
    "classes": [
      "bardo",
      "clerigo",
      "druida"
    ],
    "casting_time": "Acción",
    "range": "60 pies / 30 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Una ola de energía curativa brota de un punto que puedas ver dentro del alcance. Elige a hasta seis criaturas en una esfera de 30 pies de radio centrada en ese punto. Cada objetivo recupera una cantidad de puntos de golpe igual a 5d8 más tu modificador por aptitud mágica.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "La curación aumenta en 1d8 por cada nivel por encima de 5 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 30,
      "measure": "radius"
    }
  },
  {
    "name": "CÍRCULO DE MUERTE",
    "level": 6,
    "school": "Nigromancia",
    "classes": [
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "150 pies / 60 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una perla negra pulverizada que valga al menos 500 po"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Una energía negativa se propaga en un radio de 60 pies desde un punto que elijas dentro del alcance. Todas las criaturas situadas en la zona realizan una tirada de salvación de Constitución; sufrirán 8d8 de daño necrótico si la fallan o la mitad del daño si la superan.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 2d8 por cada nivel por encima de 6 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 60,
      "measure": "radius"
    }
  },
  {
    "name": "CÍRCULO DE PODER",
    "level": 5,
    "school": "Abjuración",
    "classes": [
      "clerigo",
      "mago",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "Personal / 30 pies de emanación",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Un aura surge de ti en una emanación de 30 pies hasta que el conjuro termine. Mientras permanezcáis dentro, tus aliados y tú tendréis ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos.\n\nCuando una criatura afectada realice una tirada de salvación contra un conjuro o un efecto mágico que le permita hacer una tirada de salvación para recibir solo la mitad del daño, no sufrirá daño si la supera.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 30,
      "measure": "radius"
    }
  },
  {
    "name": "CÍRCULO DE TELETRANSPORTACIÓN",
    "level": 5,
    "school": "Conjuración",
    "classes": [
      "bardo",
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "1 minuto",
    "range": "10 pies",
    "components": {
      "v": true,
      "s": false,
      "m": true,
      "material": "tintas inusuales que valgan al menos 50 po, que se consumen como parte del conjuro"
    },
    "duration": "1 asalto",
    "ritual": false,
    "concentration": false,
    "description": "Mientras lanzas el conjuro, trazas en el suelo un círculo de 5 pies de radio en el cual inscribes sellos que vinculan tu ubicación con un círculo de teletransportación permanente de tu elección cuya secuencia de sellos conozcas y que esté en el mismo plano de existencia que tú. En el círculo dibujado aparecerá un portal brillante que permanecerá abierto hasta el final de tu siguiente turno.\n\nCualquier criatura que entre en el portal aparecerá instantáneamente a 5 pies o menos del círculo de destino o en el espacio sin ocupar más cercano si ese está ocupado. Muchos grandes templos y casas gremiales, así como otros lugares importantes, cuentan con círculos de teletransportación permanentes. Cada uno incluye una secuencia de sellos única, una serie de runas dispuestas con un patrón concreto.\n\nLa primera vez que obtienes la capacidad de lanzar este conjuro, aprendes las secuencias de sellos de dos destinos en el Plano Material a elección de tu DM. Durante tus aventuras, es posible que aprendas más secuencias de sellos. Puedes memorizar una nueva secuencia de sellos si la estudias durante 1 minuto.\n\nSi lanzas este conjuro a diario en el mismo lugar durante 365 días, puedes crear un círculo de teletransportación permanente.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "CÍRCULO MÁGICO",
    "level": 3,
    "school": "Abjuración",
    "classes": [
      "brujo",
      "clerigo",
      "mago",
      "paladin"
    ],
    "casting_time": "1 minuto",
    "range": "10 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "sal y plata en polvo que valga al menos 100 po, que se consumen como parte del conjuro"
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Creas un cilindro de energía mágica de 10 pies de radio y 20 pies de altura centrado en un punto del suelo que puedas ver dentro del alcance. En los puntos de intersección entre el cilindro y el suelo o cualquier otra superficie aparecerán unas runas brillantes.\n\nElige uno o más de los siguientes tipos de criaturas: celestiales, elementales, feéricos, infernales o muertos vivientes. El círculo afecta a una criatura del tipo elegido de las siguientes formas:\n\n• La criatura no puede entrar voluntariamente en el cilindro por medios no mágicos. Si la criatura intenta usar el teletransporte o el viaje interplanar para hacerlo, antes deberá superar una tirada de salvación de Carisma.\n\n• La criatura tiene desventaja en las tiradas de ataque contra objetivos que estén dentro del cilindro.\n\n• Los objetivos dentro del cilindro no pueden ser poseídos por la criatura ni obtener los estados de asustados o hechizados a causa de ella. Cada vez que lances este conjuro, puedes hacer que su magia funcione en sentido inverso para impedir que una criatura del tipo especificado salga del cilindro y proteger así a los objetivos que estén fuera de él.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "La duración aumenta en 1 hora por cada nivel por encima de 3 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DAÑAR",
    "level": 6,
    "school": "Nigromancia",
    "classes": [
      "clerigo"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Desatas una magia virulenta sobre una criatura que puedas ver dentro del alcance. El objetivo hace una tirada de salvación de Constitución. Si la falla, sufre 14d6 de daño necrótico y sus puntos de golpe máximos se reducen en una cantidad igual al daño necrótico recibido. Si la supera, recibirá solo la mitad de daño. Este conjuro no puede reducir los puntos de golpe máximos del objetivo a menos de 1.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DE LA CARNE A LA PIEDRA",
    "level": 6,
    "school": "Transmutación",
    "classes": [
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una pluma de cocatriz"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Intentas convertir en piedra a una criatura que puedas ver dentro del alcance. El objetivo hace una tirada de salvación de Constitución. Si la falla, tendrá el estado de apresado hasta que el conjuro termine. Si la supera, su velocidad será 0 hasta el principio de tu siguiente turno. Los autómatas superan automáticamente la tirada de salvación. Un objetivo apresado realiza otra tirada de salvación de Constitución al final de cada uno de sus turnos. Si la supera tres veces, el conjuro termina. Si la falla tres veces, se convierte en piedra y sufre el estado de petrificada hasta que termine el conjuro. Los éxitos y los fallos no tienen por qué ser consecutivos: lleva la cuenta de ambos hasta que el objetivo tenga tres de un mismo tipo. Si mantienes la concentración en este conjuro durante toda su duración posible, el objetivo tendrá el estado de petrificado hasta que un conjuro restablecimiento mayor u otro efecto mágico similar le ponga fin.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DEDO DE LA MUERTE",
    "level": 7,
    "school": "Nigromancia",
    "classes": [
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Desatas una energía negativa hacia una criatura que puedas ver dentro del alcance. El objetivo hace una tirada de salvación de Constitución; sufrirá 7d8 + 30 de daño necrótico si la falla o la mitad del daño si la supera. Si un humanoide muere a causa de este conjuro, se alzará al principio de tu siguiente turno como un zombi (consulta el apéndice B) y seguirá tus órdenes verbales.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DESCARGA CONVERGENTE",
    "level": 0,
    "school": "Evocación",
    "classes": [
      "artifice",
      "bardo",
      "brujo",
      "clerigo",
      "druida",
      "explorador",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies / 20 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Lanzas un rayo de energía arcana a una criatura u objeto dentro del alcance. Haz un ataque de conjuro a distancia contra el objetivo. Si acierta, el objetivo recibe 1d8 de daño arcano. Si impacta, lanza 1d20, si el resultado es 19 o 20, se produce el efecto Convergencia arcana, desde el objetivo hasta un radio de 20 pies todas las criaturas son golpeadas recibiendo 1d8 de daño arcano.",
    "tables": [],
    "sections": [
      {
        "title": "Mejora de truco",
        "text": "El daño del conjuro aumenta en 1d8 cuando alcanzas el nivel 5 (2d8), el nivel 11 (3d8) y el nivel 17 (4d8)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 20,
      "measure": "radius"
    }
  },
  {
    "name": "DESCARGA DE CAOS",
    "level": 0,
    "school": "Nigromancia",
    "classes": [
      "segador"
    ],
    "casting_time": "Acción de magia",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Canalizas el poder de la entidad atrapada en tu interior en forma de energía destructiva. Realizas un ataque de conjuro contra una criatura que puedas ver dentro del alcance. Si impactas, el objetivo recibe 1d10 de daño necrótico.",
    "tables": [],
    "sections": [
      {
        "title": "Mejora de truco",
        "text": "El daño aumenta en 1d10 al nivel 5 (2d10), nivel 11 (3d10) y nivel 17 (4d10)."
      }
    ],
    "source": "Homebrew"
  },
  {
    "name": "DESCARGA DE FUEGO",
    "level": 0,
    "school": "Evocación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Arrojas una mota de fuego a una criatura u objeto dentro del alcance. Haz un ataque de conjuro a distancia contra el objetivo. Si acierta, el objetivo recibe 1d10 de daño de fuego. Los objetos inflamables a los que acierte el conjuro empezarán a arder si nadie los lleva o viste.",
    "tables": [],
    "sections": [
      {
        "title": "Mejora de truco",
        "text": "El daño aumenta en 1d10 cuando alcanzas los niveles 5 (2d10), 11 (3d10) y 17 (4d10)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DESCARGA SOBRENATURAL",
    "level": 0,
    "school": "Evocación",
    "classes": [
      "brujo"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Lanzas un rayo de energía chisporroteante. Haz un ataque de conjuro a distancia contra una criatura u objeto dentro del alcance. Si acierta, el objetivo recibe 1d10 de daño de fuerza.",
    "tables": [],
    "sections": [
      {
        "title": "Mejora de truco",
        "text": "El conjuro crea dos rayos a nivel 5, tres rayos a nivel 11 y cuatro rayos a nivel 17. Puedes dirigir los rayos al mismo objetivo o a objetivos distintos. Realiza una tirada de ataque por separado para cada rayo."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DESEO",
    "level": 9,
    "school": "Conjuración",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Deseo es el conjuro más poderoso que puede lanzar un mortal. Solo con decirlo en voz alta, puedes alterar la propia realidad.\n\nEl uso básico de este conjuro es duplicar cualquier otro conjuro de nivel 8 o inferior. Si lo usas de esta forma, no necesitas cumplir ningún requisito de dicho conjuro, incluido cualquier componente costoso. El conjuro simplemente surte efecto.\n\nComo alternativa, puedes crear uno de los siguientes efectos a tu elección:\n\n• **Creación de objetos.** Creas un objeto con un valor de hasta 25 000 po que no sea un objeto mágico. El objeto no puede medir más de 300 pies en cualquier dimensión y aparece en un espacio sin ocupar que puedas ver sobre el suelo.\n\n• **Curación instantánea.** Permites que hasta veinte criaturas que puedas ver, incluido tú, recuperen todos sus puntos de golpe y pones fin a todos los efectos que las afecten descritos en el conjuro *restablecimiento mayor*.\n\n• **Resistencia.** Concedes resistencia permanente a un tipo de daño de tu elección a hasta diez criaturas que puedas ver.\n\n• **Inmunidad a conjuros.** Concedes inmunidad a un único conjuro u otro efecto mágico durante 8 horas a hasta diez criaturas que puedas ver.\n\n• **Aprendizaje repentino.** Sustituyes una de tus dotes por otra para la que cumplas los requisitos. Pierdes todos los beneficios de la dote anterior y obtienes los de la nueva. No puedes sustituir una dote que funcione como requisito para cualquiera de tus otras dotes o rasgos.\n\n• **Rehacer tiradas.** Deshaces un solo suceso reciente obligando a repetir cualquier tirada realizada durante el último asalto (incluido tu último turno). La realidad se reconforma para amoldarse al nuevo resultado. Puedes hacer que la tirada se repita con ventaja o desventaja y elegir si se usa el nuevo resultado o el original.\n\n• **Remodelar la realidad.** Puedes desear algo que no se incluya entre los efectos anteriores. Explica tu deseo de la forma más precisa posible al DM, quien decide el resultado. Cuanto mayor sea el deseo, más probable es que algo vaya mal: el conjuro podría fallar, el efecto podría lograrse solo parcialmente o podrías sufrir consecuencias imprevisibles. Si el deseo afecta a comunidades, regiones, dioses o al propio multiverso, puede provocar reacciones inmediatas o fallar por completo.\n\n**Tensión de deseo.** La tensión de lanzar deseo para producir cualquier efecto que no sea duplicar otro conjuro te debilita. Tras soportar dicha tensión, cada vez que lances un conjuro antes de finalizar un descanso largo, recibes 1d10 de daño necrótico por cada nivel del conjuro, daño que no se puede reducir ni prevenir. Además, tu Fuerza se convierte en 3 durante 2d4 días. Por cada día que pases descansando y realizando solo actividades ligeras, el tiempo restante se reduce en 2 días. Por último, existe un 33 % de probabilidad de que no puedas volver a lanzar deseo nunca más.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DESINTEGRAR",
    "level": 6,
    "school": "Transmutación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies / 10 pies de cubo",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un imán natural y polvo"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Lanzas un rayo verde hacia un objetivo que puedas ver dentro del alcance. El objetivo puede ser una criatura, un objeto no mágico o una creación de fuerza mágica, como una pared creada por muro de fuerza. Una criatura que sea objetivo de este conjuro deberá hacer una tirada de salvación de Destreza. Si la falla, recibirá 10d6 + 40 de daño de fuerza. Si este daño reduce sus puntos de golpe a 0, la criatura y todos los objetos no mágicos que vista o lleve quedarán reducidos a un polvo gris. La criatura solo puede ser devuelta a la vida mediante un conjuro deseo o resurrección verdadera. Este conjuro desintegra automáticamente cualquier objeto no mágico de tamaño Grande o más pequeño o cualquier creación de fuerza mágica. Si el objetivo es Enorme o mayor, el conjuro desintegrará una parte de él con forma de cubo de 10 pies de lado.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 3d6 por cada nivel por encima de 6 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "cube",
      "sizeFt": 10
    }
  },
  {
    "name": "DESPERTAR",
    "level": 5,
    "school": "Transmutación",
    "classes": [
      "bardo",
      "druida"
    ],
    "casting_time": "8 horas",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un ágata que valga al menos 1000 po y que se consume como parte del conjuro"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Dedicas el tiempo de lanzamiento a trazar surcos mágicos dentro de una piedra preciosa y luego tocas al objetivo, que debe ser una criatura de tipo \"bestia\" o \"planta\" con una puntuación de Inteligencia de 3 o menos o una planta natural que no sea una criatura. El objetivo obtiene una Inteligencia de 10 y la capacidad de hablar un idioma que conoces.\n\nSi el objetivo es una planta natural, se convierte en una criatura de tipo \"planta\" y obtiene la capacidad de mover sus miembros, raíces, ramas, enredaderas, etc., así como unos sentidos similares a los de una persona. Tu DM elegirá el perfil adecuado para la planta despertada, por ejemplo el del arbusto despertado o el del árbol despertado del Manual de monstruos.\n\nEl objetivo despertado tiene el estado de hechizado durante 30 días o hasta que tú o tus aliados le causéis daño. Cuando termine el estado, la criatura despertada decidirá su actitud hacia ti.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DESPLAZAMIENTO",
    "level": 3,
    "school": "Transmutación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "1 minuto",
    "ritual": false,
    "concentration": false,
    "description": "Tira 1d6 al final de cada uno de tus turnos hasta que el conjuro termine. Si el resultado es 4-6, desapareces de tu plano de existencia actual y apareces en el Plano Etéreo (el conjuro termina al instante si ya estabas en ese plano).\n\nMientras estás en el Plano Etéreo, puedes percibir lo que sucede en el plano del que procedes, que se muestra en distintos tonos de gris, pero no puedes ver nada que esté a más de 60 pies. Solo puedes afectar a criaturas que estén en el Plano Etéreo y solo estas criaturas te pueden afectar a ti.\n\nLas criaturas que estén en el otro plano no pueden percibirte en el Plano Etéreo a menos que tengan una capacidad especial que les permita percibir cosas en el Plano Etéreo.\n\nAl principio de tu siguiente turno, y si el conjuro acaba mientras estás en el Plano Etéreo, volverás al otro plano y aparecerás en un espacio sin ocupar de tu elección que puedas ver a 10 pies o menos del espacio que hayas abandonado.\n\nSi no hay ningún espacio sin ocupar en ese alcance, aparecerás en el espacio sin ocupar más cercano.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DESPLAZAMIENTO ENTRE PLANOS",
    "level": 7,
    "school": "Conjuración",
    "classes": [
      "brujo",
      "clerigo",
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una vara de metal con forma de horquilla que valga al menos 250 po y esté sintonizada con un plano de existencia"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Tú y hasta ocho criaturas voluntarias que unan sus manos formando un círculo sois transportadas a un plano de existencia distinto. Puedes especificar un destino en términos generales, como la Ciudad de Oropel en el Plano Elemental del Fuego o el palacio de Dispater en el segundo nivel de los Nueve Infiernos, y apareceréis en ese destino o cerca de él, según decida tu DM.\n\nComo alternativa, si conoces la secuencia de sellos de un círculo de teletransportación en otro plano de existencia, este conjuro puede llevarte hasta dicho círculo. Si el círculo de teletransportación es demasiado pequeño como para que quepan todas las criaturas que has transportado, aparecerán en los espacios sin ocupar más cercanos a él.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DESTELLO DE FUEGO DE HECHICERÍA",
    "level": 1,
    "school": "Evocación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantánea",
    "ritual": false,
    "concentration": false,
    "description": "Liberas una explosión de fuego brillante. Realiza un ataque de conjuro a distancia contra una criatura dentro del alcance. Impacto: el objetivo recibe 2d10 de daño radiante. Para esta tirada de ataque, el objetivo no obtiene beneficio por Cobertura Media ni por Cobertura Tres Cuartos.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DESTIERRO",
    "level": 4,
    "school": "Abjuración",
    "classes": [
      "brujo",
      "clerigo",
      "hechicero",
      "mago",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un pentáculo"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Una criatura que puedas ver dentro del alcance deberá superar una tirada de salvación de Carisma o se teletransportará a un semiplano inofensivo hasta que termine el conjuro. Mientras permanezca allí, tendrá el estado de incapacitada.\n\nCuando el conjuro termine, el objetivo reaparecerá en el espacio que abandonó o en el espacio sin ocupar más cercano si dicho espacio está ocupado. Si el conjuro dura 1 minuto y el objetivo es una aberración, un celestial, un elemental, un feérico o un infernal, no regresará. En vez de ello, se teletransportará a un lugar aleatorio de un plano (a elección de tu DM) relacionado con su tipo de criatura.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Puedes hacer objetivo a una criatura adicional por cada nivel por encima de 4 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DETECTAR EL BIEN Y EL MAL",
    "level": 1,
    "school": "Adivinación",
    "classes": [
      "clerigo",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Hasta que el conjuro termine, percibes la ubicación de cualquier aberración, celestial, elemental, feérico, infernal o muerto viviente a 30 pies o menos de ti. También percibes si hay un conjuro consagrar activo en el espacio y su ubicación. El conjuro no puede atravesar 1 pie de piedra, tierra o madera, 1 pulgada de metal o una lámina fina de plomo.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DETECTAR MAGIA",
    "level": 1,
    "school": "Adivinación",
    "classes": [
      "bardo",
      "clerigo",
      "druida",
      "paladin",
      "explorador",
      "hechicero",
      "brujo",
      "mago"
    ],
    "casting_time": "Acción o ritual",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 10 minutos",
    "ritual": true,
    "concentration": true,
    "description": "Hasta que el conjuro termine, podrás percibir la presencia de efectos mágicos a 30 pies o menos de ti. Si percibes alguno, puedes usar una acción de magia para ver una débil aura alrededor de cualquier objeto o criatura visible dentro de la zona que esté afectada por la magia y, si el efecto lo creó un conjuro, distingues a qué escuela mágica pertenece.\n\nEl conjuro no puede atravesar 1 pie de piedra, tierra o madera, 1 pulgada de metal o una lámina fina de plomo.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DETECTAR PENSAMIENTOS",
    "level": 2,
    "school": "Adivinación",
    "classes": [
      "bardo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "1 pieza de cobre"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Activas uno de los siguientes efectos. Hasta que el conjuro termine, puedes activar cualquiera de ellos como acción de magia en tus siguientes turnos.\n\n• **Sentir pensamientos.**\nPercibes la presencia de pensamientos que pertenecen a criaturas que conozcan idiomas o sean telepáticas a 30 pies o menos de ti. No lees sus pensamientos, pero sabes que hay una criatura pensante cerca.\n\nEl conjuro no puede atravesar 1 pie de piedra, tierra o madera, 1 pulgada de metal o una lámina fina de plomo.\n\n• **Leer pensamientos.**\nHaces objetivo a una criatura que puedas ver a 30 pies o menos de ti o a una criatura a 30 pies o menos de ti que hayas detectado con la opción de sentir pensamientos, y averiguas lo principal que ocupa su mente en ese momento. Si el objetivo no conoce ningún idioma o no es telepático, no descubres nada.\n\nComo acción de magia en tu próximo turno, puedes intentar sondear en profundidad su mente. Si lo haces, el objetivo deberá hacer una tirada de salvación de Sabiduría. Si falla, descubrirás su forma de razonar, sus emociones y algo que sea de gran importancia en su mente, como una preocupación o algo que ame u odie. Si la supera, el conjuro terminará.\n\nDe cualquier forma, el objetivo sabrá que estás sondeando su mente y, a menos que desplaces tu atención, podrá usar una acción en su turno para hacer una prueba de Inteligencia (Conocimiento arcano) contra tu CD de salvación de conjuros. Si la supera, el conjuro terminará.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DETECTAR TRAMPAS",
    "level": 2,
    "school": "Adivinación",
    "classes": [
      "clerigo",
      "druida",
      "explorador"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Detectas cualquier trampa dentro del alcance que esté en tu línea de visión. En lo que a este conjuro respecta, una trampa incluye cualquier objeto o mecanismo que fuese creado para causar un daño u otro peligro. Por tanto, el conjuro detectaría los conjuros alarma y glifo custodio o una trampa de pozo mecánica, pero no revelaría una debilidad natural del suelo, un techo inestable o un socavón oculto.\n\nEste conjuro alerta de la existencia de una trampa, pero no te indica su ubicación. Aun así, descubres la naturaleza general del peligro que supone una trampa que detectas.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Puedes hacer objetivo a una criatura adicional por cada nivel por encima de 4 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DETECTAR VENENOS Y ENFERMEDADES",
    "level": 1,
    "school": "Adivinación",
    "classes": [
      "clerigo",
      "druida",
      "explorador",
      "paladin"
    ],
    "casting_time": "Acción o ritual",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una hoja de tejo"
    },
    "duration": "hasta 10 minutos",
    "ritual": true,
    "concentration": true,
    "description": "Hasta que el conjuro termine, percibes la ubicación de venenos, criaturas venenosas y enfermedades mágicas a 30 pies o menos de ti, e identificas el tipo de veneno, criatura o enfermedad en cada caso. El conjuro no puede atravesar 1 pie de piedra, tierra o madera, 1 pulgada de metal o una lámina fina de plomo.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DISCO FLOTANTE DE TENSER",
    "level": 1,
    "school": "Conjuración",
    "classes": [
      "mago"
    ],
    "casting_time": "Acción o ritual",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una gota de mercurio"
    },
    "duration": "1 hora",
    "ritual": true,
    "concentration": false,
    "description": "Este conjuro crea un plano de fuerza horizontal de 3 pies de diámetro y 1 pulgada de grosor que flota 3 pies por encima del suelo en un espacio sin ocupar de tu elección que puedas ver dentro del alcance. El disco dura hasta que termina el conjuro y puede soportar un peso de hasta 500 libras. Si se pone más peso sobre él, el conjuro termina y todo lo que hay en el disco cae al suelo.\n\nEl disco permanecerá inmóvil mientras estés a 20 pies o menos de él. Si te alejas a más de 20 pies de él, te seguirá para mantenerse a 20 pies de ti. Se puede mover por terreno irregular y subir y bajar escaleras, pendientes y similares, pero no puede superar un cambio de elevación de 10 pies o más.\n\nPor ejemplo, el disco no puede cruzar un pozo de 10 pies de profundidad ni salir de él si se crea en el fondo de este. Si te alejas más de 100 pies del disco (normalmente, porque no pueda superar un obstáculo para seguirte), el conjuro termina.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DISFRAZARSE",
    "level": 1,
    "school": "Ilusionismo",
    "classes": [
      "bardo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Haces que tu aspecto (incluyendo tu vestimenta, armadura, armas y otras posesiones que lleves contigo) parezca diferente hasta que el conjuro termine. Puedes aparentar tener una altura 1 pie mayor o menor y una complexión más pesada o ligera. Debes adoptar una forma que tenga la misma configuración de miembros que tú.\n\nPor lo demás, la ilusión puede modificar todo lo que quieras de tu aspecto. Los cambios realizados por este conjuro pueden descubrirse mediante una inspección física. Por ejemplo, si usas este conjuro para añadir un sombrero a tu vestimenta, los objetos atravesarán el sombrero y cualquiera que lo toque no sentirá nada.\n\nPara darse cuenta de que te has disfrazado, una criatura debe emplear la acción de estudiar para inspeccionar tu apariencia y superar una prueba de Inteligencia (Investigación) contra tu CD de salvación de conjuros.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DISIPAR EL BIEN Y EL MAL",
    "level": 5,
    "school": "Abjuración",
    "classes": [
      "clerigo",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "plata y hierro en polvo"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Hasta que el conjuro termine, los celestiales, elementales, feéricos, infernales y muertos vivientes tienen desventaja en las tiradas de ataque contra ti.\n\nPuedes poner fin al conjuro antes de tiempo si utilizas una de las siguientes funciones especiales:\n\n• **Despido.** Como acción de magia, eliges como objetivo a una criatura que puedas ver a 5 pies o menos de ti y que sea de uno de los tipos anteriores. El objetivo debe superar una tirada de salvación de Carisma o es devuelto a su plano natal si no se encuentra ya en él. Si no está en su plano natal, los muertos vivientes son enviados al Páramo Sombrío, y los feéricos a los Parajes Feéricos.\n\n• **Romper encantamiento.** Como acción de magia, tocas a una criatura que esté asustada o hechizada, o que esté poseída por una o más criaturas de los tipos anteriores. El objetivo deja de estar poseído, asustado o hechizado por dichas criaturas.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DISIPAR MAGIA",
    "level": 3,
    "school": "Abjuración",
    "classes": [
      "bardo",
      "clerigo",
      "druida",
      "paladin",
      "explorador",
      "hechicero",
      "brujo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Elige una criatura, un objeto o un efecto mágico dentro del alcance. Cualquier conjuro activo de nivel 3 o inferior presente en el objetivo termina. Para cada conjuro activo de nivel 4 o superior, haz una prueba de característica usando tu aptitud mágica (CD 10 más el nivel de ese conjuro).\n\nSi superas la tirada, el conjuro termina.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Disipas automáticamente un conjuro sobre el obje tivo cuyo nivel sea menor o igual al nivel del espacio de conjuro que hayas utilizado."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DISTURBIO MENTAL",
    "level": 0,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "brujo",
      "hechicero",
      "mago",
      "segador"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Lanzas una pulsación psíquica desestabilizadora contra una criatura que puedas ver dentro del alcance. El objetivo debe superar una tirada de salvación de Constitución. Si falla, recibe 1d4 de daño psíquico. Si la criatura está concentrando en un conjuro, la siguiente tirada de salvación de Constitución que haga para mantener esa concentración antes del final de tu siguiente turno se realiza con desventaja.",
    "tables": [],
    "sections": [
      {
        "title": "Mejora de truco",
        "text": "El daño aumenta en 1d4 cuando alcanzas los niveles 5 (2d4), 11 (3d4) y 17 (4d4)."
      }
    ],
    "source": "Homebrew"
  },
  {
    "name": "DOMINAR BESTIA",
    "level": 4,
    "school": "Encantamiento",
    "classes": [
      "druida",
      "explorador",
      "hechicero"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Una bestia que puedas ver dentro del alcance deberá superar una tirada de salvación de Sabiduría o tendrá el estado de hechizada hasta que termine el conjuro. El objetivo tiene ventaja en la tirada si está luchando contra ti o tus aliados. Siempre que reciba daño, repetirá la tirada de salvación y, si tiene éxito, se librará del conjuro. Tendrás un vínculo telepático con el objetivo hechizado mientras estéis en el mismo plano de existencia. En tu turno, puedes usar este vínculo para dar órdenes al objetivo (no requiere acción), como \"ataca a esa criatura\", \"muévete hacia allí\" o \"tráeme ese objeto\". En su turno, el objetivo hace todo lo posible por obedecer. Si lleva a cabo una orden y no recibe más instrucciones de tu parte, actúa y se mueve libremente y se centra en protegerse. Puedes ordenarle al objetivo que lleve a cabo reacciones, pero para ello deberás usar tu propia reacción.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Tu concentración puede durar más con un espacio de conjuro de nivel 5 (hasta 10 minutos), 6 (hasta 1 hora) o 7 o más (hasta 8 horas)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DOMINAR MONSTRUO",
    "level": 8,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Una criatura que puedas ver dentro del alcance deberá superar una tirada de salvación de Sabiduría o tendrá el estado de hechizada hasta que termine el conjuro. El objetivo tiene ventaja en la tirada si está luchando contra ti o tus aliados. Siempre que reciba daño, repetirá la tirada de salvación y, si tiene éxito, se librará del conjuro. Tendrás un vínculo telepático con el objetivo hechizado mientras estéis en el mismo plano de existencia. En tu turno, puedes usar este vínculo para dar órdenes al objetivo (no requiere acción), como \"ataca a esa criatura\", \"muévete hacia allí\" o \"tráeme ese objeto\". En su turno, el objetivo hace todo lo posible por obedecer. Si lleva a cabo una orden y no recibe más instrucciones de tu parte, actúa y se mueve libremente y se centra en protegerse. Puedes ordenarle al objetivo que lleve a cabo reacciones, pero para ello deberás usar tu propia reacción.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Tu concentración puede durar más con un espacio de conjuro de nivel 9 (hasta 8 horas)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DOMINAR PERSONA",
    "level": 5,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": false,
      "m": true,
      "material": "un zigurat en miniatura"
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Un humanoide que puedas ver dentro del alcance deberá superar una tirada de salvación de Sabiduría o tendrá el estado de hechizado hasta que termine el conjuro. El objetivo tiene ventaja en la tirada si está luchando contra ti o tus aliados. Siempre que reciba daño, repetirá la tirada de salvación y, si tiene éxito, se librará del conjuro. Tendrás un vínculo telepático con el objetivo hechizado mientras estéis en el mismo plano de existencia. En tu turno, puedes usar este vínculo para dar órdenes al objetivo (no requiere acción), como \"ataca a esa criatura\", \"muévete hacia allí\" o \"tráeme ese objeto\". En su turno, el objetivo hace todo lo posible por obedecer. Si lleva a cabo una orden y no recibe más instrucciones de tu parte, actúa y se mueve libremente y se centra en protegerse. Puedes ordenarle al objetivo que lleve a cabo reacciones, pero para ello deberás usar tu propia reacción.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Tu concentración puede durar más con un espacio de conjuro de nivel 6 (hasta 10 minutos), 7 (hasta 1 hora) u 8 o más (hasta 8 horas)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DON DE LENGUAS",
    "level": 3,
    "school": "Adivinación",
    "classes": [
      "bardo",
      "brujo",
      "clerigo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": false,
      "m": true,
      "material": "un zigurat en miniatura"
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Este conjuro permite a la criatura que toques comprender cualquier idioma hablado que oiga o lengua de signos que vea. Asimismo, cuando el objetivo se comunica oralmente o mediante signos, cualquier criatura que conozca al menos un idioma podrá entenderlo si lo escucha hablar o lo ve signar.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DORMIR",
    "level": 1,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies / 5 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una pizca de arena o pétalos de rosa"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Todas las criaturas de tu elección en una esfera de 5 pies de radio centrada en un punto dentro del alcance deben superar una tirada de salvación de Sabiduría o tendrán el estado de incapacitadas hasta el final de su siguiente turno, momento en el que deberán repetir la tirada de salvación. Si un objetivo falla la segunda tirada, tendrá el estado de inconsciente hasta que termine el conjuro. El conjuro termina sobre un objetivo si recibe daño o si alguien a 5 pies o menos de él emplea una acción para zarandearlo y poner fin al efecto del conjuro. Las criaturas que no duermen, como los elfos, o que tengan inmunidad al estado de cansancio superan automáticamente las tiradas de salvación contra este conjuro.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 5,
      "measure": "radius"
    }
  },
  {
    "name": "DUELO FORZADO",
    "level": 1,
    "school": "Encantamiento",
    "classes": [
      "paladin"
    ],
    "casting_time": "Acción adicional",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Intentas forzar a una criatura a batirse en duelo, Una criatura que puedas ver dentro del alcance realiza una tirada de salvación de Sabiduría. Si la falla, el objetivo tendrá desventaja en las tiradas de ataque contra criaturas que no seas tú y no podrá moverse voluntariamente a ningún espacio que se encuentre a más de 30 pies de ti. El conjuro termina si haces una tirada de ataque contra una criatura distinta al objetivo, si lanzas un conjuro contra un enemigo distinto a él, si uno de tus aliados hace daño al objetivo o si terminas tu turno a más de 30 pies de él.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "DULCE DESCANSO",
    "level": 2,
    "school": "Nigromancia",
    "classes": [
      "clerigo",
      "mago",
      "paladin"
    ],
    "casting_time": "Acción o ritual",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "Una pizca de sal y una moneda de cobre colocada en cada ojo del cadáver, que el conjuro consume."
    },
    "duration": "10 días",
    "ritual": true,
    "concentration": false,
    "description": "Tocas un cadáver u otro tipo de restos mortales. Hasta que termine el conjuro, el objetivo está protegido de la descomposición y no se puede convertir en un muerto viviente. El conjuro también amplía el tiempo máximo para resucitar al objetivo, ya que los días que pasa bajo su influencia no cuentan para el límite de tiempo de conjuros como alzar a los muertos.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ECO RESIDUAL",
    "level": 0,
    "school": "Adivinación",
    "classes": [
      "bardo",
      "brujo",
      "clerigo",
      "druida",
      "mago",
      "segador"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Elige un objeto, una superficie o un punto dentro del alcance que haya estado presente durante al menos 1 minuto. Percibes un eco tenue de lo ocurrido allí recientemente. Elige una de las siguientes opciones: escuchar el último sonido breve originado en ese punto durante el último minuto, de hasta 6 segundos; o percibir la última emoción intensa que dejó una criatura en ese lugar durante la última hora, como miedo, ira, dolor o júbilo. Este truco no revela identidades, pensamientos exactos ni información más detallada que la indicada.",
    "tables": [],
    "sections": [],
    "source": "Homebrew"
  },
  {
    "name": "ELEMENTALISMO",
    "level": 0,
    "school": "Transmutación",
    "classes": [
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "30 pies / 5 pies de cubo",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Controlas los elementos y produces uno de los siguientes efectos dentro del alcance:\n\n• **Esculpir los elementos.** Haces que tierra, arena, fuego, humo, niebla o agua que quepan en un cubo de 1 pie de lado adopten una forma tosca (como la de una criatura) durante 1 hora.\n\n• **Invocar el agua.** Creas un rocío de fría niebla que humedece ligeramente a criaturas y objetos en un cubo de 5 pies de lado. Como alternativa, creas una taza de agua limpia en un recipiente abierto o sobre una superficie. El agua se evapora al cabo de 1 minuto.\n\n• **Invocar el aire.** Creas una brisa lo bastante fuerte como para ondear telas, remover polvo, agitar hojas y cerrar puertas o contraventanas abiertas dentro de un cubo de 5 pies de lado. Las puertas o contraventanas que estén sujetas no se ven afectadas.\n\n• **Invocar el fuego.** Creas una fina nube de ascuas inofensivas y humo perfumado en un cubo de 5 pies de lado. Tú eliges el color y el olor. Las ascuas pueden encender velas, antorchas o lámparas dentro de la zona. El aroma del humo permanece durante 1 minuto.\n\n• **Invocar la tierra.** Creas una fina capa de polvo o arena que cubre superficies en un área de 5 pies de lado, o haces que aparezca una sola palabra escrita con tu letra en una superficie de tierra o arena.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "cube",
      "sizeFt": 5
    }
  },
  {
    "name": "ELUSIÓN DE ELMINSTER",
    "level": 2,
    "school": "Abjuración",
    "classes": [
      "mago"
    ],
    "casting_time": "Acción adicional",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Protecciones arcanas te defienden de la magia durante la duración. Tienes Ventaja en las tiradas de salvación contra conjuros y efectos mágicos.\n\nAdemás, si superas una tirada de salvación contra un conjuro o efecto mágico que normalmente te permitiría recibir solo la mitad del daño, no recibes daño alguno.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "EMBELESAR",
    "level": 2,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "brujo"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Creas una serie de palabras encantadoras que provocan que una o más criaturas de tu elección a las que puedas ver dentro del alcance deban hacer una tirada de salvación de Sabiduría. Cualquier criatura contra la que luchéis tus aliados o tú superará automáticamente esta tirada. Si la falla, el objetivo sufrirá un penalizador de -10 a las pruebas de Sabiduría (Percepción) y a la Percepción pasiva hasta que el conjuro termine.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ENCANTAR ANIMAL",
    "level": 1,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "druida",
      "explorador"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "unas migajas de comida"
    },
    "duration": "24 horas",
    "ritual": false,
    "concentration": false,
    "description": "Haces objetivo a una bestia que puedas ver dentro del alcance. El objetivo deberá superar una tirada de salvación de Sabiduría o tendrá el estado de hechizado hasta que termine el conjuro. Si alguno de tus aliados o tú dañáis al objetivo, el conjuro termina.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Puedes hacer objetivo a una bestia adicional por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ENCONTRAR EL CAMINO",
    "level": 6,
    "school": "Adivinación",
    "classes": [
      "bardo",
      "clerigo",
      "druida"
    ],
    "casting_time": "1 minuto",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un juego de herramientas de divinación, como cartas o runas, que valga al menos 100 po"
    },
    "duration": "hasta 1 día",
    "ritual": false,
    "concentration": true,
    "description": "Percibes mágicamente el camino físico más corto hacia un lugar que nombres. Debes estar familiarizado con él, y el conjuro fallará si nombras un destino en otro plano de existencia, un destino que se mueva (como una fortaleza ambulante) o un destino inespecífico (como \"la guarida de un dragón verde\").\n\nHasta que termine el conjuro y mientras estés en el mismo plano de existencia que el destino, sabrás lo lejos que está y en qué dirección se halla. Cuando te topes con una encrucijada mientras vas al destino, identificarás qué camino es el más corto.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ENCONTRAR FAMILIAR",
    "level": 1,
    "school": "Conjuración",
    "classes": [
      "mago"
    ],
    "casting_time": "1 hora o un ritual",
    "range": "10 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "incienso para quemar que valga al menos 10 po, que se consume como parte del conjuro"
    },
    "duration": "Instantáneo",
    "ritual": true,
    "concentration": false,
    "description": "Obtienes los servicios de un familiar, un espíritu que adopta una forma animal de tu elección: araña, búho, comadreja, cuervo, gato, halcón, lagarto, murciélago, pulpo, rana, rata u otra bestia con valor de desafío 0. El familiar aparece en un espacio sin ocupar dentro del alcance.\n\nEl familiar usa el perfil de la forma elegida (consulta el capítulo “Monstruos”), pero es un celestial, feérico o infernal (a tu elección) en lugar de una bestia. Tu familiar actúa de forma independiente, pero obedece tus órdenes.\n\n• **Conexión telepática** Mientras tu familiar esté a 100 pies o menos de ti, podéis comunicaros telepáticamente. Además, como acción adicional, puedes ver a través de sus ojos y escuchar lo que oye hasta el inicio de tu siguiente turno. Durante ese tiempo, también obtienes los beneficios de cualquier sentido especial que tenga.\n\n• **Conjuros de toque** Cuando lanzas un conjuro con alcance de toque, puedes hacer que tu familiar sea quien toque al objetivo. El familiar debe estar a 100 pies o menos de ti y debe usar su reacción para tocar al objetivo cuando lanzas el conjuro.\n\n• **Combate** El familiar se considera un aliado para ti y tus aliados. Tira su propia iniciativa y actúa en su propio turno. Un familiar no puede atacar, pero puede realizar otras acciones de manera normal.\n\n• **Desaparición del familiar** Si los puntos de golpe del familiar se reducen a 0, este desaparece y no reaparece hasta que vuelvas a lanzar este conjuro. Como acción de magia, puedes hacer que el familiar se retire temporalmente a una dimensión de bolsillo. Como alternativa, puedes hacer que desaparezca para siempre. Mientras el familiar esté retirado temporalmente, puedes usar una acción de magia para hacer que reaparezca en un espacio sin ocupar a 30 pies o menos de ti. Siempre que el familiar desaparezca por cualquiera de estos medios, deja en el espacio que ocupaba cualquier objeto que estuviera vistiendo o llevando.\n\n• **Un solo familiar** No puedes tener más de un familiar al mismo tiempo. Si lanzas este conjuro mientras ya tienes un familiar, este adopta una nueva forma que cumpla los requisitos del conjuro.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ENGAÑAR",
    "level": 5,
    "school": "Ilusionismo",
    "classes": [
      "bardo",
      "brujo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": false,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Obtienes el estado de invisible al mismo tiempo que un doble ilusorio de ti aparece en tu sitio. El doble permanece hasta que termine el conjuro, pero la invisibilidad acaba de inmediato después de que hagas una tirada de ataque, causes daño o lances un conjuro.\n\nComo acción de magia, puedes hacer que tu doble ilusorio se mueva hasta el doble de tu velocidad y hacer que realice gestos, hable y se comporte del modo que quieras. El doble es intangible e invulnerable. Puedes ver a través de sus ojos y oír con sus oídos como si estuvieras en su ubicación.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ENLACE TELEPÁTICO DE RARY",
    "level": 5,
    "school": "Adivinación",
    "classes": [
      "bardo",
      "mago"
    ],
    "casting_time": "Acción o ritual",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "dos huevos"
    },
    "duration": "1 hora",
    "ritual": true,
    "concentration": false,
    "description": "Forjas un enlace telepático entre hasta ocho criaturas voluntarias de tu elección dentro del alcance y las vinculas psíquicamente unas con otras hasta que termine el conjuro. Las criaturas que no pueden comunicarse mediante idiomas no se ven afectadas. Hasta que el conjuro termine, los objetivos se pueden comunicar telepáticamente usando el enlace, tanto si comparten idioma como si no.\n\nEsta comunicación se puede producir a cualquier distancia, pero no se extiende a otros planos de existencia.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ENMARAÑAR",
    "level": 1,
    "school": "Conjuración",
    "classes": [
      "druida",
      "explorador"
    ],
    "casting_time": "Acción",
    "range": "90 pies / 20 pies de cuadrado",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Unas plantas apresadoras surgen del suelo en un cuadrado de 20 pies de lado dentro del alcance. Hasta que termine el conjuro, estas plantas convertirán la zona en terreno difícil y desaparecerán cuando el conjuro termine. Cada criatura (excepto tú) que esté en la zona cuando lances el conjuro deberá superar una tirada de salvación de Fuerza o tendrá el estado de apresada hasta que el conjuro termine. Una criatura apresada puede emplear una acción para hacer una prueba de Fuerza (Atletismo) contra tu CD de salvación de conjuros.\n\nSi la supera, se liberará de las plantas y dejará de estar apresada por ellas.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "square",
      "sizeFt": 20
    }
  },
  {
    "name": "ENREDADERA",
    "level": 4,
    "school": "Conjuración",
    "classes": [
      "druida",
      "explorador"
    ],
    "casting_time": "Acción adicional",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Conjuras una enredadera que brota de una superficie en un espacio sin ocupar que puedas ver dentro del alcance y permanece hasta que el conjuro termine. Haz un ataque de conjuro cuerpo a cuerpo contra una criatura a 30 pies o menos de la enredadera. Si acierta, el objetivo sufrirá 4d8 de daño contundente y será arrastrado hasta 30 pies hacia la enredadera. Si el objetivo es Enorme o más pequeño, tendrá el estado de agarrado (CD para escapar igual a tu CD de salvación de conjuros).",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "La cantidad de criaturas que puede agarrar la enredadera aumenta en uno por cada nivel por encima de 4 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ENSUEÑO",
    "level": 5,
    "school": "Ilusionismo",
    "classes": [
      "bardo",
      "brujo",
      "mago"
    ],
    "casting_time": "1 minuto",
    "range": "Especial",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un puñado de arena"
    },
    "duration": "8 horas",
    "ritual": false,
    "concentration": false,
    "description": "Elige como objetivo a una criatura que conozcas en el mismo plano de existencia. Una criatura voluntaria a la que toques o tú entraréis en un estado de trance y serviréis de mensajero onírico. Mientras esté en el trance, el mensajero tendrá el estado de incapacitado y una velocidad de 0. Si el objetivo está dormido, el mensajero aparece en sus sueños y puede conversar con él mientras siga dormido y hasta que termine el conjuro. El mensajero también puede dar forma al entorno del sueño y crear paisajes, objetos y otras imágenes. El mensajero puede salir del trance en cualquier momento, lo que pondrá fin al conjuro. Al despertar, el objetivo recordará el sueño a la perfección. Si el objetivo está despierto cuando lances el conjuro, el mensajero lo sabrá y podrá poner fin al trance (y al conjuro) o esperar a que se duerma, momento en el cual entrará en sus sueños. Puedes hacer que el mensajero se le aparezca al objetivo como un ser aterrador. Si lo haces, el mensajero podrá entregar un mensaje de un máximo de 10 palabras y luego el objetivo hará una tirada de salvación de Sabiduría. Si la falla, no recibirá beneficio alguno del descanso y sufrirá 3d6 de daño psíquico cuando se despierte.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ENTENDER IDIOMAS",
    "level": 1,
    "school": "Adivinación",
    "classes": [
      "bardo",
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción o ritual",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "1 hora",
    "ritual": true,
    "concentration": false,
    "description": "Hasta que el conjuro termine, entiendes el significado literal de las palabras que escuches o veas signadas en cualquier idioma. También comprendes todas las palabras escritas que ves, independientemente del idioma en el que estén, pero debes tocar la superficie en la que estén inscritas. Tardas aproximadamente 1 minuto en leer una página.\n\nEste conjuro no descifra mensajes secretos ni símbolos.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ESCUDO",
    "level": 1,
    "school": "Abjuración",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Reacción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "1 asalto",
    "ritual": false,
    "concentration": false,
    "description": "Lanzas este conjuro como reacción que llevas a cabo cuando te acierta una tirada de ataque o eres el objetivo del conjuro proyectil mágico. Una barrera imperceptible de fuerza mágica te protege. Hasta el principio de tu siguiente turno, tienes un bonificador de +5 a la CA, incluido contra el ataque al que reacciona, y no recibes ningún daño del conjuro proyectil mágico.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ESCUDO CACOFÓNICO",
    "level": 3,
    "school": "Evocación",
    "classes": [
      "bardo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Una emanación atronadora de 10 pies se extiende desde ti durante la duración del conjuro. Siempre que la emanación entre en el espacio de una criatura, o cuando una criatura entre o termine su turno en ella, esa criatura deberá realizar una tirada de salvación de Constitución. Si falla, recibirá 3d6 de daño de trueno y quedará Ensordecida hasta el inicio de tu siguiente turno. Si la supera, recibirá la mitad del daño y no quedará ensordecida.\n\nObtienes resistencia al daño de trueno, y los ataques a distancia realizados contra ti se hacen con Desventaja.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ESCUDO DE FE",
    "level": 1,
    "school": "Abjuración",
    "classes": [
      "clerigo",
      "paladin"
    ],
    "casting_time": "Acción adicional",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un pergamino de plegarias"
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Un campo titilante envuelve a una criatura de tu elección dentro del alcance y le otorga un bonificador de +2 a la CA hasta que el conjuro termine.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ESCUDO DE FUEGO",
    "level": 4,
    "school": "Evocación",
    "classes": [
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal / 10 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una luciérnaga o una pizca de fósforo"
    },
    "duration": "10 minutos",
    "ritual": false,
    "concentration": false,
    "description": "Unas llamas tenues envuelven tu cuerpo hasta que termine el conjuro y emiten luz brillante en un radio de 10 pies y luz tenue 10 pies más allá. Las llamas te proporcionan un escudo cálido o un escudo frío, a tu elección. El escudo cálido te proporciona resistencia al daño de frío, mientras que el escudo frío te concede resistencia al daño de fuego.\n\nAdemás, siempre que una criatura a 5 pies o menos de ti te acierte con una tirada de ataque cuerpo a cuerpo, el escudo estallará en llamas. El atacante recibirá 2d8 de daño de fuego de un escudo cálido o 2d8 de daño de frío de un escudo frío.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 10,
      "measure": "radius"
    }
  },
  {
    "name": "ESCUDRIÑAR",
    "level": 5,
    "school": "Adivinación",
    "classes": [
      "bardo",
      "brujo",
      "clerigo",
      "druida",
      "mago"
    ],
    "casting_time": "10 minutos",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un canalizador que valga al menos 1000 po, como una bola de cristal, un espejo o una pila llena de agua"
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Puedes ver y oír a una criatura concreta de tu elección que esté en tu mismo plano de existencia. El objetivo debe hacer una tirada de salvación de Sabiduría, modificada según lo bien que lo conozcas y la clase de vínculo físico que tengas con él, tal como se indica en la tabla. Si la falla, creas un sensor invisible a 10 pies o menos del objetivo. Puedes ver y oír a través del sensor como si estuvieras allí. El sensor se mueve con el objetivo y permanece hasta que el conjuro termine. Una criatura que pueda ver objetos invisibles ve el sensor como un orbe luminoso del tamaño aproximado de tu puño. En vez de hacer objetivo a una criatura, puedes elegir un lugar que hayas visto antes; en ese caso, el sensor aparece allí y no se mueve.",
    "tables": [
      {
        "title": "Conocimiento sobre el objetivo",
        "columns": [
          "Conocimiento",
          "Modificador de la tirada de salvación"
        ],
        "rows": [
          [
            "De segundas (has oído hablar del objetivo)",
            "+5"
          ],
          [
            "De primera mano (has conocido al objetivo)",
            "+0"
          ],
          [
            "Familiar (conoces bien al objetivo)",
            "−5"
          ]
        ]
      },
      {
        "title": "¿Qué tienes del objetivo?",
        "columns": [
          "Objeto",
          "Modificador de la tirada de salvación"
        ],
        "rows": [
          [
            "Dibujo u otro retrato",
            "−2"
          ],
          [
            "Prenda u otra posesión",
            "−4"
          ],
          [
            "Parte del cuerpo, mechón de pelo o trozo de uña",
            "−10"
          ]
        ]
      }
    ],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ESFERA CONGELANTE DE OTILUKE",
    "level": 6,
    "school": "Evocación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "300 pies / 60 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una esfera de cristal en miniatura"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Un globo glacial surge de ti y golpea un punto de tu elección dentro del alcance, donde explota en una esfera de 60 pies de radio. Todas las criaturas situadas en la zona realizan una tirada de salvación de Constitución; sufrirán 10d6 de daño de frío si la fallan o la mitad del daño si la superan. Si el globo golpea una masa de agua, la congelará hasta una profundidad de 6 pulgadas en un área cuadrada de 30 pies de lado. El hielo dura 1 minuto. Las criaturas que estuvieran nadando en la superficie del agua congelada quedarán atrapadas en el hielo y tendrán el estado de apresadas. Una criatura atrapada puede utilizar una acción para hacer una prueba de Fuerza (Atletismo) contra tu CD de salvación de conjuros para liberarse. Puedes renunciar a lanzar el globo tras completar el conjuro. En ese caso, en tu mano aparecerá un globo de tamaño similar a un proyectil de honda que resulta frío al tacto. En cualquier momento, tú o una criatura a la que le entregues el orbe podéis lanzarlo con la mano (hasta un alcance de 40 pies) o arrojarlo con una honda (hasta el alcance normal de la honda). Se hará añicos al impactar y causará el mismo efecto que el uso normal del conjuro. También puedes dejar el orbe en el suelo sin hacerlo pedazos y, tras 1 minuto, explotará si nadie lo ha hecho estallar.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d6 por cada nivel por encima de 6 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 60,
      "measure": "radius"
    }
  },
  {
    "name": "ESFERA DE LLAMAS",
    "level": 2,
    "school": "Conjuración",
    "classes": [
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies / 20 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una bola de cera"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Creas una esfera de fuego de 5 pies de diámetro en un espacio sin ocupar del suelo dentro del alcance, y durará hasta que termine el conjuro. Cualquier criatura que termine su turno a 5 pies o menos de ella hará una tirada de salvación de Destreza; sufrirá 2d6 de daño de fuego si la falla o la mitad de daño si la supera.\n\nComo acción adicional, puedes mover la esfera hasta 30 pies haciéndola rodar. Si mueves la esfera al espacio de una criatura, esta hará la tirada de salvación contra la esfera, que ya no podrá moverse más durante el turno. Cuando mueves la esfera, puedes llevarla por encima de barreras de hasta 5 pies de alto y hacer que salte huecos de hasta 10 pies de ancho. La esfera prende los objetos inflamables que toque y no lleve o vista nadie y emite luz brillante en un radio de 20 pies y luz tenue otros 20 pies más allá.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d6 por cada nivel por encima de 2 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 20,
      "measure": "radius"
    }
  },
  {
    "name": "ESFERA ELÁSTICA DE OTILUKE",
    "level": 4,
    "school": "Abjuración",
    "classes": [
      "mago"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una esfera de cristal"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Una esfera destellante encierra a una criatura u objeto Grande o más pequeño dentro del alcance. Una criatura no voluntaria deberá superar una tirada de salvación de Destreza o quedará encerrada hasta que el conjuro termine. Nada (ni objetos físicos ni energía ni los efectos de otros conjuros) puede atravesar la barrera, aunque una criatura que esté en la esfera puede respirar en su interior. La esfera es inmune a todo el daño y una criatura o un objeto en su interior no puede sufrir daño por ataques o efectos que se originen en el exterior y tampoco puede dañar a nada que haya fuera de la esfera. La esfera no pesa nada y tiene un tamaño justo como para contener a la criatura o el objeto de su interior. Una criatura encerrada puede utilizar una acción para empujar las paredes de la esfera y hacerla rodar a hasta la mitad de su velocidad. De forma similar, otras criaturas pueden recoger la esfera y moverla. Un conjuro desintegrar que haga objetivo a la esfera la destruirá, pero no dañará nada que haya dentro.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ESFERA VITRIÓLICA",
    "level": 4,
    "school": "Evocación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "150 pies / 20 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una gota de bilis"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Señalas un lugar dentro del alcance y una bola resplandeciente de ácido de 1 pie de diámetro vuela hacia el punto escogido y explota en una esfera de 20 pies de radio. Todas las criaturas situadas en esa zona realizan una tirada de salvación de Destreza. Si la fallan, recibirán 10d4 de daño de ácido y otros 5d4 de daño de ácido al final de su siguiente turno. Si la superan, solo sufren la mitad del daño inicial.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño inicial aumenta en 2d4 por cada nivel por encima de 4 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 20,
      "measure": "radius"
    }
  },
  {
    "name": "ESFERAS FULGURANTES DE ELMINSTER",
    "level": 6,
    "school": "Evocación",
    "classes": [
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un ópalo valorado en 1.000 po"
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Seis esferas cromáticas orbitan a tu alrededor durante la duración. Mientras las esferas estén presentes, puedes gastar esferas para crear uno de los siguientes efectos:\n\n• Absorber Energía. Cuando recibes daño ácido, frío, fuego, relámpago o trueno, puedes usar tu Reacción para gastar una esfera y obtener resistencia al daño desencadenante hasta el inicio de tu siguiente turno.\n\n• Descarga Energética. Como Acción adicional, lanzas una esfera contra un objetivo que puedas ver a 120 pies. Realiza un ataque de conjuro a distancia. Si impacta, el objetivo recibe 3d6 de daño del tipo elegido (ácido, frío, fuego, relámpago o trueno). La esfera se consume tanto si impacta como si falla. El conjuro termina si no te quedan esferas.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ESPADA DE MORDENKAINEN",
    "level": 7,
    "school": "Evocación",
    "classes": [
      "bardo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "90 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una espada en miniatura que valga al menos 250 po"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Creas una espada espectral que levitará dentro del alcance y durará hasta que termine el conjuro.\n\nCuando aparezca la espada, puedes realizar un ataque de conjuro cuerpo a cuerpo contra un objetivo que se encuentre a 5 pies o menos de ella. Si acierta, el objetivo recibe una cantidad de daño de fuerza igual a 4d12 más tu modificador por aptitud mágica. En tus turnos posteriores, puedes emplear una acción adicional para mover la espada hasta 30 pies a un lugar que puedas ver y repetir el ataque contra el mismo objetivo u otro distinto.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ESPEJISMO ARCANO",
    "level": 7,
    "school": "Ilusionismo",
    "classes": [
      "bardo",
      "druida",
      "mago"
    ],
    "casting_time": "10 minutos",
    "range": "Vista",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "10 días",
    "ritual": false,
    "concentration": false,
    "description": "Haces que el terreno de una zona cuadrada de hasta 1 milla de lado tenga el aspecto, los sonidos, los olores e incluso las sensaciones de otro tipo de terreno. Podrías hacer que un campo abierto o una carretera se parezcan a un pantano, una colina, una grieta u otro tipo de terreno difícil o infranqueable.\n\nSe puede hacer que un estanque parezca una pradera cubierta de hierba, que un precipicio se aparezca como una suave cuesta o que un barranco pedregoso y estrecho se presente como una carretera amplia y lisa. De forma similar, puedes alterar el aspecto de las estructuras o añadir algunas donde no las hay. El conjuro no disfraza, oculta ni añade criaturas.\n\nLa ilusión incluye elementos sonoros, visuales, táctiles y olfativos, por lo que puede convertir un lugar despejado en un terreno difícil (o viceversa) o entorpecer de otra forma el movimiento por la zona. Cualquier parte del terreno ilusorio (como una piedra o un palo) que se saque de la zona desaparece de inmediato.\n\nLas criaturas con visión verdadera pueden ver a través de la ilusión y distinguir la verdadera forma del terreno. Sin embargo, todos los demás elementos de la ilusión permanecen, por lo que, aunque dichas criaturas serán conscientes de que se trata de una ilusión, podrán interactuar físicamente con ella.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ESPÍRITUS GUARDIANES",
    "level": 3,
    "school": "Conjuración",
    "classes": [
      "clerigo"
    ],
    "casting_time": "Acción",
    "range": "Personal / 15 pies de emanación",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un pergamino de plegarias"
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Unos espíritus protectores revolotean a tu alrededor en una emanación de 15 pies hasta que el conjuro termine. Si tu alineamiento es bueno o neutral, su forma espectral parece angelical o feérica (a tu elección). Si es malvado, su forma es infernal. Cuando lanzas este conjuro, puedes elegir criaturas para que no les afecte. La velocidad de las demás criaturas se reducirá a la mitad en la emanación. Cuando esta entre en el espacio de una criatura o cuando una criatura entre en la emanación o termine su turno en ella, la criatura deberá hacer una tirada de salvación de Sabiduría. Si la falla, recibirá 3d8 de daño radiante (si tu alineamiento es bueno o neutral) o 3d8 de daño necrótico (si tu alineamiento es malvado). Si la supera, recibirá la mitad de daño. Una criatura solo hace esta tirada una vez por turno.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d8 por cada nivel por encima de 3 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 15,
      "measure": "radius"
    }
  },
  {
    "name": "ESTALLIDO MÁGICO",
    "level": 0,
    "school": "Evocación",
    "classes": [
      "hechicero"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Lanzas energía mágica contra una criatura u objeto dentro del alcance. Haz un ataque de conjuro a distancia contra el objetivo. Si acierta, el objetivo recibe 1d8 de daño del tipo que elijas: ácido, frío, fuego, psíquico, relámpago, trueno o veneno. Si sacas un 8 en un d8 con este conjuro, puedes tirar otro d8 y sumarlo al daño. Cuando lances este conjuro, la cantidad máxima de d8 que puedes sumar al daño del conjuro es igual a tu modificador por aptitud mágica.",
    "tables": [],
    "sections": [
      {
        "title": "Mejora de truco",
        "text": "El daño aumenta en 1d8 cuando alcanzas los niveles 5 (2d8), 11 (3d8) y 17 (4d8)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ESTRELLA SAGRADA DE MYSTRA",
    "level": 8,
    "school": "Evocación",
    "classes": [
      "clerigo",
      "mago"
    ],
    "casting_time": "Acción adicional",
    "range": "Personal / 5 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Creas un mote de energía sagrada brillante que flota sobre ti durante la duración. El mote emite luz brillante en un radio de 5 pies y luz tenue durante 5 pies adicionales. Cuando lanzas este conjuro, y como Acción adicional en turnos posteriores, puedes liberar un rayo de luz desde el mote contra una criatura que puedas ver a 120 pies. Realiza un ataque de conjuro a distancia. Impacto: el objetivo recibe 4d10 de daño de fuerza o radiante (a tu elección). Mientras el mote esté presente, obtienes Cobertura Tres Cuartos.\n\nAdemás, si superas una tirada de salvación contra un conjuro de nivel 7 o inferior que te tenga como único objetivo y no cree un área de efecto, puedes usar tu Reacción para desviar el conjuro de vuelta hacia el lanzador. El lanzador debe realizar una tirada de salvación contra su propio conjuro usando su CD de salvación de conjuros.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 5,
      "measure": "radius"
    }
  },
  {
    "name": "ESTÁTICA SINÁPTICA",
    "level": 5,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies / 20 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Una energía psíquica surge de ti hacia un punto dentro del alcance. Todas las criaturas situadas en una esfera de 20 pies de radio centrada en ese punto hacen una tirada de salvación de Inteligencia; sufrirán 8d6 de daño psíquico si la fallan o la mitad del daño si la superan. Si la falla, un objetivo también tendrá la mente nublada durante 1 minuto. Durante ese tiempo, restará 1d6 a todas sus tiradas de ataque y pruebas de característica, así como a cualquier tirada de salvación de Constitución para mantener la concentración. El objetivo hará una tirada de salvación de Inteligencia al final de cada uno de sus turnos y, si tiene éxito, se librará del efecto.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 20,
      "measure": "radius"
    }
  },
  {
    "name": "EXCURSIÓN ETÉREA",
    "level": 7,
    "school": "Conjuración",
    "classes": [
      "bardo",
      "brujo",
      "clerigo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Hasta 8 horas",
    "ritual": false,
    "concentration": false,
    "description": "Entras en las regiones fronterizas del Plano Etéreo, donde se superpone con tu plano actual. Permaneces en la Frontera Etérea hasta que termine el conjuro. Durante este tiempo, puedes moverte en cualquier dirección.\n\nSi te mueves hacia arriba o hacia abajo, cada pie de movimiento te cuesta 1 pie adicional. Puedes percibir el plano del que vienes, que se mostrará gris, y no puedes ver más allá de 60 pies. Mientras estés en el Plano Etéreo, solo puedes afectar y ser afectado por criaturas, objetos y efectos que haya en dicho plano.\n\nLas criaturas que no estén en él no podrán percibirte o interactuar contigo a menos que un rasgo les otorgue la capacidad de hacerlo.\n\nCuando el conjuro termine, reaparecerás en el plano del que viniste en el mismo sitio que se corresponde con tu espacio en la Frontera Etérea.\n\nSi apareces en un espacio ocupado, te desplazarás al espacio sin ocupar más cercano y recibirás 2 de daño de fuerza por cada 1 pie que te hayas movido. Este conjuro termina al instante si lo lanzas mientras estás en el Plano Etéreo o en un plano que no tenga frontera con él, como alguno de los Planos Exteriores.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Puedes hacer objetivo a hasta tres criaturas volun tarias (incluyéndote a ti) por cada nivel por encima de 7 que tenga el espacio. Estas criaturas deben estar a 10 pies o menos de ti cuando lances el conjuro."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "EXPLOSIÓN SOLAR",
    "level": 8,
    "school": "Evocación",
    "classes": [
      "clerigo",
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "150 pies / 60 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un trozo de heliolita"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Una esfera de 60 pies de radio centrada en un punto de tu elección dentro del alcance resplandece con una brillante luz solar. Todas las criaturas situadas en la esfera hacen una tirada de salvación de Constitución. Si la fallan, recibirán 12d6 daño radiante y tendrán el estado de cegadas durante 1 minuto. Si la superan, recibirán solo la mitad de daño. Una criatura cegada por este conjuro realiza una tirada de salvación de Constitución al final de cada uno de sus turnos y, si tiene éxito, se librará del efecto. Este conjuro dispersa la oscuridad que haya en la zona y que fuera creada por un conjuro.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 60,
      "measure": "radius"
    }
  },
  {
    "name": "FABRICAR",
    "level": 4,
    "school": "Transmutación",
    "classes": [
      "mago"
    ],
    "casting_time": "10 minutos",
    "range": "120 pies / 10 pies de cubo",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Conviertes materias primas en productos del mismo material. Por ejemplo, puedes fabricar un puente de madera a partir de unos árboles, una cuerda con un trozo de cáñamo o prendas usando lino o lana. Elige materias primas que puedas ver dentro del alcance.\n\nPuedes fabricar un objeto Grande o más pequeño (que quepa en un cubo de 10 pies de lado u ocho cubos conectados de 5 pies de lado), siempre y cuando tengas suficiente material. Sin embargo, si trabajas con metal, piedra u otra sustancia mineral, el objeto fabricado no puede ser mayor que Mediano (y debe caber en un cubo de 5 pies de lado). La calidad de los objetos fabricados depende de la calidad de los materiales.\n\nNo se pueden crear criaturas ni objetos mágicos con este conjuro, y tampoco puedes usarlo para crear objetos que requieran un alto grado de habilidad, como armas o armaduras, a menos que tengas competencia en el tipo de herramientas de artesano usadas para elaborar esos objetos.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "cube",
      "sizeFt": 10
    }
  },
  {
    "name": "FALSA VIDA",
    "level": 1,
    "school": "Nigromancia",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una gota de alcohol"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Obtienes 2d4 + 4 puntos de golpe temporales.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Obtienes 5 puntos de golpe temporales adicionales por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "FAVOR DIVINO",
    "level": 1,
    "school": "Transmutación",
    "classes": [
      "paladin"
    ],
    "casting_time": "Acción adicional",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "1 minuto",
    "ritual": false,
    "concentration": false,
    "description": "Hasta que el conjuro termine, tus ataques con armas infligen 1d4 de daño radiante adicional si aciertan.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "FESTÍN DE HÉROES",
    "level": 6,
    "school": "Conjuración",
    "classes": [
      "bardo",
      "clerigo",
      "druida"
    ],
    "casting_time": "10 minutos",
    "range": "Personal / 10 pies de cubo",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un cuenco incrustado de gemas que valga al menos 1000 po y que se consume como parte del conjuro"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Conjuras un festín que aparece sobre una superficie en un cubo de 10 pies de lado sin ocupar junto a ti. Se tarda 1 hora en consumirlo, desaparece al final de ese tiempo y sus efectos beneficiosos no se aplican hasta que concluye dicha hora. En el festín pueden participar hasta doce criaturas.\n\nUna criatura que participe obtiene varios beneficios que durarán 24 horas. Esa criatura tendrá resistencia al daño de veneno e inmunidad a los estados de asustada y envenenada.\n\nAdemás, sus puntos de golpe máximos aumentan en 2d10 y recupera la misma cantidad de puntos de golpe.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "cube",
      "sizeFt": 10
    }
  },
  {
    "name": "FINGIR MUERTE",
    "level": 3,
    "school": "Nigromancia",
    "classes": [
      "bardo",
      "clerigo",
      "druida",
      "mago"
    ],
    "casting_time": "Acción o ritual",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una pizca de tierra de cementerio"
    },
    "duration": "1 hora",
    "ritual": true,
    "concentration": false,
    "description": "Tocas a una criatura voluntaria y la sumes en un estado cataléptico que no se puede distinguir de la muerte. Hasta que termine el conjuro, la criatura parecerá muerta ante cualquier inspección externa o conjuro que intente averiguar su estado. El objetivo tendrá los estados de cegado e incapacitado y su velocidad será 0.\n\nEl objetivo también tendrá resistencia a todo el daño excepto el psíquico e inmunidad al estado de envenenado.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "FLECHA DE RELÁMPAGO",
    "level": 3,
    "school": "Transmutación",
    "classes": [
      "explorador"
    ],
    "casting_time": "Acción adicional",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Lanzas este conjuro como acción adicional que realizas. Cuando tu ataque contra el objetivo acierte o falle, el arma ola munición que usas se transforma en un relámpago. En vez de sufrir daño u otros efectos del ataque, el objetivo recibe 4d8 de daño de relámpago si el ataque acierta o la mitad de daño si falla. Todas las criaturas a 10 pies o menos del objetivo harán después una tirada de salvación de Destreza; sufrirán 2d8 de daño de relámpago si la fallan o la mitad del daño si la superan.\n\nLuego, el arma o la munición vuelve a la normalidad. Con un espacio de conjuro de nivel superior. El daño de los dos efectos del conjuro aumenta en 1d8 por cada nivel por encima de 3 que tenga el espacio.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "FLECHA ÁCIDA DE MELF",
    "level": 2,
    "school": "Evocación",
    "classes": [
      "mago"
    ],
    "casting_time": "Acción",
    "range": "90 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "ruibarbo en polvo"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Una brillante flecha verde sale disparada hacia un objetivo dentro del alcance y estalla en una lluvia de ácido. Haz un ataque de conjuro a distancia contra el objetivo. Si acierta, el objetivo recibe 4d4 de daño de ácido y 2d4 de daño de ácido al final de su siguiente turno. Si falla, la flecha salpica al objetivo con ácido y solo le causa la mitad del daño inicial.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "FORMA GASEOSA",
    "level": 3,
    "school": "Transmutación",
    "classes": [
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un poco de gasa"
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Una criatura voluntaria a la que toques cambia de forma, junto con todo lo que lleve o vista, y se convierte en una niebla fina hasta que termine el conjuro. El conjuro termina para el objetivo si sus puntos de golpe se reducen a 0 o si emplea una acción de magia para ponerle fin.\n\nMientras está en esta forma, el único método de movimiento del objetivo es una velocidad volando de 10 pies, y podrá levitar y entrar en el espacio de otra criatura y ocuparlo. El objetivo tiene resistencia al daño contundente, cortante y perforante, inmunidad al estado de derribado y ventaja en las tiradas de salvación de Fuerza, Destreza y Constitución.\n\nEl objetivo puede atravesar aberturas estrechas, pero trata los líquidos como si fueran superficies sólidas. El objetivo no puede hablar ni manipular objetos y no puede soltar, usar ni interactuar de ninguna otra forma con cualquier objeto que llevara o sostuviera.\n\nPor último, el objetivo no puede atacar ni lanzar conjuros.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Puedes hacer objetivo a una criatura adicional por cada nivel por encima de 3 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "FRAGMENTO MENTAL",
    "level": 0,
    "school": "Encantamiento",
    "classes": [
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "1 asalto",
    "ritual": false,
    "concentration": false,
    "description": "Intentas fragmentar de forma temporal la mente de una criatura que puedas ver dentro del alcance. El objetivo deberá superar una tirada de salvación de Inteligencia o recibirá 1d6 de daño psíquico y restará 1d4 en la siguiente tirada de salvación que haga antes del final de tu siguiente turno.",
    "tables": [],
    "sections": [
      {
        "title": "Mejora de truco",
        "text": "El daño aumenta en 1d6 cuando alcanzas los niveles 5 (2d6), 11 (3d6) y 17 (4d6)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "FUEGO FEÉRICO",
    "level": 1,
    "school": "Evocación",
    "classes": [
      "bardo",
      "druida"
    ],
    "casting_time": "Acción",
    "range": "60 pies / 10 pies de radio",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "El conjuro ilumina con luz azul, verde o violeta, a tu elección, el contorno de los objetos en un cubo de 20 pies de lado dentro del alcance. También se ilumina el contorno de cualquier criatura dentro del cubo que falle una tirada de salvación de Destreza. Hasta que termine el conjuro, los objetos y criaturas afectados emitirán luz tenue en un radio de 10 pies y no podrán beneficiarse del estado de invisibles. Las tiradas de ataque contra las criaturas u objetos afectados tendrán ventaja si el atacante puede verlos.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 10,
      "measure": "radius"
    }
  },
  {
    "name": "FUENTE DE LUZ LUNAR",
    "level": 4,
    "school": "Evocación",
    "classes": [
      "bardo",
      "druida"
    ],
    "casting_time": "Acción",
    "range": "Personal / 20 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Mientras dure el efecto, una luz fría envuelve tu cuerpo y emite luz brillante en un radio de 20 pies y luz tenue 20 pies más allá. Hasta que el conjuro termine, tienes resistencia al daño radiante y tus ataques cuerpo a cuerpo causarán 2d6 de daño radiante adicional cuando acierten.\n\nAdemás, inmediatamente después de recibir daño de una criatura que puedas ver a 60 pies o menos de ti, puedes usar una reacción para obligar a la criatura a hacer una tirada de salvación de Constitución. Si la falla, tendrá el estado de cegada hasta el final de tu siguiente turno.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 20,
      "measure": "radius"
    }
  },
  {
    "name": "FUERZA FANTASMAL",
    "level": 2,
    "school": "Ilusionismo",
    "classes": [
      "bardo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies / 10 pies de cubo",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un poco de vellón"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Intentas crear una ilusión en la mente de una criatura que puedas ver dentro del alcance. El objetivo hace una tirada de salvación de Inteligencia. Si la falla, creas un objeto o una criatura fantasmal u otro fenómeno cuyas dimensiones no excedan las de un cubo de 10 pies de lado y que solo puede percibir el objetivo hasta que el conjuro termine. El fantasma puede emitir sonidos, alterar la temperatura y producir otros estímulos. El objetivo puede usar una acción de estudiar para examinar la imagen con una prueba de Inteligencia (Investigación) contra tu CD de salvación de conjuros.\n\nSi la supera, se da cuenta de que el fantasma es una ilusión y el conjuro termina. Mientras esté afectado por este conjuro, el objetivo tratará al fantasma como si fuera real y racionalizará cualquier resultado ilógico derivado de interactuar con él. Por ejemplo, si el objetivo intenta caminar por un puente ilusorio y sobrevive a la caída, creerá que el puente existe y que otra cosa ha provocado su caída. Un objetivo afectado incluso puede recibir daño de la ilusión si el fantasma se muestra como una amenaza o una criatura peligrosa.\n\nEn cada uno de tus turnos, la forma fantasmal puede causar 2d8 de daño psíquico al objetivo si está en el área que ocupa el fantasma o a 5 pies de él. El objetivo percibe el daño como de un tipo apropiado para la ilusión.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "cube",
      "sizeFt": 10
    }
  },
  {
    "name": "FUNDIRSE CON LA PIEDRA",
    "level": 3,
    "school": "Transmutación",
    "classes": [
      "clerigo",
      "druida",
      "explorador"
    ],
    "casting_time": "Acción o ritual",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "8 horas",
    "ritual": true,
    "concentration": false,
    "description": "Entras en un objeto o una superficie de piedra lo suficientemente grande como para que tu cuerpo quepa dentro y tanto tú como tu equipo os fundís con la piedra hasta que termine el conjuro. Para ello, debes tocar la piedra. No queda nada de tu presencia visible ni que se pueda detectar mediante sentidos que no sean mágicos.\n\nMientras estés fundido con la piedra, no puedes ver lo que sucede fuera y tienes desventaja en las pruebas de Sabiduría (Percepción) que hagas para escuchar sonidos en el exterior.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "GEAS",
    "level": 5,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "clerigo",
      "druida",
      "mago",
      "paladin"
    ],
    "casting_time": "1 minuto",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "30 días",
    "ritual": false,
    "concentration": false,
    "description": "Das una orden verbal a una criatura que puedas ver dentro del alcance y la obligas a llevar a cabo un cometido o le impides realizar una acción o actividad, según desees. El objetivo deberá superar una tirada de salvación de Sabiduría o tendrá el estado de hechizado hasta que termine el conjuro. El objetivo la superará automáticamente si no entiende la orden. Mientras esté hechizada, la criatura sufre 5d10 de daño psíquico si actúa de manera contraria a tus instrucciones, y solo podrá recibir este daño una vez al día. Puedes dar cualquier orden que quieras, siempre que no sea una actividad que suponga una muerte segura. Si das una orden suicida, el conjuro termina. Un conjuro deseo, levantar maldición o restablecimiento mayor también pone fin a este conjuro.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Si usas un espacio de niveles 7 u 8, la duración será de 365 días. Si usas un espacio de nivel 9, el conjuro durará hasta que se le pone fin mediante uno de los conjuros mencionados anteriormente."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "GLIFO CUSTODIO",
    "level": 3,
    "school": "Abjuración",
    "classes": [
      "bardo",
      "clerigo",
      "mago"
    ],
    "casting_time": "1 hora",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "diamante en polvo que valga al menos 200 po, que se consume como parte del conjuro"
    },
    "duration": "Hasta que sea disipado o se active",
    "ritual": false,
    "concentration": false,
    "description": "Inscribe un glifo que liberará posteriormente un efecto mágico. Puedes hacerlo en una superficie, como una mesa o un trozo de suelo, o en un objeto que se pueda cerrar, como un libro o un cofre, para ocultar dicho glifo. Este puede abarcar una zona de hasta 10 pies de diámetro. Si la superficie o el objeto se mueven más de 10 pies respecto al lugar donde lanzaste el conjuro, el glifo se romperá y el conjuro terminará sin activarse.\n\nEl glifo es casi imperceptible, y es necesario superar una prueba de Sabiduría (Percepción) contra tu CD de salvación de conjuros para detectarlo.\n\nCuando inscribes el glifo, decides qué lo activa y eliges si se trata de una runa explosiva o un glifo de conjuro, como se explica a continuación.\n\n• **Establecer el activador.**\nCuando lances el conjuro, decide qué activará el glifo. En el caso de los glifos inscritos en una superficie, las condiciones que suelen activarlos incluyen tocarlos o situarse sobre ellos, quitar otro objeto que los cubra o acercarse a cierta distancia de ellos. En el caso de los glifos inscritos en un objeto, suelen activarse al abrir el objeto o mirar el glifo. En cuanto un glifo se activa, este conjuro termina.\n\nPuedes especificar aún más la condición, de modo que solo las criaturas de ciertos tipos puedan activarlo, como que solo afecte a las aberraciones. También puedes establecer excepciones sobre qué criaturas no activarán el glifo, como aquellas que pronuncien una contraseña.\n\n• **Runa explosiva.**\nCuando se activa, el glifo estalla con energía mágica en una esfera de 20 pies de radio centrada en él. Todas las criaturas situadas en esa zona deberán realizar una tirada de salvación de Destreza. Si la fallan, sufrirán 5d8 de daño de ácido, frío, fuego, relámpago o trueno, a tu elección cuando creas el glifo. Si la superan, recibirán la mitad del daño.\n\n• **Glifo de conjuro.**\nPuedes almacenar un conjuro preparado de nivel 3 o inferior en el glifo si lo lanzas como parte de la creación de dicho glifo. El conjuro debe tener como objetivo una sola criatura o un área. El conjuro almacenado no tiene ningún efecto inmediato cuando se lanza de esta manera.\n\nCuando el glifo se activa, el conjuro almacenado surte efecto. Si el conjuro tiene un objetivo, elige como dicho objetivo a la criatura que haya activado el glifo. Si afecta a un área, la zona está centrada en esa criatura. Si el conjuro invoca criaturas hostiles o crea objetos o trampas perjudiciales, aparecerán lo más cerca posible del intruso y lo atacarán. Si el conjuro requiere concentración, no terminará hasta alcanzar su duración máxima.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño de una runa explosiva aumenta en 1d8 por cada nivel por encima de 3 que tenga el espacio. Si creas un glifo de conjuro, puedes almacenar cualquier conjuro de hasta el mismo nivel que el espacio de conjuro que hayas empleado para el glifo custodio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "GLOBO DE INVULNERABILIDAD",
    "level": 6,
    "school": "Abjuración",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal / 10 pies de emanación",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una cuenta de cristal"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Una barrera inmóvil y brillante surge en una emanación de 10 pies alrededor de ti y permanece hasta que el conjuro termine. Cualquier conjuro de nivel 5 o inferior que se lance desde fuera de la barrera no puede afectar a nada dentro de ella. Tales conjuros pueden hacer objetivo a criaturas y objetos que estén dentro de la barrera, pero no tendrán ningún efecto sobre ellos.\n\nDe forma similar, el interior de la barrera estará excluido de las áreas de efecto creadas por dichos conjuros.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "La barrera bloquea los conjuros de un nivel más por cada nivel por encima de 6 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 10,
      "measure": "radius"
    }
  },
  {
    "name": "GOLPE APRESADOR",
    "level": 1,
    "school": "Conjuración",
    "classes": [
      "explorador"
    ],
    "casting_time": "Acción adicional",
    "range": "Personal",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Lanzas este conjuro como acción adicional que realizas. Al acertar al objetivo, unas enredaderas aparecerán sobre él y deberá hacer una tirada de salvación de Fuerza. Las criaturas Grandes o de mayor tamaño tienen ventaja en esta tirada. Si la falla, tendrá el estado de apresado hasta que el conjuro termine. Si la supera, las enredaderas se marchitan y el conjuro termina. Mientras esté apresado, el objetivo sufrirá 1d6 de daño perforante al principio de cada uno de sus turnos. El objetivo o una criatura a su alcance puede emplear una acción para hacer una prueba de Fuerza (Atletismo) contra tu CD de salvación de conjuros.\n\nSi la supera, el conjuro termina.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d6 por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "GOLPE DE VIENTO ACERADO",
    "level": 5,
    "school": "Conjuración",
    "classes": [
      "explorador",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": false,
      "s": true,
      "m": true,
      "material": "un arma cuerpo a cuerpo que valga al menos 1 pp"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Blandes el arma utilizada al lanzar el conjuro y luego desapareces para golpear como el viento. Elige hasta cinco criaturas que puedas ver dentro del alcance. Haz un ataque de conjuro cuerpo a cuerpo contra cada objetivo. Si acierta, el objetivo recibe 6d10 de daño de fuerza.\n\nA continuación, te teletransportas a un espacio sin ocupar que puedas ver a 5 pies de uno de los objetivos.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "GOLPE FLAMÍGERO",
    "level": 5,
    "school": "Evocación",
    "classes": [
      "clerigo"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una pizca de azufre"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Una columna de fuego brillante ruge desde el cielo. Todas las criaturas en un cilindro de 10 pies de radio y 40 pies de altura centrado en un punto dentro del alcance realizan una tirada de salvación de Destreza; sufrirán 5d6 de daño de fuego y 5d6 de daño radiante si la fallan o la mitad de daño si la superan.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño de fuego y radiante aumentan en 1d6 por cada nivel por encima de 5 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "GRASA",
    "level": 1,
    "school": "Conjuración",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies / 10 pies de cuadrado",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un poco de piel de cerdo o de mantequilla"
    },
    "duration": "1 minuto",
    "ritual": false,
    "concentration": false,
    "description": "Una grasa no inflamable cubre una zona cuadrada del suelo de 10 pies de lado centrada en un punto dentro del alcance y que la convierte en terreno difícil hasta que termina el conjuro.\n\nCuando aparezca la grasa, las criaturas que haya en esa zona deberán superar una tirada de salvación de Destreza o tendrán el estado de derribadas. Una criatura que entre en la zona o termine su turno ahí deberá superar esa tirada de salvación o caerá derribada.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "square",
      "sizeFt": 10
    }
  },
  {
    "name": "GUARDA CONTRA LA MUERTE",
    "level": 4,
    "school": "Abjuración",
    "classes": [
      "clerigo",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "8 horas",
    "ritual": false,
    "concentration": false,
    "description": "Tocas a una criatura y le concedes cierta protección frente a la muerte. La primera vez que los puntos de golpe del objetivo fueran a reducirse a o antes de que el conjuro termine, en lugar de eso, se reducen a 1 y el conjuro termina. Si el conjuro sigue activo cuando el objetivo sufre un efecto que fuera a matarlo al instante sin causarle daño, se niega ese efecto y el conjuro termina.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "GUARDAS Y GUARDIAS",
    "level": 6,
    "school": "Abjuración",
    "classes": [
      "bardo",
      "mago"
    ],
    "casting_time": "1 hora",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una vara de plata que valga al menos 10 po"
    },
    "duration": "24 horas",
    "ritual": false,
    "concentration": false,
    "description": "Creas una protección mágica que cubre hasta 2 500 pies cuadrados de superficie en el suelo. La zona protegida puede tener hasta 20 pies de altura y puede adoptar una de las siguientes formas:\n\nUn área cuadrada de 50 pies de lado.\n\nCien cuadrados contiguos de 5 pies de lado.\n\nVeinticinco cuadrados contiguos de 10 pies de lado.\n\nCuando lanzas el conjuro, puedes designar criaturas específicas que no se verán afectadas por sus efectos. También puedes establecer una contraseña; cualquier criatura que pronuncie la contraseña en voz alta a 5 pies o menos de la zona protegida queda inmune a los efectos del conjuro.\n\n**Efectos de la protección**\n\nLa zona protegida queda bajo los siguientes efectos mágicos.\n\nDisipar magia no tiene efecto sobre guardas y guardias en su conjunto, pero los efectos individuales descritos a continuación pueden disiparse. Si se disipan los cuatro, el conjuro termina.\n\nSi lanzas este conjuro a diario durante 365 días en la misma zona, el conjuro se vuelve permanente hasta que todos sus efectos sean disipados.\n\n• **Escaleras** Todas las escaleras de la zona protegida se llenan de telas de araña de arriba abajo, como si estuvieran bajo los efectos del conjuro telaraña. Mientras dure guardas y guardias, estas telas de araña se regeneran en un plazo de 10 minutos si son destruidas.\n\n• **Pasillos** Todos los pasillos protegidos se llenan de niebla y quedan en oscuridad intensa. Además, en cada intersección o bifurcación que permita elegir una dirección, existe un 50 % de probabilidad de que una criatura que no seas tú crea que avanza en la dirección opuesta a la que eligió.\n\n• **Puertas** Todas las puertas de la zona protegida quedan cerradas mágicamente, como si estuvieran afectadas por el conjuro cerradura arcana. Además, puedes cubrir hasta 10 puertas con una ilusión para que parezcan simples secciones de pared.\n\n**Efecto adicional**\n\nElige uno de los siguientes efectos mágicos adicionales para la zona protegida:\n\n• **Luces danzantes.** Aparecen luces danzantes en hasta cuatro pasillos, siguiendo un patrón sencillo que se repite mientras dure el conjuro.\n\n• **Boca mágica.** Aparece una boca mágica en hasta dos lugares de la zona.\n\n• **Nube apestosa.** Aparece una nube apestosa en hasta dos lugares. Si los vapores se dispersan, reaparecen tras 10 minutos mientras dure el conjuro.\n\n• **Ráfaga de viento.** Una ráfaga de viento sopla de forma continua en un pasillo o una sala mientras dure el conjuro.\n\n• **Sugestión.** Se inscribe una sugestión en un cuadrado de 5 pies de lado. Cualquier criatura que entre en esa zona recibe la sugerencia mentalmente.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "GUARDIA DE CUCHILLAS",
    "level": 0,
    "school": "Abjuración",
    "classes": [
      "bardo",
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Siempre que una criatura haga una tirada de ataque contra ti antes de que el conjuro termine, el atacante restará 1d4 a esa tirada.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "GUARDIÁN DE LA FE",
    "level": 4,
    "school": "Conjuración",
    "classes": [
      "clerigo"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "8 horas",
    "ritual": false,
    "concentration": false,
    "description": "Un guardián espectral Grande aparece en un espacio sin ocupar que puedas ver dentro del alcance y levita sobre él hasta que termine el conjuro. El guardián ocupa ese espacio, es invulnerable y se muestra en una forma adecuada para tu deidad o panteón. Cualquier enemigo que entre en un espacio a 10 pies o menos del guardián por primera vez en un turno o empiece su turno allí hará una tirada de salvación de Destreza; sufrirá 20 de daño radiante si la falla o la mitad de daño si la supera. El guardián se desvanece cuando ha causado un total de 60 de daño.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "GUÍA",
    "level": 0,
    "school": "Adivinación",
    "classes": [
      "clerigo",
      "druida",
      "segador"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Tocas a una criatura voluntaria y eliges una habilidad. Hasta que el conjuro termine, la criatura añade 1d4 a una prueba de característica con la habilidad elegida.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "HABLAR CON LAS PLANTAS",
    "level": 3,
    "school": "Transmutación",
    "classes": [
      "bardo",
      "druida",
      "explorador"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "10 minutos",
    "ritual": false,
    "concentration": false,
    "description": "Insuflas una consciencia y una animación limitadas a las plantas en una emanación inmóvil de 30 pies, lo que les otorga la capacidad de comunicarse contigo y obedecer órdenes sencillas que les des. Puedes preguntar a las plantas acerca de sucesos que hayan ocurrido en la zona del conjuro durante el último día y conseguir información sobre qué criaturas han pasado por allí, el clima y otras circunstancias.\n\nTambién puedes convertir el terreno difícil debido al crecimiento vegetal (como matorrales y maleza) en terreno normal hasta que termine el conjuro o puedes convertir un terreno normal en el que haya plantas en terreno difícil hasta que termine el conjuro. El conjuro no permite que las plantas se liberen del suelo y se desplacen, pero sí que pueden mover sus ramas, zarcillos y tallos por ti.\n\nSi hay una criatura de tipo \"planta\" en la zona, puedes comunicarte con ella como si compartierais un idioma común.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "HABLAR CON LOS ANIMALES",
    "level": 1,
    "school": "Adivinación",
    "classes": [
      "bardo",
      "druida",
      "explorador",
      "brujo"
    ],
    "casting_time": "Acción o ritual",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "10 minutos",
    "ritual": true,
    "concentration": false,
    "description": "Hasta que termine el conjuro, puedes comprender y comunicarte verbalmente con bestias y usar con ellas cualquiera de las opciones de la acción de influir. La mayoría de bestias tienen poco que decir en cuestiones que no tengan que ver con la supervivencia o la compañía, pero como mínimo podrán proporcionarte información sobre los lugares y monstruos cercanos, incluyendo lo que hayan percibido en el último día.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "HABLAR CON LOS MUERTOS",
    "level": 3,
    "school": "Nigromancia",
    "classes": [
      "bardo",
      "clerigo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "10 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "incienso para quemar"
    },
    "duration": "10 minutos",
    "ritual": false,
    "concentration": false,
    "description": "Concedes a un cadáver la apariencia de vida y la capacidad de hablar. El cadáver debe tener boca y no puede ser un muerto viviente. El conjuro fracasa si el cadáver fue objetivo de este conjuro en los últimos 10 días.\n\nHasta que el conjuro termine, puedes hacer hasta cinco preguntas al cadáver. El cadáver conoce solo lo que supo en vida, incluyendo los idiomas que conocía, y está limitado por su capacidad de recordar hechos pasados.\n\nLas respuestas suelen ser breves, crípticas o repetitivas. El cadáver no es consciente del tiempo transcurrido desde su muerte y no puede aprender nueva información. Este conjuro no devuelve el alma a la criatura ni la obliga a decir la verdad.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "HACER AÑICOS",
    "level": 2,
    "school": "Evocación",
    "classes": [
      "bardo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies / 10 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una lasca de mica"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Un fuerte ruido surge de un punto de tu elección dentro del alcance. Todas las criaturas situadas en una esfera de 10 pies de radio centrada en ese punto hacen una tirada de salvación de Constitución; sufrirán 3d8 de daño de trueno si la fallan o la mitad del daño si la superan. Los autómatas tienen desventaja en esta tirada. Los objetos no mágicos que se encuentren dentro del área del conjuro también recibirán el daño, salvo si los lleva o viste una criatura.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d8 por cada nivel por encima de 2 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 10,
      "measure": "radius"
    }
  },
  {
    "name": "HALLAR CORCEL",
    "level": 2,
    "school": "Conjuración",
    "classes": [
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Invocas un ser sobrenatural que asume la forma de un corcel fiel en un espacio sin ocupar de tu elección dentro del alcance. La criatura usa el perfil de **Corcel sobrenatural**. Si ya tienes un corcel gracias a este conjuro, se sustituirá por el nuevo.\n\nEl corcel se parece a un animal Grande que puedas montar de tu elección, como un caballo, un alce, un camello o un lobo terrible. Siempre que lances el conjuro, elige el tipo de criatura del corcel (celestial, feérico o infernal), lo que determinará ciertos atributos de su perfil.\n\n• Combate. El corcel se considera un aliado para tus aliados y para ti. En combate, la criatura comparte tu orden de iniciativa y funciona como una montura controlada mientras vayas sobre ella (como se describe en las normas del combate montado). Si tienes el estado de incapacitado, su turno irá justo después del tuyo, actuará con independencia de ti y se centrará en protegerte.\n\n• Desaparición del corcel. El corcel desaparece si sus puntos de golpe se reducen a 0 o si mueres. Cuando desaparece, deja atrás todo lo que vistiera o llevase. Si vuelves a lanzar este conjuro, decides si invocas al corcel que desapareció u otro distinto.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Usa el nivel del espacio de conjuro para determinar el nivel del conjuro en el perfil."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "HAMBRE DE HADAR",
    "level": 3,
    "school": "Conjuración",
    "classes": [
      "brujo"
    ],
    "casting_time": "Acción",
    "range": "150 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un tentáculo en salmuera"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Abres un portal al Reino Lejano, una región infestada de horrores ignotos. Aparece una esfera de oscuridad de 20 pies de radio centrada en un punto dentro del alcance y que permanece hasta que el conjuro termine. La esfera se considera terreno difícil y está llena de susurros extraños y sonidos de succión, audibles a 30 pies de distancia. Ninguna luz mágica u ordinaria puede iluminar la zona, y las criaturas completamente dentro de ella tendrán el estado de cegadas. Cualquier criatura que comience su turno dentro de la zona recibirá 2d6 de daño de frío. Cualquier criatura que termine su turno dentro deberá superar una tirada de salvación de Destreza o recibirá 2d6 de daño de ácido de unos tentáculos sobrenaturales.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño de frío o de ácido (a tu elección) aumenta en 1d6 por cada nivel por encima de 3 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "HECHIZAR MONSTRUO",
    "level": 4,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "brujo",
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Una criatura que puedas ver dentro del alcance realiza una tirada de salvación de Sabiduría. La hace con ventaja si está luchando contra ti o tus aliados. Si la falla, tendrá el estado de hechizada hasta que el conjuro termine o hasta que tus aliados o tú le hagáis daño. La criatura hechizada es amistosa contigo, pero cuando el conjuro termine, sabrá que la hechizaste.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Puedes hacer objetivo a una criatura adicional por cada nivel por encima de 4 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "HECHIZAR PERSONA",
    "level": 1,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "brujo",
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Un humanoide que puedas ver dentro del alcance realiza una tirada de salvación de Sabiduría. La hace con ventaja si está luchando contra ti o tus aliados. Si la falla, tendrá el estado de hechizado hasta que el conjuro termine o hasta que tus aliados o tú le hagáis daño. La criatura hechizada es amistosa contigo, pero cuando el conjuro termine, sabrá que la hechizaste.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Puedes hacer objetivo a una criatura adicional por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "HEROÍSMO",
    "level": 1,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Una criatura voluntaria que toques se imbuye de valentía. Hasta que el conjuro termine, la criatura es inmune al estado de Asustado y obtiene puntos de golpe temporales iguales a tu modificador por aptitud mágica al comienzo de cada uno de sus turnos.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Puedes hacer objetivo a una criatura adicional por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "HOJA DE FUEGO",
    "level": 2,
    "school": "Evocación",
    "classes": [
      "druida",
      "hechicero"
    ],
    "casting_time": "Acción adicional",
    "range": "Personal / 10 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una hoja de zumaque"
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Haces aparecer una hoja ardiente en tu mano libre que es similar en tamaño y forma a una cimitarra y que durará hasta que termine el conjuro. Si sueltas la hoja, desaparece, pero puedes volver a invocarla como acción adicional. Como acción de magia, puedes hacer un ataque de conjuro cuerpo a cuerpo con la hoja ardiente. Si acierta, el objetivo sufrirá una cantidad de daño de fuego igual a 3d6 más tu modificador por aptitud mágica. La hoja llameante emite luz brillante en un radio de 10 pies y luz tenue 10 pies más allá.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d6 por cada nivel por encima de 2 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 10,
      "measure": "radius"
    }
  },
  {
    "name": "HOJA DEL DESASTRE",
    "level": 9,
    "school": "Conjuración",
    "classes": [
      "hechicero",
      "brujo",
      "mago"
    ],
    "casting_time": "Acción adicional",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Creas una grieta planar con forma de hoja de 3 pies de largo, que aparece en un espacio desocupado dentro del alcance y permanece durante la duración del conjuro. Cuando el conjuro se lanza, puedes realizar hasta dos ataques de conjuro cuerpo a cuerpo contra criaturas u objetos situados a 5 pies de la grieta. Con un impacto, el objetivo recibe 10d6 de daño de fuerza. Este ataque obtiene un impacto crítico con un resultado de 18 o superior en el d20. Como Acción adicional en tus turnos posteriores, puedes mover la grieta hasta 60 pies y repetir los dos ataques contra criaturas u objetos dentro de 5 pies de ella, ya sea contra el mismo objetivo o contra otros distintos. La hoja puede atravesar sin problema barreras creadas por conjuros como Muro de Fuerza.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "HOMÚNCULOS ÚTILES DE DERYAN",
    "level": 2,
    "school": "Conjuración",
    "classes": [
      "clerigo",
      "mago"
    ],
    "casting_time": "Acción o Ritual",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "gemas pulverizadas valoradas en 100 po, que el conjuro consume, y un juego de herramientas de artesano con el que seas competente"
    },
    "duration": "8 horas",
    "ritual": true,
    "concentration": false,
    "description": "Invocas un grupo de espíritus útiles que permanecen durante la duración. Los espíritus aparecen como homúnculos u otros constructos de tu elección, pero son intangibles e invulnerables. Durante el lanzamiento del conjuro, se considera que eres competente en las herramientas arcanas y en el uso del juego de herramientas de artesano empleado como componente material.\n\nSi estás fabricando un objeto, los espíritus funcionan como un único asistente, reduciendo a la mitad el tiempo de fabricación.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "IDENTIFICAR",
    "level": 1,
    "school": "Adivinación",
    "classes": [
      "bardo",
      "mago"
    ],
    "casting_time": "1 minuto o un ritual",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una perla que valga al menos 100 po"
    },
    "duration": "Instantáneo",
    "ritual": true,
    "concentration": false,
    "description": "Tocas un objeto durante el lanzamiento del conjuro. Si se trata de un objeto mágico de un objeto imbuido de magia, averiguarás sus propiedades y cómo usarlas, si hace falta sintonizarse con él y cuántas cargas tiene, si corresponde. Si hay conjuros activos que afecten al objeto, sabrás cuáles son.\n\nSi el objeto se creó mediante un conjuro, averiguarás su nombre. Si tocas a una criatura en lugar de un objeto, averiguarás qué conjuros activos le afectan en ese momento, si hay alguno.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ILUSIÓN MENOR",
    "level": 0,
    "school": "Ilusionismo",
    "classes": [
      "bardo",
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": false,
      "s": true,
      "m": true,
      "material": "un poco de vellón"
    },
    "duration": "1 minuto",
    "ritual": false,
    "concentration": false,
    "description": "Creas un sonido o una imagen de un objeto situado dentro del alcance que permanecerá hasta que termine el conjuro. Consulta las descripciones a continuación para conocer sus efectos. La ilusión termina si lanzas el conjuro de nuevo.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ILUSIÓN PROGRAMADA",
    "level": 6,
    "school": "Ilusionismo",
    "classes": [
      "bardo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies / 30 pies de cubo",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "polvo de jade con un valor de al menos 25 po"
    },
    "duration": "Hasta que sea disipado",
    "ritual": false,
    "concentration": false,
    "description": "Creas una ilusión de un objeto, una criatura u otro tipo de fenómeno visible dentro del alcance que se activa cuando se produce una condición específica. Hasta entonces, la ilusión es imperceptible. No puede tener un tamaño mayor que un cubo de 30 pies de lado y, cuando lanzas el conjuro, tú decides cómo se comporta y el sonido que emite.\n\nEsta actuación programada puede durar hasta 5 minutos. Cuando se produzca la condición especificada, la ilusión se activará y actuará de la manera que hayas descrito. En cuanto finalice su actuación, desaparecerá y permanecerá inactiva durante 10 minutos, tras lo cual podrá volver a activarse la ilusión.\n\nLa condición puede ser tan genérica o detallada como quieras, aunque debe basarse en fenómenos visuales o audibles que se produzcan a 30 pies o menos del área.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "cube",
      "sizeFt": 30
    }
  },
  {
    "name": "IMAGEN MAYOR",
    "level": 3,
    "school": "Ilusionismo",
    "classes": [
      "bardo",
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies / 20 pies de cubo",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un poco de vellón"
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Creas una imagen de un objeto, una criatura u otro tipo de fenómeno visible cuyas dimensiones no excedan las de un cubo de 20 pies de lado. La imagen aparece en un sitio que puedas ver dentro del alcance y se mantiene hasta que termine el conjuro. Parece real e incluye sonidos, olores y temperatura apropiados para lo que se representa, pero no puede hacer daño ni provocar estados.\n\nSi estás dentro del alcance de la ilusión, puedes utilizar una acción de magia para moverla a otro sitio dentro de dicho alcance. Al cambiarla de sitio, puedes alterar su apariencia de forma que sus movimientos parezcan naturales. Por ejemplo, si creas la imagen de una criatura y la mueves, puedes alterarla de forma que parezca estar andando.\n\nDe forma similar, puedes hacer que la ilusión produzca distintos sonidos en diferentes momentos e incluso mantener una conversación, por ejemplo. La interacción física con la imagen revela que es una ilusión, ya que las cosas pueden atravesarla.\n\nSi una criatura emplea una acción de estudiar para examinar la imagen, puede determinar que es una ilusión si supera una prueba de Inteligencia (Investigación) contra tu CD de salvación de conjuros.\n\nSi la criatura descubre que la imagen es una ilusión, no se dejará engañar por ella y sus otras cualidades sensoriales se irán desvaneciendo para esa criatura.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El conjuro durará hasta que sea disipado y no requerirá concentración si se lanza con un espacio de conjuro de nivel 4 o superior."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "cube",
      "sizeFt": 20
    }
  },
  {
    "name": "IMAGEN MÚLTIPLE",
    "level": 2,
    "school": "Ilusionismo",
    "classes": [
      "bardo",
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un poco de vellón"
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "En tu espacio aparecen tres duplicados ilusorios de ti. Hasta que el conjuro termine, estos duplicados se mueven a la vez que tú e imitan tus acciones cambiando de posición, por lo que es imposible saber cuál es la imagen real. Cada vez que una criatura te acierte con una tirada de ataque mientras dure el conjuro, tira 1d6 por cada uno de tus duplicados restantes.\n\nSi cualquiera de los resultados es de 3 o más, uno de los duplicados recibe el golpe en tu lugar y es destruido. Por lo demás, los duplicados ignoran el resto del daño y efectos. Cuando los tres duplicados son destruidos, el conjuro termina.\n\nUna criatura no se verá afectada por este conjuro si tiene el estado de cegada, visión ciega o visión verdadera.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "IMAGEN SILENCIOSA",
    "level": 1,
    "school": "Ilusionismo",
    "classes": [
      "bardo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies / 15 pies de cubo",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un poco de vellón"
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Creas una imagen de un objeto, una criatura u otro tipo de fenómeno visible cuyas dimensiones no excedan las de un cubo de 15 pies de lado. La imagen aparece en un sitio dentro del alcance y se mantiene hasta el final del conjuro. La imagen es solamente visual; no está acompañada de sonido, olor u otros efectos sensoriales.\n\nComo acción de magia, puedes mover la imagen a cualquier sitio dentro del alcance. Al cambiarla de sitio, puedes alterar su apariencia de forma que sus movimientos parezcan naturales. Por ejemplo, si creas la imagen de una criatura y la mueves, puedes alterarla de forma que parezca estar andando.\n\nLa interacción física con la imagen revela que es una ilusión, ya que las cosas pueden atravesarla. Si una criatura emplea una acción de estudiar para examinar la imagen, puede determinar que es una ilusión si supera una prueba de Inteligencia (Investigación) contra tu CD de salvación de conjuros.\n\nSi la criatura descubre que la imagen es una ilusión, no se dejará engañar por ella.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "cube",
      "sizeFt": 15
    }
  },
  {
    "name": "IMPACTO CERTERO",
    "level": 0,
    "school": "Adivinación",
    "classes": [
      "bardo",
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": false,
      "s": true,
      "m": true,
      "material": "un arma con la que tengas competencia y que valga al menos 1 pc"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Un destello de perspicacia mágica te guía y haces un ataque con el arma empleada para lanzar el conjuro. El ataque usa tu aptitud mágica para las tiradas de ataque y de daño en lugar de la Fuerza o la Destreza.\n\nSi el ataque inflige daño, puede ser radiante o del tipo de daño normal del arma (a tu elección).",
    "tables": [],
    "sections": [
      {
        "title": "Mejora de truco",
        "text": "Independientemente de si haces daño radiante o del tipo normal del arma, el ataque inflige daño radiante adicional cuando alcanzas los niveles 5 (1d6), 11 (2d6) y 17 (3d6)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "IMPONER MALDICIÓN",
    "level": 3,
    "school": "Nigromancia",
    "classes": [
      "bardo",
      "clerigo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Tocas a una criatura, que deberá superar una tirada de salvación de Sabiduría o quedará maldecida hasta que el conjuro termine. Hasta que se rompa la maldición, el objetivo sufrirá uno de los siguientes efectos a tu elección:\n\n• Elige una característica. El objetivo tendrá desventaja en las pruebas de característica y tiradas de salvación hechas con esa característica.\n\n• El objetivo tendrá desventaja en las tiradas de ataque contra ti.\n\n• En combate, el objetivo deberá superar una tirada de salvación de Sabiduría al principio de cada uno de sus turnos o se verá obligado a llevar a cabo la acción de esquivar ese turno.\n\n• Si causas daño al objetivo con una tirada de ataque o un conjuro, recibirá 1d8 de daño necrótico adicional.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "INDETECTABLE",
    "level": 3,
    "school": "Abjuración",
    "classes": [
      "bardo",
      "explorador",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una pizca de diamante en polvo que valga al menos 25 po, que se consume como parte del conjuro"
    },
    "duration": "8 horas",
    "ritual": false,
    "concentration": false,
    "description": "Hasta que termine el conjuro, escondes a un objetivo que toques ante los conjuros de adivinación. Este puede ser una criatura voluntaria, o un lugar o un objeto que no midan más de 10 pies en ninguna de sus dimensiones. El objetivo no podrá ser el objetivo de conjuros de adivinación ni podrá ser percibido mediante sensores mágicos de escudriñamiento.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "INFLIGIR HERIDAS",
    "level": 1,
    "school": "Nigromancia",
    "classes": [
      "clerigo"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Una criatura a la que toques hace una tirada de salvación de Constitución; sufrirá 2d10 de daño necrótico si la falla o la mitad del daño si la supera.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d10 por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "INFUSIÓN ELEMENTAL DE SONGAL",
    "level": 5,
    "school": "Transmutación",
    "classes": [
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal / 15 pies de emanación",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una perla valorada en 100 po"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Te imbuyes con el poder elemental de los genios. Hasta que el conjuro termine, obtienes los siguientes beneficios:\n\n• **Inmunidad Elemental.**\nCuando lanzas este conjuro, eliges uno de los siguientes tipos de daño: ácido, frío, fuego, relámpago o trueno. Obtienes resistencia al tipo elegido.\n\n• **Pulso Elemental.**\nCuando lanzas este conjuro y al inicio de cada uno de tus turnos, liberas una explosión de energía elemental en una emanación de 15 pies. Cada criatura de tu elección dentro del área debe realizar una tirada de salvación de Destreza. Si falla, recibe 2d6 de daño del tipo elegido y queda derribada. Si la supera, recibe la mitad del daño y no queda derribada.\n\n• **Vuelo.**\nObtienes una velocidad de vuelo de 30 pies y puedes flotar.\n\n• **Lanzamiento como Conjuro de Círculo.**\nLa duración pasa a ser Concentración, hasta 10 minutos. Por cada lanzador secundario, puedes designar una criatura adicional para que obtenga los beneficios del conjuro.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 15,
      "measure": "radius"
    }
  },
  {
    "name": "INMOVILIZAR MONSTRUO",
    "level": 5,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "90 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un trozo de hierro recto"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Elige a una criatura que puedas ver dentro del alcance. El objetivo deberá superar una tirada de salvación de Sabiduría o tendrá el estado de paralizado hasta que termine el conjuro. Al final de cada uno de sus turnos, el objetivo repite la tirada de salvación y, si tiene éxito, se librará del conjuro.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Puedes hacer objetivo a una criatura adicional por cada nivel por encima de 5 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "INMOVILIZAR PERSONA",
    "level": 2,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "brujo",
      "clerigo",
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un trozo de hierro recto"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Elige a un humanoide que puedas ver dentro del alcance. El objetivo deberá superar una tirada de salvación de Sabiduría o tendrá el estado de paralizado hasta que termine el conjuro. Al final de cada uno de sus turnos, el objetivo repite la tirada de salvación y, si tiene éxito, se librará del conjuro.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Puedes hacer objetivo a un humanoide adicional por cada nivel por encima de 2 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "INSECTO GIGANTE",
    "level": 4,
    "school": "Conjuración",
    "classes": [
      "druida"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Invocas una araña, una avispa o un ciempiés gigantes (a tu elección cuando lanzas el conjuro). Se manifiesta en un espacio sin ocupar que puedas ver dentro del alcance y utiliza el perfil de **Insecto gigante**. La forma que elijas determina ciertos aspectos de su perfil.\n\nLa criatura desaparecerá si sus puntos de golpe se reducen a 0 o si el conjuro termina. La criatura se considera un aliado para tus aliados y para ti. En combate, la criatura comparte tu orden de iniciativa, pero su turno va justo después del tuyo, obedece tus órdenes verbales (no requiere acción) y, si no le das ninguna, realiza la acción de esquivar y usa su movimiento para evitar el peligro.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Usa el nivel del espacio de conjuro para determinar el nivel del conjuro en el perfil."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "INVERTIR LA GRAVEDAD",
    "level": 7,
    "school": "Transmutación",
    "classes": [
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "100 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un imán natural y virutas de hierro"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Este conjuro invierte la gravedad en un cilindro de 50 pies de radio y 100 pies de alto centrado en un punto dentro del alcance. Todas las criaturas y objetos dentro de la zona que no estén fijados al suelo caerán hacia arriba y llegarán a la parte superior del cilindro. Una criatura puede hacer una tirada de salvación de Destreza para agarrarse a un objeto fijo a su alcance y así evitar la caída hacia arriba. Si un techo o un objeto fijo se interpone en la caída, las criaturas y objetos chocan contra él como harían en una caída normal hacia abajo. Si una criatura u objeto llega a la parte superior del cilindro sin chocarse con nada, permanecerá allí flotando hasta que el conjuro termine. Cuando ocurra, las criaturas y objetos afectados caerán hacia abajo.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "INVISIBILIDAD",
    "level": 2,
    "school": "Ilusionismo",
    "classes": [
      "bardo",
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una pestaña envuelta en goma arábiga"
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Una criatura a la que tocas tiene el estado de invisible hasta que el conjuro termine. El conjuro terminará inmediatamente después de que el objetivo haga una tirada de ataque, cause daño o lance un conjuro.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Puedes hacer objetivo a una criatura adicional por cada nivel por encima de 2 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "INVISIBILIDAD MEJORADA",
    "level": 4,
    "school": "Ilusionismo",
    "classes": [
      "bardo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Una criatura a la que tocas tiene el estado de invisible hasta que el conjuro termine.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "INVOCACIÓN INSTANTÁNEA DE DRAWMIJ",
    "level": 6,
    "school": "Conjuración",
    "classes": [
      "mago"
    ],
    "casting_time": "1 minuto o un ritual",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un zafiro que valga al menos 1000 po"
    },
    "duration": "Hasta que sea disipado",
    "ritual": true,
    "concentration": false,
    "description": "Tocas el zafiro empleado en el lanzamiento y un objeto que pese 10 libras o menos y cuya dimensión más grande sea de 5 pies o menos. El conjuro deja una marca invisible en su superficie y graba de la misma forma el nombre del objeto en el zafiro. Cada vez que lances este conjuro, deberás usar un zafiro distinto.\n\nA partir de entonces, podrás emplear una acción de magia para decir el nombre del objeto y aplastar el zafiro. El objeto aparecerá en tu mano al instante, sin importar las distancias físicas o interplanares, y el conjuro terminará. Si otra criatura sostiene o lleva el objeto consigo, aplastar el zafiro no lo llevará hasta ti.\n\nEn su lugar, descubrirás quién es la criatura que lo tiene y su paradero actual.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "INVOCAR ABERRACIÓN",
    "level": 4,
    "school": "Conjuración",
    "classes": [
      "brujo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "90 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un tentáculo en salmuera y un globo ocular en un vial con incrustaciones de platino que valga al menos 400 po"
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Invocas un espíritu aberrante que se manifiesta en un espacio sin ocupar que puedas ver dentro del alcance y usa el perfil del espíritu aberrante. Cuando lances el conjuro, elige azotamentes, contemplador o slaad. La criatura se parecerá a una aberración de ese tipo, lo que determinará ciertos detalles de su perfil.\n\nLa criatura desaparecerá si sus puntos de golpe se reducen a 0 o si el conjuro termina. La criatura se considera un aliado para tus aliados y para ti. En combate, comparte tu orden de iniciativa, pero su turno va justo después del tuyo, obedece tus órdenes verbales (no requiere acción) y, si no le das ninguna, realiza la acción de esquivar y usa su movimiento para evitar el peligro.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "INVOCAR AUTÓMATA",
    "level": 4,
    "school": "Conjuración",
    "classes": [
      "mago"
    ],
    "casting_time": "Acción",
    "range": "90 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una caja de seguridad que valga al menos 400 po"
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Invocas el espíritu de un autómata, que se manifiesta en un espacio sin ocupar que puedas ver dentro del alcance y usa el perfil del espíritu autómata. Cuando lances el conjuro, elige un material: arcilla, metal o piedra. La criatura parecerá una estatua animada (tú decides el aspecto) hecha del material en cuestión, lo que determinará ciertos detalles de su perfil.\n\nLa criatura desaparecerá si sus puntos de golpe se reducen a 0 o si el conjuro termina. La criatura se considera un aliado para tus aliados y para ti. En combate, la criatura comparte tu orden de iniciativa, pero su turno va justo después del tuyo, obedece tus órdenes verbales (no requiere acción) y, si no le das ninguna, realiza la acción de esquivar y usa su movimiento para evitar el peligro.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "INVOCAR BESTIA",
    "level": 2,
    "school": "Conjuración",
    "classes": [
      "druida",
      "explorador"
    ],
    "casting_time": "Acción",
    "range": "90 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una pluma, un poco de pelaje y cola de pez dentro de una bellota bañada en oro que valga al menos 200 po"
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Invocas un espíritu bestial que se manifiesta en un espacio sin ocupar que puedas ver dentro del alcance y usa el perfil del espíritu bestial. Cuando lances el conjuro, elige un hábitat: tierra, mar o aire. La criatura se parecerá a un animal de tu elección de ese hábitat, lo que determinará ciertos detalles de su perfil.\n\nLa criatura desaparecerá si sus puntos de golpe se reducen a 0 o si el conjuro termina. La criatura se considera un aliado para tus aliados y para ti. En combate, la criatura comparte tu orden de iniciativa, pero su turno va justo después del tuyo, obedece tus órdenes verbales (no requiere acción) y, si no le das ninguna, realiza la acción de esquivar y usa su movimiento para evitar el peligro.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Usa el nivel del espacio de conjuro para determinar el nivel del conjuro en el perfil."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "INVOCAR CELESTIAL",
    "level": 5,
    "school": "Conjuración",
    "classes": [
      "clerigo",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "90 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un relicario que valga al menos 500 po"
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Invocas un espíritu celestial que se manifiesta con una forma angelical en un espacio sin ocupar que puedas ver dentro del alcance y usa el perfil del espíritu celestial. Cuando lances el conjuro, elige defensor o vengador. Tu elección determinará ciertos detalles de su perfil.\n\nLa criatura desaparecerá si sus puntos de golpe se reducen a 0 o si el conjuro termina. La criatura se considera un aliado para tus aliados y para ti. En combate, la criatura comparte tu orden de iniciativa, pero su turno va justo después del tuyo, obedece tus órdenes verbales (no requiere acción) y, si no le das ninguna, realiza la acción de esquivar y usa su movimiento para evitar el peligro.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Usa el nivel del espacio de conjuro para determinar el nivel del conjuro en el perfil."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "INVOCAR DRAGÓN",
    "level": 5,
    "school": "Conjuración",
    "classes": [
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un objeto con la imagen de un dragón grabada en él que valga al menos 500 po"
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Invocas el espíritu de un dragón, que se manifiesta en un espacio sin ocupar que puedas ver dentro del alcance y usa el perfil de **Espíritu dracónico**. La criatura desaparecerá si sus puntos de golpe se reducen a 0 o si el conjuro termina. La criatura se considera un aliado para tus aliados y para ti.\n\nEn combate, la criatura comparte tu orden de iniciativa, pero su turno va justo después del tuyo, obedece tus órdenes verbales (no requiere acción) y, si no le das ninguna, realiza la acción de esquivar y usa su movimiento para evitar el peligro.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "INVOCAR ELEMENTAL",
    "level": 4,
    "school": "Conjuración",
    "classes": [
      "druida",
      "explorador",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "90 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "aire, un guijarro, ceniza y agua dentro de un vial con incrustaciones de oro que valga al menos 400 po"
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Invocas un espíritu elemental que se manifiesta en un espacio sin ocupar que puedas ver dentro del alcance y usa el perfil del espíritu elemental. Cuando lances el conjuro, elige un elemento: agua, aire, fuego o tierra. La criatura se parecerá a un ser bípedo envuelto en el elemento elegido, lo que determinará ciertos detalles de su perfil.\n\nLa criatura desaparecerá si sus puntos de golpe se reducen a 0 o si el conjuro termina. La criatura se considera un aliado para tus aliados y para ti. En combate, la criatura comparte tu orden de iniciativa, pero su turno va justo después del tuyo, obedece tus órdenes verbales (no requiere acción) y, si no le das ninguna, realiza la acción de esquivar y usa su movimiento para evitar el peligro.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Usa el nivel del espacio de conjuro para determinar el nivel del conjuro en el perfil."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "INVOCAR FEÉRICO",
    "level": 3,
    "school": "Conjuración",
    "classes": [
      "brujo",
      "druida",
      "explorador",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "90 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una flor bañada. en oro que valga al menos 300 po"
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Invocas un espíritu feérico que se manifiesta en un espacio sin ocupar que puedas ver dentro del alcance y usa el perfil del espíritu feérico. Cuando lances el conjuro, elige un estado de ánimo: alegre, burlón o enfurecido. La criatura se parecerá a un ser feérico de tu elección con ese estado de ánimo, lo que determinará ciertos detalles de su perfil.\n\nLa criatura desaparecerá si sus puntos de golpe se reducen a 0 o si el conjuro termina. La criatura se considera un aliado para tus aliados y para ti. En combate, la criatura comparte tu orden de iniciativa, pero su turno va justo después del tuyo, obedece tus órdenes verbales (no requiere acción) y, si no le das ninguna, realiza la acción de esquivar y usa su movimiento para evitar el peligro.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "INVOCAR INFERNAL",
    "level": 6,
    "school": "Conjuración",
    "classes": [
      "brujo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "90 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un vial con sangre que valga al menos 600 po"
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Invocas un espíritu infernal que se manifiesta en un espacio sin ocupar que puedas ver dentro del alcance y usa el perfil del espíritu infernal. Cuando lances el conjuro, elige demonio, diablo o yugoloth. La criatura se parecerá a un infernal del tipo elegido, lo que determinará ciertos detalles de su perfil.\n\nLa criatura desaparecerá si sus puntos de golpe se reducen a 0 o si el conjuro termina. La criatura se considera un aliado para tus aliados y para ti. En combate, la criatura comparte tu orden de iniciativa, pero su turno va justo después del tuyo, obedece tus órdenes verbales (no requiere acción) y, si no le das ninguna, realiza la acción de esquivar y usa su movimiento para evitar el peligro.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Usa el nivel del espacio de conjuro para determinar el nivel del conjuro en el perfil."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "INVOCAR MUERTO VIVIENTE",
    "level": 3,
    "school": "Nigromancia",
    "classes": [
      "brujo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "90 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una calavera bañada en oro que valga al menos 300 po"
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Invocas un espíritu muerto viviente que se manifiesta en un espacio sin ocupar que puedas ver dentro del alcance y usa el perfil del espíritu muerto viviente. Cuando lances el conjuro, elige la forma de la criatura: esquelética, fantasmal o pútrida. El espíritu se parecerá a un muerto viviente con la forma elegida, lo que determinará ciertos detalles de su perfil.\n\nLa criatura desaparecerá si sus puntos de golpe se reducen a 0 o si el conjuro termina. La criatura se considera un aliado para tus aliados y para ti. En combate, la criatura comparte tu orden de iniciativa, pero su turno va justo después del tuyo, obedece tus órdenes verbales (no requiere acción) y, si no le das ninguna, realiza la acción de esquivar y usa su movimiento para evitar el peligro.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Usa el nivel del espacio de conjuro para determinar el nivel del conjuro en el perfil."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "JAULA DE FUERZA",
    "level": 7,
    "school": "Evocación",
    "classes": [
      "bardo",
      "brujo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "100 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "polvo de rubí que valga al menos 1500 po, que se consume como parte del conjuro"
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Una prisión inmóvil e invisible con forma de cubo y compuesta de fuerza mágica surge en una zona de tu elección dentro del alcance. Puede ser una jaula o una caja de paredes sólidas, según desees. Una prisión con forma de jaula puede tener hasta 20 pies de lado y estar hecha de barrotes de 1/2 pulgada de diámetro separados 1/2 pulgada entre sí. Una prisión con forma de caja puede tener hasta 10 pies de lado. Creará una barrera sólida que impida que cualquier materia la atraviese y bloqueará cualquier conjuro que se lance a esa zona o desde ella. Cuando lances el conjuro, cualquier criatura que esté completamente dentro del área de la jaula quedará atrapada en ella. A las criaturas que se encuentren solo parcialmente dentro del área o sean demasiado grandes para caber en ella se las empujará lejos del centro de la jaula hasta estar completamente fuera de la zona. Una criatura que esté dentro de la jaula no puede salir de ella por medios que no sean mágicos. Si la criatura intenta usar el teletransporte o el viaje interplanar para huir, primero deberá hacer una tirada de salvación de Carisma. Si la supera, podrá usar esa magia para salir de la jaula. Si falla la tirada, no saldrá y se perderá el espacio de conjuro o el efecto. La jaula también se extiende hasta el Plano Etéreo e impide el viaje etéreo. Este conjuro no se puede eliminar mediante disipar magia.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "LABERINTO",
    "level": 8,
    "school": "Conjuración",
    "classes": [
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Destierras a una criatura que puedas ver dentro del alcance a un semiplano laberíntico. El objetivo permanecerá allí hasta que termine el conjuro o hasta que escape del laberinto. El objetivo puede llevar a cabo una acción de estudiar para intentar escapar.\n\nCuando lo haga, realizará una prueba de Inteligencia (Investigación) con CD 20. Si la supera, escapará y el conjuro terminará.\n\nCuando el conjuro termine, el objetivo reaparecerá en el espacio que abandonó o en el espacio sin ocupar más cercano si dicho espacio está ocupado.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "LABIA",
    "level": 8,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "brujo"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Hasta que el conjuro termine, cuando hagas una prueba de Carisma, puedes sustituir el resultado de la tirada por un 15.\n\nAdemás, digas lo que digas, cualquier magia usada para detectar si dices la verdad indicará que la estás diciendo.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "LANZA PLATEADA DE LAERAL",
    "level": 3,
    "school": "Evocación",
    "classes": [
      "clerigo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal / 120 pies de línea",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una lanza de plata valorada en 250 po"
    },
    "duration": "Instantánea",
    "ritual": false,
    "concentration": false,
    "description": "Una explosión de energía plateada surge de ti formando una línea de 120 pies de largo y 5 pies de ancho. Cada criatura de tu elección dentro de la línea debe realizar una tirada de salvación de Fuerza. Si falla, recibe 3d10 de daño de fuerza y queda derribada. Si la supera, recibe la mitad del daño y no queda derribada.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "line",
      "sizeFt": 120
    }
  },
  {
    "name": "LEVANTAR MALDICIÓN",
    "level": 3,
    "school": "Abjuración",
    "classes": [
      "brujo",
      "clerigo",
      "mago",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Con tan solo tocar a una criatura o un objeto, eliminarás todas las maldiciones que le afecten. Si el objetivo es un objeto mágico maldito, la maldición permanecerá, pero este conjuro romperá la sintonización del objeto con el dueño, lo que le permitirá quitárselo o deshacerse de él.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "LEVITAR",
    "level": 2,
    "school": "Transmutación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un muelle de metal"
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Una criatura o un objeto suelto de tu elección que puedas ver dentro del alcance se eleva verticalmente hasta 20 pies y se mantiene suspendido hasta que el conjuro termine. El conjuro puede hacer levitar un objeto que pese hasta 500 libras y no afecta a una criatura no voluntaria que supere una tirada de salvación de Constitución. El objetivo solo puede moverse empujándose o tirando de un objeto fijo o una superficie a su alcance (como una pared o techo), lo que le permite desplazarse como si estuviera trepando. En tu turno, puedes variar la altitud del objetivo hasta 20 pies en cualquier sentido. Si tú mismo eres el objetivo, te puedes mover hacia arriba o abajo como parte de tu movimiento. En caso contrario, puedes usar una acción de magia para mover al objetivo, que deberá permanecer dentro del alcance del conjuro.\n\nCuando el conjuro termine, el objetivo flotará suavemente hasta llegar al suelo si todavía está en el aire.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "LIBERTAD DE MOVIMIENTO",
    "level": 4,
    "school": "Abjuración",
    "classes": [
      "bardo",
      "clerigo",
      "druida",
      "explorador"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una tira de cuero"
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Tocas a una criatura voluntaria.\n\nHasta que termine el conjuro, el movimiento del objetivo no se ve afectado por el terreno difícil y los conjuros y otros efectos mágicos no pueden reducir su velocidad ni hacer que tenga los estados de apresado o paralizado.\n\nAdemás, el objetivo tiene una velocidad nadando igual a su velocidad.\n\nEl objetivo también puede gastar 5 pies de movimiento para escapar automáticamente de ataduras no mágicas, como unas esposas o una criatura que le imponga el estado de agarrado.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Puedes hacer objetivo a una criatura adicional por cada nivel por encima de 4 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "LLAMA PERMANENTE",
    "level": 2,
    "school": "Evocación",
    "classes": [
      "clerigo",
      "druida",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque / 20 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "polvo de rubí que valga al menos 50 po, que se consume como parte del conjuro"
    },
    "duration": "Hasta que sea disipado",
    "ritual": false,
    "concentration": false,
    "description": "Una llama surge de un objeto que toques. El efecto emite una luz brillante en un radio de 20 pies y una luz tenue 20 pies más allá. Parece una llama normal, pero no genera calor ni consume combustible.\n\nLa llama se puede tapar u ocultar, pero no se puede apagar ni extinguir.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 20,
      "measure": "radius"
    }
  },
  {
    "name": "LLAMA SAGRADA",
    "level": 0,
    "school": "Evocación",
    "classes": [
      "clerigo"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Un fulgor de llamas desciende sobre una criatura que puedas ver dentro del alcance. El objetivo deberá superar una tirada de salvación de Destreza o sufrirá 1d8 de daño radiante. No podrá beneficiarse de la cobertura media o tres cuartos en esta tirada.",
    "tables": [],
    "sections": [
      {
        "title": "Mejora de truco",
        "text": "El daño aumenta en 1d8 cuando alcanzas los niveles 5 (2d8), 11 (3d8) y 17 (4d8)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "LLAMAR AL RELÁMPAGO",
    "level": 3,
    "school": "Conjuración",
    "classes": [
      "druida"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Una nube de tormenta aparece en un punto dentro del alcance que puedas ver por encima de ti. La nube adopta la forma de un cilindro de 10 pies de altura y 60 pies de radio. Cuando lances el conjuro, elige un punto que puedas ver bajo la nube y de ella caerá un relámpago hacia ese punto. Todas las criaturas a 5 pies o menos de ese punto hacen una tirada de salvación de Destreza; sufrirán 3d10 de daño de relámpago si la fallan o la mitad del daño si la superan. Hasta que el conjuro termine, puedes usar una acción de magia para volver a invocar otro relámpago y elegir como objetivo el mismo punto u otro distinto. Si estás al aire libre y hay una tormenta cuando lanzas este conjuro, te da el control de ella en vez de crear una nueva. En estas condiciones, el daño del conjuro aumenta en 1d10.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d10 por cada nivel por encima de 3 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "LOCALIZAR ANIMALES O PLANTAS",
    "level": 2,
    "school": "Adivinación",
    "classes": [
      "bardo",
      "druida",
      "explorador"
    ],
    "casting_time": "Acción o ritual",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "pelaje de un sabueso"
    },
    "duration": "Instantáneo",
    "ritual": true,
    "concentration": false,
    "description": "Describe o nombra un tipo concreto de bestia, criatura de tipo \"planta\" o planta no mágica. Descubres la dirección y la distancia hasta la criatura o la planta de ese tipo más cercana que esté a 5 millas o menos, siempre y cuando haya alguna.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "LOCALIZAR CRIATURA",
    "level": 4,
    "school": "Adivinación",
    "classes": [
      "bardo",
      "clerigo",
      "druida",
      "explorador",
      "mago",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "pelaje de un sabueso"
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Describe o nombra una criatura que conozcas. Presientes la dirección en la que se encuentra dicha criatura si está a 1000 pies o menos de ti. Si la criatura se está moviendo, conoces la dirección de su movimiento.\n\nEl conjuro puede localizar a una criatura específica que conozcas o a la criatura más cercana de un tipo específico (como un humano o un unicornio) si has visto a una criatura así de cerca (a 30 pies o menos) al menos una vez. Si una criatura que describas o nombres está adoptando una forma distinta, por ejemplo bajo los efectos de un conjuro de la carne a la piedra o polimorfar, este conjuro no la localiza.\n\nEl conjuro no puede localizar a una criatura si hay cualquier grosor de plomo que bloquee una ruta directa entre la criatura y tú.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "LOCALIZAR OBJETO",
    "level": 2,
    "school": "Adivinación",
    "classes": [
      "bardo",
      "clerigo",
      "druida",
      "explorador",
      "mago",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una ramita con forma de horquilla"
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Describe o nombra un objeto que conozcas. Presientes la dirección en la que se encuentra dicho objeto si está a 1000 pies o menos de ti. Si el objeto se está moviendo, conoces la dirección de su movimiento.\n\nEl conjuro puede localizar un objeto específico que conozcas si lo has visto de cerca (a 30 pies o menos) al menos una vez. Como alternativa, el conjuro puede localizar el objeto más cercano de un tipo particular, como un cierto tipo de ropa, joyas, muebles, herramientas o armas. El conjuro no puede localizar un objeto si hay cualquier grosor de plomo que bloquee una ruta directa entre dicho objeto y tú.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "LUCES DANZANTES",
    "level": 0,
    "school": "Ilusionismo",
    "classes": [
      "bardo",
      "hechicero",
      "mago",
      "segador"
    ],
    "casting_time": "Acción",
    "range": "120 pies / 10 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una pizca de fósforo"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Creas hasta cuatro luces del tamaño de antorchas dentro del alcance. Puedes darles la apariencia de antorchas, linternas u orbes luminosos, y levitarán hasta que el conjuro termine. Como alternativa, combinas las cuatro luces en una sola de tamaño Mediano y aspecto vagamente humanoide.\n\nEn ambos casos, cada luz proyecta una luz tenue en un radio de 10 pies.\n\nComo acción adicional, puedes mover las luces hasta 60 pies a otro espacio dentro del alcance. Cada luz debe estar a 20 pieso menos de otra luz creada por este conjuro y se desvanecerá si sale del alcance del mismo.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 10,
      "measure": "radius"
    }
  },
  {
    "name": "LUZ",
    "level": 0,
    "school": "Evocación",
    "classes": [
      "bardo",
      "clerigo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque / 20 pies de radio",
    "components": {
      "v": true,
      "s": false,
      "m": true,
      "material": "una luciérnaga o musgo fosforescente"
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Tocas un objeto Grande o más pequeño que nadie lleve o vista. Hasta que el conjuro termine, el objeto emitirá luz brillante en un radio de 20 pies y luz tenue otros 20 pies más allá. La luz puede tener el color que desees.\n\nTapar completamente el objeto con un material opaco bloquea la luz. El conjuro termina si lo vuelves a lanzar.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 20,
      "measure": "radius"
    }
  },
  {
    "name": "LUZ DEL DÍA",
    "level": 3,
    "school": "Evocación",
    "classes": [
      "clerigo",
      "druida",
      "explorador",
      "hechicero",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "60 pies / 60 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Hasta que el conjuro termine, una luz solar se extiende desde un punto dentro del alcance y llena una esfera de 60 pies de radio. La zona que cubre es de luz brillante y emite una luz tenue 60 pies más allá. Como alternativa, lanzas el conjuro sobre un objeto que no lleve o vista nadie, lo que hará que la luz solar llene una emanación de 60 pies que se origina en él.\n\nCubrir el objeto con algo opaco, como un cuenco o un casco, bloqueará la luz solar. Si cualquier zona del conjuro se superpone con una zona de oscuridad creada por un conjuro de nivel 3 o inferior, el conjuro que creó esa oscuridad se disipa.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 60,
      "measure": "radius"
    }
  },
  {
    "name": "LÁTIGO DE ESPINAS",
    "level": 0,
    "school": "Transmutación",
    "classes": [
      "druida"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "el tallo de una planta con espinas"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Creas un látigo similar a una enredadera cubierta de espinas que fustiga bajo tus órdenes a una criatura dentro del alcance. Haz un ataque de conjuro cuerpo a cuerpo contra el objetivo. Si acierta, el objetivo sufre 1d6 de daño perforante y, si es Grande o más pequeño, puedes arrastrarlo hasta 10 pies hacia ti.",
    "tables": [],
    "sections": [
      {
        "title": "Mejora de truco",
        "text": "El daño aumenta en 1d6 cuando alcanzas los niveles 5 (2d6), 11 (3d6) y 17 (4d6)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "MAL DE OJO",
    "level": 6,
    "school": "Nigromancia",
    "classes": [
      "bardo",
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Hasta que el conjuro termine, tus ojos se transforman en un vacío oscuro. Una criatura de tu elección que puedas ver a 60 pies o menos de ti debe superar una tirada de salvación de Sabiduría o verse afectada por uno de los efectos descritos a continuación, a tu elección, durante la duración del conjuro.\n\nEn cada uno de tus turnos mientras el conjuro esté activo, puedes usar una acción de magia para hacer objetivo a otra criatura que puedas ver dentro del alcance. No puedes volver a elegir como objetivo a una criatura que haya superado la tirada de salvación contra este lanzamiento del conjuro.\n\n**Efectos del mal de ojo**\n\nElige uno de los siguientes efectos cuando una criatura falle su tirada de salvación:\n\n• **Náuseas.** El objetivo queda envenenado.\n\n• **Pánico.** El objetivo queda asustado. Mientras esté asustado de este modo, en cada uno de sus turnos debe usar su acción para correr y alejarse de ti por la ruta más corta y segura disponible. Si el objetivo se mueve a un espacio que esté al menos a 60 pies de ti y desde el que no pueda verte, el efecto termina.\n\n• **Sueño.** El objetivo queda inconsciente. Se despierta si recibe daño o si otra criatura usa una acción para despertarlo.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "MALEFICIO",
    "level": 1,
    "school": "Encantamiento",
    "classes": [
      "brujo"
    ],
    "casting_time": "Acción adicional",
    "range": "90 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "el ojo petrificado de un tritón"
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Impones una maldición a una criatura que puedas ver dentro del alcance. Hasta que el conjuro termine, infliges 1d6 de daño necrótico adicional al objetivo siempre que le aciertes con una tirada de ataque.\n\nAdemás, elige una característica cuando lances el conjuro.\n\nEl objetivo tendrá desventaja en las pruebas que haga con la característica elegida. Silos puntos de golpe del objetivo se reducen a 0 antes de que el conjuro termine, puedes usar una acción adicional en un turno posterior para maldecir a una nueva criatura.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Tu concentración puede durar más si usas un espacio de conjuro de nivel 2 (hasta 4 horas), 3 o 4 (hasta 8 horas) o 5 o más (24 horas)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "MANO DE BIGBY",
    "level": 5,
    "school": "Evocación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una cáscara de huevo y un guante"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Creas una mano de energía mágica brillante de tamaño Grande en un espacio sin ocupar que puedas ver dentro del alcance. La mano permanece hasta que el conjuro termina y obedece tus órdenes, imitando los movimientos de tu propia mano.\n\nLa mano es un objeto mágico. Tiene CA 20 y una cantidad de puntos de golpe igual a tus puntos de golpe máximos. Si sus puntos de golpe se reducen a 0, el conjuro termina. La mano no ocupa el espacio en el que se encuentra.\n\nCuando lanzas el conjuro, y como acción adicional en cada uno de tus turnos posteriores, puedes mover la mano hasta 60 pies y luego usar uno de los efectos siguientes:\n\n**Efectos de la mano**\n\n• **Mano apresadora.** La mano intenta agarrar a una criatura Enorme o más pequeña que esté a 5 pies o menos de ella. El objetivo debe superar una tirada de salvación de Destreza o queda agarrado (CD igual a tu CD de salvación de conjuros). Mientras la mano agarre al objetivo, puedes usar una acción adicional para hacer que la mano lo aplaste, causándole 4d6 de daño contundente + tu modificador por aptitud mágica.\n\n• **Mano contundente.** La mano intenta empujar a una criatura Enorme o más pequeña que esté a 5 pies o menos de ella. El objetivo debe superar una tirada de salvación de Fuerza o es empujado hasta 5 pies, más 5 pies adicionales por tu modificador por aptitud mágica. La mano se mueve junto con el objetivo y permanece a 5 pies o menos de él.\n\n• **Mano interpuesta.** La mano te proporciona cobertura media contra ataques y otros efectos que se originen en su espacio o intenten atravesarlo. Además, el espacio de la mano se considera terreno difícil para tus enemigos.\n\n• **Puño cerrado.** La mano golpea a una criatura a 5 pies o menos de ella. Realiza un ataque de conjuro cuerpo a cuerpo. Si impacta, el objetivo recibe 5d8 de daño de fuerza.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño del puño cerrado aumenta en 2d8 y el daño de la mano apresadora aumenta en 2d6 por cada nivel por encima de 5 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "MANO DE MAGO",
    "level": 0,
    "school": "Conjuración",
    "classes": [
      "bardo",
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "1 minuto",
    "ritual": false,
    "concentration": false,
    "description": "Conjuras una mano espectral flotante en un punto de tu elección dentro del alcance. La mano dura hasta que el conjuro termine.\n\nAdemás, desaparecerá si en algún momento está a más de 30 pies de ti o si vuelves a lanzar este conjuro.\n\nCuando lances este conjuro, puedes utilizar la mano para manipular un objeto, abrir una puerta o un recipiente que no estén cerrados con llave, sacar un objeto de un recipiente abierto o guardarlo en él o verter el contenido de un vial. Como acción de magia en tus siguientes turnos, puedes volver a controlar la mano de esta forma. Como parte de la acción, puedes mover la mano hasta 30 pies.\n\nLa mano no puede atacar, activar objetos mágicos ni llevar más de 10 libras de peso.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "MANOS ARDIENTES",
    "level": 1,
    "school": "Evocación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal / 15 pies de cono",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Una fina capa de llamas se proyecta desde ti. Todas las criaturas situadas en un cono de 15 pies hacen una tirada de salvación de Destreza; sufrirán 3d6 de daño de fuego si la fallan o la mitad del daño si la superan. Los objetos inflamables dentro del cono que no lleve o vista nadie empezarán a arder.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d6 por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "cone",
      "sizeFt": 15
    }
  },
  {
    "name": "MANSIÓN MAGNÍFICA DE MORDENKAINEN",
    "level": 7,
    "school": "Conjuración",
    "classes": [
      "bardo",
      "mago"
    ],
    "casting_time": "1 minuto",
    "range": "300 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una puerta en miniatura que valga al menos 15 po"
    },
    "duration": "24 horas",
    "ritual": false,
    "concentration": false,
    "description": "Conjuras una puerta brillante dentro del alcance que permanece hasta que el conjuro termine. La puerta mide 5 pies de ancho y 10 pies de alto y lleva a una morada extradimensional. Tú y cualquier criatura que designes cuando lances el conjuro podréis entrar en la morada extradimensional mientras la puerta permanezca abierta. Puedes abrirla o cerrarla (no requiere acción) si estás a 90 pies o menos de ella. Mientras permanezca cerrada, es imperceptible. Al otro lado de la puerta encuentras un fastuoso recibidor, tras el cual se hallan numerosas estancias. La morada está limpia y es fresca y cálida. Puedes crear cualquier plano de planta que desees, pero no puede superar los 50 cubos contiguos, cada uno de 10 pies de lado. El lugar está amueblado y decorado como elijas y contiene comida suficiente como para servir un banquete de nueve platos a hasta 100 personas. Los muebles y otros objetos creados por este conjuro se convierten en humo si se sacan del lugar. El personal de servicio está compuesto de 100 sirvientes casi transparentes que atienden a todos los que entran. Tú decides la apariencia y el atuendo de estos sirvientes, que son invulnerables y obedecen tus órdenes. Los sirvientes pueden realizar las tareas que haría un humano, pero no pueden atacar ni realizar ninguna acción que dañaría directamente a otra criatura. Por lo tanto, pueden traer y llevar cosas, limpiar, arreglar y plegar ropa, encender fuegos, servir comida y vino, etc, aunque no pueden abandonar el lugar. Cuando el conjuro termina, todas las criaturas u objetos que queden en el espacio extradimensional son expulsados a los espacios sin ocupar más cercanos a la entrada.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "MANTO DEL CRUZADO",
    "level": 3,
    "school": "Evocación",
    "classes": [
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "Personal / 30 pies de emanación",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Irradias un aura mágica en una emanación de 30 pies. Mientras permanezcáis dentro, tus aliados y tú causaréis 1d4 de daño radiante adicional cuando acertéis con un arma o un ataque sin armas.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 30,
      "measure": "radius"
    }
  },
  {
    "name": "MARCA DEL CAZADOR",
    "level": 1,
    "school": "Adivinación",
    "classes": [
      "explorador"
    ],
    "casting_time": "Acción adicional",
    "range": "90 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Marcas mágicamente a una criatura que puedas ver dentro del alcance como tu presa. Hasta que el conjuro termine, infliges 1d6 de daño de fuerza adicional al objetivo siempre que le aciertes con una tirada de ataque. También tendrás ventaja en cualquier prueba de Sabiduría (Percepción o Supervivencia) que realices para buscarlo.\n\nSi los puntos de golpe del objetivo se reducen a 0 antes de que el conjuro termine, puedes emplear una acción adicional para transferir la marca a una nueva criatura que puedas ver dentro del alcance.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Tu concentración puede durar más si usas un espacio de conjuro de nivel 3 o 4 (hasta 8 horas) o 5 o más (hasta 24 horas)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "MARCHITAR",
    "level": 4,
    "school": "Nigromancia",
    "classes": [
      "brujo",
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Una criatura a la que puedas ver dentro del alcance deberá hacer una tirada de salvación de Constitución; sufrirá 8d8 de daño necrótico si la falla o la mitad del daño si la supera. Las criaturas de tipo \"planta\" fallan automáticamente la tirada. Como alternativa, haz objetivo a una planta no mágica que no sea una criatura, como un árbol o un arbusto. No hará una tirada de salvación: simplemente se marchitará y morirá.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d8 por cada nivel por encima de 4 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "MAREA DE PERDICIÓN",
    "level": 4,
    "school": "Conjuración",
    "classes": [
      "bardo",
      "clerigo",
      "brujo"
    ],
    "casting_time": "Acción",
    "range": "120 pies / 20 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "hollín y una anguila seca"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Creas una esfera de 20 pies de radio de niebla oscura y aceitosa dentro del alcance. La niebla es oscuridad mágica y permanece durante la duración o hasta que un viento fuerte, como el creado por el conjuro Ráfaga de Viento, la disperse.\n\nCada criatura dentro de la esfera cuando aparece deberá realizar una tirada de salvación de Sabiduría. Si falla, recibirá 5d6 de daño psíquico y restará 1d6 de sus tiradas de salvación hasta el final de su siguiente turno. Si la supera, recibirá la mitad del daño. Una criatura también debe hacer esta tirada cuando la esfera se mueve hacia su espacio, cuando entra en la esfera o cuando termina su turno en ella. Una criatura solo puede recibir este daño una vez por turno.\n\nLa esfera se mueve 10 pies alejándose de ti al final de cada uno de tus turnos.\n\n**Lanzamiento como Conjuro de Círculo.**\nRequiere al menos cinco lanzadores secundarios y un componente especial, una cuerda negra del Plano de Pandemónium, que el conjuro consume. La duración pasa a ser 1 minuto, sin Concentración, y la esfera persiste hasta dispersarse.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 20,
      "measure": "radius"
    }
  },
  {
    "name": "MASTÍN FIEL DE MORDENKAINEN",
    "level": 4,
    "school": "Conjuración",
    "classes": [
      "mago"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un silbato de plata"
    },
    "duration": "3 horas",
    "ritual": false,
    "concentration": false,
    "description": "Conjuras un perro guardián en un espacio sin ocupar que puedas ver dentro del alcance. El perro permanece hasta que el conjuro termine o hasta que os alejéis a más de 300 pies. Solo tú puedes verlo y es intangible e invulnerable.\n\nCuando una criatura Pequeña o de mayor tamaño se acerque a 30 pies o menos de él sin decir la contraseña que especifiques al lanzar el conjuro, el mastín empezará a ladrar ruidosamente.\n\nAdemás, tiene visión verdadera hasta 30 pies.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "MENSAJE",
    "level": 0,
    "school": "Transmutación",
    "classes": [
      "bardo",
      "druida",
      "hechicero",
      "mago",
      "segador"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": false,
      "s": true,
      "m": true,
      "material": "un alambre de cobre"
    },
    "duration": "1 asalto",
    "ritual": false,
    "concentration": false,
    "description": "Señalas a una criatura dentro del alcance y susurras un mensaje. El objetivo (y únicamente el objetivo) escucha el mensaje y puede responder con un susurro que solamente tú puedes oír. Puedes lanzar este conjuro a través de objetos físicos si conoces al objetivo. y sabes que está detrás de la barrera.\n\nEl silencio mágico, 1 pie de piedra, metal o madera o una lámina fina de plomo bloquean el conjuro.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "MENSAJERO ANIMAL",
    "level": 2,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "druida",
      "explorador"
    ],
    "casting_time": "Acción o ritual",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "unas migajas de comida"
    },
    "duration": "24 horas",
    "ritual": true,
    "concentration": false,
    "description": "Una bestia Diminuta de tu elección que puedas ver dentro del alcance deberá superar una tirada de salvación de Carisma o intentará enviar un mensaje por ti (si el valor de desafío del objetivo no es O, la supera automáticamente). Indica un lugar que hayas visitado y da una descripción general del destinatario, como \"una persona que lleva un uniforme de guardia de la ciudad\" o \"una enana pelirroja con un gorro puntiagudo\".\n\nAdemás, le transmites al animal un mensaje de hasta 25 palabras. Hasta que termine el conjuro, la bestia viajará hacia el lugar elegido y recorrerá aproximadamente 25 millas cada 24 horas o 50 millas si puede volar. Cuando llegue, la bestia entregará tu mensaje a la criatura que le hayas descrito e imitará tu forma de comunicarte. Si la bestia no llega a su destino antes de que el conjuro termine, el mensaje se pierde y la bestia regresa al lugar donde lanzaste el conjuro.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "La duración del conjuro aumenta en 48 horas por cada nivel por encima de 2 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "MENTE EN BLANCO",
    "level": 8,
    "school": "Abjuración",
    "classes": [
      "bardo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "24 horas",
    "ritual": false,
    "concentration": false,
    "description": "Hasta que el conjuro termine, una criatura voluntaria a la que toques tendrá inmunidad al daño psíquico y al estado de hechizada.\n\nAdemás, no se verá afectada por nada que pudiera percibir sus emociones o alineamiento, leer sus pensamientos o detectar mágicamente su ubicación, y ningún conjuro (ni siquiera deseo) puede conseguir información sobre el objetivo, observarlo desde lejos o controlar su mente.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "MOLDEAR LA PIEDRA",
    "level": 4,
    "school": "Transmutación",
    "classes": [
      "clerigo",
      "druida",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "arcilla blanda"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Tocas un objeto de piedra de tamaño Mediano o más pequeño, o una sección de piedra que no mida más de 5 pies en cualquier dimensión, y lo moldeas como desees. Por ejemplo, podrías convertir una piedra grande en un arma, una estatua o un cofre, o crear un pasaje pequeño a través de una pared con un grosor de 5 pies. También podrías transformar una puerta de piedra o su marco para dejarla sellada.\n\nEl objeto que crees puede tener hasta dos bisagras y un pestillo, pero no es posible dotarlo de detalles mecánicos más precisos.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "MOVER LA TIERRA",
    "level": 6,
    "school": "Transmutación",
    "classes": [
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una pala en miniatura"
    },
    "duration": "hasta 2 horas",
    "ritual": false,
    "concentration": true,
    "description": "Elige una zona de terreno que no tenga más de 40 pies de lado dentro del alcance. Puedes cambiar como quieras la forma de la tierra, la arena o la arcilla del área hasta que termine el conjuro. Puedes aumentar o reducir la elevación de la zona, crear o llenar una zanja, levantar o derribar una pared o formar una columna.\n\nLa extensión de cualquiera de estos cambios no puede superar la mitad de la dimensión más larga de la zona. Por ejemplo, si afectas a un cuadrado de 40 pies de lado, puedes crear una columna de hasta 20 pies de altura, aumentar o reducir la elevación del cuadrado hasta 20 pies, cavar una zanja de hasta 20 pies de profundidad, etc. Estos cambios tardan 10 minutos en completarse.\n\nComo la transformación de la zona se produce poco a poco, las criaturas que haya en ella generalmente no quedarán atrapadas por el movimiento del suelo ni sufrirán daños por ello. Al final de cada 10 minutos que pases concentrándote en el conjuro, podrás elegir una nueva zona de terreno que modificar dentro del alcance. Este conjuro no puede manipular la piedra natural ni las construcciones de piedra.\n\nLas rocas y las estructuras se desplazan para acomodar el nuevo terreno. Si la forma que le das al terreno hace que una estructura sea inestable, esta podría hundirse. De forma similar, este conjuro no afecta directamente al crecimiento vegetal y la tierra desplazada se lleva con ella cualquier planta que haya.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "MURO DE ESPINAS",
    "level": 6,
    "school": "Conjuración",
    "classes": [
      "druida"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un puñado de espinas vegetales"
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Creas un muro de maleza enmarañada que está repleta de espinas puntiagudas como agujas. Este muro aparecerá dentro del alcance sobre una superficie sólida y durará hasta que termine el conjuro. Eliges si crear un muro recto de hasta 60 pies de longitud, 10 pies de altura y 5 pies de grosor o un círculo de arbustos de hasta 20 pies de diámetro, 20 pies de altura y 5 pies de grosor. El muro bloquea la línea de visión.\n\nCuando aparezca el muro, todas las criaturas situadas en su área hacen una tirada de salvación de Destreza; sufrirán 7d8 de daño perforante si la fallan o la mitad de daño si la superan. Las criaturas pueden atravesar el muro, pero es un proceso lento y doloroso. Una criatura que atraviese el muro deberá gastar 4 pies de movimiento por cada 1 pie que avance.\n\nAdemás, la primera vez que una criatura entre en un espacio del muro o termine su turno allí, realizará una tirada de salvación de Destreza; sufrirá 7d8 de daño cortante si la falla o la mitad del daño si la supera Una criatura solo hace esta tirada una vez por turno.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Los dos tipos de daño aumentan en 1d8 por cada nivel por encima de 6 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "MURO DE FUEGO",
    "level": 4,
    "school": "Evocación",
    "classes": [
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un trozo de carbón"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Creas un muro de fuego en una superficie sólida dentro del alcance. Puedes formar un muro recto de hasta 60 pies de longitud, 20 pies de altura y 1 pie de grosor o un muro circular de hasta 20 pies de diámetro, 20 pies de altura y 1 pie de grosor. El muro es opaco y durará hasta que termine el conjuro.\n\nCuando aparezca el muro, todas las criaturas situadas en su área hacen una tirada de salvación de Destreza; sufrirán 5d8 de daño de fuego si la fallan o la mitad de daño si la superan. Un lado del muro, que seleccionas cuando lanzas el conjuro, causa 5d8 de daño de fuego a cada criatura que termine su turno a 10 pies o menos de ese lado o dentro del muro. Una criatura recibirá el mismo daño cuando entre en el muro por primera vez en un turno o termine su turno allí. El otro lado del muro no causa ningún daño.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d8 por cada nivel por encima de 4 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "MURO DE FUERZA",
    "level": 5,
    "school": "Evocación",
    "classes": [
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un trozo de vidrio"
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Un muro de fuerza invisible surge de la nada en un punto de tu elección dentro del alcance. Este muro adopta la orientación que tú elijas y puede ser tanto una barrera horizontal o vertical como estar situado en ángulo. También puede flotar o estar apoyado en una superficie sólida.\n\nPuedes darle forma de cúpula semiesférica o de globo con un radio de hasta 10 pies o puedes hacer que sea una superficie plana compuesta por hasta 10 paneles de 10 pies por 10 pies. Cada panel debe estar adyacente a otro panel. En cualquiera de las formas, el muro tiene un grosor de 1/4 pulgada y durará hasta que termine el conjuro.\n\nAl aparecer, si el muro atraviesa el espacio de una criatura, esta es empujada hacia un lado del muro (tú eliges cuál). Nada puede atravesar el muro físicamente. Es inmune a todo el daño y no se puede eliminar mediante disipar magia.\n\nSin embargo, un conjuro desintegrar destruye el muro al instante. El muro también se extiende hasta el Plano Etéreo e impide el viaje etéreo a través de él.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "MURO DE HIELO",
    "level": 6,
    "school": "Evocación",
    "classes": [
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un trozo de cuarzo"
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Creas un muro de hielo en una superficie sólida dentro del alcance. Puedes darle forma de cúpula semiesférica o de globo con un radio de hasta 10 pies o puedes hacer que sea una superficie plana compuesta por hasta 10 paneles cuadrados de 10 pies de lado. Cada panel debe estar adyacente a otro panel. En cualquiera de las formas, el muro tiene un grosor de 1 pie y durará hasta que termine el conjuro. Al aparecer, si el muro atraviesa el espacio de una criatura, esta es empujada hacia un lado del muro (tú eliges cuál) y hace una tirada de salvación de Destreza; sufrirá 10d6 de daño de frío si la falla o la mitad de daño si la supera. El muro es un objeto que se puede dañar y, por tanto, atravesar. Tiene una CA de 12, 30 puntos de golpe por cada sección de 10 pies de lado, inmunidad al daño de frío, psíquico y de veneno y vulnerabilidad al daño de fuego. Si se reduce una sección del muro de 10 pies de lado a 0 puntos de golpe, se destruirá y dejará una capa de aire gélido en el lugar que ocupaba. Si una criatura pasa por la capa de aire gélido por primera vez en un turno, deberá hacer una tirada de salvación de Constitución; sufrirá 5d6 de daño de frío si la falla o la mitad de daño si la supera.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño que causa el muro al aparecer aumenta en 2d6 y el que se sufre por cruzar la capa de aire géli do aumenta en 1d6 por cada nivel por encima de 6 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "MURO DE PIEDRA",
    "level": 5,
    "school": "Evocación",
    "classes": [
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un cubo de granito"
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Un muro no mágico de piedra sólida brota en un punto de tu elección dentro del alcance. Tiene 6 pulgadas de grosor y está compuesto de 10 paneles de 10 pies por 10 pies. Cada panel debe estar adyacente a otro panel. Como alternativa, puedes crear paneles de 10 pies por 20 pies cuyo grosor sea solo de 3 pulgadas. Al aparecer, si el muro atraviesa el espacio de una criatura, esta es empujada hacia un lado del muro (tú eliges cuál). Si una criatura fuera a quedar rodeada por todas partes por el muro (o por el muro y otra superficie sólida), puede hacer una tirada de salvación de Destreza. Si la supera, podrá usar su reacción para moverse hasta su velocidad y no quedar encerrada por el muro. El muro puede adoptar la forma que desees, pero no puede ocupar el mismo espacio que una criatura o un objeto. El muro no tiene por qué ser vertical ni apoyarse en una base firme. Sin embargo, sí debe fundirse con alguna masa de piedra existente que lo sostenga firmemente. Así, podrías usar este conjuro para formar un puente que cruce una sima o para crear una rampa. Si creas un muro que se extienda más de 20 pies, debes reducir a la mitad el tamaño de cada panel para crear soportes. Puedes moldear el muro de forma tosca para que tenga almenas y elementos similares. El muro es un objeto hecho de piedra que se puede dañar y, por tanto, atravesar. Cada panel tiene una CA de 15, 30 puntos de golpe por cada 1 pulgada de grosor e inmunidad al daño psíquico y de veneno. Si los puntos de golpe de un panel se reducen a 0, se destruye, lo que podría provocar que los paneles conectados se derrumben, a discreción de tu DM.\n\nSi mantienes la concentración en este conjuro durante toda su duración, el muro se vuelve permanente y no se puede disipar. De lo contrario, desaparece en cuanto el conjuro termine.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "MURO DE VIENTO",
    "level": 3,
    "school": "Evocación",
    "classes": [
      "druida",
      "explorador"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un abanico y una pluma"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Un muro conformado por un intenso viento surge del suelo en un punto de tu elección dentro del alcance. Puedes formar un muro de hasta 50 pies de longitud, 15 pies de altura y 1 pie de grosor. Puedes darle a ese muro la forma que quieras, siempre que trace una ruta continua por el suelo, y durará hasta que termine el conjuro.\n\nCuando aparezca el muro, todas las criaturas situadas en su área hacen una tirada de salvación de Fuerza; sufrirán 4d8 de daño contundente si la fallan o la mitad de daño si la superan. El viento fuerte mantiene a raya la niebla, el humo y otros gases. Las criaturas voladoras de tamaño Pequeño o menor no pueden atravesar el muro. Los materiales sueltos de poco peso que entran en el muro salen volando hacia arriba. Las flechas, los virotes y otros proyectiles ordinarios lanzados a objetivos que estén detrás del muro salen despedidos hacia arriba y fallan automáticamente. Los pedruscos lanzados por gigantes o máquinas de asedio y los proyectiles similares no se ven afectados. Las criaturas en forma gaseosa no pueden atravesarlo.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "MURO PRISMÁTICO",
    "level": 9,
    "school": "Abjuración",
    "classes": [
      "bardo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "10 minutos",
    "ritual": false,
    "concentration": false,
    "description": "Un plano de luz rutilante y multicolor forma un muro vertical opaco (de hasta 90 pies de largo, 30 pies de alto y 1 pulgada de grosor) centrado en un punto dentro del alcance. Como alternativa, le das al muro la forma de un globo de hasta 30 pies de diámetro centrado en un punto dentro del alcance. El muro permanecerá allí hasta que termine el conjuro. Si lo colocas en un espacio que ocupa una criatura, el conjuro termina al instante sin surtir efecto. El muro emite luz brillante hasta 100 pies y luz tenue 100 pies más allá. Las criaturas que indiques cuando lanzas el conjuro y tú podéis atravesar el muro y estar cerca de él sin sufrir daños. Si otra criatura que pueda ver el muro se acerca a 20 pies o menos de él, deberá superar una tirada de salvación de Constitución o tendrá el estado de cegada durante 1 minuto. El muro consta de siete capas, cada una de un color distinto. Cuando una criatura meta una mano en el muro o lo atraviese, lo debe hacer capa por capa hasta superarlas todas. Para cada una, deberá realizar una tirada de salvación de Destreza o quedará afectada por las propiedades de esa capa, con un efecto distinto. El muro, que tiene una CA de 10, se puede destruir capa por capa, en orden de rojo a violeta, por el medio específico para cada una de ellas. Si se destruye una capa, seguirá eliminada hasta que termine el conjuro. Campo antimagia no tiene efecto en el muro y disipar magia solo puede afectar a la capa violeta. Los efectos de cada capa prismática se detallan en la tabla.",
    "tables": [
      {
        "title": "Capas prismáticas",
        "columns": [
          "Capa",
          "Efecto"
        ],
        "rows": [
          [
            "1",
            "Roja. Si falla la tirada: 12d6 de daño de fuego. Si supera la tirada: la mitad de daño. Efectos adicionales: los ataques a distancia no mágicos no pueden atravesar esta capa, que se destruye si recibe al menos 25 de daño de frío."
          ],
          [
            "2",
            "Naranja. Si falla la tirada: 12d6 de daño de ácido. Si supera la tirada: la mitad de daño. Efectos adicionales: los ataques a distancia mágicos no atraviesan esta capa, que puede destruirse mediante un viento fuerte (como el que crea ráfaga de viento). 3"
          ],
          [
            "3",
            "Amarilla. Si falla la tirada: 12d6 de daño de relámpago. Si supera la tirada: la mitad de daño. Efectos adicionales: la capa se destruye si recibe al menos 60 de daño de fuerza. 4"
          ],
          [
            "4",
            "Verde. Si falla la tirada: 12d6 de daño de veneno. Si supera la tirada: la mitad de daño. Efectos adicionales: un conjuro pasamuros u otro del mismo nivel o superior que puedan abrir un portal en una superficie sólida destruirán esta capa. 5"
          ],
          [
            "5",
            "Azul. Si falla la tirada: 12d6 de daño de frío. Si supera la tirada: la mitad de daño. Efectos adicionales: la capa se destruye si recibe al menos 25 de daño de fuego. 6"
          ],
          [
            "6",
            "Añil. Si falla la tirada: el objetivo tendrá el estado de apresado y hará una tirada de salvación de Constitución al final de cada uno de sus turnos. Si la supera tres veces, el estado terminará. Si la falla tres veces, tendrá el estado de petrificado hasta que lo libere un efecto como el del conjuro restablecimiento mayor. Los éxitos y los fallos no tienen por qué ser consecutivos: lleva la cuenta de ambos hasta que el objetivo tenga tres de un mismo tipo. Efectos adicionales: no es posible lanzar conjuros a través de esta capa, que puede destruirse mediante la luz brillante del conjuro luz del día. 7."
          ],
          [
            "7",
            "Violeta. Si falla la tirada: el objetivo tendrá el estado de cegado y hará una tirada de salvación de Sabiduría al principio de tu siguiente turno. Si la supera, el estado terminará. Si la falla, el estado terminará y la criatura se teletransportará a otro plano de existencia (a elección de tu DM). Efectos adicionales: esta capa puede destruirse mediante disipar magia."
          ]
        ]
      }
    ],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "NUBE ANIQUILADORA",
    "level": 5,
    "school": "Conjuración",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Creas una esfera de una niebla amarillo-verdosa de 20 pies de radio centrada en un punto dentro del alcance. La niebla dura hasta que el conjuro termine o hasta que la disperse un viento intenso (por ejemplo, el que crea ráfaga de viento), lo que pondrá fin al conjuro. La zona que ocupa está muy oscura. Todas las criaturas situadas en la esfera hacen una tirada de salvación de Constitución; sufrirán 5d8 de daño de veneno si la fallan o la mitad del daño si la superan. Una criatura también deberá hacer esta tirada cuando la esfera entre en su espacio o cuando la criatura entre en la esfera o termine su turno en ella. Una criatura solo hace esta tirada una vez por turno. La esfera se aleja de ti 10 pies al principio de cada uno de tus turnos.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d8 por cada nivel por encima de 5 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "NUBE APESTOSA",
    "level": 3,
    "school": "Conjuración",
    "classes": [
      "bardo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "90 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un huevo podrido"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Creas una esfera de gas nauseabundo y amarillento de 20 pies de radio centrada en un punto dentro del alcance. La nube está muy oscura y permanece en el aire hasta que el conjuro termine o hasta que la disperse un viento fuerte (por ejemplo, el que crea ráfaga de viento). Todas las criaturas que comiencen su turno en la esfera deberán superar una tirada de salvación de Constitución o tendrán el estado de envenenadas hasta el final del turno actual. Mientras estén envenenadas de esta forma, no podrán realizar acciones ni acciones adicionales.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "NUBE DE DAGAS",
    "level": 2,
    "school": "Conjuración",
    "classes": [
      "bardo",
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un fragmento de cristal"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Conjuras dagas giratorias en un cubo de 5 pies centrado en un punto dentro del alcance. Todas las criaturas situadas en esa zona sufren 4d4 de daño cortante. Una criatura también recibe daño si entra en el cubo, si termina su turno en él o si el cubo entra en su espacio.\n\nUna criatura solo sufre este daño una vez por turno. En tus siguientes turnos, puedes usar una acción de magia para teletransportar el cubo hasta 30 pies.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 2d4 por cada nivel por encima de 2 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "NUBE DE OSCURECIMIENTO",
    "level": 1,
    "school": "Conjuración",
    "classes": [
      "druida",
      "explorador",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Creas una esfera de niebla de 20 pies de radio centrada en un punto dentro del alcance. La esfera está muy oscura y dura hasta que el conjuro termine o hasta que la disperse un viento fuerte (por ejemplo, el que crea ráfaga de viento).",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El radio de la niebla aumenta en 20 pies por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "NUBE INCENDIARIA",
    "level": 8,
    "school": "Conjuración",
    "classes": [
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "150 pies / 20 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Una nube turbulenta de humo y ascuas llena una esfera de 20 pies de radio centrada en un punto dentro del alcance. La zona que ocupa la nube está muy oscura y dura hasta que el conjuro termine o hasta que la disperse un viento fuerte (por ejemplo, el que crea ráfaga de viento).\n\nCuando aparezca la nube, todas las criaturas dentro de ella harán una tirada de salvación de Destreza; sufrirán 10d8 de daño de fuego si la fallan o la mitad del daño si la superan. Una criatura también deberá hacer esta tirada cuando la esfera entre en su espacio o cuando la criatura entre en la esfera o termine su turno en ella. Una criatura solo hace esta tirada una vez por turno. La nube se aleja de ti 10 pies en la dirección que elijas al principio de cada uno de tus turnos.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 20,
      "measure": "radius"
    }
  },
  {
    "name": "OFUSCACIÓN",
    "level": 8,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "brujo",
      "druida",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "150 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un llavero sin llaves"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Atacas la mente de una criatura que puedas ver dentro del alcance. El objetivo hace una tirada de salvación de Inteligencia. Si la falla, sufrirá 4d6 de daño psíquico y no podrá lanzar conjuros ni realizar acciones de magia. Al final de cada 30 días, el objetivo repite la tirada de salvación y, si tiene éxito, se librará del efecto. También se puede finalizar este efecto mediante un conjuro curar, deseo o restablecimiento mayor. Si supera la tirada, solo sufrirá la mitad de ese daño.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "OJO ARCANO",
    "level": 4,
    "school": "Adivinación",
    "classes": [
      "mago"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un poco de pelo de murciélago"
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Creas un ojo invisible e invulnerable dentro del alcance que levita hasta que el conjuro termine. Recibes mentalmente información visual desde el ojo, que puede mirar en cualquier dirección y tiene visión en la oscuridad hasta 30 pies.\n\nComo acción adicional, puedes mover el ojo hasta 30 pies en cualquier dirección.\n\nEl ojo no podrá atravesar una barrera sólida, pero podrá pasar por cualquier abertura de 1 pulgada de diámetro como mínimo.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "OLA ATRONADORA",
    "level": 1,
    "school": "Evocación",
    "classes": [
      "bardo",
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal / 15 pies de cubo",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Desatas una ola de energía atronadora. Todas las criaturas situadas en un cubo de 15 pies de lado adyacente a ti harán una tirada de salvación de Constitución. Si la fallan, recibirán 2d8 de daño de trueno y serán empujadas 10 pies respecto a ti. Si la superan, solo sufrirán la mitad de ese daño.\n\nAdemás, a los objetos sueltos que estén completamente dentro del cubo se les empujará 10 pies respecto a ti y la explosión atronadora podrá oírse a 300 pies de distancia.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d8 por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "cube",
      "sizeFt": 15
    }
  },
  {
    "name": "OLA DESTRUCTORA",
    "level": 5,
    "school": "Evocación",
    "classes": [
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "Personal / 30 pies de emanación",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Una energía destructiva surge de ti formando ondas en una emanación de 30 pies. Las criaturas que elijas dentro de la emanación realizan una tirada de salvación de Constitución. Si la fallan, sufrirán 5d6 de daño de trueno, 5d6 de daño radiante o necrótico (a tu elección) y tendrán el estado de derribadas. Si la superan, solamente recibirán la mitad de ese daño.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 30,
      "measure": "radius"
    }
  },
  {
    "name": "ORBE CROMÁTICO",
    "level": 1,
    "school": "Evocación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "90 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un diamante que valga al menos 50 po"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Lanzas un orbe de energía a un objetivo dentro del alcance. Elige entre ácido, frío, fuego, relámpago, trueno o veneno para el tipo de orbe creado y después haz un ataque de conjuro a distancia contra el objetivo. Si acierta, el objetivo recibe 3d8 de daño del tipo elegido. Si sacas el mismo número en dos o más de los d8, el orbe salta a otro objetivo distinto de tu elección que esté a 30 pies o menos del objetivo. Haz una tirada de ataque contra el nuevo objetivo y otra tirada de daño. El orbe no puede volver a saltar, a menos que lances el conjuro con un espacio de nivel 2 o superior.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d8 por cada nivel por encima de 1 que tenga el espacio. El orbe puede saltar un máximo de veces igual al nivel del espacio gastado. Una criatura solo puede ser el objetivo una vez por cada lanzamiento del conjuro."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ORDEN IMPERIOSA",
    "level": 1,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "clerigo",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Pronuncias una orden de una sola palabra dirigida a una criatura que puedas ver dentro del alcance. El objetivo debe superar una tirada de salvación de Sabiduría o verse obligado a obedecer la orden en su próximo turno.\n\nElige una de las siguientes órdenes:\n\n• **Acércate.** El objetivo se acerca a ti por la ruta más corta y directa posible. Su turno termina si se sitúa a 5 pies o menos de ti.\n\n• **Detente.** En su turno, el objetivo no se mueve ni realiza acciones ni acciones adicionales.\n\n• **Huye.** El objetivo emplea su turno en alejarse de ti lo más rápido posible.\n\n• **Póstrate.** El objetivo queda derribado y termina su turno.\n\n• **Suelta.** El objetivo suelta lo que esté sosteniendo y termina su turno.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Puedes afectar a una criatura adicional por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "OSCURIDAD",
    "level": 2,
    "school": "Evocación",
    "classes": [
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies / 15 pies de radio",
    "components": {
      "v": true,
      "s": false,
      "m": true,
      "material": "pelaje de murciélago y un trozo de carbón"
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Hasta que el conjuro termine, una oscuridad mágica se propaga desde un punto dentro del alcance y llena una esfera de 15 pies de radio. La visión en la oscuridad no puede ver a través de ella y la luz no mágica no puede alumbrarla. Como alternativa, lanzas el conjuro sobre un objeto que no lleve o vista nadie, lo que hará que la oscuridad llene una emanación de 15 pies que se origina en él.\n\nCubrir el objeto con algo opaco, como un cuenco o un casco, bloqueará la oscuridad. Si cualquier zona del conjuro se superpone con una zona de luz brillante o luz tenue creada por un conjuro de nivel 2 o inferior, el conjuro que creó esa luz se disipa.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 15,
      "measure": "radius"
    }
  },
  {
    "name": "PALABRA DE CURACIÓN",
    "level": 1,
    "school": "Abjuración",
    "classes": [
      "bardo",
      "clerigo",
      "druida"
    ],
    "casting_time": "Acción adicional",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Una criatura de tu elección que puedas ver dentro del alcance recupera una cantidad de puntos de golpe igual a 2d4 más tu modificador por aptitud mágica.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "La curación aumenta en 2d4 por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PALABRA DE CURACIÓN EN MASA",
    "level": 3,
    "school": "Abjuración",
    "classes": [
      "bardo",
      "clerigo"
    ],
    "casting_time": "Acción adicional",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Hasta seis criaturas de tu elección que puedas ver dentro del alcance recuperan una cantidad de puntos de golpe igual a 2d4 más tu modificador por aptitud mágica.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "La curación aumenta en 1d4 por cada nivel por encima de 3 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PALABRA DE PODER: ATURDIR",
    "level": 8,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Abrumas la mente de una criatura que puedas ver dentro del alcance. Si el objetivo tiene 150 puntos de golpe o menos, tendrá el estado de aturdido. De lo contrario, su velocidad será 0 hasta el principio de tu siguiente turno. El objetivo aturdido hace una tirada de salvación de Constitución al final de cada uno de sus turnos y, si tiene éxito, se librará del estado.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PALABRA DE PODER: FORTALECER",
    "level": 7,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "clerigo"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Refuerzas a hasta seis criaturas que puedas ver dentro del alcance. El conjuro proporciona 120 puntos de golpe temporales, que divides entre los objetivos.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PALABRA DE PODER: MATAR",
    "level": 9,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Obligas a morir a una criatura que puedas ver dentro del alcance. Si el objetivo tiene 100 puntos de golpe o menos, morirá. De lo contrario, sufrirá 12d12 de daño psíquico.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PALABRA DE PODER: SANAR",
    "level": 9,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "clerigo"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Una criatura que puedas ver dentro del alcance se ve envuelta por una oleada de energía sanadora. El objetivo recupera todos sus puntos de golpe. Si la criatura tiene los estados de asustada, aturdida, envenenada, hechizada o paralizada, los estados terminan.\n\nSi la criatura tiene el estado de derribada, puede usar su reacción para levantarse.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PALABRA DE REGRESO",
    "level": 6,
    "school": "Conjuración",
    "classes": [
      "clerigo"
    ],
    "casting_time": "Acción",
    "range": "5 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Tú y hasta cinco criaturas voluntarias a 5 pies o menos de ti os teletransportáis al instante a un santuario designado previamente. Tú y cualquier criatura que se teletransporte contigo apareceréis en el espacio sin ocupar más cercano al punto designado al preparar el santuario (consulta más adelante). Si lanzas este conjuro sin preparar antes un santuario, no tiene ningún efecto.\n\nDebes designar un lugar como santuario lanzando este conjuro allí; por ejemplo, en un templo.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PALABRA DE RESPLANDOR",
    "level": 0,
    "school": "Evocación",
    "classes": [
      "clerigo"
    ],
    "casting_time": "Acción",
    "range": "Personal / 5 pies de emanación",
    "components": {
      "v": true,
      "s": false,
      "m": true,
      "material": "un símbolo con forma de rayo"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Un fulgor ardiente surge de ti en una emanación de 5 pies. Todas las criaturas de tu elección que puedas ver en ella deberán superar una tirada de salvación de Constitución o sufrirán 1d6 de daño radiante.",
    "tables": [],
    "sections": [
      {
        "title": "Mejora de truco",
        "text": "El daño aumenta en 1d6 cuando alcanzas los niveles 5 (2d6), 11 (3d6) y 17 (4d6)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 5,
      "measure": "radius"
    }
  },
  {
    "name": "PALABRA DIVINA",
    "level": 7,
    "school": "Evocación",
    "classes": [
      "clerigo"
    ],
    "casting_time": "Acción adicional",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Susurras una palabra imbuida con el poder de los Planos Superiores. Todas las criaturas de tu elección dentro del alcance deben hacer una tirada de salvación de Carisma. Si la fallan, los objetivos que tengan 50 puntos de golpe o menos sufren un efecto según sus puntos de golpe actuales; consulta la tabla de Efectos de palabra divina. Con independencia de sus puntos de golpe, cualquier objetivo celestial, elemental, feérico o infernal que falle la tirada de salvación se ve forzado a regresar a su plano de origen, si no está ya en él, y no puede regresar al plano actual durante 24 horas por ningún medio que no sea un conjuro de deseo.",
    "tables": [
      {
        "title": "Efectos de palabra divina",
        "columns": [
          "Puntos de golpe",
          "Efecto"
        ],
        "rows": [
          [
            "0–20",
            "El objetivo muere."
          ],
          [
            "21–30",
            "El objetivo tiene los estados de aturdido, cegado y ensordecido durante 1 hora."
          ],
          [
            "31–40",
            "El objetivo tiene los estados de cegado y ensordecido durante 10 minutos."
          ],
          [
            "41–50",
            "El objetivo tiene el estado de ensordecido durante 1 minuto."
          ]
        ]
      }
    ],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PARAR EL TIEMPO",
    "level": 9,
    "school": "Transmutación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Detienes el paso del tiempo brevemente para todo el mundo menos para ti. Para las demás criaturas, el tiempo no avanza, mientras que tú puedes llevar a cabo 1d4 + 1 turnos seguidos, durante los cuales puedes usar acciones y moverte con normalidad.\n\nEste conjuro termina si una de las acciones que usas o uno de los efectos que creas durante este periodo afecta a una criatura que no seas tú o a un objeto que lleve o vista alguien que no seas tú. También termina si te mueves a un sitio que esté a más de 1000 pies del lugar donde lo lanzaste.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PASAMUROS",
    "level": 5,
    "school": "Transmutación",
    "classes": [
      "mago"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una pizca de semillas de sésamo"
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Aparece un pasaje en un punto que puedas ver en una superficie de madera, yeso o piedra (como una pared, un techo o un suelo) dentro del alcance y se mantiene hasta que termine el conjuro. Tú eliges las dimensiones de la abertura: hasta 5 pies de ancho, 8 pies de alto y 20 pies de largo. El pasaje no crea ninguna inestabilidad en la estructura que lo rodea.\n\nCuando la abertura desaparece, las criaturas o los objetos que sigan en el pasaje creado por el conjuro serán expulsados sin daño alguno al espacio sin ocupar más cercano a la superficie sobre la que lanzaste el conjuro.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PASAR SIN RASTRO",
    "level": 2,
    "school": "Abjuración",
    "classes": [
      "druida",
      "explorador"
    ],
    "casting_time": "Acción",
    "range": "Personal / 30 pies de emanación",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "cenizas de muérdago quemado"
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Hasta que el conjuro termine, irradias un aura de ocultación en una emanación de 30 pies. Mientras permanezcáis dentro, las criaturas que elijas y tú tendréis un bonificador de +10 alas pruebas de Destreza (Sigilo) y no dejaréis huellas.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 30,
      "measure": "radius"
    }
  },
  {
    "name": "PASO ARBÓREO",
    "level": 5,
    "school": "Conjuración",
    "classes": [
      "druida",
      "explorador"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Obtienes la capacidad de entrar en un árbol y moverte desde dentro al interior de otro árbol del mismo tipo que esté a 120 pies o menos. Ambos árboles tienen que estar vivos y ser al menos del mismo tamaño que tú. Para entrar en un árbol debes gastar 5 pies de movimiento.\n\nAl instante conoces la ubicación de todos los demás árboles del mismo tipo situados a 120 pies o menos y, como parte del movimiento gastado para entrar en el árbol, puedes pasar al interior de uno de esos árboles o salir del árbol en el que estás. Apareces en un punto de tu elección a 5 pies o menos del árbol de destino gastando otros 5 pies de movimiento.\n\nSi no te queda movimiento, apareces a 5 pies o menos del árbol en el que entraste. Puedes usar esta capacidad de transporte solo una vez en cada uno de tus turnos y debes terminar cada turno fuera de un árbol.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PASO BRUMOSO",
    "level": 2,
    "school": "Conjuración",
    "classes": [
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción adicional",
    "range": "Personal",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Una niebla plateada te rodea brevemente y te teletransportas hasta 30 pies a un espacio sin ocupar que puedas ver.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PATRÓN HIPNÓTICO",
    "level": 3,
    "school": "Ilusionismo",
    "classes": [
      "bardo",
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies / 30 pies de cubo",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una pizca de confeti"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Creas un patrón de colores que se retuercen en un cubo de 30 pies de lado dentro del alcance. El patrón aparece un instante y se desvanece. Todas las criaturas de la zona que puedan ver el patrón deberán superar una tirada de salvación de Sabiduría o tendrán el estado de hechizadas hasta que termine el conjuro. Mientras estén hechizadas, las criaturas tendrán una velocidad de 0 y el estado de incapacitadas. El conjuro finaliza para una criatura afectada si esta recibe daño o si alguien más emplea una acción para sacudir a dicha criatura y sacarla de su estupor.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "cube",
      "sizeFt": 30
    }
  },
  {
    "name": "PEQUEÑA CHOZA DE LEOMUND",
    "level": 3,
    "school": "Evocación",
    "classes": [
      "bardo",
      "mago"
    ],
    "casting_time": "1 minuto o un ritual",
    "range": "Personal / 10 pies de emanación",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una cuenta de cristal"
    },
    "duration": "8 horas",
    "ritual": true,
    "concentration": false,
    "description": "Una emanación de 10 pies surge a tu alrededor y permanece estática hasta que termine el conjuro. El conjuro fallará al lanzarlo si la emanación no es lo bastante grande como para cubrir a todas las criaturas en su área. Las criaturas y los objetos que haya en la emanación cuando lances el conjuro pueden moverse por ella libremente.\n\nEl resto de criaturas y objetos no pueden atravesarla. No pueden lanzarse conjuros de nivel 3 o inferior a través de ella y los efectos de estos conjuros no pueden penetrar a su interior. Dentro de la emanación, la atmósfera es cómoda y seca, con independencia del clima exterior.\n\nHasta que el conjuro termine, puedes hacer que el interior esté iluminado con luz tenue o a oscuras (no requiere acción). Desde el exterior, la emanación es opaca y del color que elijas, pero es transparente desde el interior. El conjuro termina antes si sales de la emanación o lo vuelves a lanzar.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 10,
      "measure": "radius"
    }
  },
  {
    "name": "PERDICIÓN",
    "level": 1,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "clerigo",
      "brujo"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una gota de sangre"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Hasta tres criaturas de tu elección a las que puedas ver dentro del alcance deberán hacer una tirada de salvación de Carisma cada una.\n\nSiempre que un objetivo que haya fallado esta tirada de salvación haga una tirada de ataque o de salvación antes de que termine el conjuro, deberá restar 1d4 al resultado de dicha tirada.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Puedes hacer objetivo a una criatura adicional por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PIEDAD CON LOS MORIBUNDOS",
    "level": 0,
    "school": "Nigromancia",
    "classes": [
      "clerigo",
      "druida"
    ],
    "casting_time": "Acción",
    "range": "15 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Elige a una criatura dentro del alcance que tenga 0 puntos de golpe y no esté muerta. La criatura pasa a estar estable.",
    "tables": [],
    "sections": [
      {
        "title": "Mejora de truco",
        "text": "El alcance se duplica cuando alcanzas los niveles 5 (30 pies), 11 (60 pies) y 17 (120 pies)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PIEL PÉTREA",
    "level": 4,
    "school": "Transmutación",
    "classes": [
      "druida",
      "explorador",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "polvo de diamante que valga al menos 100 po y que se consume como parte del conjuro"
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Hasta que el conjuro termine, una criatura voluntaria a la que toques tiene resistencia al daño contundente, cortante y perforante.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PIEL ROBLIZA",
    "level": 2,
    "school": "Transmutación",
    "classes": [
      "druida",
      "explorador"
    ],
    "casting_time": "Acción adicional",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un puñado de corteza"
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Tocas a una criatura voluntaria.\n\nHasta que el conjuro termine, la piel del objetivo adopta una apariencia de corteza y su clase de armadura no podrá ser inferior a 17.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PLAGA DE INSECTOS",
    "level": 5,
    "school": "Conjuración",
    "classes": [
      "clerigo",
      "druida",
      "hechicero"
    ],
    "casting_time": "Acción",
    "range": "300 pies / 20 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una langosta"
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Un enjambre de langostas llena una esfera de 20 pies de radio centrada en un punto de tu elección dentro del alcance. Permanece hasta que termine el conjuro y la zona se considera ligeramente oscura y terreno difícil.\n\nCuando aparezca el enjambre, todas las criaturas dentro de él harán una tirada de salvación de Constitución; sufrirán 4d10 de daño perforante si la fallan o la mitad del daño si la superan. Una criatura también hará esta tirada cuando entre en el área del conjuro por primera vez en un turno o termine su turno allí. Una criatura solo hace esta tirada una vez por turno.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d10 por cada nivel por encima de 5 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 20,
      "measure": "radius"
    }
  },
  {
    "name": "PLEGARIA DE CURACIÓN",
    "level": 2,
    "school": "Abjuración",
    "classes": [
      "clerigo",
      "paladin"
    ],
    "casting_time": "10 minutos",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Hasta cinco criaturas de tu elección que permanezcan dentro del alcance del conjuro durante todo su lanzamiento obtienen los beneficios de un descanso corto y también recuperan 2d8 puntos de golpe. Las criaturas no pueden volver a beneficiarse de este conjuro hasta que finalicen un descanso largo.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "La curación aumenta en 1d8 por cada nivel por encima de 2 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "POLIMORFAR",
    "level": 4,
    "school": "Transmutación",
    "classes": [
      "bardo",
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un capullo de oruga"
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Intentas transformar en una bestia a una criatura que puedas ver dentro del alcance. El objetivo debe superar una tirada de salvación de Sabiduría o adoptará la forma de una bestia hasta que termine el conjuro. Esa forma Puede ser la de cualquier bestia que elijas y cuyo valor de desafío sea igual o menor que el del objetivo (o que el nivel del objetivo si este no tiene un valor de desafío). El perfil del objetivo se sustituye por el de la bestia elegida, pero el objetivo conservará su alineamiento, personalidad, tipo de criatura, puntos de golpe y dados de puntos de golpe. En el apéndice B puedes consultar varios perfiles de bestias. El objetivo obtiene una cantidad de puntos de golpe temporales igual a los puntos de golpe de la forma de bestia. Estos puntos de golpe temporales se desvanecerán si conservas alguno cuando el conjuro termine. El conjuro termina antes de tiempo si el objetivo se queda sin puntos de golpe temporales. Las acciones que puede realizar el objetivo están limitadas por la anatomía de su nueva forma y no podrá hablar ni lanzar conjuros. El equipo del objetivo se funde con su nueva forma y la criatura no podrá usar ese equipo ni beneficiarse de él.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "POLIMORFAR VERDADERO",
    "level": 9,
    "school": "Transmutación",
    "classes": [
      "bardo",
      "brujo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una gota de mercurio, un poco de goma arábiga y un jirón de humo"
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Elige a una criatura o a un objeto no mágico que puedas ver dentro del alcance. La criatura adopta la forma de otra criatura o de un objeto no mágico, o el objeto se convierte en una criatura (el objeto no puede llevarse ni vestirse).\n\nLa transformación dura hasta que el conjuro termine o hasta que el objetivo muera o sea destruido. Sin embargo, si mantienes la concentración durante toda la duración del conjuro, la transformación se vuelve permanente hasta que sea disipado.\n\nUna criatura no voluntaria puede realizar una tirada de salvación de Sabiduría. Si la supera, el conjuro no tiene efecto sobre ella.\n\n• **Criatura en criatura** Si transformas a una criatura en otra criatura, la nueva forma puede ser de cualquier tipo que elijas, siempre que tenga un valor de desafío igual o inferior al valor de desafío o al nivel del objetivo (lo que sea mayor). El perfil del objetivo se sustituye por el perfil de la nueva forma, pero el objetivo mantiene sus puntos de golpe, dados de puntos de golpe, alineamiento y personalidad. El objetivo obtiene una cantidad de puntos de golpe temporales igual a los puntos de golpe de la nueva forma. Estos puntos de golpe temporales desaparecen si aún quedan cuando el conjuro termina. Las acciones que puede realizar el objetivo quedan limitadas por la anatomía de su nueva forma. No puede hablar ni lanzar conjuros. Todo el equipo del objetivo se funde con su nueva forma. El objetivo no puede usar ese equipo ni beneficiarse de él mientras dure la transformación.\n\n• **Objeto en criatura** Puedes transformar un objeto no mágico en una criatura, siempre que el tamaño de la criatura no sea mayor que el del objeto y que su valor de desafío sea 9 o inferior. La criatura es amistosa contigo y con tus aliados. En combate, actúa inmediatamente después de tu turno y obedece tus órdenes. Si el conjuro dura más de 1 hora, dejas de controlar a la criatura. En ese caso, puede seguir siendo amistosa contigo según cómo la hayas tratado.\n\n• **Criatura en objeto** Si transformas a una criatura en un objeto no mágico, se convierte en esa forma junto con todo lo que lleve o vista, siempre que el tamaño del objeto no sea mayor que el de la criatura. El perfil de la criatura se sustituye por el del objeto. Cuando el conjuro termina y la criatura recupera su forma original, no recuerda el tiempo que pasó transformada.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PORTAL",
    "level": 9,
    "school": "Conjuración",
    "classes": [
      "brujo",
      "clerigo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un diamante que valga al menos 5000 po"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Conjuras un portal que enlaza un espacio sin ocupar que puedas ver dentro del alcance con una ubicación precisa situada en otro plano de existencia. El portal es una abertura circular a la que puedes dar un diámetro de entre 1,5 y 20 pies, que puedes orientar en la dirección que elijas. El portal permanece hasta que el conjuro termine y puede verse su destino a través de él.\n\nEl portal tiene una parte delantera y otra trasera en cada plano en el que aparece y solo es posible desplazarse a través de él si se atraviesa por la parte delantera. Cualquier cosa que lo haga es transportada al instante al otro plano y aparecerá en el espacio sin ocupar más cercano al portal.\n\nLas deidades y otros gobernantes de planos pueden impedir que los portales creados mediante este conjuro se abran en su presencia o en cualquier lugar dentro de sus dominios. Cuando lances el conjuro, puedes decir el nombre de una criatura específica (no sirven un pseudónimo, un título o un apodo).\n\nSi esa criatura está en un plano distinto al tuyo, el portal se abrirá junto a la criatura mencionada y la transportará al espacio sin ocupar más cercano en tu lado del portal. No obtienes ningún poder especial sobre la criatura y será libre de actuar según tu DM considere apropiado: puede irse, atacarte o ayudarte.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "POTENCIAR CARACTERÍSTICA",
    "level": 2,
    "school": "Transmutación",
    "classes": [
      "bardo",
      "clerigo",
      "druida",
      "explorador",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "pelo de animal o una pluma"
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Tocas a una criatura y eliges Fuerza, Destreza, Inteligencia, Sabiduría o Carisma.\n\nHasta que termine el conjuro, el objetivo tiene ventaja en las pruebas con la característica elegida.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Puedes hacer objetivo a una criatura adicional por cada nivel por encima de 2 que tenga el espacio. Puedes elegir una característica distinta para cada objetivo."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PRESCIENCIA",
    "level": 9,
    "school": "Adivinación",
    "classes": [
      "bardo",
      "brujo",
      "druida",
      "mago"
    ],
    "casting_time": "1 minuto",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una pluma de colibrí"
    },
    "duration": "8 horas",
    "ritual": false,
    "concentration": false,
    "description": "Tocas a una criatura voluntaria y la dotas de una capacidad limitada de ver el futuro inmediato. Hasta que el conjuro termine, el objetivo tendrá ventaja en las pruebas con d20 y las demás criaturas tendrán desventaja en las tiradas de ataque contra él. El conjuro termina antes si lo vuelves a lanzar.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PRESENCIA REGIA DE YOLANDE",
    "level": 5,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal / 10 pies de emanación",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una tiara en miniatura"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Te rodeas de una majestuosidad sobrenatural en una emanación de 10 pies. Siempre que la emanación entre en el espacio de una criatura que puedas ver y siempre que una criatura que puedas ver entre en la emanación o termine su turno allí, puedes obligar a la criatura a hacer una tirada de salvación de Sabiduría. Si la falla, el objetivo sufrirá 4d6 de daño psíquico, tendrá el estado de derribado y podrás empujarlo hasta 10 pies respecto a ti. Si la supera, solo sufrirá la mitad de ese daño. Una criatura solo hace esta tirada una vez por turno.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 10,
      "measure": "radius"
    }
  },
  {
    "name": "PRESTIDIGITACIÓN",
    "level": 0,
    "school": "Transmutación",
    "classes": [
      "bardo",
      "brujo",
      "hechicero",
      "mago",
      "segador"
    ],
    "casting_time": "Acción",
    "range": "10 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Hasta 1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Creas un efecto mágico dentro del alcance, elegido de entre las opciones siguientes. Si lanzas este conjuro varias veces, puedes mantener activos al mismo tiempo hasta tres de sus efectos no instantáneos.\n\n• **Creación menor.** Creas un abalorio no mágico o una imagen ilusoria que cabe en tu mano y dura hasta el final de tu siguiente turno. El abalorio no inflige daño ni tiene valor monetario.\n\n• **Efecto sensorial.** Creas un efecto sensorial instantáneo e inofensivo, como una lluvia de chispas, una ligera ráfaga de viento, tenues notas musicales o un olor extraño.\n\n• **Jugar con fuego.** Enciendes o apagas al instante una vela, una antorcha o una hoguera pequeña.\n\n• **Limpiar o ensuciar.** Limpias o ensucias al instante un objeto de hasta 1 pie cúbico.\n\n• **Marca mágica.** Haces que aparezca una mancha de color, una pequeña marca o un símbolo en un objeto o superficie durante 1 hora.\n\n• **Sensación menor.** Enfrías, calientas o das sabor a un material inerte de hasta 1 pie cúbico durante 1 hora.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PROHIBICIÓN",
    "level": 6,
    "school": "Abjuración",
    "classes": [
      "clerigo"
    ],
    "casting_time": "10 minutos o un ritual",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "polvo de rubí que valga al menos 1000 po"
    },
    "duration": "1 día",
    "ritual": true,
    "concentration": false,
    "description": "Creas una protección contra los viajes mágicos que cubre una zona del suelo de 40 000 pies cuadrados hasta una altura de 30 pies. Hasta que termine el conjuro, ninguna criatura podrá teletransportarse a esa zona ni entrar en ella usando portales, como los creados por el conjuro portal.\n\nEl conjuro protege la zona frente al viaje interplanar, por lo que impide que cualquier criatura entre en el área mediante el Plano Astral, el Plano Etéreo, los Parajes Feéricos, el Páramo Sombrío o el conjuro desplazamiento entre planos.\n\nAdemás, el conjuro daña a los tipos de criaturas que elijas al lanzarlo.\n\nElige uno o más de los siguientes: aberraciones, celestiales, elementales, feéricos, infernales y muertos vivientes. Cuando una criatura de un tipo elegido entre en la zona del conjuro por primera vez en un turno o termine su turno allí, recibirá 5d10 de daño radiante o necrótico (a tu elección cuando lanzas el conjuro). Puedes designar una contraseña cuando lanzas el conjuro.\n\nSi una criatura pronuncia la contraseña al entrar en el área, no recibirá daño del conjuro. La zona del conjuro no se puede superponer con la de otro conjuro prohibición. Si lanzas prohibición todos los días durante 30 días en la misma ubicación, el conjuro durará hasta que sea disipado y los componentes materiales se consumirán en el último lanzamiento.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PROTECCIÓN CONTRA EL BIEN Y EL MAL",
    "level": 1,
    "school": "Abjuración",
    "classes": [
      "brujo",
      "clerigo",
      "druida",
      "mago",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un frasco de agua bendita que valga al menos 25 po, que se consume como parte del conjuro"
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Hasta que el conjuro termine, una criatura voluntaria a la que toques estará protegida contra aberraciones, celestiales, elementales, feéricos, infernales o muertos vivientes. La protección concede varios beneficios. Las criaturas de esos tipos tendrán desventaja en las tiradas de ataque contra el objetivo.\n\nEl objetivo tampoco puede ser poseído por las criaturas ni obtener los estados de asustado o hechizado a causa de ellas. Si el objetivo ya está asustado, hechizado o poseído por una criatura de estos tipos, dicho objetivo tendrá ventaja en cualquier nueva tirada de salvación contra el efecto correspondiente.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PROTECCIÓN CONTRA ENERGÍA",
    "level": 3,
    "school": "Abjuración",
    "classes": [
      "clerigo",
      "druida",
      "explorador",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Hasta que termine el conjuro, una criatura voluntaria a la que toques tendrá resistencia a un tipo de daño de tu elección: ácido, frío, fuego, relámpago o trueno.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PROTECCIÓN CONTRA VENENO",
    "level": 2,
    "school": "Abjuración",
    "classes": [
      "clerigo",
      "druida",
      "explorador",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Tocas a una criatura y pones fin al estado de envenenada silo sufre. Hasta que termine el conjuro, el objetivo tiene ventaja en las tiradas de salvación para evitar o poner fin al estado de envenenado y resistencia al daño de veneno.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PROYECCIÓN ASTRAL",
    "level": 9,
    "school": "Nigromancia",
    "classes": [
      "brujo",
      "clerigo",
      "mago"
    ],
    "casting_time": "1 hora",
    "range": "10 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "por cada objetivo del conjuro, un jacinto que valga al menos 1000 po y un lingote de plata que valga al menos 100 po, que se consumen como parte del conjuro"
    },
    "duration": "Hasta que sea disipado",
    "ritual": false,
    "concentration": false,
    "description": "Tú y hasta ocho criaturas voluntarias dentro del alcance proyectáis vuestros cuerpos astrales al Plano Astral (si ya estáis allí, el conjuro termina al instante). El cuerpo material que deja atrás un objetivo queda en animación suspendida; tiene el estado de inconsciente, no necesita aire ni comida y no envejece.\n\nEl cuerpo astral de un objetivo es semejante a su cuerpo en casi todo y replica su perfil y sus posesiones. La diferencia principal es un cordón plateado que sale de entre los omóplatos de la forma astral y se desvanece a los 1 pie. Si el cordón se corta (algo que solo puede ocurrir si un efecto así lo indica), el cuerpo y la forma astral del objetivo mueren.\n\nUna forma astral puede viajar a través del Plano Astral.\n\nSi abandona el plano, el cuerpo y las posesiones del objetivo viajan a través del cordón de plata, permitiéndole volver a entrar en su cuerpo en el nuevo plano. El daño y otros efectos que se le apliquen a una forma astral no afectan al cuerpo del objetivo y viceversa.\n\nSi los puntos de golpe del cuerpo del objetivo o de su forma astral se reducen a 0, el conjuro terminará para él. El conjuro termina para todos los objetivos si empleas una acción de magia para ponerle fin. Cuando el conjuro termine para un'objetivo que no esté muerto, reaparecerá en su cuerpo y concluirá su animación suspendida.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PROYECTAR IMAGEN",
    "level": 7,
    "school": "Ilusionismo",
    "classes": [
      "bardo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "500 millas",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una estatuilla de ti que valga al menos 5 po"
    },
    "duration": "hasta 1 día",
    "ritual": false,
    "concentration": true,
    "description": "Creas una copia ilusoria de ti que dura hasta que termine el conjuro. La copia puede aparecer en cualquier lugar dentro del alcance que hayas visto antes, sin importar que haya obstáculos que se interpongan. La ilusión tiene tu aspecto y suena como tú, pero es intangible.\n\nSi recibe cualquier daño, desaparecerá y el conjuro terminará. Puedes ver a través de sus ojos y oír con sus oídos como si estuvieras en su espacio. Como acción de magia, puedes hacer que se mueva hasta 60 pies y que realice gestos, hable y se comporte del modo que quieras.\n\nImita tu gestualidad a la perfección. La interacción física con la imagen revela que es una ilusión, ya que las cosas pueden atravesarla. Si una criatura emplea una acción de estudiar para examinar la imagen, puede determinar que es una ilusión si supera una prueba de Inteligencia (Investigación) contra tu CD de salvación de conjuros.\n\nSi la criatura descubre que la imagen es una ilusión, no se dejará engañar por ella y los sonidos que emita le sonarán huecos.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PROYECTIL MÁGICO",
    "level": 1,
    "school": "Evocación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Creas tres dardos brillantes de fuerza mágica y cada uno de ellos golpea a una criatura de tu elección a la que puedas ver dentro del alcance. Cada dardo inflige 1d4 + 1 de daño de fuerza al objetivo. Todos los dardos aciertan a la vez y puedes dirigirlos para que acierten a una sola criatura o a varias.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El conjuro crea un dardo adicional por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PUERTA ARCANA",
    "level": 6,
    "school": "Conjuración",
    "classes": [
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Creas portales de teletransporte enlazados. Elige dos espacios Grandes sin ocupar en el suelo que puedas ver, uno dentro del alcance y el otro a 10 pies o menos de ti. Un portal circular se abre en cada uno de dichos espacios y permanece hasta que el conjuro termine.\n\nLos portales son anillos bidimensionales, brillantes y cubiertos de una niebla que tapa la vista, y levitan a unas pocas pulgadas del suelo, perpendiculares a él. Cada portal solo se abre por un lado (tú decides cuál). Todo lo que entre por el lado abierto de un portal sale por el lado abierto del otro como si estuvieran adyacentes entre sí.\n\nComo acción adicional, puedes cambiar la orientación de los lados abiertos.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PUERTA DIMENSIONAL",
    "level": 4,
    "school": "Conjuración",
    "classes": [
      "bardo",
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Te teletransportas a una ubicación dentro del alcance y llegas exactamente al sitio deseado. Puede ser un lugar que tengas a la vista, uno que logres visualizar o uno que puedas describir indicando la distancia y la dirección, como \"195 pies en línea recta hacia abajo\" o \"300 pies hacia arriba y hacia el noroeste en un ángulo de 45 grados\". También puedes teletransportar contigo a una criatura voluntaria.\n\nLa criatura deberá estar a 5 pies o menos de ti cuando te teletransportes y aparecerá en un espacio a 5 pies o menos de tu espacio de destino. Si la otra criatura, tú o las dos fuerais a llegar a un espacio ya ocupado por una criatura o totalmente ocupado por uno o más objetos, la criatura que viaje contigo y tú sufriréis 4d6 de daño de fuerza y la teletransportación fallará.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "PURIFICAR COMIDA Y BEBIDA",
    "level": 1,
    "school": "Transmutación",
    "classes": [
      "clerigo",
      "druida",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "Personal / 5 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "la semilla de una legumbre"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Eliminas el veneno y la podredumbre de la comida y bebida no mágicas en una esfera de 5 pies de radio centrada en un punto dentro del alcance.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 5,
      "measure": "radius"
    }
  },
  {
    "name": "RALENTIZAR",
    "level": 3,
    "school": "Transmutación",
    "classes": [
      "bardo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies / 40 pies de cubo",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una gota de melaza"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Alteras el tiempo alrededor de hasta seis criaturas de tu elección en un cubo de 40 pies de lado dentro del alcance. Cada objetivo deberá superar una tirada de salvación de Sabiduría o se verá afectado hasta que termine el conjuro. Un objetivo afectado ve cómo su velocidad se reduce a la mitad, sufre un penalizador de -2 a la CA y a las tiradas de salvación de Destreza y no puede llevar a cabo reacciones. En sus turnos, puede realizar una acción o una acción adicional, pero no ambas, y solo puede hacer un ataque si emplea la acción de atacar. Si lanza un conjuro con un componente somático, hay un 25 % de probabilidades de que el conjuro falle porque el objetivo haga los gestos demasiado despacio. Un objetivo afectado repetirá la tirada de salvación al final de cada uno de sus turnos y, si tiene éxito, se librará del conjuro.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "cube",
      "sizeFt": 40
    }
  },
  {
    "name": "RAYO ABRASADOR",
    "level": 2,
    "school": "Evocación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Lanzas tres rayos ardientes y los arrojas contra uno o varios objetivos dentro del alcance. Haz un ataque de conjuro a distancia por cada rayo. Si acierta, el objetivo recibe 2d6 de daño de fuego.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Creas un rayo adicional por cada nivel por encima de 2 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "RAYO DE ESCARCHA",
    "level": 0,
    "school": "Evocación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una ramita golpeada por un rayo"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Lanzas un rayo helado de luz blanquiazul hacia una criatura dentro del alcance. Haz un ataque de conjuro a distancia contra el objetivo. Si acierta, el objetivo recibe 1d8 de daño de frío y su velocidad se reduce en 10 pies hasta el principio de tu siguiente turno.",
    "tables": [],
    "sections": [
      {
        "title": "Mejora de truco",
        "text": "El daño aumenta en 1d8 cuando alcanzas los niveles 5 (2d8), 11 (3d8) y 17 (4d8)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "RAYO DE HECHICERÍA",
    "level": 1,
    "school": "Evocación",
    "classes": [
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una ramita golpeada por un rayo"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Un rayo de energía chisporroteante sale disparado hacia una criatura dentro del alcance, formando un arco constante similar a un relámpago entre el objetivo y tú. Haz un ataque de conjuro a distancia contra él. Si acierta, el objetivo sufre 2d12 de daño de relámpago. En cada uno de tus siguientes turnos, puedes emplear una acción adicional para causar 1d12 de daño de relámpago al objetivo automáticamente, incluso si el primer ataque falla. El conjuro termina si en algún momento el objetivo queda fuera del alcance del conjuro o si consigue tener cobertura completa respecto a ti.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "RAYO DE LUNA",
    "level": 2,
    "school": "Evocación",
    "classes": [
      "druida"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una hoja con forma de media luna"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Un rayo de luz pálida y plateada brilla en un cilindro de 5 pies de radio y 40 pies de alto centrado en un punto dentro del alcance. Hasta que el conjuro termine, una luz tenue llena el cilindro y puedes emplear una acción de magia en turnos posteriores para mover el cilindro hasta 60 pies. Cuando el cilindro aparezca, todas las criaturas que haya en él realizan una tirada de salvación de Constitución. Si la fallan, recibirán 2d10 de daño radiante, y si una criatura ha cambiado de forma (por ejemplo, como resultado del conjuro polimorfar), volverá a su forma real y no podrá cambiarla hasta que salga del cilindro. Si la superan, solo sufrirán la mitad de ese daño. Una criatura también deberá hacer esta tirada cuando el área del conjuro entre en su espacio o cuando la criatura entre en el área o acabe su turno en ella. Una criatura solo hace esta tirada una vez por turno.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d10 por cada nivel por encima de 2 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "RAYO DEBILITADOR",
    "level": 2,
    "school": "Nigromancia",
    "classes": [
      "brujo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Un haz de energía debilitadora surge de ti hacia una criatura dentro del alcance. El objetivo deberá hacer una tirada de salvación de Constitución. Si la supera, tendrá desventaja en la siguiente tirada de ataque que haga hasta el principio de tu siguiente turno. Si la falla, tendrá desventaja en las pruebas con d20 basadas en la Fuerza hasta que termine el conjuro. Durante ese tiempo, también restará 1d8 a todas las tiradas de daño que haga. El objetivo repetirá la tirada de salvación al final de cada uno de sus turnos y, si tiene éxito, se librará del conjuro.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "RAYO NAUSEABUNDO",
    "level": 1,
    "school": "Nigromancia",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Disparas un rayo verduzco hacia una criatura dentro del alcance. Haz un ataque de conjuro a distancia contra el objetivo. Si acierta, el objetivo sufrirá 2d8 de daño de veneno y tendrá el estado de envenenado hasta el final de tu siguiente turno.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d8 por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "RAYO SOLAR",
    "level": 6,
    "school": "Evocación",
    "classes": [
      "clerigo",
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal / 30 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una lupa"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Lanzas un rayo solar en una línea de 5 pies de ancho y 60 pies de largo. Todas las criaturas situadas en esa línea harán una tirada de salvación de Constitución. Si la fallan, recibirán 6d8 de daño radiante y tendrán el estado de cegadas hasta el principio de tu siguiente turno. Si la superan, recibirán solo la mitad de daño. Hasta que el conjuro termine, puedes emplear una acción de magia para crear una nueva línea de luz radiante. SS Hasta que termine el conjuro, por encima de ti brillará una mota radiante que emite luz brillante en un radio de 30 pies y luz tenue 30 pies más allá. Esta luz es luz solar.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 30,
      "measure": "radius"
    }
  },
  {
    "name": "RECADO",
    "level": 3,
    "school": "Adivinación",
    "classes": [
      "bardo",
      "clerigo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Ilimitado",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un alambre de cobre"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Envías un mensaje corto de 25 palabras o menos a una criatura que conozcas o a una criatura que te haya descrito alguien que la conozca. El objetivo escucha el mensaje en su mente, te reconoce como emisor si sabe quién eres y puede responder de manera similar inmediatamente. El conjuro permite que los objetivos comprendan el significado del mensaje.\n\nPuedes enviar el mensaje a cualquier distancia e incluso a otros planos de existencia, pero si el objetivo está en un plano diferente al tuyo, existe una probabilidad del 5 % de que el mensaje no llegue. Si el mensaje no llega, lo sabrás. Al recibir tu mensaje, una criatura puede impedir que te pongas en contacto con ella otra vez con este conjuro durante 8 horas.\n\nSi intentas enviarle otro mensaje durante ese tiempo, sabrás que te ha bloqueado y el conjuro fallará.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "RECHAZO ARCANO",
    "level": 1,
    "school": "Abjuración",
    "classes": [
      "bardo",
      "clerigo",
      "paladin",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una mano de arcilla en miniatura"
    },
    "duration": "Instantánea",
    "ritual": false,
    "concentration": false,
    "description": "Diriges una fuerza mágica disuasoria contra una criatura dentro del alcance. El objetivo debe realizar una tirada de salvación de Constitución. Los Constructos y los No Muertos superan automáticamente esta tirada. Si falla, recibe 2d4 de daño de fuerza, su velocidad se reduce a la mitad hasta el inicio de tu siguiente turno y, en su próximo turno, solo puede realizar una acción o una acción adicional, pero no ambas. Si la supera, recibe la mitad del daño y no sufre otros efectos.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "RECLUIR",
    "level": 7,
    "school": "Transmutación",
    "classes": [
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "polvo de piedras preciosas que valga al menos 5000 po, que se consume como parte del conjuro"
    },
    "duration": "Hasta que sea disipado",
    "ritual": false,
    "concentration": false,
    "description": "Con un toque, recluyes mágicamente un objeto o a una criatura voluntaria. Hasta que el conjuro termine, el objetivo tiene el estado de invisible y no puede ser objetivo de conjuros de adivinación, detectado con magia ni observado desde lejos mediante magia. Si el objetivo es una criatura, entra en un estado de animación suspendida: tiene el estado de inconsciente, no envejece y no necesita aire, beber ni comer.\n\nPuedes establecer una condición para que el conjuro termine antes de tiempo, que puede ser cualquier cosa que elijas, pero debe ocurrir o ser visible a 1 milla o menos del objetivo. Por ejemplo, \"cuando transcurran 1000 años\" o \"cuando se despierte la tarasca\". Este conjuro también termina si el objetivo recibe cualquier daño.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "REENCARNAR",
    "level": 5,
    "school": "Nigromancia",
    "classes": [
      "druida"
    ],
    "casting_time": "1 hora",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "aceites raros que valgan al menos 1000 po, que se consumen como parte del conjuro"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Tocas a un humanoide muerto o una parte de sus restos. Siempre que la criatura no lleve muerta más de 10 días, el conjuro forma un nuevo cuerpo y llama al alma para que entre en él. Tira 1d10 y consulta la tabla para determinar la especie del cuerpo, o bien tu DM elige otra especie jugable. La criatura reencarnada hace cualquier elección que ofrezca la descripción de la especie y recuerda su vida anterior. Conserva las capacidades que tenía en su forma original, pero los atributos de su especie nueva sustituyen a los de la anterior.",
    "tables": [
      {
        "title": "1d10",
        "columns": [
          "1d10",
          "Especie"
        ],
        "rows": [
          [
            "1",
            "Vuelve a tirar"
          ],
          [
            "2",
            "Dracónido"
          ],
          [
            "3",
            "Elfo"
          ],
          [
            "4",
            "Enano"
          ],
          [
            "5",
            "Gnomo"
          ],
          [
            "6",
            "Goliat"
          ],
          [
            "7",
            "Humano"
          ],
          [
            "8",
            "Mediano"
          ],
          [
            "9",
            "Orco"
          ],
          [
            "10",
            "Tiefling"
          ]
        ]
      }
    ],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "REGENERAR",
    "level": 7,
    "school": "Transmutación",
    "classes": [
      "bardo",
      "clerigo",
      "druida"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una rueda de plegarias"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Una criatura a la que toques recupera 4d8 + 15 puntos de golpe. Hasta que el conjuro termine, el objetivo recupera 1 punto de golpe al principio de cada uno de sus turnos y los miembros cercenados crecen de nuevo al cabo de 2 minutos.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "RELÁMPAGO",
    "level": 3,
    "school": "Evocación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal / 100 pies de línea",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un poco de pelaje y una vara de cristal"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Un relámpago que forma una línea de 100 pies de largo y 5 pies de ancho surge de ti en la dirección que elijas. Todas las criaturas situadas en esa línea deberán hacer una tirada de salvación de Destreza; sufrirán 8d6 de daño de relámpago si la fallan o la mitad del daño si la superan.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d6 por cada nivel por encima de 3 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "line",
      "sizeFt": 100
    }
  },
  {
    "name": "RELÁMPAGO EN CADENA",
    "level": 6,
    "school": "Evocación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "150 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "tres alfileres de plata"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Lanzas un relámpago hacia un objetivo que puedas ver dentro del alcance.\n\nA continuación, de ese objetivo surgirán otros tres relámpagos dirigidos a otros tantos objetivos de tu elección, cada uno de los cuales deberá estar a 30 pies o menos del primero. Un objetivo puede ser una criatura o un objeto y solo puede ser objetivo de uno de los relámpagos. Cada objetivo hace una tirada de salvación de Destreza; sufrirá 10d8 de daño de relámpago si la falla o la mitad del daño si la supera.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Surge un relámpago adicional del primer objetivo a otro objetivo por cada nivel por encima de 6 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "REPARAR",
    "level": 0,
    "school": "Transmutación",
    "classes": [
      "bardo",
      "clerigo",
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "1 minuto",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "dos imanes naturales"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Este conjuro repara una sola grieta o desgarrón en un objeto que toques, como un eslabón roto en una cadena, las dos mitades de una llave partida, una capa rasgada o una fuga en una bota de vino. Mientras la grieta o el desgarrón no tenga más de 1 pie de tamaño en ninguna de sus dimensiones, lo arreglarás sin dejar rastro del daño.\n\nEste conjuro puede reparar el componente físico de un objeto mágico, pero no puede restaurar su magia.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "REPRENSIÓN INFERNAL",
    "level": 1,
    "school": "Evocación",
    "classes": [
      "brujo"
    ],
    "casting_time": "Reacción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Lanzas este conjuro como reacción que llevas a cabo en respuesta a recibir daño de una criatura que puedas ver a 60 pies o menos de ti..\n\nLa criatura que te ha dañado se ve rodeada momentáneamente por unas llamas verdes y hará una tirada de salvación de Destreza; sufrirá 2d10 de daño de fuego si la falla o la mitad del daño si la supera.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d10 por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "REPRESALIA ARCANA",
    "level": 4,
    "school": "Abjuración",
    "classes": [
      "bardo",
      "hechicero",
      "brujo",
      "mago"
    ],
    "casting_time": "Reacción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantánea",
    "ritual": false,
    "concentration": false,
    "description": "Lanzas este conjuro como reacción que realizas al recibir daño.\n\nTe proteges contra energía destructiva, reduciendo el daño que recibes en 4d6 + tu modificador de característica de conjuro. Si la fuente del daño es una criatura que puedes ver dentro del alcance, puedes obligarla a realizar una tirada de salvación de Constitución. Si falla, recibe 4d6 de daño de fuerza. Si la supera, recibe la mitad de ese daño.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "RESISTENCIA",
    "level": 0,
    "school": "Abjuración",
    "classes": [
      "clerigo",
      "druida",
      "segador"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Tocas a una criatura voluntaria y eliges un tipo de daño: ácido, contundente, cortante, frío, fuego, necrótico, perforante, radiante, relámpago, trueno o veneno. Cuando la criatura sufra daño del tipo elegido antes de que termine el conjuro, reduce el daño total recibido en 1d4. Una criatura solo puede beneficiarse de este conjuro una vez por turno.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "RESPIRAR BAJO EL AGUA",
    "level": 3,
    "school": "Transmutación",
    "classes": [
      "druida",
      "explorador",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción o ritual",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un junco corto"
    },
    "duration": "24 horas",
    "ritual": true,
    "concentration": false,
    "description": "Este conjuro concede a hasta diez criaturas voluntarias que elijas dentro del alcance la capacidad de respirar bajo el agua hasta que el conjuro termine. Las criaturas afectadas también conservan su modo de respiración normal.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "RESTABLECIMIENTO MAYOR",
    "level": 5,
    "school": "Abjuración",
    "classes": [
      "bardo",
      "clerigo",
      "druida",
      "explorador",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "polvo de diamante que valga al menos 100 po y que se consume como parte del conjuro"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Tocas a una criatura y eliminas mágicamente uno de los siguientes efectos de ella:\n\n• 1 nivel de cansancio.\n\n• Los estados de hechizado o petrificado.\n\n• Una maldición, incluida la sintonización del objetivo con un objeto mágico maldito.\n\n• Cualquier reducción de una de las puntuaciones de característica del objetivo.\n\n• Cualquier reducción de los puntos de golpe máximos del objetivo.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "RESTABLECIMIENTO MENOR",
    "level": 2,
    "school": "Abjuración",
    "classes": [
      "bardo",
      "clerigo",
      "druida",
      "paladin",
      "explorador"
    ],
    "casting_time": "Acción adicional",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Tocas a una criatura y le pones fin a un estado que tenga: cegada, ensordecida, envenenada o paralizada.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "RESURRECCIÓN",
    "level": 7,
    "school": "Nigromancia",
    "classes": [
      "bardo",
      "clerigo"
    ],
    "casting_time": "1 hora",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un diamante que valga al menos 1000 po y que se consume como parte del conjuro"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Con un toque, revives a una criatura que no lleve más de un siglo muerta, que no muriera de vieja y que no fuera un muerto viviente cuando falleció. La criatura vuelve a la vida con todos sus puntos de golpe. El conjuro también neutraliza cualquier veneno que afectase a la criatura en el momento de su muerte.\n\nEste conjuro cierra todas las heridas mortales y devuelve las partes del cuerpo que falten. Regresar de entre los muertos es una experiencia complicada. El objetivo tendrá un penalizador de -4 a las pruebas con d20.\n\nCada vez que finalice un descanso largo, el penalizador se reduce en 1 hasta desaparecer. Lanzar el conjuro para revivir a una criatura que lleve muerta 365 días o más te exige un gran esfuerzo. Hasta que finalices un descanso largo, no podrás volver a lanzar conjuros y tendrás desventaja en las pruebas con d20.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "RESURRECCIÓN VERDADERA",
    "level": 9,
    "school": "Nigromancia",
    "classes": [
      "clerigo",
      "druida"
    ],
    "casting_time": "1 hora",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "diamantes que valgan al menos 25 000 po, que se consumen como parte del conjuro"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Tocas a una criatura que no lleve más de 200 años muerta y que falleciera por cualquier motivo menos de vieja. La criatura revive con todos sus puntos de golpe. Este conjuro cierra todas las heridas, neutraliza cualquier veneno, cura todas las enfermedades mágicas y levanta las maldiciones que afectaran a la criatura cuando murió.\n\nTambién sustituye los órganos y las extremidades que le falten o sufrieran daños. Si la criatura era un muerto viviente, la resucitará con su forma normal. El conjuro puede proporcionar un nuevo cuerpo si el original ya no existe, en cuyo caso debes pronunciar el nombre de la criatura.\n\nA continuación, esta aparecerá en un espacio sin ocupar que elijas a 10 pies o menos de ti.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "RETIRADA EXPEDITIVA",
    "level": 1,
    "school": "Transmutación",
    "classes": [
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción adicional",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Realizas la acción de correr y, hasta que el conjuro termine, puedes volver a hacerla como acción adicional.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "REVIVIR",
    "level": 3,
    "school": "Nigromancia",
    "classes": [
      "clerigo",
      "druida",
      "explorador",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un diamante que valga al menos 300 po, que se consume como parte del conjuro"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Tocas a una criatura que haya muerto en el último minuto. La criatura revive con 1 punto de golpe. Este conjuro no puede revivir a una criatura que haya muerto de vieja ni devolverle las partes del cuerpo que haya perdido.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "RISA HORRIBLE DE TASHA",
    "level": 1,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "brujo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una tarta y una pluma"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Una criatura de tu elección que puedas ver dentro del alcance realiza una tirada de salvación de Sabiduría. Si la falla, tendrá los estados de derribada e incapacitada hasta que el conjuro termine. Durante ese tiempo, se reirá de forma incontrolable si tiene la capacidad de reírse y no podrá poner fin a su estado de derribada. Al final de cada uno de sus turnos y cada vez que reciba daño, realizará otra tirada de salvación de Sabiduría. Tendrá ventaja en ella si la realiza por sufrir daño. Si la supera, el conjuro terminará.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Puedes hacer objetivo a una criatura adicional por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ROCIADA DE COLOR",
    "level": 1,
    "school": "Ilusionismo",
    "classes": [
      "bardo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal / 15 pies de cono",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una pizca de arena de colores"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Emites una ráfaga de luces brillantes y parpadeantes de múltiples colores. Todas las criaturas situadas en un cono de 15 pies que se origina en ti deberán superar una tirada de salvación de Constitución o tendrán el estado de cegadas hasta el final de tu siguiente turno.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "cone",
      "sizeFt": 15
    }
  },
  {
    "name": "ROCIADA PRISMÁTICA",
    "level": 7,
    "school": "Evocación",
    "classes": [
      "bardo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal / 60 pies de cono",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Ocho rayos multicolores destellan desde tu mano. Cada rayo tiene un color diferente y un poder distinto. Todas las criaturas situadas en un cono de 60 pies deben hacer una tirada de salvación de Destreza. Por cada objetivo, tira 1d8 para determinar qué rayo lo afecta, según la tabla. Si sacas 8, el objetivo recibe el efecto de dos rayos distintos; tira de nuevo dos veces, ignorando nuevos resultados de 8.",
    "tables": [
      {
        "title": "Rayos prismáticos",
        "columns": [
          "Resultado/Opción",
          "Efecto"
        ],
        "rows": [
          [
            "1",
            "Rojo. Si falla la tirada: 12d6 de daño de fuego. Si supera la tirada: la mitad de daño."
          ],
          [
            "2",
            "Naranja. Si falla la tirada: 12d6 de daño de ácido. Si supera la tirada: la mitad de daño."
          ],
          [
            "3",
            "Amarillo. Si falla la tirada: 12d6 de daño de relámpago. Si supera la tirada: la mitad de daño."
          ],
          [
            "4",
            "Verde. Si falla la tirada: 12d6 de daño de veneno. Si supera la tirada: la mitad de daño."
          ],
          [
            "5",
            "Azul. Si falla la tirada: 12d6 de daño de frío. Si supera la tirada: la mitad de daño."
          ],
          [
            "6",
            "Añil. Si falla la tirada: el objetivo tendrá el estado de apresado y hará una tirada de salvación de Constitución al final de cada uno de sus turnos. Si la supera tres veces, el estado terminará. Si la falla tres veces, tendrá el estado de petrificado hasta que lo libere un efecto como el del conjuro restablecimiento mayor. Los éxitos y los fallos no tienen por qué ser consecutivos: lleva la cuenta de ambos hasta que el objetivo tenga tres de un mismo tipo."
          ],
          [
            "7",
            "Violeta. Si falla la tirada: El objetivo tendrá el estado de cegado y hará una tirada de salvación de Sabiduría al principio de tu siguiente turno. Si la supera, el estado terminará. Si la falla, el estado terminará y la criatura se teletransportará a otro plano de existencia (a elección de tu DM)."
          ],
          [
            "8",
            "Especial. Dos rayos alcanzan al objetivo. Tira dos veces y repite los resultados de 8."
          ]
        ]
      }
    ],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "cone",
      "sizeFt": 60
    }
  },
  {
    "name": "ROCIADA VENENOSA",
    "level": 0,
    "school": "Nigromancia",
    "classes": [
      "brujo",
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Rocías a una criatura dentro del alcance con una niebla tóxica. Haz un ataque de conjuro a distancia contra el objetivo. Si aciertas, el objetivo recibe 1d12 de daño de veneno.",
    "tables": [],
    "sections": [
      {
        "title": "Mejora de truco",
        "text": "El daño aumenta en 1d12 cuando alcanzas los niveles 5 (2d12), 11 (3d12) y 17 (4d12)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "RÁFAGA DE VIENTO",
    "level": 2,
    "school": "Evocación",
    "classes": [
      "druida",
      "explorador",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "la semilla de una legumbre"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "De ti surge una ráfaga de viento fuerte en una línea recta de 60 pies de largo y 10 pies de ancho en la dirección que elijas hasta que termine el conjuro. Todas las criaturas en esa línea deberán superar una tirada de salvación de Fuerza o serán empujadas 15 pies en la dirección de la línea. Las criaturas que terminen su turno en ella también deberán hacer la tirada de salvación. Cualquier criatura que esté en la línea deberá gastar 2 pies de movimiento por cada pie que se mueva para acercarse a ti. La ráfaga dispersa el gas o el vapor y apaga velas y otras llamas desprotegidas de la zona. Hace que las llamas protegidas, como las de los faroles, se agiten salvajemente y tienen un 50 % de probabilidad de apagarse. Como acción adicional en tus siguientes turnos, puedes cambiar la dirección en la que la línea surge de ti.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "SABER DRUÍDICO",
    "level": 0,
    "school": "Transmutación",
    "classes": [
      "druida"
    ],
    "casting_time": "Acción",
    "range": "30 pies / 5 pies de cubo",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Susurras a los espíritus de la naturaleza y produces uno de los siguientes efectos dentro del alcance.\n\n• Sensor climático. Creas un efecto sensorial Diminuto e inofensivo que predice el clima que habrá en tu ubicación durante las siguientes 24 horas. El efecto se manifiesta como un orbe dorado para los cielos despejados, una nube para la lluvia, copos de nieve para la nieve, etc. Este efecto persiste durante 1 asalto.\n\n• Florecer. Haces que, al instante, una flor florezca, una vaina de semillas se abra o el brote de una hoja germine.\n\n• Efecto sensorial. Creas un efecto sensorial inofensivo, como hojas cayendo, hadas espectrales bailando, una suave brisa, el sonido de un animal o un leve olor a mofeta. El efecto debe caber en un cubo de 5 pies de lado.\n\n• Jugar con fuego. Enciendes o apagas una vela, una antorcha o una hoguera.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "cube",
      "sizeFt": 5
    }
  },
  {
    "name": "SAETA GUÍA",
    "level": 1,
    "school": "Evocación",
    "classes": [
      "clerigo"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "1 asalto",
    "ritual": false,
    "concentration": false,
    "description": "Lanzas un rayo de luz hacia una criatura dentro del alcance. Haz un ataque de conjuro a distancia contra el objetivo. Si acierta, el objetivo recibirá 4d6 de daño radiante y la siguiente tirada de ataque contra él antes del final de tu siguiente turno tendrá ventaja.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d6 por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "SALPICADURA ÁCIDA",
    "level": 0,
    "school": "Evocación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies / 5 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Creas una burbuja ácida en un punto dentro del alcance, donde explotará en una esfera de 5 pies de radio. Todas las criaturas situadas en la esfera deberán superar una tirada de salvación de Destreza o sufrirán 1d6 de daño de ácido.",
    "tables": [],
    "sections": [
      {
        "title": "Mejora de truco",
        "text": "El daño aumenta en 1d6 cuando alcanzas los niveles 5 (2d6), 11 (3d6) y 17 (4d6)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 5,
      "measure": "radius"
    }
  },
  {
    "name": "SALTO",
    "level": 1,
    "school": "Transmutación",
    "classes": [
      "druida",
      "explorador",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción adicional",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "la pata trasera de un saltamontes"
    },
    "duration": "1 minuto",
    "ritual": false,
    "concentration": false,
    "description": "Tocas a una criatura voluntaria.\n\nUna vez en cada uno de sus turnos hasta que el conjuro termine, la criatura puede saltar hasta 30 pies usando 10 pies de movimiento.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d6 por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "SANCTASANCTÓRUM PRIVADO DE MORDENKAINEN",
    "level": 4,
    "school": "Abjuración",
    "classes": [
      "mago"
    ],
    "casting_time": "10 minutos",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una lámina dina de plomo"
    },
    "duration": "24 horas",
    "ritual": false,
    "concentration": false,
    "description": "Haces que una zona dentro del alcance sea mágicamente segura. Esta zona es un cubo que puede tener un tamaño desde tan solo 5 pies de lado a hasta 100 pies y permanecerá hasta que el conjuro termine.\n\nCuando lanzas el conjuro, decides el tipo de seguridad que proporciona eligiendo cualesquiera de las siguientes propiedades:\n\n• El sonido no puede atravesar la barrera del perímetro de la zona protegida.\n\n• La barrera de la zona protegida parece oscura y con niebla, impidiendo ver a través de ella (incluso a la visión en la oscuridad).\n\n• Dentro de la zona protegida no pueden aparecer sensores creados mediante conjuros de adivinación, ni estos pueden atravesar la barrera del perímetro.\n\n• Las criaturas en la zona no pueden ser el objetivo de conjuros de adivinación.\n\n• Nada puede teletransportarse ni al interior ni al exterior del área protegida.\n\n• El viaje interplanar está bloqueado dentro de la zona. Si este conjuro se lanza a diario en el mismo lugar durante 365 días, durará hasta que sea disipado.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "SANTUARIO",
    "level": 1,
    "school": "Abjuración",
    "classes": [
      "clerigo"
    ],
    "casting_time": "Acción adicional",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un trozo de vidrio de un espejo"
    },
    "duration": "1 minuto",
    "ritual": false,
    "concentration": false,
    "description": "Proteges a una criatura que esté dentro del alcance. Hasta que el conjuro termine, cualquier criatura que haga objetivo a la criatura protegida con un ataque o un conjuro que inflija daño deberá superar primero una tirada de salvación de Sabiduría; de lo contrario, elegirá un nuevo objetivo o perderá el ataque o conjuro. Este conjuro no protege a la criatura contra los efectos de área. El conjuro termina si la criatura protegida hace una tirada de ataque, lanza un conjuro o inflige daño.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "SEMIPLANO",
    "level": 8,
    "school": "Conjuración",
    "classes": [
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": false,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Creas una puerta de sombras Mediana en una superficie sólida plana que puedas ver dentro del alcance. Esta puerta puede abrirse y cerrarse y lleva a un semiplano que parece una habitación vacía de 30 pies de lado en cada dimensión, hecha de madera o de piedra (a tu elección). Cuando el conjuro termina, la puerta se desvanecerá y todos los objetos dentro del semiplano permanecerán en él.\n\nLas criaturas que haya también se quedarán dentro salvo que prefieran que la puerta las expulse cuando se desvanece, lo que hará que aterricen con el estado de derribadas en los espacios sin ocupar más cercanos a donde estaba la puerta. Cada vez que lances este conjuro, puedes crear un nuevo semiplano o hacer que la puerta de sombras conecte con un semiplano que hayas creado previamente con el conjuro.\n\nAdemás, si conoces la naturaleza y el contenido de un semiplano creado cuando otra criatura lanzó este conjuro, en su lugar puedes hacer que la puerta de sombras conecte con dicho semiplano.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "SENTIDOS DE LA BESTIA",
    "level": 2,
    "school": "Adivinación",
    "classes": [
      "druida",
      "explorador"
    ],
    "casting_time": "Acción o ritual",
    "range": "Toque",
    "components": {
      "v": false,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 hora",
    "ritual": true,
    "concentration": true,
    "description": "Tocas a una bestia voluntaria.\n\nHasta que el conjuro termine, puedes percibir a través de los sentidos de la bestia, así como de los tuyos. Cuando percibes a través de ella, te beneficias de cualquier sentido especial que tenga.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "SEÑAL DE ESPERANZA",
    "level": 3,
    "school": "Abjuración",
    "classes": [
      "clerigo"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Elige cualquier cantidad de criaturas dentro del alcance. Hasta que el conjuro termine, todos los objetivos tienen ventaja en sus tiradas de salvación de Sabiduría y sus tiradas de salvación contra muerte, y también recuperan la cantidad máxima posible de puntos de golpe en cualquier curación.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "SHILLELAGH",
    "level": 0,
    "school": "Transmutación",
    "classes": [
      "druida"
    ],
    "casting_time": "Acción adicional",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "muérdago"
    },
    "duration": "1 minuto",
    "ritual": false,
    "concentration": false,
    "description": "Un bastón o un garrote que sostengas se ve impregnado del poder de la naturaleza. Hasta que termine el conjuro, puedes usar tu aptitud mágica en lugar de tu Fuerza para las tiradas de ataque y de daño de tus ataques cuerpo a cuerpo usando esa arma y el dado de daño pasa a ser un d8. Si el ataque inflige daño, puede ser de fuerza o del tipo de daño normal del arma (a tu elección).\n\nEl conjuro termina antes de tiempo si lo vuelves a lanzar o si sueltas el arma.",
    "tables": [],
    "sections": [
      {
        "title": "Mejora de truco",
        "text": "El dado de daño cambia cuando alcanzas los niveles 5 (d10), 11 (d12) y 17 (2d6)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "SILENCIO",
    "level": 2,
    "school": "Ilusionismo",
    "classes": [
      "bardo",
      "clerigo",
      "explorador"
    ],
    "casting_time": "Acción o ritual",
    "range": "120 pies / 20 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 10 minutos",
    "ritual": true,
    "concentration": true,
    "description": "Hasta que termine el conjuro, creas una esfera de 20 pies de radio centrada en un punto de tu elección dentro del alcance. Ningún sonido podrá atravesarla ni originarse en su interior. Toda criatura u objeto tiene inmunidad al daño de trueno si se halla completamente dentro de la esfera, y las criaturas tienen el estado de ensordecidas en su interior.\n\nDentro de ella es imposible lanzar conjuros que tengan un componente verbal.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 20,
      "measure": "radius"
    }
  },
  {
    "name": "SIMULACRO",
    "level": 7,
    "school": "Ilusionismo",
    "classes": [
      "mago"
    ],
    "casting_time": "12 horas",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "rubí en polvo que valga al menos 1500 po, que se consume como parte del conjuro"
    },
    "duration": "Hasta que sea disipado",
    "ritual": false,
    "concentration": false,
    "description": "Creas un simulacro de una bestia o humanoide que permanezca a 10 pies o menos de ti durante todo el tiempo de lanzamiento del conjuro. Para finalizar el lanzamiento, tocas a la criatura y una pila de hielo o nieve de su mismo tamaño, de modo que la pila se transformará en un simulacro y será una criatura.\n\nEl simulacro tendrá el perfil de la criatura original en el momento del lanzamiento, excepto que es un autómata, tiene la mitad de puntos de golpe máximos y no puede lanzar este conjuro. El simulacro es amistoso contigo y con las criaturas que designes, obedece tus órdenes y actúa en tu turno en combate.\n\nAdemás, no puede subir de nivel ni hacer descansos cortos o largos.\n\nSi el simulacro sufre daño, la única forma de restaurar sus puntos de golpe es repararlo cuando hagas un descanso largo. En ese momento, puedes gastar componentes con un valor de 100 po por cada punto de golpe recuperado. Para repararlo, el simulacro debe permanecer a 5 pies o menos de ti.\n\nEl simulacro dura hasta que sus puntos de golpe se reducen a 0, momento en el que vuelve a convertirse en nieve o hielo y se derrite. Si vuelves a lanzar este conjuro, cualquier simulacro que hayas creado antes con él se destruye al instante.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "SIRVIENTE HOMÚNCULO",
    "level": 2,
    "school": "Conjuración",
    "classes": [
      "artifice"
    ],
    "casting_time": "1 hora o ritual",
    "range": "10 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una gema con un valor de 100 po o más"
    },
    "duration": "Instantáneo",
    "ritual": true,
    "concentration": false,
    "description": "Invocas a un homúnculo especial en un espacio desocupado dentro del alcance. Esta criatura usa el perfil de Sirviente Homúnculo. Si ya tienes un homúnculo creado por este conjuro, el homúnculo anterior es reemplazado por el nuevo.\n\nTú determinas la apariencia del homúnculo, como un pájaro de aspecto mecánico, un vial alado o un pequeño caldero animado en miniatura.\n\nCombate. El homúnculo es un aliado para ti y tus aliados. En combate, comparte tu cuenta de iniciativa, pero actúa inmediatamente después de ti. Obedece tus órdenes (no requiere ninguna acción por tu parte). Si no le das ninguna, realiza la acción de Esquivar y usa su movimiento para evitar el peligro.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Usa el nivel del espacio de conjuro para determinar el nivel del conjuro en el perfil."
      }
    ],
    "source": "PHB2024 + EFotA"
  },
  {
    "name": "SIRVIENTE INVISIBLE",
    "level": 1,
    "school": "Conjuración",
    "classes": [
      "bardo",
      "brujo",
      "mago"
    ],
    "casting_time": "Acción o ritual",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un trozo de cuerda y uno de madera"
    },
    "duration": "1 hora",
    "ritual": true,
    "concentration": false,
    "description": "Este conjuro crea una fuerza invisible de tamaño Mediano, sin mente y sin forma, que realiza las tareas sencillas que le ordenes hasta que el conjuro termine. El sirviente surge en un espacio sin ocupar en el suelo dentro del alcance. Tiene una CA de 10, 1 punto de golpe, una Fuerza de 2 y no puede atacar.\n\nSi sus puntos de golpe se reducen a 0, el conjuro termina. Una vez en cada uno de tus turnos como acción adicional, puedes ordenar mentalmente al sirviente que se mueva hasta 15 pies y que interactúe con un objeto. El sirviente puede realizar tareas sencillas que también podría llevar a cabo un humano, como traer y llevar cosas, limpiar, remendar, plegar ropa, encender un fuego y servir comida o bebida.\n\nEn cuanto das la orden, el sirviente realiza la tarea lo mejor que puede hasta que la completa y luego espera tu siguiente orden. Si ordenas al sirviente que lleve a cabo una tarea que lo alejaría más de 60 pies de ti, el conjuro termina.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "SORDERA/CEGUERA",
    "level": 2,
    "school": "Transmutación",
    "classes": [
      "bardo",
      "clerigo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "1 minuto",
    "ritual": false,
    "concentration": false,
    "description": "Una criatura que puedas ver dentro del alcance deberá superar una tirada de salvación de Constitución o tendrá el estado de cegada o ensordecida (a tu elección) hasta que el conjuro termine. Al final de cada uno de sus turnos, el objetivo repite la tirada de salvación y, si tiene éxito, se librará del conjuro.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Puedes hacer objetivo a una criatura adicional por cada nivel por encima de 2 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "SUGESTIÓN",
    "level": 2,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": false,
      "m": true,
      "material": "una gota de miel"
    },
    "duration": "hasta 8 horas",
    "ritual": false,
    "concentration": true,
    "description": "Sugieres un curso de acción (de no más de 25 palabras) a una criatura que puedas ver dentro del alcance y que te pueda oír y entender. La sugerencia tiene que parecer factible y no ser claramente dañina para el objetivo o sus aliados. Por ejemplo, podrías decir: \"Ve a por la llave de la cámara del tesoro de la secta y tráemela\", o quizá \"deja de luchar, vete pacíficamente de la biblioteca y no vuelvas\". El objetivo deberá superar una tirada de salvación de Sabiduría o tendrá el estado de hechizado hasta que termine el conjuro o hasta que tus aliados o tú le hagáis daño. El objetivo hechizado llevará a cabo la sugerencia lo mejor que pueda. La actividad sugerida puede seguir hasta que termine el conjuro, pero si se puede completar en menos tiempo, el conjuro terminará sobre el objetivo cuando la complete.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "SUGESTIÓN EN MASA",
    "level": 6,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": false,
      "m": true,
      "material": "una lengua de serpiente"
    },
    "duration": "24 horas",
    "ritual": false,
    "concentration": false,
    "description": "Influyes mágicamente en la mente de hasta doce criaturas de tu elección que puedas ver dentro del alcance y que puedan oírte. Cada objetivo debe superar una tirada de salvación de Sabiduría o quedar hechizado durante la duración.\n\nMientras esté hechizado de este modo, el objetivo sigue una sugerencia que formulas y que debe sonar razonable. La sugerencia puede ordenar una acción concreta o una conducta general durante toda la duración del conjuro.\n\nLa sugerencia no puede implicar un daño evidente para el objetivo. El conjuro termina para un objetivo si este recibe daño o si completas la tarea sugerida.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "SUSURROS DISCORDANTES",
    "level": 1,
    "school": "Encantamiento",
    "classes": [
      "bardo"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Una criatura de tu elección que puedas ver dentro del alcance oye una melodía discordante en su mente. El objetivo hace una tirada de salvación de Sabiduría. Si la falla, recibirá 3d6 de daño psíquico y deberá utilizar su reacción inmediatamente, si es posible, para alejarse de ti tanto como pueda por la ruta más segura. Si supera la tirada, solo sufrirá la mitad de ese daño.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d6 por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "SYNOSTODWEOMER DE LA SÍMBUL",
    "level": 7,
    "school": "Transmutación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Imbuyes a una criatura que toques con energía mágica curativa durante la duración. Siempre que el objetivo lance un conjuro usando un espacio de conjuro, el objetivo puede tirar un número de Dados de Golpe no gastados igual al nivel del espacio de conjuro utilizado.\n\nEl objetivo recupera puntos de golpe iguales al total obtenido en las tiradas más tu modificador de característica de conjuro, y esos Dados de Golpe quedan gastados.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "SÍMBOLO",
    "level": 7,
    "school": "Abjuración",
    "classes": [
      "bardo",
      "clerigo",
      "druida",
      "mago"
    ],
    "casting_time": "1 minuto",
    "range": "Toque / 60 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "diamante en polvo que valga al menos 1000 po y que se consume como parte del conjuro"
    },
    "duration": "Hasta que sea disipado",
    "ritual": false,
    "concentration": false,
    "description": "Inscribes un glifo dañino en una superficie (como una sección de suelo o una pared) o en un objeto que se pueda cerrar (como un libro o un cofre). El glifo puede abarcar un área de hasta 10 pies de diámetro. Si eliges un objeto, este debe permanecer en su lugar; si se mueve más de 10 pies desde donde lanzaste el conjuro, el glifo se rompe y el conjuro termina sin activarse.\n\nEl glifo es casi imperceptible. Para detectarlo, una criatura debe superar una prueba de Sabiduría (Percepción) contra tu CD de salvación de conjuros.\n\nCuando inscribes el glifo, decides qué condición lo activa y qué efecto produce el símbolo entre los que se describen a continuación.\n\n• **Establecer el activador** Al lanzar el conjuro, decides qué activa el glifo. En una superficie, las condiciones habituales incluyen tocarlo, situarse sobre él, retirar un objeto que lo cubra o acercarse a cierta distancia. En un objeto, suele activarse al abrirlo o al mirar el glifo. Puedes especificar condiciones adicionales, como que solo ciertas criaturas lo activen (por ejemplo, solo aberraciones), o establecer excepciones, como criaturas que conozcan una contraseña.\n\n• **Área de efecto** Una vez activado, el glifo brilla y llena una esfera de 60 pies de radio con luz tenue durante 10 minutos, tras lo cual el conjuro termina. Todas las criaturas dentro de la esfera cuando el glifo se activa son objetivo del efecto, al igual que cualquier criatura que entre en la esfera por primera vez en un turno o termine su turno allí. Una criatura solo puede verse afectada una vez por turno.\n\n**Efectos del símbolo**\n\nElige uno de los siguientes efectos cuando inscribes el glifo:\n\n• **Aturdimiento.** Cada objetivo debe superar una tirada de salvación de Sabiduría o queda aturdido durante 1 minuto.\n\n• **Discordia.** Cada objetivo hace una tirada de salvación de Sabiduría. Si falla, discute verbalmente con otras criaturas durante 1 minuto. Durante ese tiempo, no puede comunicarse de forma razonable y tiene desventaja en las tiradas de ataque y las pruebas de característica.\n\n• **Dolor.** Cada objetivo debe superar una tirada de salvación de Constitución o queda incapacitado durante 1 minuto.\n\n• **Muerte.** Cada objetivo hace una tirada de salvación de Constitución. Si falla, sufre 10d10 de daño necrótico; si tiene éxito, recibe la mitad del daño.\n\n• **Sueño.** Cada objetivo debe superar una tirada de salvación de Sabiduría o queda inconsciente durante 10 minutos. La criatura despierta si recibe daño o si otra criatura usa una acción para sacudirla.\n\n• **Terror.** Cada objetivo debe superar una tirada de salvación de Sabiduría o queda asustado durante 1 minuto. Mientras esté asustado de este modo, el objetivo debe alejarse al menos 30 pies del glifo en cada uno de sus turnos, si puede.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 60,
      "measure": "radius"
    }
  },
  {
    "name": "TAUMATURGIA",
    "level": 0,
    "school": "Transmutación",
    "classes": [
      "clerigo",
      "segador"
    ],
    "casting_time": "Acción",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Hasta 1 minuto",
    "ritual": false,
    "concentration": false,
    "description": "Manifiestas un pequeño milagro dentro del alcance y produces uno de los siguientes efectos mágicos. Si lanzas este conjuro varias veces, puedes mantener activos al mismo tiempo hasta tres efectos de 1 minuto.\n\n• **Jugar con fuego.** Haces que las llamas parpadeen, brillen más, se atenúen o cambien de color durante 1 minuto.\n\n• **Mano invisible.** Abres o cierras de golpe una puerta o ventana que no esté cerrada con llave.\n\n• **Ojos alterados.** Cambias el aspecto de tus ojos durante 1 minuto.\n\n• **Sonido fantasmal.** Creas un sonido instantáneo que procede de un punto de tu elección dentro del alcance, como el retumbar de un trueno, el graznido de un cuervo o unos susurros inquietantes.\n\n• **Temblores.** Provocas que la tierra tiemble levemente sin causar daños durante 1 minuto.\n\n• **Voz atronadora.** Tu voz resuena hasta tres veces más alto de lo normal durante 1 minuto. Hasta que termine el conjuro, tienes ventaja en las pruebas de Carisma (Intimidación).",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "TAÑIDO POR LOS MUERTOS",
    "level": 0,
    "school": "Nigromancia",
    "classes": [
      "brujo",
      "clerigo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Señalas a una criatura que puedas ver dentro del alcance y el sonido de una campana funesta suena a 10 pies o menos del objetivo. El objetivo deberá superar una tirada de salvación de Sabiduría o sufrirá 1d8 de daño necrótico. Si el objetivo no tiene todos sus puntos de golpe, el daño necrótico aumenta a 1d12.",
    "tables": [],
    "sections": [
      {
        "title": "Mejora de truco",
        "text": "El daño aumenta cuando alcanzas los niveles 5 (2d8 o 2d12), 11 (3d8 o 3d12) y 17 (4d8 o 4d12)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "TELARAÑA",
    "level": 2,
    "school": "Conjuración",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies / 20 pies de cubo",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un poco de tela de araña"
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Conjuras una masa de telarañas pegajosas en un punto dentro del alcance. Las telarañas ocupan un cubo de 20 pies de lado en ese espacio hasta que el conjuro termine. Las telarañas son terreno difícil y su interior se considera ligeramente oscuro. Si las telarañas no están ancladas entre dos objetos sólidos (como muros o árboles) o extendidas sobre un suelo, muro o techo, se vendrán abajo y el conjuro terminará al principio de tu siguiente turno. Las telarañas dispuestas sobre una superficie plana tienen una profundidad de 5 pies. La primera vez que una criatura entre en las telarañas o termine su turno allí, deberá superar una tirada de salvación de Destreza o tendrá el estado de apresada mientras permanezca en ellas o hasta que se libere. Una criatura apresada puede utilizar una acción para hacer una prueba de Fuerza (Atletismo) contra tu CD de salvación de conjuros.\n\nSi la supera, dejará de estar apresada. Las telarañas son inflamables. Cualquier cubo de telarañas de 5 pies de lado expuesto al fuego se quema por completo en 1 asalto y causa 2d4 de daño de fuego a cualquier criatura que comience su turno en el incendio.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "cube",
      "sizeFt": 20
    }
  },
  {
    "name": "TELEPATÍA",
    "level": 8,
    "school": "Adivinación",
    "classes": [
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Ilimitado",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un par de anillos de plata enlazados"
    },
    "duration": "24 horas",
    "ritual": false,
    "concentration": false,
    "description": "Creas un enlace telepático entre tú y una criatura voluntaria que conozcas. El objetivo puede estar en cualquier lugar del mismo plano de existencia que tú, pero el conjuro terminará si dejáis de estar en el mismo plano.\n\nHasta que el conjuro termine, el objetivo y tú podéis compartir de forma instantánea palabras, imágenes, sonidos y otros mensajes sensoriales mediante el enlace, y el objetivo te reconoce como la criatura con la que se está comunicando. El conjuro permite que una criatura comprenda el significado de tus palabras y cualquier mensaje sensorial que le envíes.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "TELEQUINESIS",
    "level": 5,
    "school": "Transmutación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Obtienes la capacidad de mover o manipular criaturas u objetos con la mente. Cuando lanzas este conjuro y como acción de magia en tus siguientes hasta que termine el conjuro, puedes imponer tu voluntad sobre una criatura o un objeto que puedas ver dentro del alcance y provocar el efecto correspondiente de los indicados debajo. Puedes afectar al mismo objetivo cada asalto o elegir uno nuevo cada vez. Si cambias de objetivo, el anterior dejará de estar afectado por el conjuro.\n\n• Criatura. Puedes intentar mover a una criatura Enorme o más pequeña. El objetivo deberá superar una tirada de salvación de Fuerza o lo moverás hasta 30 pies en cualquier dirección dentro del alcance del conjuro. Hasta el final de tu siguiente turno, la criatura tendrá el estado de apresada y, si la elevas en el aire, quedará suspendida. Caerá al final de tu siguiente turno a menos que vuelvas a usar esta opción y falle la tirada de salvación.\n\n• Objeto. Puedes intentar mover un objeto Enorme o más pequeño. Si el objeto no lo lleva ni viste nadie, lo mueves automáticamente hasta 30 pies en cualquier dirección dentro del alcance del conjuro.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "TELETRANSPORTE",
    "level": 7,
    "school": "Conjuración",
    "classes": [
      "bardo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "10 pies",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Este conjuro te transporta al instante a ti y hasta ocho criaturas voluntarias de tu elección que puedas ver dentro del alcance, o a un único objeto que puedas ver dentro del alcance, hasta un destino que selecciones. Si haces objetivo a un objeto, debe caber por completo dentro de un cubo de 10 pies y no puede estar siendo sujetado ni llevado por una criatura no voluntaria. El destino que elijas debe resultarte conocido y encontrarse en tu mismo plano de existencia. Tu grado de familiaridad con el destino determina si llegas donde pretendías, según la tabla.",
    "tables": [
      {
        "title": "Resultado del teletransporte",
        "columns": [
          "Familiaridad",
          "Percance",
          "Área similar",
          "Lejos del objetivo",
          "En el objetivo"
        ],
        "rows": [
          [
            "Círculo permanente",
            "—",
            "—",
            "—",
            "01–00"
          ],
          [
            "Objeto vinculado",
            "—",
            "—",
            "—",
            "01–00"
          ],
          [
            "Muy familiar",
            "01–05",
            "06–13",
            "14–24",
            "25–00"
          ],
          [
            "Visto esporádicamente",
            "01–33",
            "34–43",
            "44–53",
            "54–00"
          ],
          [
            "Visto una vez o descrito",
            "01–43",
            "44–53",
            "54–73",
            "74–00"
          ],
          [
            "Destino falso",
            "01–50",
            "51–00",
            "—",
            "—"
          ]
        ]
      }
    ],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "TENTÁCULOS NEGROS DE EVARD",
    "level": 4,
    "school": "Conjuración",
    "classes": [
      "mago"
    ],
    "casting_time": "Acción",
    "range": "90 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un tentáculo"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Unos tentáculos color ébano que se retuercen llenan un cuadrado en el suelo de 20 pies de lado que puedas ver dentro del alcance. Hasta que termine el conjuro, estos tentáculos convertirán la zona en terreno difícil. Todas las criaturas situadas en esa zona hacen una tirada de salvación de Fuerza. Si la fallan, sufrirán 3d6 de daño contundente y tendrán el estado de apresadas hasta que el conjuro termine. Una criatura también deberá hacer la tirada si entra en la zona o termina su turno en ella. Cada criatura solo hace esta tirada una vez por turno. Una criatura apresada puede emplear una acción para hacer una prueba de Fuerza (Atletismo) contra tu CD de salvación de conjuros y, si la supera, pondrá fin a su estado.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "TERREMOTO",
    "level": 8,
    "school": "Transmutación",
    "classes": [
      "clerigo",
      "druida",
      "hechicero"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una piedra fracturada"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Elige un punto del suelo que puedas ver dentro del alcance. Hasta que el conjuro termine, una intensa sacudida afecta al suelo en un círculo de 100 pies de radio centrado en ese punto. El suelo de la zona se considera terreno difícil. Cuando lances este conjuro y al final de cada uno de tus turnos hasta que termine, todas las criaturas que haya en el suelo en la zona deberán hacer una tirada de salvación de Destreza. Si la fallan, tendrán el estado de derribadas y perderán la concentración.\n\nAdemás, podrás provocar los siguientes efectos.\n\n• Grietas. Se abre un total de 1d6 fisuras en la zona del conjuro al final del turno en que lo lances. Tú eliges la ubicación de las grietas, que pueden estar debajo de estructuras. Cada una tiene una profundidad de 1d10 x 10 pies y una anchura de 10 pies y se extiende desde un borde del área del conjuro hasta otro borde. Una criatura que esté en el mismo espacio que una grieta deberá superar una tirada de salvación de Destreza o caerá en ella. Si la supera, la criatura se moverá a la vez que se abre el borde de la grieta y se mantendrá allí.\n\n• Estructuras. El temblor causa 50 de daño contundente a cualquier estructura que esté en contacto con el suelo de la zona cuando lances el conjuro y al final de cada uno de tus turnos hasta que el conjuro termine. Si los puntos de golpe de una estructura se reducen a 0, se derrumbará. Una criatura que se encuentre a una distancia de una estructura que se derrumba igual a la mitad de su altura hace una tirada de salvación de Destreza. Si la falla, sufrirá 12d6 de daño contundente, tendrá el estado de derribada y quedará enterrada entre los escombros. Para escapar, como acción tendrá que superar una prueba de Fuerza (Atletismo) con CD 20. Si la supera, solo sufrirá la mitad de ese daño.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "TERRENO ALUCINATORIO",
    "level": 4,
    "school": "Ilusionismo",
    "classes": [
      "bardo",
      "brujo",
      "druida",
      "mago"
    ],
    "casting_time": "10 minutos",
    "range": "300 pies / 150 pies de cubo",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una seta"
    },
    "duration": "24 horas",
    "ritual": false,
    "concentration": false,
    "description": "Haces que un terreno natural en un cubo de 150 pies de lado dentro del alcance tenga el aspecto, los sonidos y los olores de otro tipo de terreno natural. Por ejemplo, puedes hacer que un campo abierto o una carretera se parezcan a un pantano, una colina, una grieta u otro tipo de terreno difícil o infranqueable.\n\nSe puede hacer que un estanque parezca una pradera cubierta de hierba, que un precipicio se aparezca como una suave cuesta o que un barranco pedregoso y estrecho se presente como una carretera amplia y lisa. Las estructuras fabricadas, el equipo y las criaturas en la zona no cambian.\n\nLas características táctiles del terreno no cambian, por lo que es probable que las criaturas que entren en la zona descubran que es una ilusión. Si la diferencia no es obvia al tacto, cualquier criatura que examine la ilusión puede usar una acción de estudiar y hacer una prueba de Inteligencia (Investigación) contra tu CD de salvación de conjuros para distinguirla.\n\nSi criatura percibe que es una ilusión, la verá como una imagen difusa y superpuesta al terreno de verdad.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "cube",
      "sizeFt": 150
    }
  },
  {
    "name": "TERROR",
    "level": 3,
    "school": "Ilusionismo",
    "classes": [
      "bardo",
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal / 30 pies de cono",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una pluma blanca"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Todas las criaturas situadas en un cono de 30 pies deberán superar una tirada de salvación de Sabiduría o soltarán cualquier cosa que tengan agarrada y tendrán el estado de asustadas hasta que termine el conjuro. Una criatura asustada realizará la acción de correr en todos sus turnos para alejarse de ti por la ruta más segura, a menos que no haya por dónde huir. Si la criatura acaba su turno en un espacio desde el que no tenga línea de visión directa de ti, hará una tirada de salvación de Sabiduría. Si la supera, el conjuro terminará para ella.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "cone",
      "sizeFt": 30
    }
  },
  {
    "name": "TERROR ABYECTO",
    "level": 9,
    "school": "Ilusionismo",
    "classes": [
      "brujo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies / 30 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Intentas crear horrores ilusorios en las mentes de otros. Todas las criaturas de tu elección situadas en una esfera de 30 pies de radio centrada en un punto dentro del alcance realizan una tirada de salvación de Sabiduría. Si la fallan, los objetivos sufrirán 10d10 de daño psíquico y tendrán el estado de asustados hasta que el conjuro termine. Si la superan, solamente recibirán la mitad de ese daño. Un objetivo asustado hará una tirada de salvación de Sabiduría al final de cada uno de sus turnos. Si la falla, sufrirá 5d10 de daño psíquico. Si la supera, el conjuro terminará para ese objetivo.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 30,
      "measure": "radius"
    }
  },
  {
    "name": "TEXTO ILUSORIO",
    "level": 1,
    "school": "Ilusionismo",
    "classes": [
      "bardo",
      "brujo",
      "mago"
    ],
    "casting_time": "1 minuto o un ritual",
    "range": "Toque",
    "components": {
      "v": false,
      "s": true,
      "m": true,
      "material": "tinta que valga al menos 10 po, que se consume como parte del conjuro"
    },
    "duration": "10 días",
    "ritual": true,
    "concentration": false,
    "description": "Escribes en pergamino, papel u otro material adecuado y lo impregnas con una ilusión hasta que termine el conjuro. Para ti y las demás criaturas que designes cuando lanzas el conjuro, el texto parece normal, escrito con tu letra, y transmite el significado que pretendieras al escribirlo. Para los demás, el texto parece escrito en letra mágica o desconocida y es ininteligible.\n\nComo alternativa, la ilusión puede modificar el significado, la caligrafía y el idioma de un texto, aunque el idioma debe ser uno que conozcas. Si el conjuro se disipa, desaparecerán tanto el escrito original como la ilusión. Una criatura con visión verdadera puede leer el mensaje oculto.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "TOQUE HELADO",
    "level": 0,
    "school": "Nigromancia",
    "classes": [
      "brujo",
      "hechicero",
      "mago",
      "segador"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Canalizas un frío sepulcral y haces un ataque de conjuro cuerpo a cuerpo contra un objetivo dentro del alcance. Si acierta, el objetivo recibirá 1d10 de daño necrótico y no podrá recuperar puntos de golpe hasta el final de tu siguiente turno.",
    "tables": [],
    "sections": [
      {
        "title": "Mejora de truco",
        "text": "El daño aumenta en 1d10 cuando alcanzas los niveles 5 (2d10), 11 (3d10) y 17 (4d10)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "TOQUE VAMPÍRICO",
    "level": 3,
    "school": "Nigromancia",
    "classes": [
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "El toque de tu mano envuelta en sombras puede absorber la fuerza vital de otros para curar tus heridas. Haz un ataque de conjuro cuerpo a cuerpo contra una criatura dentro del alcance. Si acierta, el objetivo sufrirá 3d6 de daño necrótico y tú recuperarás una cantidad de puntos de golpe igual a la mitad del daño necrótico infligido. Hasta que el conjuro termine, podrás realizar el ataque otra vez como acción de magia en cada uno de tus turnos y hacer objetivo a la misma criatura o a otra distinta.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d6 por cada nivel por encima de 3 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "TORMENTA DE AGUANIEVE",
    "level": 3,
    "school": "Conjuración",
    "classes": [
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "150 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un paraguas en miniatura"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Hasta que el conjuro termine, caerá aguanieve en un cilindro de 40 pies de alto y 20 pies de radio centrado en un punto que elijas dentro del alcance. La zona está muy oscura y las llamas desprotegidas que haya en ella se apagan. El suelo abarcado en el cilindro es terreno difícil. Cuando una criatura entre en el cilindro por primera vez en un turno o comience su turno en él, deberá superar una tirada de salvación de Destreza o tendrá el estado de derribada y perderá la concentración.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "TORMENTA DE ESPINAS",
    "level": 1,
    "school": "Conjuración",
    "classes": [
      "explorador"
    ],
    "casting_time": "Acción adicional",
    "range": "Personal",
    "components": {
      "v": true,
      "s": false,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Lanzas este conjuro como acción adicional que realizas. Al golpear a la criatura, el conjuro crea una lluvia de espinas que saldrá disparada de tu arma a distancia o munición. El objetivo del ataque y todas las criaturas a 5 pies o menos de él hacen una tirada de salvación de Destreza; sufrirán 1d10 de daño perforante si la fallan o la mitad del daño si la superan.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño aumenta en 1d10 por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "TORMENTA DE FUEGO",
    "level": 7,
    "school": "Evocación",
    "classes": [
      "clerigo",
      "druida",
      "hechicero"
    ],
    "casting_time": "Acción",
    "range": "150 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Una tormenta de llamas aparece dentro del alcance. El área de la tormenta consta de hasta diez cubos de 10 pies de lado que puedes disponer según desees, cada uno de los cuales debe estar adyacente al menos a otro. Todas las criaturas situadas en la zona de 15 pies deberán realizar una tirada de salvación de Destreza; sufrirán 7d10 de daño de fuego si la fallan o la mitad del daño si la superan. Los objetos inflamables dentro del área que no lleve o vista nadie empezarán a arder.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "TORMENTA DE FUEGO DE HECHICERÍA",
    "level": 4,
    "school": "Evocación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "60 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Conjuras un pilar de fuego de hechicería en forma de cilindro de 20 pies de radio y 20 pies de altura, centrado en un punto que puedas ver dentro del alcance. El área queda iluminada con luz brillante. Cuando el cilindro aparece, cada criatura dentro de él debe realizar una tirada de salvación de Constitución. Si falla, recibe 4d10 de daño radiante. Si la supera, recibe la mitad del daño. Una criatura también debe realizar esta tirada la primera vez que entra en el área en un turno o cuando termina su turno en ella. Una criatura solo puede recibir este daño una vez por turno. Cuando lanzas este conjuro, puedes designar criaturas para que no se vean afectadas por él.\n\n**Lanzamiento como Conjuro de Círculo.**\nRequiere un componente especial, un zafiro estrella azul valorado en 25.000 po, que se consume. La duración y el tamaño del área aumentan según el número de lanzadores secundarios.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "TORMENTA DE HIELO",
    "level": 4,
    "school": "Evocación",
    "classes": [
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "300 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una manopla"
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Una granizada cae en un cilindro de 20 pies de radio y 40 pies de altura centrado en un punto dentro del alcance. Todas las criaturas situadas en el cilindro hacen una tirada de salvación de Destreza; sufrirán 2d10 de daño contundente y 4d6 de daño de frío si la fallan o la mitad del daño si la superan. Las bolas de granizo convierten el suelo del cilindro en terreno difícil hasta el final de tu siguiente turno.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño contundente aumenta en 1d10 por cada nivel por encima de 4 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "TORMENTA DE LA VENGANZA",
    "level": 9,
    "school": "Conjuración",
    "classes": [
      "druida"
    ],
    "casting_time": "Acción",
    "range": "1 milla / 300 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Hasta que termine el conjuro, una nube de tormenta se forma centrada en un punto dentro del alcance y se extiende hasta un radio de 300 pies. Todas las criaturas que estén debajo de ella cuando aparezca deberán superar una tirada de salvación de Constitución o sufrirán 2d6 de daño de trueno y tendrán el estado de ensordecidas hasta que el conjuro termine. Al principio de cada uno de tus siguientes turnos, la tormenta produce efectos diferentes, como se detalla a continuación.\n\n• Turno 2. Cae una lluvia ácida. Todas las criaturas y objetos que estén debajo de la nube sufrirán 4d6 de daño de ácido.\n\n• Turno 3. Invocas seis relámpagos que surgen de la nube para golpear a seis criaturas u objetos distintos bajo ella. Cada objetivo hace una tirada de salvación de Destreza; sufrirá 10d6 de daño de relámpago si la falla o la mitad del daño si la supera.\n\n• Turno 4. Caen bolas de granizo. Todas las criaturas que estén debajo de la nube sufrirán 2d6 de daño contundente.\n\n• Turnos 5 a 10. La zona bajo la nube se ve asolada por vendavales y aguanieve. Todas las criaturas que estén allí sufren 1d6 de daño de frío. Hasta que el conjuro termine, la zona es terreno difícil y está muy oscura. Además, es imposible hacer ataques con armas a distancia, ya que un fuerte viento sopla en toda la zona.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 300,
      "measure": "radius"
    }
  },
  {
    "name": "TORMENTA DE METEORITOS",
    "level": 9,
    "school": "Evocación",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "1 milla / 40 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Unos orbes de fuego abrasador caen en picado en cuatro puntos del suelo distintos que puedas ver dentro del alcance. Todas las criaturas situadas en una esfera de 40 pies de radio centrada en cada uno de esos puntos hacen una tirada de salvación de Destreza. Sufrirán 20d6 de daño de fuego y 20d6 de daño contundente si la fallan o la mitad del daño si la superan. Las criaturas que estén situadas en el área de efecto de más de una de las esferas ardientes solo se verán afectadas por una. Los objetos no mágicos que se encuentren dentro del área del conjuro también recibirán el daño, salvo silos lleva o viste una criatura, y empezarán a arder si son inflamables.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 40,
      "measure": "radius"
    }
  },
  {
    "name": "TORMENTA RESPLANDECIENTE DE JALLARZI",
    "level": 5,
    "school": "Evocación",
    "classes": [
      "brujo",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "120 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una pizca de fósforo"
    },
    "duration": "hasta 1 minuto",
    "ritual": false,
    "concentration": true,
    "description": "Desatas una tormenta de luz intermitente y truenos intensos en un cilindro de 10 pies de radio y 40 pies de alto centrado en un punto que puedas ver dentro del alcance. Mientras estén en esta zona, las criaturas tendrán los estados de cegadas y ensordecidas y no podrán lanzar Cuando aparezca la tormenta, todas las criaturas dentro de ella harán una tirada de salvación de Constitución; sufrirán 2d10 de daño radiante y 2d10 de daño de trueno si la fallan o la mitad del daño si la superan. Una criatura también hará esta tirada cuando entre en el área del conjuro por primera vez en un turno o termine su turno allí. Una criatura solo hace esta tirada una vez por turno. Mientras estén en esta zona, las criaturas tendrán los estados de cegadas y ensordecidas y no podrán lanzar conjuros que tengan un componente verbal.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "El daño radiante y de trueno aumenta en 1d10 por cada nivel por encima de 5 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "TREPAR CUAL ARÁCNIDO",
    "level": 2,
    "school": "Transmutación",
    "classes": [
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una gota de betún y una araña"
    },
    "duration": "hasta 1 hora",
    "ritual": false,
    "concentration": true,
    "description": "Hasta que el conjuro termine, una criatura voluntaria a la que toques gana la capacidad de moverse hacia arriba, hacia abajo y de lado por superficies verticales, así como por techos. Esta manera de moverse no requiere del uso de las manos, que quedan libres.\n\nAdemás, el objetivo obtiene una velocidad trepando igual a su velocidad.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Puedes hacer objetivo a una criatura adicional por cada nivel por encima de 2 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "TRONAR",
    "level": 0,
    "school": "Evocación",
    "classes": [
      "bardo",
      "brujo",
      "druida",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal / 5 pies de emanación",
    "components": {
      "v": false,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Todas las criaturas situadas en una emanación de 5 pies que se origina en ti deberán superar una tirada de salvación de Constitución o sufrirán 1d6 de daño de trueno. El sonido atronador del conjuro se puede oír a una distancia de hasta 100 pies.",
    "tables": [],
    "sections": [
      {
        "title": "Mejora de truco",
        "text": "El daño aumenta en 1d6 cuando alcanzas los niveles 5 (2d6), 11 (3d6) y 17 (4d6)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 5,
      "measure": "radius"
    }
  },
  {
    "name": "TRUCO DE LA CUERDA",
    "level": 2,
    "school": "Transmutación",
    "classes": [
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un trozo de cuerda"
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Tocas una cuerda, lo que hace que uno de sus extremos flote hacia arriba hasta que la cuerda se ponga perpendicular al suelo o toque un techo. En el extremo superior de la cuerda se abre un portal invisible de 5 pies por 5 pies, el cual conduce a un espacio extradimensional que dura hasta que el conjuro termine. Este espacio puede alcanzarse trepando por la cuerda, que puede recogerse o soltarse desde el interior.\n\nEn el espacio caben hasta ocho criaturas Medianas o más pequeñas.\n\nLos ataques, conjuros y otros efectos no pueden cruzar el espacio en ningún sentido, pero las criaturas que están dentro pueden ver a través del portal. Todo lo que esté dentro del espacio caerá fuera cuando el conjuro termine.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "TSUNAMI",
    "level": 8,
    "school": "Conjuración",
    "classes": [
      "druida"
    ],
    "casting_time": "1 minuto",
    "range": "1 milla",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "hasta 6 asaltos",
    "ritual": false,
    "concentration": true,
    "description": "Un muro de agua surge de la nada en un punto de tu elección dentro del alcance. Puedes hacerlo de hasta 300 pies de longitud, 300 pies de alto y 50 pies de grosor y durará hasta que termine el conjuro.\n\nCuando aparezca el muro, todas las criaturas situadas en su área hacen una tirada de salvación de Fuerza; sufrirán 6d10 de daño contundente si la fallan o la mitad de daño si la superan.\n\nAl principio de cada uno de tus turnos tras la aparición del muro, se alejará 50 pies de ti junto con todas las criaturas que haya en su interior. Cualquier criatura Enorme o más pequeña dentro del muro, o a cuyo espacio entre el muro cuando este se mueva, deberá superar una tirada de salvación de Fuerza o sufrirá 5d10 de daño contundente. Una criatura solo puede sufrir este daño una vez por asalto.\n\nAl final del turno, la altura del muro se reduce en 50 pies y el daño que causa el muro en asaltos subsiguientes se reduce en 1d10. Cuando el muro llegue a 0 pies de altura, el conjuro termina.\n\nUna criatura atrapada en el muro puede moverse nadando. Sin embargo, debido a la fuerza de la ola, la criatura deberá superar una prueba de Fuerza (Atletismo) contra tu CD de salvación de conjuros para moverse. Si no la supera, no podrá hacerlo.\n\nUna criatura que salga del muro caerá al suelo.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "URNA MÁGICA",
    "level": 6,
    "school": "Nigromancia",
    "classes": [
      "mago"
    ],
    "casting_time": "1 minuto",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una gema, un cristal o un relicario que valga al menos 500 po"
    },
    "duration": "Hasta que sea disipado",
    "ritual": false,
    "concentration": false,
    "description": "Tu cuerpo entra en estado catatónico y tu alma lo abandona y entra en el recipiente que has usado como componente material del conjuro. Mientras tu alma esté dentro del recipiente, serás consciente de lo que te rodea, igual que si estuvieras en el espacio de dicho recipiente. No podrás moverte ni llevar a cabo reacciones.\n\nLa única acción que puedes realizar es proyectar tu alma hasta 100 pies del recipiente, bien para regresar a tu cuerpo viviente (y poner fin al conjuro) o bien para tratar de poseer el cuerpo de un humanoide.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "VER INVISIBILIDAD",
    "level": 2,
    "school": "Adivinación",
    "classes": [
      "bardo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una pizca de talco"
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Hasta que termine el conjuro, ves a las criaturas y objetos que tengan el estado de invisibles como si fueran visibles y puedes ver en el Plano Etéreo.\n\nLas criaturas y objetos que haya en él tendrán un aspecto fantasmal.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "VIAJAR CON EL VIENTO",
    "level": 6,
    "school": "Transmutación",
    "classes": [
      "druida"
    ],
    "casting_time": "1 minuto",
    "range": "30 pies",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una vela"
    },
    "duration": "8 horas",
    "ritual": false,
    "concentration": false,
    "description": "del alcance asumís formas gaseosas hasta que termine el conjuro y tenéis la apariencia de jirones de nubes. En esta forma de nube, un objetivo tiene una velocidad volando de 300 pies, puede levitar, tiene inmunidad al estado de derribado y resistencia al daño contundente, cortante y perforante.\n\nLas únicas acciones que puede realizar un objetivo en esta forma son la acción de correr o una acción de magia para empezar a volver a su forma normal. Recuperarla lleva 1 minuto, durante el cual el objetivo tendrá el estado de aturdido. Hasta que el conjuro termine, el objetivo puede volver a la forma de nube, lo que también requiere una acción de magia seguida de una transformación de 1 minuto.\n\nSi un objetivo se encuentra en forma de nube y volando cuando el efecto termina, desciende 60 pies por asalto durante 1 minuto hasta aterrizar, lo que hace sin ningún peligro. Si transcurrido ese minuto no ha aterrizado, caerá la distancia restante.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "VIAJAR MEDIANTE PLANTAS",
    "level": 6,
    "school": "Conjuración",
    "classes": [
      "druida"
    ],
    "casting_time": "Acción",
    "range": "10 pies",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "1 minuto",
    "ritual": false,
    "concentration": false,
    "description": "Este conjuro crea un vínculo mágico entre una planta inanimada de tamaño Grande o mayor dentro del alcance y otra planta a cualquier distancia en el mismo plano de existencia. Tienes que haber visto o tocado la planta de destino al menos una vez antes. Hasta que termine el conjuro, cualquier criatura puede entrar en la planta objetivo y salir por la de destino gastando 5 pies de movimiento.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "VIGOR ARCANO",
    "level": 2,
    "school": "Abjuración",
    "classes": [
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción adicional",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Recurres a tu fuerza vital para curarte. Tira uno o dos de tus dados de puntos de golpe no gastados para recuperar una cantidad de puntos de golpe igual al resultado total de la tirada más tu modificador por aptitud mágica. Después, los dados se consideran gastados.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "La cantidad de dados de golpe no gastados que puedes tirar aumenta en uno por cada nivel por encima de 2 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "VISIÓN EN LA OSCURIDAD",
    "level": 2,
    "school": "Transmutación",
    "classes": [
      "druida",
      "explorador",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una zanahoria seca"
    },
    "duration": "8 horas",
    "ritual": false,
    "concentration": false,
    "description": "Hasta que el conjuro termine, una criatura voluntaria a la que toques tendrá visión en la oscuridad hasta 150 pies.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "VISIÓN VERAZ",
    "level": 6,
    "school": "Adivinación",
    "classes": [
      "bardo",
      "brujo",
      "clerigo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "hongos pulverizados que valgan al menos 25 po, que se consumen como parte del conjuro"
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Hasta que el conjuro termine, la criatura voluntaria ala que toques tendrá visión verdadera hasta 120 pies.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "VOLAR",
    "level": 3,
    "school": "Transmutación",
    "classes": [
      "brujo",
      "hechicero",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una pluma"
    },
    "duration": "hasta 10 minutos",
    "ritual": false,
    "concentration": true,
    "description": "Tocas a una criatura voluntaria.\n\nHasta que el conjuro termine, el objetivo consigue una velocidad volando de 60 pies y puede levitar.\n\nCuando el conjuro termine, el objetivo caerá si aún está en el aire, excepto si puede detener la caída.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Puedes hacer objetivo a una criatura adicional por cada nivel por encima de 3 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "VOLUTA ESTELAR",
    "level": 0,
    "school": "Evocación",
    "classes": [
      "bardo",
      "druida"
    ],
    "casting_time": "Acción",
    "range": "60 pies / 10 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "Instantáneo",
    "ritual": false,
    "concentration": false,
    "description": "Lanzas una mota de luz contra una criatura u objeto dentro del alcance. Haz un ataque de conjuro a distancia contra el objetivo. Si acierta, el objetivo recibirá 1d8 de daño radiante y, hasta el final de tu siguiente turno, emitirá luz tenue en un radio de 10 pies y no podrá beneficiarse del estado de invisible.",
    "tables": [],
    "sections": [
      {
        "title": "Mejora de truco",
        "text": "El daño aumenta en 1d8 cuando alcanzas los niveles 5 (2d8), 11 (3d8) y 17 (4d8)."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 10,
      "measure": "radius"
    }
  },
  {
    "name": "VÍBORA DE SYLUNÉ",
    "level": 3,
    "school": "Conjuración",
    "classes": [
      "druida",
      "mago"
    ],
    "casting_time": "Acción adicional",
    "range": "Personal",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un colmillo de serpiente"
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Una serpiente espectral y reluciente se enrosca alrededor de tu cuerpo durante la duración. Obtienes 15 puntos de golpe temporales. El conjuro termina antes si pierdes todos los puntos de golpe temporales.\n\nMientras el conjuro esté activo, obtienes los siguientes beneficios:\n\n• Trepar. Obtienes una velocidad de trepar igual a tu velocidad.\n\n• Mordedura Venenosa. Como Acción Mágica, puedes realizar un ataque de conjuro a distancia contra una criatura a 50 pies usando la serpiente. Impacto: 1d6 de daño de fuerza y el objetivo queda Envenenado hasta el inicio de tu siguiente turno. Si el objetivo ya estaba Envenenado, queda Incapacitado hasta el inicio de tu siguiente turno.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "VÍNCULO PROTECTOR",
    "level": 2,
    "school": "Abjuración",
    "classes": [
      "clerigo",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "un par de anillos de platino que valgan al menos 50 po cada uno y que debéis llevar puestos tanto tú como el objetivo hasta que termine el conjuro"
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Tocas a otra criatura voluntaria y creas una conexión mística entre ella y tú hasta que el conjuro termine. Mientras el objetivo esté a 60 pies o menos de ti, obtiene un bonificador de +1 a la CA y a las tiradas de salvación, así como resistencia a todo el daño. Sin embargo, cada vez que reciba daño, tú sufrirás la misma cantidad de daño.\n\nEl conjuro termina si tus puntos de golpe se reducen a 0 o si el objetivo y tú os separáis más de 60 pies. También termina si se lanza otra vez sobre cualquiera de las dos criaturas conectadas.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ZANCADA PRODIGIOSA",
    "level": 1,
    "school": "Transmutación",
    "classes": [
      "bardo",
      "druida",
      "explorador",
      "mago"
    ],
    "casting_time": "Acción",
    "range": "Toque",
    "components": {
      "v": true,
      "s": true,
      "m": true,
      "material": "una pizca de tierra"
    },
    "duration": "1 hora",
    "ritual": false,
    "concentration": false,
    "description": "Tocas a una criatura y su velocidad aumenta en 10 pies hasta que el conjuro termine.",
    "tables": [],
    "sections": [
      {
        "title": "A niveles superiores",
        "text": "Puedes hacer objetivo a una criatura adicional por cada nivel por encima de 1 que tenga el espacio."
      }
    ],
    "source": "PHB2024 + FRHoF + SRD"
  },
  {
    "name": "ZONA DE LA VERDAD",
    "level": 2,
    "school": "Encantamiento",
    "classes": [
      "bardo",
      "clerigo",
      "paladin"
    ],
    "casting_time": "Acción",
    "range": "60 pies / 15 pies de radio",
    "components": {
      "v": true,
      "s": true,
      "m": false,
      "material": null
    },
    "duration": "10 minutos",
    "ritual": false,
    "concentration": false,
    "description": "Creas una zona mágica que protege contra el engaño en una esfera de 15 pies de radio centrada en un punto dentro del alcance. Hasta que el conjuro termine, una criatura que entre en la zona del conjuro por primera vez en un turno o comience su turno allí realizará una tirada de salvación de Carisma. Si la falla, no podrá decir una mentira voluntariamente mientras esté en el radio del conjuro. Sabrás si una criatura supera o falla esta tirada. Una criatura afectada es consciente del conjuro y puede evitar responder a preguntas a las que normalmente respondería con una mentira. Dicha criatura puede dar respuestas evasivas, pero deberá ser sincera.",
    "tables": [],
    "sections": [],
    "source": "PHB2024 + FRHoF + SRD",
    "aoe": {
      "type": "sphere",
      "sizeFt": 15,
      "measure": "radius"
    }
  }
];
