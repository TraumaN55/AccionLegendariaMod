window.BESTIARY_DATA = {
  "creatures": [
    {
      "id": "aboleth",
      "name": "Aboleth",
      "size": "Grande",
      "type": "aberración",
      "alignment": "legal malvada",
      "ac": 17,
      "initiative": {
        "modifier": 7,
        "score": 17
      },
      "hp": {
        "average": 150,
        "formula": "20d10 + 40"
      },
      "speed": {
        "walk": "10 pies",
        "swim": "40 pies"
      },
      "abilities": {
        "str": 21,
        "dex": 9,
        "con": 15,
        "int": 18,
        "wis": 15,
        "cha": 18
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 5
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 6
        },
        {
          "ability": "int",
          "bonus": 8
        },
        {
          "ability": "wis",
          "bonus": 6
        },
        {
          "ability": "cha",
          "bonus": 4
        }
      ],
      "traits": [
        {
          "name": "Anfibio",
          "text": "El aboleth puede respirar tanto dentro como fuera del agua."
        },
        {
          "name": "Nube mucosa",
          "text": "Mientras permanezca bajo el agua, el aboleth estará rodeado por una mucosa. Tirada de salvación de Constitución: CD 14, todas las criaturas en una emanación de 5 pies que se origina en el aboleth al final de su turno. Fallo: el objetivo estará maldito. Hasta que la maldición termine, la piel del objetivo se volverá viscosa, el objetivo podrá respirar tanto dentro como fuera del agua y no podrá recuperar puntos de golpe excepto si está bajo el agua. Mientras la criatura maldita esté fuera de una masa de agua, recibirá 6 (1d12) de daño de ácido al final de cada periodo de 10 minutos, a menos que se le aplique humedad a su piel antes de que transcurra este tiempo."
        },
        {
          "name": "Recuperación sobrenatural",
          "text": "Si es destruido, el aboleth obtiene un nuevo cuerpo tras 5d10 días y revive con todos sus puntos de golpe en el Reino Lejano o en otro lugar a elección de cada GM. Resistencia legendaria (3/día o 4/día en la guarida). El aboleth puede elegir tener éxito en una tirada de salvación que haya fallado."
        },
        {
          "name": "Telepatía inquisitiva",
          "text": "Si una criatura a la que el aboleth pueda ver se comunica telepáticamente con este, el aboleth descubrirá cuáles son los deseos más intensos de la criatura."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El aboleth realiza dos ataques con sus tentáculos y usa o bien su acción de consumir recuerdos o bien la de dominar la mente si está disponible."
        },
        {
          "name": "Tentáculo",
          "text": "Tirada de ataque cuerpo a cuerpo: +9, alcance 15 pies. Acierto: 12 (2d6 + 5) de daño contundente. Si el objetivo es una criatura Grande o más pequeña, tendrá el estado de agarrada (CD 14 para escapar) por uno de los cuatro tentáculos."
        },
        {
          "name": "Consumir recuerdos",
          "text": "Tirada de salvación de Inteligencia: CD 16, una criatura a 30 pies o menos que esté agarrada o hechizada por el aboleth. Fallo: 10 (3d6) de daño psíquico. Éxito: la mitad del daño. Fallo o éxito: el aboleth obtendrá los recuerdos del objetivo si este es un humanoide y sus puntos de golpe se reducen a 0 por esta acción."
        },
        {
          "name": "Dominar la mente (2/día)",
          "text": "Tirada de salvación de Sabiduría: CD 16, una criatura que el aboleth pueda ver a 30 pies o menos. Fallo: el objetivo tendrá el estado de hechizado hasta que el aboleth muera o esté en un plano de existencia diferente al del objetivo. Mientras esté hechizado, el objetivo actuará como aliado del aboleth y estará bajo su control si se encuentra a 60 pies o menos de él. Además, el aboleth y el objetivo se podrán comunicar telepáticamente entre sí a cualquier distancia. El objetivo repetirá la tirada de salvación siempre que reciba daño y tras cada 24 horas que pase a al menos 1 milla de distancia del aboleth; si la supera, se librará del efecto."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, el aboleth puede emplear un uso para llevar a cabo una de las siguientes acciones. El aboleth recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Drenaje psíquico",
          "text": "Si el aboleth tiene al menos a una criatura agarrada o hechizada, usa su acción de consumir recuerdos y recupera 5 (1d10) puntos de golpe."
        },
        {
          "name": "Latigazo",
          "text": "El aboleth realiza un ataque con un tentáculo."
        }
      ],
      "skills": [
        {
          "name": "Historia",
          "bonus": 12
        },
        {
          "name": "Percepción",
          "bonus": 10
        }
      ],
      "senses": [
        "visión en la oscuridad 120 pies",
        "Percepción pasiva 20"
      ],
      "languages": [
        "habla de las profundidades",
        "telepatía 120 pies"
      ],
      "cr": "10",
      "proficiencyBonus": 4,
      "xp": 5900,
      "xpText": "5900 PX o 7200 en la guarida"
    },
    {
      "id": "acechador_invisible",
      "name": "Acechador invisible",
      "size": "Grande",
      "type": "elemental",
      "alignment": "neutral",
      "ac": 14,
      "initiative": {
        "modifier": 7,
        "score": 22
      },
      "hp": {
        "average": 97,
        "formula": "13d10 + 26"
      },
      "speed": {
        "walk": "50 pies",
        "fly": "50 pies (levitar)"
      },
      "abilities": {
        "str": 16,
        "dex": 19,
        "con": 14,
        "int": 10,
        "wis": 15,
        "cha": 11
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 4
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [
        {
          "name": "Forma de aire",
          "text": "El acechador puede entrar en el espacio de un enemigo y detenerse allí. Puede moverse a través de un espacio de solo 1 pulgada de ancho sin gastar movimiento adicional para hacerlo."
        },
        {
          "name": "Invisibilidad",
          "text": "El acechador tiene el estado de invisible."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El acechador realiza tres ataques con su zarpazo de viento. Puede sustituir un ataque por un uso de su vórtice."
        },
        {
          "name": "Zarpazo de viento",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 11 (2d6 + 4) de daño de fuerza."
        },
        {
          "name": "Vórtice",
          "text": "Tirada de salvación de Constitución: CD 14, una criatura Grande o más pequeña en el espacio del acechador. Fallo: 7 (1d8 + 3) de daño de trueno y el objetivo tendrá el estado de agarrado (CD 13 para escapar). Hasta que el agarre termine, el objetivo no podrá lanzar conjuros con un componente verbal y recibirá 7 (2d6) de daño de trueno al principio de cada turno del acechador."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 8
        },
        {
          "name": "Sigilo",
          "bonus": 10
        }
      ],
      "damageResistances": [
        "contundente",
        "cortante",
        "perforante"
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "agarrado",
        "apresado",
        "cansancio",
        "derribado",
        "envenenado",
        "inconsciente",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 18"
      ],
      "languages": [
        "común",
        "primordial (aurano)"
      ],
      "cr": "6",
      "proficiencyBonus": 3,
      "xp": 2300
    },
    {
      "id": "ankheg",
      "name": "Ankheg",
      "size": "Grande",
      "type": "monstruosidad",
      "alignment": "sin alineamiento",
      "ac": 14,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 45,
        "formula": "6d10 + 12"
      },
      "speed": {
        "walk": "30 pies",
        "burrow": "10 pies"
      },
      "abilities": {
        "str": 17,
        "dex": 11,
        "con": 14,
        "int": 1,
        "wis": 13,
        "cha": 6
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": -5
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [
        {
          "name": "Excavador",
          "text": "El ankheg puede excavar a través de roca sólida a la mitad de su velocidad excavando y deja a su paso un túnel de 10 pies de diámetro."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +5 (con ventaja si el ankheg tiene agarrado al objetivo), alcance 5 pies. Acierto: 10 (2d6 + 3) de daño cortante más 3 (1d6) de daño de ácido. Si el objetivo es una criatura Grande o más pequeña, tendrá el estado de agarrada (CD 13 para escapar)."
        },
        {
          "name": "Chorro de ácido (recarga 6)",
          "text": "Tirada de salvación de Destreza: CD 12, todas las criaturas en una línea de 30 pies de largo y 5 pies de ancho. Fallo: 14 (4d6) de daño de ácido. Éxito: la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "senses": [
        "sentir vibraciones 60 pies, visión en la oscuridad 60 pies",
        "Percepción pasiva 11"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "aparicion",
      "name": "Aparición",
      "size": "Mediano o Pequeño",
      "type": "muerto viviente",
      "alignment": "neutral malvado",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 67,
        "formula": "9d8 + 27"
      },
      "speed": {
        "walk": "5 pies",
        "fly": "60 pies (levitar)"
      },
      "abilities": {
        "str": 6,
        "dex": 16,
        "con": 16,
        "int": 12,
        "wis": 14,
        "cha": 15
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -2
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "traits": [
        {
          "name": "Movimiento incorpóreo",
          "text": "La aparición puede moverse a través de otras criaturas y objetos como si fueran terreno difícil. Recibe 5 (1d10) de daño de fuerza si acaba su turno dentro de un objeto."
        },
        {
          "name": "Sensibilidad a la luz solar",
          "text": "Bajo la luz del sol, la aparición tiene desventaja en las pruebas de característica y las tiradas de ataque."
        }
      ],
      "actions": [
        {
          "name": "Consumir vida",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 21 (4d8 + 3) de daño necrótico. Si el objetivo es una criatura, sus puntos de golpe máximos se reducen en una cantidad igual al daño sufrido."
        },
        {
          "name": "Crear espectro",
          "text": "La aparición hace objetivo a un cadáver de humanoide que esté a 10 pies o menos de ella y haya muerto hace 1 minuto como máximo. El espíritu del objetivo se alza como un espectro en el espacio de su cadáver o en el espacio sin ocupar más cercano."
        },
        {
          "name": "El espectro estará bajo el control de la aparición",
          "text": "Esta última no puede tener más de siete espectros bajo su control a la vez."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageResistances": [
        "ácido",
        "contundente",
        "cortante",
        "frío",
        "fuego",
        "perforante"
      ],
      "damageImmunities": [
        "necrótico",
        "veneno"
      ],
      "conditionImmunities": [
        "agarrado",
        "apresado",
        "cansancio",
        "derribado",
        "envenenado",
        "hechizado",
        "inconsciente",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "común y otros dos idiomas"
      ],
      "cr": "5",
      "proficiencyBonus": 3,
      "xp": 1800
    },
    {
      "id": "arana_de_fase",
      "name": "Araña de fase",
      "size": "Grande",
      "type": "monstruosidad",
      "alignment": "sin alineamiento",
      "ac": 14,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 45,
        "formula": "7d10 + 7"
      },
      "speed": {
        "walk": "30 pies",
        "climb": "30 pies"
      },
      "abilities": {
        "str": 15,
        "dex": 16,
        "con": 12,
        "int": 6,
        "wis": 10,
        "cha": 6
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [
        {
          "name": "Caminar por telarañas",
          "text": "La araña ignora todas las restricciones de movimiento causadas por las telarañas y conoce la ubicación de cualquier otra criatura que esté en contacto con la misma telaraña."
        },
        {
          "name": "Trepar cual arácnido",
          "text": "La araña puede trepar por superficies difíciles e incluso recorrer techos sin tener que realizar pruebas de característica."
        },
        {
          "name": "Visión etérea",
          "text": "La araña puede ver a 60 pies de distancia en el Plano Etéreo cuando se encuentra en el Plano Material y viceversa."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "La araña realiza dos ataques de mordisco."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 8 (1d10 + 3) de daño perforante más 9 (2d8) de daño de veneno. Si este daño reduce a 0 los puntos de golpe del objetivo, pasará a estar estable y tendrá el estado de envenenado durante 1 hora. Mientras esté envenenado, también tendrá el estado de paralizado."
        }
      ],
      "bonusActions": [
        {
          "name": "Salto etéreo",
          "text": "La araña se teletransporta del Plano Material al Plano Etéreo o viceversa."
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 7
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "3",
      "proficiencyBonus": 2,
      "xp": 700
    },
    {
      "id": "arpia",
      "name": "Arpía",
      "size": "Mediana",
      "type": "monstruosidad",
      "alignment": "caótica malvada",
      "ac": 11,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 38,
        "formula": "7d8 + 7"
      },
      "speed": {
        "walk": "20 pies",
        "fly": "40 pies"
      },
      "abilities": {
        "str": 12,
        "dex": 13,
        "con": 12,
        "int": 7,
        "wis": 10,
        "cha": 13
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 1
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 1
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +3, alcance 5 pies. Acierto: 6 (2d4 + 1) de daño cortante."
        },
        {
          "name": "Canción tentadora",
          "text": "La arpía canta una melodía mágica, que dura hasta que la arpía deja de concentrarse en ella. Tirada de salvación de Sabiduría: CD 11, todos los humanoides y gigantes en una emanación de 300 pies que se origina en la arpía cuando empieza la canción. Fallo: el objetivo tendrá el estado de hechizado hasta que termine la canción y repetirá la tirada de salvación al final de cada uno de sus turnos. Mientras esté hechizado, tendrá el estado de incapacitado e ignorará la canción tentadora de otras arpías. Si el objetivo se encuentra a más de 5 pies de la arpía, deberá moverse durante su turno hacia ella por el camino más corto para intentar situarse a 5 pies o menos de ella. No evitará provocar ataques de oportunidad; sin embargo, antes de moverse a un terreno que le causaría daño (como lava o un pozo) y cada vez que sufra daño de una fuente distinta a la arpía, repetirá la tirada de salvación. Éxito: el objetivo será inmune a la canción tentadora de esta arpía durante 24 horas."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "senses": [
        "Percepción pasiva 10"
      ],
      "languages": [
        "común"
      ],
      "cr": "1",
      "proficiencyBonus": 2,
      "xp": 200
    },
    {
      "id": "asesino",
      "name": "Asesino",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 16,
      "initiative": {
        "modifier": 10,
        "score": 20
      },
      "hp": {
        "average": 97,
        "formula": "15d8 + 30"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 11,
        "dex": 18,
        "con": 14,
        "int": 16,
        "wis": 11,
        "cha": 10
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 0
        },
        {
          "ability": "dex",
          "bonus": 7
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": 6
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [
        {
          "name": "Evasión",
          "text": "Si el asesino sufre un efecto que le permita hacer una tirada de salvación de Destreza para sufrir solo la mitad de daño, no recibe ningún daño si la supera y solo sufre la mitad si la falla. No puede usar este atributo si tiene el estado de incapacitado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El asesino realiza tres ataques con su espada corta o su ballesta ligera en cualquier combinación."
        },
        {
          "name": "Espada corta",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 7 (1d6 + 4) de daño perforante más 17 (5d6) de daño de veneno y el objetivo tendrá el estado de envenenado hasta el principio del siguiente turno del asesino."
        },
        {
          "name": "Ballesta ligera",
          "text": "Tirada de ataque a distancia: +7, alcance 24/315 pies. Acierto: 8 (1d8 + 4) de daño perforante más 21 (6d6) de daño de veneno."
        }
      ],
      "bonusActions": [
        {
          "name": "Acción astuta",
          "text": "El asesino realiza las acciones de correr, destrabarse o esconderse. Azer"
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Acrobacias",
          "bonus": 7
        },
        {
          "name": "Percepción",
          "bonus": 6
        },
        {
          "name": "Sigilo",
          "bonus": 10
        }
      ],
      "damageResistances": [
        "veneno"
      ],
      "equipment": [
        "armadura de cuero tachonado",
        "ballesta ligera",
        "espada corta"
      ],
      "senses": [
        "Percepción pasiva 16"
      ],
      "languages": [
        "común",
        "jerga de ladrones"
      ],
      "cr": "8",
      "proficiencyBonus": 3,
      "xp": 3900
    },
    {
      "id": "centinela_azer",
      "name": "Centinela azer",
      "size": "Mediano",
      "type": "elemental",
      "alignment": "legal neutral",
      "ac": 17,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 39,
        "formula": "6d8 + 12"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 17,
        "dex": 12,
        "con": 15,
        "int": 12,
        "wis": 13,
        "cha": 10
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [
        {
          "name": "Aura de fuego",
          "text": "Al final de cada turno del azer, todas las criaturas a elección del azer en una emanación de 5 pies que se origina en él recibirán 5 (1d10) de daño de fuego, a menos que el azer tenga el estado de incapacitado."
        },
        {
          "name": "Iluminación",
          "text": "El azer emite luz brillante en un radio de 10 pies y luz tenue 10 pies más allá."
        }
      ],
      "actions": [
        {
          "name": "Martillo ardiente",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 8 (1d10 + 3) de daño contundente más 3 (1d6) de daño de fuego."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageImmunities": [
        "fuego",
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado"
      ],
      "senses": [
        "Percepción pasiva 11"
      ],
      "languages": [
        "primordial (ígneo)"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "balor",
      "name": "Balor",
      "size": "Enorme",
      "type": "infernal",
      "alignment": "caótico malvado",
      "ac": 19,
      "initiative": {
        "modifier": 14,
        "score": 24
      },
      "hp": {
        "average": 287,
        "formula": "23d12 + 138"
      },
      "speed": {
        "walk": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 26,
        "dex": 15,
        "con": 22,
        "int": 20,
        "wis": 16,
        "cha": 22
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 8
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 12
        },
        {
          "ability": "int",
          "bonus": 5
        },
        {
          "ability": "wis",
          "bonus": 9
        },
        {
          "ability": "cha",
          "bonus": 6
        }
      ],
      "traits": [
        {
          "name": "Aura de fuego",
          "text": "Al final de cada turno del balor, todas las criaturas en una emanación de 5 pies que se origina en él reciben 13 (3d8) de daño de fuego."
        },
        {
          "name": "Resistencia legendaria (3/día)",
          "text": "El balor puede elegir tener éxito en una tirada de salvación que haya fallado."
        },
        {
          "name": "Resistencia mágica",
          "text": "El balor tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        },
        {
          "name": "Últimos estertores",
          "text": "El balor explota cuando muere. Tirada de salvación de Destreza: CD 20, todas las criaturas en una emanación de 30 pies que se origina en el balor. Fallo: 31 (9d6) de daño de fuego más 31 (9d6) de daño de fuerza. Éxito: la mitad del daño. Fallo o éxito: si el balor muere fuera del Abismo, obtiene un cuerpo nuevo al instante y revive con todos sus puntos de golpe en algún lugar del Abismo."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El balor realiza un ataque con su látigo de llamas y un ataque con su hoja de relámpago."
        },
        {
          "name": "Hoja de relámpago",
          "text": "Tirada de ataque cuerpo a cuerpo: +14, alcance 10 pies. Acierto: 21 (3d8 + 8) de daño de fuerza más 22 (4d10) de daño de relámpago y el objetivo no puede llevar a cabo reacciones hasta el principio del siguiente turno del balor."
        },
        {
          "name": "Látigo de llamas",
          "text": "Tirada de ataque cuerpo a cuerpo: +14, alcance 30 pies. Acierto: 18 (3d6 + 8) de daño de fuerza más 17 (5d6) de daño de fuego. Si el objetivo es una criatura Enorme o más pequeña, el balor la atrae hasta 25 pies en línea recta hacia él y dicho objetivo tiene el estado de derribado."
        }
      ],
      "bonusActions": [
        {
          "name": "Teletransporte",
          "text": "El balor se teletransporta a sí mismo o a un demonio voluntario que esté a 10 pies o menos de él hasta 60 pies a un espacio sin ocupar que el balor pueda ver. Bandidos"
        }
      ],
      "reactions": [],
      "subtype": "demonio",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 9
        }
      ],
      "damageResistances": [
        "frío",
        "relámpago"
      ],
      "damageImmunities": [
        "fuego",
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "envenenado",
        "hechizado"
      ],
      "senses": [
        "visión verdadera 120 pies",
        "Percepción pasiva 19"
      ],
      "languages": [
        "abisal",
        "telepatía 120 pies"
      ],
      "cr": "19",
      "proficiencyBonus": 6,
      "xp": 22000
    },
    {
      "id": "bandido",
      "name": "Bandido",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 12,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 11,
        "formula": "2d8 + 2"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 11,
        "dex": 12,
        "con": 12,
        "int": 10,
        "wis": 10,
        "cha": 10
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 0
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Cimitarra",
          "text": "Tirada de ataque cuerpo a cuerpo: +3, alcance 5 pies. Acierto: 4 (1d6 + 1) de daño cortante."
        },
        {
          "name": "Ballesta ligera",
          "text": "Tirada de ataque a distancia: +3, alcance 24/315 pies. Acierto: 5 (1d8 + 1) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "equipment": [
        "armadura de cuero",
        "ballesta ligera",
        "cimitarra"
      ],
      "senses": [
        "Percepción pasiva 10"
      ],
      "languages": [
        "común",
        "jerga de ladrones"
      ],
      "cr": "1/8",
      "proficiencyBonus": 2,
      "xp": 25
    },
    {
      "id": "capitan_bandido",
      "name": "Capitán bandido",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 15,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 52,
        "formula": "8d8 + 16"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 15,
        "dex": 16,
        "con": 14,
        "int": 14,
        "wis": 11,
        "cha": 14
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 5
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": 2
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El bandido realiza dos ataques con su cimitarra o su pistola en cualquier combinación."
        },
        {
          "name": "Cimitarra",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 6 (1d6 + 3) de daño cortante."
        },
        {
          "name": "Pistola",
          "text": "Tirada de ataque a distancia: +5, alcance 9/90 pies. Acierto: 8 (1d10 + 3) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": [
        {
          "name": "Parada",
          "text": "Detonante: una tirada de ataque cuerpo a cuerpo acierta al bandido mientras sostiene un arma. Respuesta: el bandido suma 2 a su CA contra ese ataque, lo que puede hacer que falle."
        }
      ],
      "skills": [
        {
          "name": "Atletismo",
          "bonus": 4
        },
        {
          "name": "Engaño",
          "bonus": 4
        }
      ],
      "equipment": [
        "armadura de cuero tachonado",
        "cimitarra",
        "pistola"
      ],
      "senses": [
        "Percepción pasiva 10"
      ],
      "languages": [
        "común",
        "jerga de ladrones"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "basilisco",
      "name": "Basilisco",
      "size": "Mediana",
      "type": "monstruosidad",
      "alignment": "sin alineamiento",
      "ac": 15,
      "initiative": {
        "modifier": -1,
        "score": 9
      },
      "hp": {
        "average": 52,
        "formula": "8d8 + 16"
      },
      "speed": {
        "walk": "20 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 8,
        "con": 15,
        "int": 2,
        "wis": 8,
        "cha": 7
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": -1
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": -1
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 10 (2d6 + 3) de daño perforante más 7 (2d6) de daño de veneno."
        }
      ],
      "bonusActions": [
        {
          "name": "Mirada petrificadora (recarga 4–6)",
          "text": "Tirada de salvación de Constitución: CD 12, todas las criaturas en un cono de 30 pies. Si el basilisco ve su reflejo en alguna parte del cono, deberá hacer esta tirada. Primer fallo: el objetivo tendrá el estado de apresado. Si al final de su siguiente turno sigue apresado, repetirá la tirada de salvación y se librará del efecto si la supera. Segundo fallo: el objetivo tendrá el estado de petrificado en vez del de apresado."
        }
      ],
      "reactions": [],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 9"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "3",
      "proficiencyBonus": 2,
      "xp": 700
    },
    {
      "id": "batidor",
      "name": "Batidor",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 13,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 16,
        "formula": "3d8 + 3"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 11,
        "dex": 14,
        "con": 12,
        "int": 11,
        "wis": 13,
        "cha": 11
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 0
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El batidor realiza dos ataques con su arco largo o su espada corta en cualquier combinación."
        },
        {
          "name": "Espada corta",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 5 (1d6 + 2) de daño perforante."
        },
        {
          "name": "Arco largo",
          "text": "Tirada de ataque a distancia: +4, alcance 45/600 pies. Acierto: 6 (1d8 + 2) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Naturaleza",
          "bonus": 4
        },
        {
          "name": "Percepción",
          "bonus": 5
        },
        {
          "name": "Sigilo",
          "bonus": 6
        },
        {
          "name": "Supervivencia",
          "bonus": 5
        }
      ],
      "equipment": [
        "arco largo",
        "armadura de cuero",
        "espada corta"
      ],
      "senses": [
        "Percepción pasiva 15"
      ],
      "languages": [
        "común y otro cualquiera"
      ],
      "cr": "1/2",
      "proficiencyBonus": 2,
      "xp": 100
    },
    {
      "id": "behir",
      "name": "Behir",
      "size": "Enorme",
      "type": "monstruosidad",
      "alignment": "neutral malvada",
      "ac": 17,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 168,
        "formula": "16d12 + 64"
      },
      "speed": {
        "walk": "50 pies",
        "climb": "50 pies"
      },
      "abilities": {
        "str": 23,
        "dex": 16,
        "con": 18,
        "int": 7,
        "wis": 14,
        "cha": 12
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 6
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 1
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El behir realiza un ataque de mordisco y emplea su acción de constreñir."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +10, alcance 10 pies. Acierto: 19 (2d12 + 6) de daño perforante más 11 (2d10) de daño de relámpago."
        },
        {
          "name": "Aliento de relámpago (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 16, todas las criaturas en una línea de 90 pies de largo y 5 pies de ancho. Fallo: 66 (12d10) de daño de relámpago. Éxito: la mitad del daño."
        },
        {
          "name": "Constreñir",
          "text": "Tirada de salvación de Fuerza: CD 18, una criatura Grande o más pequeña que el behir pueda ver a 5 pies o menos. Fallo: 28 (5d8 + 6) de daño contundente. El objetivo tendrá el estado de agarrado (CD 16 para escapar) y el de apresado hasta que el agarre termine."
        }
      ],
      "bonusActions": [
        {
          "name": "Engullir",
          "text": "Tirada de salvación de Destreza: CD 18, una criatura Grande o más pequeña agarrada por el behir (el behir solo puede tener una criatura engullida a la vez). Fallo: el behir engulle al objetivo, que ya no está agarrado. La criatura engullida tendrá los estados de apresada y cegada, tendrá cobertura completa contra los ataques y otros efectos fuera del behir y recibirá 21 (6d6) de daño de ácido al principio de cada turno del behir. Si el behir sufre 30 de daño o más en un solo turno por parte de la criatura engullida, deberá superar una tirada de salvación de Constitución con CD 14 al final de ese turno o regurgitará a la criatura engullida, que caerá en un espacio a 10 pies o menos del behir y tendrá el estado de derribada. Si el behir muere, la criatura engullida dejará de estar apresada y podrá gastar 15 pies de movimiento para escapar del cadáver, del que saldrá derribada."
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 6
        },
        {
          "name": "Sigilo",
          "bonus": 7
        }
      ],
      "damageImmunities": [
        "relámpago"
      ],
      "senses": [
        "visión en la oscuridad 90 pies",
        "Percepción pasiva 16"
      ],
      "languages": [
        "dracónico"
      ],
      "cr": "11",
      "proficiencyBonus": 4,
      "xp": 7200
    },
    {
      "id": "berserker",
      "name": "Berserker",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 13,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 67,
        "formula": "9d8 + 27"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 12,
        "con": 17,
        "int": 9,
        "wis": 11,
        "cha": 9
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": -1
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [
        {
          "name": "Frenesí maltrecho",
          "text": "Mientras esté maltrecho, el berserker tiene ventaja en las tiradas de ataque y las tiradas de salvación."
        }
      ],
      "actions": [
        {
          "name": "Hacha a dos manos",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 9 (1d12 + 3) de daño cortante."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "equipment": [
        "armadura de pieles",
        "hacha a dos manos"
      ],
      "senses": [
        "Percepción pasiva 10"
      ],
      "languages": [
        "común"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "bocon_barbotante",
      "name": "Bocón barbotante",
      "size": "Mediana",
      "type": "aberración",
      "alignment": "caótica neutral",
      "ac": 9,
      "initiative": {
        "modifier": -1,
        "score": 9
      },
      "hp": {
        "average": 52,
        "formula": "7d8 + 21"
      },
      "speed": {
        "walk": "20 pies",
        "swim": "20 pies"
      },
      "abilities": {
        "str": 10,
        "dex": 8,
        "con": 16,
        "int": 3,
        "wis": 10,
        "cha": 6
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 0
        },
        {
          "ability": "dex",
          "bonus": -1
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [
        {
          "name": "Barbotar",
          "text": "El bocón no cesa de balbucear incoherencias mientras no tenga el estado de incapacitado. Tirada de salvación de Sabiduría: CD 10, cualquier criatura que empiece su turno a 20 pies o menos del bocón mientras balbucea. Fallo: el objetivo tira 1d8 para determinar lo que hace durante ese turno. 1–4. El objetivo no hará nada. 5–6. El objetivo no realizará ninguna acción o acción adicional y utilizará todo su movimiento para desplazarse en una dirección aleatoria. 7–8. El objetivo realizará un ataque cuerpo a cuerpo contra una criatura determinada al azar dentro de su alcance o no hará nada si no puede ejecutar este ataque."
        },
        {
          "name": "Suelo aberrante",
          "text": "El suelo en una emanación de 10 pies que se origina en el bocón es terreno difícil."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +2, alcance 5 pies. Acierto: 7 (2d6) de daño perforante. Si el objetivo es una criatura Mediana o más pequeña, tendrá el estado de derribada. El objetivo muere si este ataque reduce sus puntos de golpe a 0. Luego, el bocón absorberá su cuerpo, dejando atrás solo su equipo."
        },
        {
          "name": "Baba cegadora (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 10, todas las criaturas en una esfera de 10 pies de radio centrada en un punto a 30 pies o menos. Fallo: 7 (2d6) de daño radiante y el objetivo tendrá el estado de cegado hasta el final del siguiente turno del bocón."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "conditionImmunities": [
        "derribado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "broza_movediza",
      "name": "Broza movediza",
      "size": "Grande",
      "type": "planta",
      "alignment": "sin alineamiento",
      "ac": 15,
      "initiative": {
        "modifier": -1,
        "score": 9
      },
      "hp": {
        "average": 110,
        "formula": "13d10 + 39"
      },
      "speed": {
        "walk": "30 pies",
        "swim": "20 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 8,
        "con": 16,
        "int": 5,
        "wis": 10,
        "cha": 5
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": -1
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": -3
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -3
        }
      ],
      "traits": [
        {
          "name": "Absorción de relámpago",
          "text": "Siempre que fuese a recibir daño de relámpago, la broza movediza recupera una cantidad de puntos de golpe igual al daño de relámpago infligido."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "La broza movediza realiza tres ataques con sus zarcillos cargados. Puede sustituir un ataque por una acción de absorber."
        },
        {
          "name": "Zarcillo cargado",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 10 pies. Acierto: 7 (1d6 + 4) de daño contundente más 5 (2d4) de daño de relámpago. Si el objetivo es una criatura Mediana o más pequeña, la broza movediza atraerá al objetivo 5 pies en línea recta hacia ella."
        },
        {
          "name": "Absorber",
          "text": "Tirada de salvación de Fuerza: CD 15, una criatura Mediana o más pequeña a 5 pies o menos. Fallo: el objetivo será arrastrado al espacio de la broza movediza y tendrá el estado de agarrado (CD 14 para escapar). Hasta que el agarre termine, el objetivo tendrá los estados de apresado y cegado y recibirá 10 (3d6) de daño de relámpago al principio de cada uno de sus turnos. Cuando la broza movediza se mueva, el objetivo agarrado se moverá con ella sin costarle movimiento adicional. La broza movediza solo puede tener a una criatura agarrada con esta acción al mismo tiempo."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 3
        }
      ],
      "damageResistances": [
        "frío",
        "fuego"
      ],
      "damageImmunities": [
        "relámpago"
      ],
      "conditionImmunities": [
        "cansancio",
        "ensordecido"
      ],
      "senses": [
        "visión ciega 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "5",
      "proficiencyBonus": 3,
      "xp": 1800
    },
    {
      "id": "bulette",
      "name": "Bulette",
      "size": "Grande",
      "type": "monstruosidad",
      "alignment": "sin alineamiento",
      "ac": 17,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 94,
        "formula": "9d10 + 45"
      },
      "speed": {
        "walk": "40 pies",
        "burrow": "40 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 11,
        "con": 21,
        "int": 2,
        "wis": 10,
        "cha": 5
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 5
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -3
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El bulette realiza dos ataques de mordisco."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 17 (2d12 + 4) de daño perforante."
        },
        {
          "name": "Salto mortífero",
          "text": "El bulette gasta 5 pies de movimiento para saltar a un espacio a 15 pies o menos que contenga una o varias criaturas Grandes o más pequeñas. Tirada de salvación de Destreza: CD 15, todas las criaturas situadas en el espacio de destino del bulette. Fallo: 19 (3d12) de daño contundente y el objetivo tiene el estado de derribado. Éxito: la mitad del daño y el objetivo es empujado 5 pies respecto al bulette en línea recta."
        }
      ],
      "bonusActions": [
        {
          "name": "Salto",
          "text": "El bulette gasta 10 pies de movimiento para saltar hasta 30 pies."
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 6
        }
      ],
      "senses": [
        "sentir vibraciones 120 pies, visión en la oscuridad 60 pies",
        "Percepción pasiva 16"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "5",
      "proficiencyBonus": 3,
      "xp": 1800
    },
    {
      "id": "caballero",
      "name": "Caballero",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 18,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 52,
        "formula": "8d8 + 16"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 11,
        "con": 14,
        "int": 11,
        "wis": 11,
        "cha": 15
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El caballero realiza dos ataques con su ballesta pesada o su espadón en cualquier combinación."
        },
        {
          "name": "Espadón",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 10 (2d6 + 3) de daño cortante más 4 (1d8) de daño radiante."
        },
        {
          "name": "Ballesta pesada",
          "text": "Tirada de ataque a distancia: +2, alcance 30/400 pies. Acierto: 11 (2d10) de daño perforante más 4 (1d8) de daño radiante."
        }
      ],
      "bonusActions": [],
      "reactions": [
        {
          "name": "Parada",
          "text": "Detonante: una tirada de ataque cuerpo a cuerpo acierta al caballero mientras sostiene un arma. Respuesta: el caballero suma 2 a su CA contra ese ataque, lo que puede hacer que falle. Centauro"
        }
      ],
      "conditionImmunities": [
        "asustado"
      ],
      "equipment": [
        "armadura de placas",
        "ballesta pesada",
        "espadón"
      ],
      "senses": [
        "Percepción pasiva 10"
      ],
      "languages": [
        "común y otro cualquiera"
      ],
      "cr": "3",
      "proficiencyBonus": 2,
      "xp": 700
    },
    {
      "id": "soldado_centauro",
      "name": "Soldado centauro",
      "size": "Grande",
      "type": "feérico",
      "alignment": "neutral bueno",
      "ac": 16,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 45,
        "formula": "6d10 + 12"
      },
      "speed": {
        "walk": "50 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 14,
        "con": 14,
        "int": 9,
        "wis": 13,
        "cha": 11
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": -1
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El centauro realiza dos ataques con su pica o su arco largo en cualquier combinación."
        },
        {
          "name": "Pica",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 10 pies. Acierto: 9 (1d10 + 4) de daño perforante."
        },
        {
          "name": "Arco largo",
          "text": "Tirada de ataque a distancia: +4, alcance 45/600 pies. Acierto: 6 (1d8 + 2) de daño perforante."
        }
      ],
      "bonusActions": [
        {
          "name": "Carga pisoteadora (recarga 5–6)",
          "text": "El centauro se mueve hasta su velocidad sin provocar ataques de oportunidad y puede atravesar los espacios de criaturas Medianas o más pequeñas. Todas las criaturas en cuyo espacio entre el centauro se convertirán una vez en objetivos del siguiente efecto. Tirada de salvación de Fuerza:"
        },
        {
          "name": "CD 14",
          "text": "Fallo: 7 (1d6 + 4) de daño contundente y el objetivo tiene el estado de derribado."
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Atletismo",
          "bonus": 6
        },
        {
          "name": "Percepción",
          "bonus": 3
        }
      ],
      "equipment": [
        "arco largo",
        "coraza",
        "pica"
      ],
      "senses": [
        "Percepción pasiva 13"
      ],
      "languages": [
        "elfo",
        "silvano"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "chuul",
      "name": "Chuul",
      "size": "Grande",
      "type": "aberración",
      "alignment": "caótica malvada",
      "ac": 16,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 76,
        "formula": "9d10 + 27"
      },
      "speed": {
        "walk": "30 pies",
        "swim": "30 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 10,
        "con": 16,
        "int": 5,
        "wis": 11,
        "cha": 5
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": -3
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -3
        }
      ],
      "traits": [
        {
          "name": "Anfibio",
          "text": "El chuul puede respirar tanto dentro como fuera del agua."
        },
        {
          "name": "Sentir magia",
          "text": "El chuul percibe la magia en un radio de 120 pies. Este atributo funciona, en todos los demás aspectos, igual que el conjuro detectar magia, pero no es mágico en sí mismo."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El chuul realiza dos ataques con sus tenazas y utiliza sus tentáculos paralizadores."
        },
        {
          "name": "Tenaza",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 10 pies. Acierto: 9 (1d10 + 4) de daño contundente. Si el objetivo es una criatura Grande o más pequeña, tendrá el estado de agarrada (CD 14 para escapar) por una de las dos tenazas."
        },
        {
          "name": "Tentáculos paralizadores",
          "text": "Tirada de salvación de Constitución: CD 13, una criatura agarrada por el chuul. Fallo: el objetivo tendrá el estado de envenenado y repetirá la tirada de salvación al final de cada uno de sus turnos. Si tiene éxito, se librará del efecto. Tras 1 minuto, tendrá éxito automáticamente. Mientras esté envenenado, tendrá el estado de paralizado."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 4
        }
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "entiende habla de las profundidades, pero no puede hablar"
      ],
      "cr": "4",
      "proficiencyBonus": 2,
      "xp": 1100
    },
    {
      "id": "cieno_gris",
      "name": "Cieno gris",
      "size": "Mediano",
      "type": "cieno",
      "alignment": "sin alineamiento",
      "ac": 9,
      "initiative": {
        "modifier": -2,
        "score": 13
      },
      "hp": {
        "average": 22,
        "formula": "3d8 + 9"
      },
      "speed": {
        "walk": "10 pies",
        "climb": "10 pies"
      },
      "abilities": {
        "str": 12,
        "dex": 6,
        "con": 16,
        "int": 1,
        "wis": 6,
        "cha": 2
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 1
        },
        {
          "ability": "dex",
          "bonus": -2
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": -5
        },
        {
          "ability": "wis",
          "bonus": -2
        },
        {
          "ability": "cha",
          "bonus": -4
        }
      ],
      "traits": [
        {
          "name": "Amorfo",
          "text": "El cieno puede moverse a través de un espacio de solo 1 pulgada de ancho sin gastar movimiento adicional para hacerlo."
        },
        {
          "name": "Forma corrosiva",
          "text": "La munición no mágica se destruirá de inmediato tras impactar en el cieno y causarle daño. Cualquier arma no mágica recibirá un penalizador acumulativo de −1 a las tiradas de ataque inmediatamente después de causar daño al cieno y entrar en contacto con él. Si el penalizador llega a −5, el arma se destruirá. El penalizador se puede eliminar lanzando el conjuro reparar sobre el arma. El cieno es capaz de devorar 2 pulgadas de madera o metal no mágicos en 1 asalto."
        }
      ],
      "actions": [
        {
          "name": "Pseudópodo",
          "text": "Tirada de ataque cuerpo a cuerpo: +3, alcance 5 pies. Acierto: 10 (2d8 + 1) de daño de ácido. La armadura no mágica que lleve el objetivo recibirá un penalizador de −1 a la CA que ofrece. La armadura se destruirá si el penalizador reduce su CA hasta 10. El penalizador se puede eliminar lanzando el conjuro reparar sobre la armadura."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 2
        }
      ],
      "damageResistances": [
        "ácido",
        "frío",
        "fuego"
      ],
      "conditionImmunities": [
        "agarrado",
        "apresado",
        "asustado",
        "cansancio",
        "cegado",
        "derribado",
        "ensordecido",
        "hechizado"
      ],
      "senses": [
        "visión ciega 60 pies",
        "Percepción pasiva 8"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/2",
      "proficiencyBonus": 2,
      "xp": 100
    },
    {
      "id": "cocatriz",
      "name": "Cocatriz",
      "size": "Pequeña",
      "type": "monstruosidad",
      "alignment": "sin alineamiento",
      "ac": 11,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 22,
        "formula": "5d6 + 5"
      },
      "speed": {
        "walk": "20 pies",
        "fly": "40 pies"
      },
      "abilities": {
        "str": 6,
        "dex": 12,
        "con": 12,
        "int": 2,
        "wis": 13,
        "cha": 5
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -2
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": -3
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Mordisco petrificador",
          "text": "Tirada de ataque cuerpo a cuerpo: +3, alcance 5 pies. Acierto: 3 (1d4 + 1) de daño perforante. Si el objetivo es una criatura, sufre el siguiente efecto. Tirada de salvación de Constitución: CD 11. Primer fallo: el objetivo tendrá el estado de apresado. Si al final de su siguiente turno sigue apresado, repetirá la tirada de salvación y se librará del efecto si la supera. Segundo fallo: el objetivo tendrá el estado de petrificado en vez del de apresado durante 24 horas."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "conditionImmunities": [
        "petrificado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 11"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/2",
      "proficiencyBonus": 2,
      "xp": 100
    },
    {
      "id": "couatl",
      "name": "Couatl",
      "size": "Mediano",
      "type": "celestial",
      "alignment": "legal bueno",
      "ac": 19,
      "initiative": {
        "modifier": 5,
        "score": 15
      },
      "hp": {
        "average": 60,
        "formula": "8d8 + 24"
      },
      "speed": {
        "walk": "30 pies",
        "fly": "90 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 20,
        "con": 17,
        "int": 18,
        "wis": 20,
        "cha": 18
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 5
        },
        {
          "ability": "con",
          "bonus": 5
        },
        {
          "ability": "int",
          "bonus": 4
        },
        {
          "ability": "wis",
          "bonus": 7
        },
        {
          "ability": "cha",
          "bonus": 4
        }
      ],
      "traits": [
        {
          "name": "Mente protegida",
          "text": "Los pensamientos del couatl no se pueden leer de ninguna forma y otras criaturas solo pueden comunicarse con él telepáticamente si se lo permite."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 11 (1d12 + 5) de daño perforante y el objetivo tendrá el estado de envenenado hasta el final del siguiente turno del couatl."
        },
        {
          "name": "Constreñir",
          "text": "Tirada de salvación de Fuerza: CD 15, una criatura Mediana o más pequeña que el couatl pueda ver a 5 pies o menos. Fallo: 8 (1d6 + 5) de daño contundente. El objetivo tendrá el estado de agarrado (CD 13 para escapar) y el de apresado hasta que el agarre termine."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El couatl lanza uno de los siguientes conjuros, que no requiere componentes y utiliza la Sabiduría como aptitud mágica (CD de salvación de conjuros 15): A voluntad: cambiar de forma (solo forma de bestia o humanoide, no se obtienen puntos de golpe temporales del conjuro y no se requieren concentración ni puntos de golpe temporales para mantener el conjuro), detectar el bien y el mal, detectar magia, detectar pensamientos 1/día cada uno: crear comida y agua, dormir, ensueño, escudriñar, restablecimiento mayor"
        }
      ],
      "bonusActions": [
        {
          "name": "Auxilio divino (2/día)",
          "text": "El couatl lanza bendición, restablecimiento menor o santuario, que no requieren componentes y utilizan la misma aptitud mágica que para su lanzamiento de conjuros."
        }
      ],
      "reactions": [],
      "damageResistances": [
        "contundente",
        "cortante",
        "perforante"
      ],
      "damageImmunities": [
        "psíquico",
        "radiante"
      ],
      "senses": [
        "visión verdadera 120 pies",
        "Percepción pasiva 15"
      ],
      "languages": [
        "todos",
        "telepatía 120 pies"
      ],
      "cr": "4",
      "proficiencyBonus": 2,
      "xp": 1100
    },
    {
      "id": "cubo_gelatinoso",
      "name": "Cubo gelatinoso",
      "size": "Grande",
      "type": "cieno",
      "alignment": "sin alineamiento",
      "ac": 6,
      "initiative": {
        "modifier": -4,
        "score": 6
      },
      "hp": {
        "average": 63,
        "formula": "6d10 + 30"
      },
      "speed": {
        "walk": "15 pies"
      },
      "abilities": {
        "str": 14,
        "dex": 3,
        "con": 20,
        "int": 1,
        "wis": 6,
        "cha": 1
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": -4
        },
        {
          "ability": "con",
          "bonus": 5
        },
        {
          "ability": "int",
          "bonus": -5
        },
        {
          "ability": "wis",
          "bonus": -2
        },
        {
          "ability": "cha",
          "bonus": -5
        }
      ],
      "traits": [
        {
          "name": "Cubo de cieno",
          "text": "El cubo ocupa su espacio por completo y es transparente. Otras criaturas podrán entrar en ese área, pero las que lo hagan serán sometidas a la acción de absorber del cubo y tendrán desventaja en la tirada de salvación. Las criaturas tienen cobertura completa en su interior y el cubo puede albergar una criatura Grande o hasta cuatro Medianas o Pequeñas a la vez. Como acción, una criatura a 5 pies o menos del cubo puede tirar de una criatura u objeto y sacarlo del cubo si supera una prueba de Fuerza (Atletismo) con CD 12, y recibirá 10 (3d6) de daño de ácido."
        },
        {
          "name": "Transparente",
          "text": "Incluso cuando el cubo está a plena vista, una criatura debe superar una prueba de Sabiduría (Percepción) con CD 15 para detectarlo si no lo ha visto moverse o actuar."
        }
      ],
      "actions": [
        {
          "name": "Pseudópodo",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 12 (3d6 + 2) de daño de ácido."
        },
        {
          "name": "Absorber",
          "text": "El cubo se mueve hasta su velocidad sin provocar ataques de oportunidad. Puede atravesar los espacios de criaturas Grandes o más pequeñas si tiene sitio en su interior para albergarlas (consulta el atributo"
        },
        {
          "name": "Cubo de cieno)",
          "text": "Tirada de salvación de Destreza: CD 12, todas las criaturas en cuyo espacio entre el cubo por primera vez durante este movimiento. Fallo: 10 (3d6) de daño de ácido y el objetivo será absorbido. Un objetivo absorbido sufrirá asfixia, no podrá lanzar conjuros con un componente verbal, tendrá el estado de apresado y sufrirá 10 (3d6) de daño de ácido al principio de cada turno del cubo. Cuando el cubo se mueva, el objetivo absorbido se moverá con él. Un objetivo absorbido puede intentar escapar utilizando una acción para realizar una prueba de Fuerza (Atletismo) con CD 12. Si la supera, escapará y entrará en el espacio sin ocupar más cercano. Éxito: la mitad del daño y el objetivo se moverá a un espacio sin ocupar a 5 pies del cubo. Si no hay espacios sin ocupar, fallará la tirada de salvación."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageImmunities": [
        "ácido"
      ],
      "conditionImmunities": [
        "asustado",
        "cansancio",
        "cegado",
        "derribado",
        "ensordecido",
        "hechizado"
      ],
      "senses": [
        "visión ciega 60 pies",
        "Percepción pasiva 8"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "deva",
      "name": "Deva",
      "size": "Mediano",
      "type": "celestial",
      "alignment": "legal bueno",
      "ac": 17,
      "initiative": {
        "modifier": 4,
        "score": 14
      },
      "hp": {
        "average": 229,
        "formula": "27d8 + 108"
      },
      "speed": {
        "walk": "30 pies",
        "fly": "90 pies (levitar)"
      },
      "abilities": {
        "str": 18,
        "dex": 18,
        "con": 18,
        "int": 17,
        "wis": 20,
        "cha": 20
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 4
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": 3
        },
        {
          "ability": "wis",
          "bonus": 9
        },
        {
          "ability": "cha",
          "bonus": 9
        }
      ],
      "traits": [
        {
          "name": "Recuperación exaltada",
          "text": "Si el deva muere fuera del Monte Celestia, su cuerpo desaparece, obtiene un cuerpo nuevo al instante y revive con todos sus puntos de golpe en algún lugar del Monte Celestia."
        },
        {
          "name": "Resistencia mágica",
          "text": "El deva tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El deva realiza dos ataques con su maza sagrada."
        },
        {
          "name": "Maza sagrada",
          "text": "Tirada de ataque cuerpo a cuerpo: +8, alcance 5 pies. Acierto: 7 (1d6 + 4) de daño contundente más 18 (4d8) de daño radiante."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El deva lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 17): A voluntad: cambiar de forma (solo forma de bestia o humanoide, no se obtienen puntos de golpe temporales del conjuro y no se requieren concentración ni puntos de golpe temporales para mantener el conjuro), detectar el bien y el mal 1/día cada uno: alzar a los muertos, comunión"
        }
      ],
      "bonusActions": [
        {
          "name": "Auxilio divino (2/día)",
          "text": "El deva lanza curar heridas, levantar maldición o restablecimiento menor usando la misma aptitud mágica que para su lanzamiento de conjuros."
        }
      ],
      "reactions": [],
      "subtype": "ángel",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 9
        },
        {
          "name": "Perspicacia",
          "bonus": 9
        }
      ],
      "damageResistances": [
        "radiante"
      ],
      "conditionImmunities": [
        "asustado",
        "cansancio",
        "hechizado"
      ],
      "senses": [
        "visión en la oscuridad 120 pies",
        "Percepción pasiva 19"
      ],
      "languages": [
        "todos",
        "telepatía 120 pies"
      ],
      "cr": "10",
      "proficiencyBonus": 4,
      "xp": 5900
    },
    {
      "id": "diablillo",
      "name": "Diablillo",
      "size": "Diminuto",
      "type": "infernal",
      "alignment": "legal malvado",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 21,
        "formula": "6d4 + 6"
      },
      "speed": {
        "walk": "20 pies",
        "fly": "40 pies"
      },
      "abilities": {
        "str": 6,
        "dex": 17,
        "con": 13,
        "int": 11,
        "wis": 12,
        "cha": 14
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -2
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "traits": [
        {
          "name": "Resistencia mágica",
          "text": "El diablillo tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Aguijón",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 6 (1d6 + 3) de daño perforante más 7 (2d6) de daño de veneno."
        },
        {
          "name": "Cambio de forma",
          "text": "El diablillo cambia de forma para parecerse a una araña (velocidad 20 pies, trepar 20 pies), un cuervo (20 pies, volar 60 pies) o una rata (20 pies), o recupera su auténtica forma. Su perfil es el mismo en todas las formas, excepto por su velocidad. Cualquier equipo que vista o lleve no se transformará."
        },
        {
          "name": "Invisibilidad",
          "text": "El diablillo lanza invisibilidad sobre sí mismo sin necesidad de componentes y utiliza el Carisma como aptitud mágica."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "diablo",
      "skills": [
        {
          "name": "Engaño",
          "bonus": 4
        },
        {
          "name": "Perspicacia",
          "bonus": 3
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "damageResistances": [
        "frío"
      ],
      "damageImmunities": [
        "fuego",
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 120 pies (no afectada por la oscuridad mágica)",
        "Percepción pasiva 11"
      ],
      "languages": [
        "común",
        "infernal"
      ],
      "cr": "1",
      "proficiencyBonus": 2,
      "xp": 200
    },
    {
      "id": "diablo_astado",
      "name": "Diablo astado",
      "size": "Grande",
      "type": "infernal",
      "alignment": "legal malvado",
      "ac": 18,
      "initiative": {
        "modifier": 7,
        "score": 17
      },
      "hp": {
        "average": 199,
        "formula": "19d10 + 95"
      },
      "speed": {
        "walk": "30 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 22,
        "dex": 17,
        "con": 21,
        "int": 12,
        "wis": 16,
        "cha": 18
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 10
        },
        {
          "ability": "dex",
          "bonus": 7
        },
        {
          "ability": "con",
          "bonus": 5
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 7
        },
        {
          "ability": "cha",
          "bonus": 8
        }
      ],
      "traits": [
        {
          "name": "Recuperación diabólica",
          "text": "Si el diablo muere fuera de los Nueve Infiernos, su cuerpo se desvanece en un humo sulfuroso, obtiene un cuerpo nuevo al instante y revive con todos sus puntos de golpe en algún lugar de los Nueve Infiernos."
        },
        {
          "name": "Resistencia mágica",
          "text": "El diablo tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El diablo realiza tres ataques con su horca abrasadora y su acción de arrojar llama en cualquier combinación. Puede sustituir un ataque por un uso de su cola infernal."
        },
        {
          "name": "Horca abrasadora",
          "text": "Tirada de ataque cuerpo a cuerpo: +10, alcance 10 pies. Acierto: 15 (2d8 + 6) de daño perforante más 9 (2d8) de daño de fuego."
        },
        {
          "name": "Arrojar llama",
          "text": "Tirada de ataque a distancia: +8, alcance 150 pies. Acierto: 26 (5d8 + 4) de daño de fuego. Si el objetivo es un objeto inflamable que no lleve o vista nadie, empieza a arder."
        },
        {
          "name": "Cola infernal",
          "text": "Tirada de salvación de Destreza: CD 17, una criatura que el diablo pueda ver a 10 pies o menos. Fallo: 10 (1d8 + 6) de daño necrótico y el objetivo recibirá una herida infernal si no tiene una ya. Mientras esté herido, perderá 10 (3d6) puntos de golpe al principio de cada uno de sus turnos. La herida se cerrará tras 1 minuto, después de que el objetivo recupere puntos de golpe por un conjuro o después de que el objetivo o una criatura a 5 pies o menos de él lleve a cabo una acción para cerrar la herida, lo que logrará si supera una prueba de Sabiduría (Medicina) con CD 17."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "diablo",
      "damageResistances": [
        "frío"
      ],
      "damageImmunities": [
        "fuego",
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 150 pies (no afectada por la oscuridad mágica)",
        "Percepción pasiva 13"
      ],
      "languages": [
        "infernal",
        "telepatía 120 pies"
      ],
      "cr": "11",
      "proficiencyBonus": 4,
      "xp": 7200
    },
    {
      "id": "diablo_barbado",
      "name": "Diablo barbado",
      "size": "Mediano",
      "type": "infernal",
      "alignment": "legal malvado",
      "ac": 13,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 58,
        "formula": "9d8 + 18"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 15,
        "con": 15,
        "int": 9,
        "wis": 11,
        "cha": 14
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 5
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": -1
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 4
        }
      ],
      "traits": [
        {
          "name": "Resistencia mágica",
          "text": "El diablo tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El diablo realiza un ataque con su barba y uno con su guja infernal."
        },
        {
          "name": "Barba",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 7 (1d8 + 3) de daño perforante y el objetivo tendrá el estado de envenenado hasta el principio del siguiente turno del diablo. Hasta que termine el efecto de este veneno, el objetivo no podrá recuperar puntos de golpe."
        },
        {
          "name": "Guja infernal",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 10 pies. Acierto: 8 (1d10 + 3) de daño cortante. Si el objetivo es una criatura y no tiene ya una herida infernal, sufre el siguiente efecto. Tirada de salvación de Constitución: CD 12. Fallo: el objetivo recibe una herida infernal. Mientras esté herido, perderá 5 (1d10) puntos de golpe al principio de cada uno de sus turnos. La herida se cerrará tras 1 minuto, después de que el objetivo recupere puntos de golpe por un conjuro o después de que el objetivo o una criatura a 5 pies o menos de él lleve a cabo una acción para cerrar la herida, lo que logrará si supera una prueba de Sabiduría (Medicina) con CD 12."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "diablo",
      "damageResistances": [
        "frío"
      ],
      "damageImmunities": [
        "fuego",
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 120 pies (no afectada por la oscuridad mágica)",
        "Percepción pasiva 10"
      ],
      "languages": [
        "infernal",
        "telepatía 120 pies"
      ],
      "cr": "3",
      "proficiencyBonus": 2,
      "xp": 700
    },
    {
      "id": "diablo_de_las_cadenas",
      "name": "Diablo de las cadenas",
      "size": "Mediano",
      "type": "infernal",
      "alignment": "legal malvado",
      "ac": 15,
      "initiative": {
        "modifier": 5,
        "score": 15
      },
      "hp": {
        "average": 85,
        "formula": "10d8 + 40"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 15,
        "con": 18,
        "int": 11,
        "wis": 12,
        "cha": 14
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 7
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 4
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "traits": [
        {
          "name": "Recuperación diabólica",
          "text": "Si el diablo muere fuera de los Nueve Infiernos, su cuerpo se desvanece en un humo sulfuroso, obtiene un cuerpo nuevo al instante y revive con todos sus puntos de golpe en algún lugar de los Nueve Infiernos."
        },
        {
          "name": "Resistencia mágica",
          "text": "El diablo tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El diablo realiza dos ataques con sus cadenas y usa la acción de conjurar cadena infernal."
        },
        {
          "name": "Cadena",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 10 pies. Acierto: 11 (2d6 + 4) de daño cortante. Si el objetivo es una criatura Grande o más pequeña, tendrá el estado de agarrada (CD 14 para escapar) por una de las dos cadenas y el de apresada hasta que el agarre termine."
        },
        {
          "name": "Conjurar cadena infernal",
          "text": "El diablo conjura una cadena ardiente para atar a una criatura. Tirada de salvación de Destreza: CD 15, una criatura que el diablo pueda ver a 60 pies o menos. Fallo: 9 (2d4 + 4) de daño de fuego y el objetivo tendrá el estado de apresado hasta el final del siguiente turno del diablo, momento en el que la cadena desaparecerá. Si el objetivo es Grande o más pequeño, el diablo lo moverá hasta 30 pies en línea recta hacia él. Éxito: la cadena desaparece."
        }
      ],
      "bonusActions": [],
      "reactions": [
        {
          "name": "Mirada inquietante",
          "text": "Detonante: una criatura que el diablo pueda ver comienza su turno a 30 pies o menos del diablo y puede ver a este. Respuesta; tirada de salvación de Sabiduría: CD 15, la criatura detonante. Fallo: el objetivo tendrá el estado de asustado hasta el final de su turno. Éxito: el objetivo será inmune a la mirada inquietante de este diablo durante 24 horas."
        }
      ],
      "subtype": "diablo",
      "damageResistances": [
        "contundente",
        "cortante",
        "frío",
        "perforante"
      ],
      "damageImmunities": [
        "fuego",
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 120 pies (no afectada por la oscuridad mágica)",
        "Percepción pasiva 11"
      ],
      "languages": [
        "infernal",
        "telepatía 120 pies"
      ],
      "cr": "8",
      "proficiencyBonus": 3,
      "xp": 3900
    },
    {
      "id": "diablo_de_la_sima",
      "name": "Diablo de la sima",
      "size": "Grande",
      "type": "infernal",
      "alignment": "legal malvado",
      "ac": 21,
      "initiative": {
        "modifier": 14,
        "score": 24
      },
      "hp": {
        "average": 337,
        "formula": "27d10 + 189"
      },
      "speed": {
        "walk": "30 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 26,
        "dex": 14,
        "con": 24,
        "int": 22,
        "wis": 18,
        "cha": 24
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 8
        },
        {
          "ability": "dex",
          "bonus": 8
        },
        {
          "ability": "con",
          "bonus": 7
        },
        {
          "ability": "int",
          "bonus": 6
        },
        {
          "ability": "wis",
          "bonus": 10
        },
        {
          "ability": "cha",
          "bonus": 7
        }
      ],
      "traits": [
        {
          "name": "Aura de miedo",
          "text": "Mientras no tenga el estado de incapacitado, el diablo de la sima emite un aura en una emanación de 20 pies. Tirada de salvación de Sabiduría: CD 21, cualquier enemigo que comience su turno dentro del aura. Fallo: el objetivo tendrá el estado de asustado hasta el principio de su siguiente turno. Éxito: el objetivo será inmune al aura de este diablo de la sima durante 24 horas."
        },
        {
          "name": "Recuperación diabólica",
          "text": "Si el diablo de la sima muere fuera de los Nueve Infiernos, su cuerpo se desvanece en un humo sulfuroso, obtiene un cuerpo nuevo al instante y revive con todos sus puntos de golpe en algún lugar de los Nueve Infiernos."
        },
        {
          "name": "Resistencia legendaria (4/día)",
          "text": "El diablo de la sima puede elegir tener éxito en una tirada de salvación que haya fallado."
        },
        {
          "name": "Resistencia mágica",
          "text": "El diablo de la sima tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El diablo de la sima realiza un ataque de mordisco, dos con su garra diabólica y uno con su maza ardiente."
        },
        {
          "name": "Garra diabólica",
          "text": "Tirada de ataque cuerpo a cuerpo: +14, alcance 10 pies. Acierto: 26 (4d8 + 8) de daño necrótico."
        },
        {
          "name": "Maza ardiente",
          "text": "Tirada de ataque cuerpo a cuerpo: +14, alcance 10 pies. Acierto: 22 (4d6 + 8) de daño de fuerza más 21 (6d6) de daño de fuego."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +14, alcance 10 pies. Acierto: 18 (3d6 + 8) de daño perforante. Si el objetivo es una criatura, deberá hacer la siguiente tirada de salvación. Tirada de salvación de"
        },
        {
          "name": "Constitución: CD 21",
          "text": "Fallo: el objetivo tendrá el estado de envenenado. Mientras esté envenenado, no podrá recuperar puntos de golpe y sufrirá 21 (6d6) de daño de veneno al principio de cada uno de sus turnos. Repetirá la tirada de salvación al final de cada uno de sus turnos y, si tiene éxito, se librará del efecto. Tras 1 minuto, tendrá éxito automáticamente. Lanzamiento de conjuros de fuego infernal (recarga 4–6). El diablo de la sima lanza bola de fuego (versión de nivel 5) dos veces, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 21). Puede sustituir una bola de fuego por inmovilizar monstruo (versión de nivel 7) o muro de fuego."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "diablo",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 10
        },
        {
          "name": "Persuasión",
          "bonus": 19
        }
      ],
      "damageResistances": [
        "frío"
      ],
      "damageImmunities": [
        "fuego",
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado"
      ],
      "senses": [
        "visión verdadera 120 pies",
        "Percepción pasiva 20"
      ],
      "languages": [
        "infernal",
        "telepatía 120 pies"
      ],
      "cr": "20",
      "proficiencyBonus": 6,
      "xp": 25000
    },
    {
      "id": "diablo_gelido",
      "name": "Diablo gélido",
      "size": "Grande",
      "type": "infernal",
      "alignment": "legal malvado",
      "ac": 18,
      "initiative": {
        "modifier": 7,
        "score": 17
      },
      "hp": {
        "average": 228,
        "formula": "24d10 + 96"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 21,
        "dex": 14,
        "con": 18,
        "int": 18,
        "wis": 15,
        "cha": 18
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 5
        },
        {
          "ability": "dex",
          "bonus": 7
        },
        {
          "ability": "con",
          "bonus": 9
        },
        {
          "ability": "int",
          "bonus": 4
        },
        {
          "ability": "wis",
          "bonus": 7
        },
        {
          "ability": "cha",
          "bonus": 9
        }
      ],
      "traits": [
        {
          "name": "Recuperación diabólica",
          "text": "Si el diablo muere fuera de los Nueve Infiernos, su cuerpo se desvanece en un humo sulfuroso, obtiene un cuerpo nuevo al instante y revive con todos sus puntos de golpe en algún lugar de los Nueve Infiernos."
        },
        {
          "name": "Resistencia mágica",
          "text": "El diablo tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El diablo realiza tres ataques con su lanza de hielo. Puede sustituir uno de ellos por un ataque con su cola."
        },
        {
          "name": "Cola",
          "text": "Tirada de ataque cuerpo a cuerpo: +10, alcance 10 pies. Acierto: 15 (3d6 + 5) de daño contundente más 18 (4d8) de daño de frío."
        },
        {
          "name": "Lanza de hielo",
          "text": "Tirada de ataque cuerpo a cuerpo o a distancia: +10, alcance 5 pies o 9/120 pies a distancia. Acierto: 14 (2d8 + 5) de daño perforante más 10 (3d6) de daño de frío. Hasta el final de su siguiente turno, el objetivo no podrá usar una acción adicional ni llevar a cabo una reacción, su velocidad se reducirá en 10 pies y en su turno podrá moverse o realizar una acción, pero no ambas cosas. Acierto o fallo: la lanza regresa mágicamente a la mano del diablo inmediatamente después de un ataque a distancia."
        },
        {
          "name": "Muro gélido (recarga 6)",
          "text": "El diablo lanza muro de hielo (versión de nivel 8), que no requiere componentes y utiliza la Inteligencia como aptitud mágica (CD de salvación de conjuros 17)."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "diablo",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 7
        },
        {
          "name": "Perspicacia",
          "bonus": 7
        },
        {
          "name": "Persuasión",
          "bonus": 9
        }
      ],
      "damageImmunities": [
        "frío",
        "fuego",
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado"
      ],
      "senses": [
        "visión ciega 120 pies",
        "Percepción pasiva 17"
      ],
      "languages": [
        "infernal",
        "telepatía 120 pies"
      ],
      "cr": "14",
      "proficiencyBonus": 5,
      "xp": 11500
    },
    {
      "id": "diablo_oseo",
      "name": "Diablo óseo",
      "size": "Grande",
      "type": "infernal",
      "alignment": "legal malvado",
      "ac": 16,
      "initiative": {
        "modifier": 7,
        "score": 17
      },
      "hp": {
        "average": 161,
        "formula": "17d10 + 68"
      },
      "speed": {
        "walk": "40 pies",
        "fly": "40 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 16,
        "con": 18,
        "int": 13,
        "wis": 14,
        "cha": 16
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 8
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": 5
        },
        {
          "ability": "wis",
          "bonus": 6
        },
        {
          "ability": "cha",
          "bonus": 7
        }
      ],
      "traits": [
        {
          "name": "Recuperación diabólica",
          "text": "Si el diablo muere fuera de los Nueve Infiernos, su cuerpo se desvanece en un humo sulfuroso, obtiene un cuerpo nuevo al instante y revive con todos sus puntos de golpe en algún lugar de los Nueve Infiernos."
        },
        {
          "name": "Resistencia mágica",
          "text": "El diablo tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El diablo realiza dos ataques con sus garras y uno con su aguijón infernal."
        },
        {
          "name": "Aguijón infernal",
          "text": "Tirada de ataque cuerpo a cuerpo: +8, alcance 10 pies. Acierto: 15 (2d10 + 4) de daño perforante más 18 (4d8) de daño de veneno y el objetivo tendrá el estado de envenenado hasta el principio del siguiente turno del diablo. Mientras esté envenenado, el objetivo no podrá recuperar puntos de golpe."
        },
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +8, alcance 10 pies. Acierto: 13 (2d8 + 4) de daño cortante."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "diablo",
      "skills": [
        {
          "name": "Engaño",
          "bonus": 7
        },
        {
          "name": "Perspicacia",
          "bonus": 6
        }
      ],
      "damageResistances": [
        "frío"
      ],
      "damageImmunities": [
        "fuego",
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 120 pies (no afectada por la oscuridad mágica)",
        "Percepción pasiva 12"
      ],
      "languages": [
        "infernal",
        "telepatía 120 pies"
      ],
      "cr": "9",
      "proficiencyBonus": 4,
      "xp": 5000
    },
    {
      "id": "diablo_punzante",
      "name": "Diablo punzante",
      "size": "Mediano",
      "type": "infernal",
      "alignment": "legal malvado",
      "ac": 15,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 110,
        "formula": "13d8 + 52"
      },
      "speed": {
        "walk": "30 pies",
        "climb": "30 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 17,
        "con": 18,
        "int": 12,
        "wis": 14,
        "cha": 14
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 6
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 7
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 5
        },
        {
          "ability": "cha",
          "bonus": 5
        }
      ],
      "traits": [
        {
          "name": "Piel espinosa",
          "text": "Al principio de cada uno de sus turnos, el diablo inflige 5 (1d10) de daño perforante a cualquier criatura a la que esté agarrando o que lo esté agarrando a él."
        },
        {
          "name": "Recuperación diabólica",
          "text": "Si el diablo muere fuera de los Nueve Infiernos, su cuerpo se desvanece en un humo sulfuroso, obtiene un cuerpo nuevo al instante y revive con todos sus puntos de golpe en algún lugar de los Nueve Infiernos."
        },
        {
          "name": "Resistencia mágica",
          "text": "El diablo tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El diablo realiza un ataque con sus garras y uno con su cola o realiza dos ataques de arrojar llama."
        },
        {
          "name": "Cola",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 10 pies. Acierto: 14 (2d10 + 3) de daño cortante."
        },
        {
          "name": "Garras",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 10 (2d6 + 3) de daño perforante. Si el objetivo es una criatura Grande o más pequeña, tendrá el estado de agarrada (CD 13 para escapar) por ambas garras."
        },
        {
          "name": "Arrojar llama",
          "text": "Tirada de ataque a distancia: +5, alcance 150 pies. Acierto: 17 (5d6) de daño de fuego. Si el objetivo es un objeto inflamable que no lleve o vista nadie, empieza a arder."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "diablo",
      "skills": [
        {
          "name": "Engaño",
          "bonus": 5
        },
        {
          "name": "Percepción",
          "bonus": 8
        },
        {
          "name": "Perspicacia",
          "bonus": 5
        }
      ],
      "damageResistances": [
        "frío"
      ],
      "damageImmunities": [
        "fuego",
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 120 pies (no afectada por la oscuridad mágica)",
        "Percepción pasiva 18"
      ],
      "languages": [
        "infernal",
        "telepatía 120 pies"
      ],
      "cr": "5",
      "proficiencyBonus": 3,
      "xp": 1800
    },
    {
      "id": "djinn",
      "name": "Djinn",
      "size": "Grande",
      "type": "elemental",
      "alignment": "neutral",
      "ac": 17,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 218,
        "formula": "19d10 + 114"
      },
      "speed": {
        "walk": "30 pies",
        "fly": "90 pies (levitar)"
      },
      "abilities": {
        "str": 21,
        "dex": 15,
        "con": 22,
        "int": 15,
        "wis": 16,
        "cha": 20
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 5
        },
        {
          "ability": "dex",
          "bonus": 6
        },
        {
          "ability": "con",
          "bonus": 6
        },
        {
          "ability": "int",
          "bonus": 2
        },
        {
          "ability": "wis",
          "bonus": 7
        },
        {
          "ability": "cha",
          "bonus": 5
        }
      ],
      "traits": [
        {
          "name": "Deseos",
          "text": "El djinn tiene un 30 % de probabilidad de conocer el conjuro deseo. Si es así, puede lanzarlo en nombre de una criatura que no sea un genio y que pida un deseo de tal modo que el djinn pueda entenderlo. Si el djinn lanza el conjuro para esa criatura, no sufrirá los efectos de la tensión del conjuro. Cuando lo haya lanzado tres veces, el djinn no podrá volver a hacerlo hasta pasados 365 días."
        },
        {
          "name": "Recuperación elemental",
          "text": "Si el djinn muere fuera del Plano Elemental del Aire, su cuerpo se convierte en niebla, obtiene un cuerpo nuevo tras 1d4 días y revive con todos sus puntos de golpe en algún lugar del Plano del Aire."
        },
        {
          "name": "Resistencia mágica",
          "text": "El djinn tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El djinn realiza tres ataques con su hoja tormentosa o su golpe de tormenta en cualquier combinación."
        },
        {
          "name": "Hoja tormentosa",
          "text": "Tirada de ataque cuerpo a cuerpo: +9, alcance 5 pies. Acierto: 12 (2d6 + 5) de daño cortante más 7 (2d6) de daño de relámpago."
        },
        {
          "name": "Golpe de tormenta",
          "text": "Tirada de ataque a distancia: +9, alcance 120 pies. Acierto: 13 (3d8) de daño de trueno. Si el objetivo es una criatura Grande o más pequeña, tendrá el estado de derribada."
        },
        {
          "name": "Crear torbellino",
          "text": "El djinn conjura un torbellino en un punto que pueda ver a 120 pies o menos. El torbellino llena un cilindro de 20 pies de radio y 60 pies de altura centrado en ese punto y durará hasta que el djinn deje de concentrarse en él. El djinn puede mover el torbellino hasta 20 pies al principio de cada uno de sus turnos. Cuando el torbellino entre en el espacio de una criatura o una criatura en él, la criatura sufrirá el siguiente efecto. Tirada de salvación de Fuerza: CD 17 (una criatura solo hace esta tirada una vez por turno y el djinn no se verá afectado). Fallo: mientras permanezca en el torbellino, el objetivo tendrá el estado de apresado y se moverá con él. Al principio de cada uno de sus turnos, el objetivo apresado sufrirá 21 (6d6) de daño de trueno. Al final de cada uno de sus turnos, el objetivo repetirá la tirada de salvación y, si tiene éxito, se librará del efecto."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El djinn lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 17): A voluntad: detectar el bien y el mal, detectar magia 2/día cada uno: crear comida y agua (puede crear vino en lugar de agua), don de lenguas, viajar con el viento 1/día cada uno: creación, desplazamiento entre planos, forma gaseosa, imagen mayor, invisibilidad"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "genio",
      "damageImmunities": [
        "relámpago",
        "trueno"
      ],
      "senses": [
        "visión en la oscuridad 120 pies",
        "Percepción pasiva 13"
      ],
      "languages": [
        "primordial (aurano)"
      ],
      "cr": "11",
      "proficiencyBonus": 4,
      "xp": 7200
    },
    {
      "id": "doppelganger",
      "name": "Doppelganger",
      "size": "Mediana",
      "type": "monstruosidad",
      "alignment": "neutral",
      "ac": 14,
      "initiative": {
        "modifier": 4,
        "score": 14
      },
      "hp": {
        "average": 52,
        "formula": "8d8 + 16"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 11,
        "dex": 18,
        "con": 14,
        "int": 11,
        "wis": 12,
        "cha": 14
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 0
        },
        {
          "ability": "dex",
          "bonus": 4
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El doppelganger realiza dos ataques con su golpe y usa su acción de rostro inquietante si está disponible."
        },
        {
          "name": "Golpe",
          "text": "Tirada de ataque cuerpo a cuerpo: +6 (con ventaja durante el primer asalto de cada combate), alcance 5 pies. Acierto: 11 (2d6 + 4) de daño contundente."
        },
        {
          "name": "Leer pensamientos",
          "text": "El doppelganger lanza detectar pensamientos, que no requiere componentes y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 12)."
        },
        {
          "name": "Rostro inquietante (recarga 6)",
          "text": "Tirada de salvación de Sabiduría: CD 12, todas las criaturas en una emanación de 15 pies que se origina en el doppelganger que puedan verlo. Fallo: el objetivo tendrá el estado de asustado y repetirá la tirada de salvación al final de cada uno de sus turnos. Si tiene éxito, se librará del efecto. Tras 1 minuto, tendrá éxito automáticamente."
        }
      ],
      "bonusActions": [
        {
          "name": "Cambio de forma",
          "text": "El doppelganger adopta la forma de un humanoide Mediano o Pequeño, o recupera su verdadera forma. Su perfil, salvo por el tamaño, es el mismo en todas las formas. Cualquier equipo que vista o lleve no se transformará. Dragones azules"
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Engaño",
          "bonus": 6
        },
        {
          "name": "Perspicacia",
          "bonus": 3
        }
      ],
      "conditionImmunities": [
        "hechizado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 11"
      ],
      "languages": [
        "común y otros tres idiomas"
      ],
      "cr": "3",
      "proficiencyBonus": 2,
      "xp": 700
    },
    {
      "id": "cria_de_dragon_azul",
      "name": "Cría de dragón azul",
      "size": "Mediano",
      "type": "dragón",
      "alignment": "legal malvado",
      "ac": 17,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 65,
        "formula": "10d8 + 20"
      },
      "speed": {
        "walk": "30 pies",
        "burrow": "15 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 17,
        "dex": 10,
        "con": 15,
        "int": 12,
        "wis": 11,
        "cha": 15
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza dos ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 8 (1d10 + 3) de daño cortante más 3 (1d6) de daño de relámpago."
        },
        {
          "name": "Aliento de relámpago (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 12, todas las criaturas en una línea de 30 pies de largo y 5 pies de ancho. Fallo: 21 (6d6) de daño de relámpago. Éxito: la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "cromático",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 4
        },
        {
          "name": "Sigilo",
          "bonus": 2
        }
      ],
      "damageImmunities": [
        "relámpago"
      ],
      "senses": [
        "visión ciega 10 pies, visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "dracónico"
      ],
      "cr": "3",
      "proficiencyBonus": 2,
      "xp": 700
    },
    {
      "id": "dragon_azul_joven",
      "name": "Dragón azul joven",
      "size": "Grande",
      "type": "dragón",
      "alignment": "legal malvado",
      "ac": 18,
      "initiative": {
        "modifier": 4,
        "score": 14
      },
      "hp": {
        "average": 152,
        "formula": "16d10 + 64"
      },
      "speed": {
        "walk": "40 pies",
        "burrow": "20 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 21,
        "dex": 10,
        "con": 19,
        "int": 14,
        "wis": 13,
        "cha": 17
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 5
        },
        {
          "ability": "dex",
          "bonus": 4
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": 2
        },
        {
          "ability": "wis",
          "bonus": 5
        },
        {
          "ability": "cha",
          "bonus": 3
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +9, alcance 10 pies. Acierto: 12 (2d6 + 5) de daño cortante más 5 (1d10) de daño de relámpago."
        },
        {
          "name": "Aliento de relámpago (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 16, todas las criaturas en una línea de 60 pies de largo y 5 pies de ancho. Fallo: 55 (10d10) de daño de relámpago. Éxito: la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "cromático",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 9
        },
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "damageImmunities": [
        "relámpago"
      ],
      "senses": [
        "visión ciega 30 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 19"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "9",
      "proficiencyBonus": 4,
      "xp": 5000
    },
    {
      "id": "dragon_azul_adulto",
      "name": "Dragón azul adulto",
      "size": "Enorme",
      "type": "dragón",
      "alignment": "legal malvado",
      "ac": 19,
      "initiative": {
        "modifier": 10,
        "score": 20
      },
      "hp": {
        "average": 212,
        "formula": "17d12 + 102"
      },
      "speed": {
        "walk": "40 pies",
        "burrow": "30 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 25,
        "dex": 10,
        "con": 23,
        "int": 16,
        "wis": 15,
        "cha": 20
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 7
        },
        {
          "ability": "dex",
          "bonus": 5
        },
        {
          "ability": "con",
          "bonus": 6
        },
        {
          "ability": "int",
          "bonus": 3
        },
        {
          "ability": "wis",
          "bonus": 7
        },
        {
          "ability": "cha",
          "bonus": 5
        }
      ],
      "traits": [
        {
          "name": "Resistencia legendaria (3/día o 4/día en la guarida)",
          "text": "El dragón puede elegir tener éxito en una tirada de salvación que haya fallado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro. Puede sustituir un ataque por un uso de su lanzamiento de conjuros para lanzar hacer añicos."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +12, alcance 10 pies. Acierto: 16 (2d8 + 7) de daño cortante más 5 (1d10) de daño de relámpago."
        },
        {
          "name": "Aliento de relámpago (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 19, todas las criaturas en una línea de 90 pies de largo y 5 pies de ancho. Fallo: 60 (11d10) de daño de relámpago. Éxito: la mitad del daño."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El dragón lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 18): A voluntad: detectar magia, hacer añicos, invisibilidad, mano de mago 1/día cada uno: escudriñar, recado"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "cromático",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, el dragón puede emplear un uso para llevar a cabo una de las siguientes acciones. El dragón recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Coletazo",
          "text": "El dragón realiza un ataque de desgarro."
        },
        {
          "name": "Estallido sónico",
          "text": "El dragón utiliza su lanzamiento de conjuros para lanzar hacer añicos. El dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        },
        {
          "name": "Vuelo encubierto",
          "text": "El dragón utiliza su lanzamiento de conjuros para lanzarse invisibilidad a sí mismo y puede volar hasta la mitad de su velocidad volando. El dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        }
      ],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 12
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "damageImmunities": [
        "relámpago"
      ],
      "senses": [
        "visión ciega 60 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 22"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "16",
      "proficiencyBonus": 5,
      "xp": 15000,
      "xpText": "15 000 PX o 18 000 en la guarida"
    },
    {
      "id": "dragon_azul_anciano",
      "name": "Dragón azul anciano",
      "size": "Gargantuesco",
      "type": "dragón",
      "alignment": "legal malvado",
      "ac": 22,
      "initiative": {
        "modifier": 14,
        "score": 24
      },
      "hp": {
        "average": 481,
        "formula": "26d20 + 208"
      },
      "speed": {
        "walk": "40 pies",
        "burrow": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 29,
        "dex": 10,
        "con": 27,
        "int": 18,
        "wis": 17,
        "cha": 25
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 9
        },
        {
          "ability": "dex",
          "bonus": 7
        },
        {
          "ability": "con",
          "bonus": 8
        },
        {
          "ability": "int",
          "bonus": 4
        },
        {
          "ability": "wis",
          "bonus": 10
        },
        {
          "ability": "cha",
          "bonus": 7
        }
      ],
      "traits": [
        {
          "name": "Resistencia legendaria (4/día o 5/día en la guarida)",
          "text": "El dragón puede elegir tener éxito en una tirada de salvación que haya fallado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro. Puede sustituir un ataque por un uso de su lanzamiento de conjuros para lanzar hacer añicos (versión de nivel 3)."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +16, alcance 15 pies. Acierto: 18 (2d8 + 9) de daño cortante más 11 (2d10) de daño de relámpago."
        },
        {
          "name": "Aliento de relámpago (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 23, todas las criaturas en una línea de 120 pies de largo y 10 pies de ancho. Fallo: 88 (16d10) de daño de relámpago. Éxito: la mitad del daño."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El dragón lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 22): A voluntad: detectar magia, hacer añicos (versión de nivel 3), invisibilidad, mano de mago 1/día cada uno: escudriñar, recado"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "cromático",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, el dragón puede emplear un uso para llevar a cabo una de las siguientes acciones. El dragón recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Coletazo",
          "text": "El dragón realiza un ataque de desgarro."
        },
        {
          "name": "Estallido sónico",
          "text": "El dragón utiliza su lanzamiento de conjuros para lanzar hacer añicos (versión de nivel 3). El dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        },
        {
          "name": "Vuelo encubierto",
          "text": "El dragón utiliza su lanzamiento de conjuros para lanzarse invisibilidad a sí mismo y puede volar hasta la mitad de su velocidad volando. El dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno. Dragones blancos"
        }
      ],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 17
        },
        {
          "name": "Sigilo",
          "bonus": 7
        }
      ],
      "damageImmunities": [
        "relámpago"
      ],
      "senses": [
        "visión ciega 60 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 27"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "23",
      "proficiencyBonus": 7,
      "xp": 50000,
      "xpText": "50 000 PX o 62 000 en la guarida"
    },
    {
      "id": "cria_de_dragon_blanco",
      "name": "Cría de dragón blanco",
      "size": "Mediano",
      "type": "dragón",
      "alignment": "caótico malvado",
      "ac": 16,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 32,
        "formula": "5d8 + 10"
      },
      "speed": {
        "walk": "30 pies",
        "burrow": "15 pies",
        "swim": "30 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 14,
        "dex": 10,
        "con": 14,
        "int": 5,
        "wis": 10,
        "cha": 11
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": -3
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [
        {
          "name": "Caminar por el hielo",
          "text": "El dragón puede moverse y trepar por superficies heladas sin tener que hacer pruebas de característica. Además, desplazarse por terreno difícil compuesto de nieve o hielo no le cuesta movimiento adicional."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza dos ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 6 (1d8 + 2) de daño cortante más 2 (1d4) de daño de frío."
        },
        {
          "name": "Aliento gélido (recarga 5–6)",
          "text": "Tirada de salvación de Constitución: CD 12, todas las criaturas en un cono de 15 pies. Fallo: 22 (5d8) de daño de frío. Éxito: la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "cromático",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 4
        },
        {
          "name": "Sigilo",
          "bonus": 2
        }
      ],
      "damageImmunities": [
        "frío"
      ],
      "senses": [
        "visión ciega 10 pies, visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "dracónico"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "dragon_blanco_joven",
      "name": "Dragón blanco joven",
      "size": "Grande",
      "type": "dragón",
      "alignment": "caótico malvado",
      "ac": 17,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 123,
        "formula": "13d10 + 52"
      },
      "speed": {
        "walk": "40 pies",
        "burrow": "20 pies",
        "swim": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 10,
        "con": 18,
        "int": 6,
        "wis": 11,
        "cha": 12
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": 2
        },
        {
          "ability": "wis",
          "bonus": 3
        },
        {
          "ability": "cha",
          "bonus": 1
        }
      ],
      "traits": [
        {
          "name": "Caminar por el hielo",
          "text": "El dragón puede moverse y trepar por superficies heladas sin tener que hacer pruebas de característica. Además, desplazarse por terreno difícil compuesto de nieve o hielo no le cuesta movimiento adicional."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 10 pies. Acierto: 9 (2d4 + 4) de daño cortante más 2 (1d4) de daño de frío."
        },
        {
          "name": "Aliento gélido (recarga 5–6)",
          "text": "Tirada de salvación de Constitución: CD 15, todas las criaturas en un cono de 30 pies. Fallo: 40 (9d8) de daño de frío. Éxito: la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "cromático",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 6
        },
        {
          "name": "Sigilo",
          "bonus": 3
        }
      ],
      "damageImmunities": [
        "frío"
      ],
      "senses": [
        "visión ciega 30 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 16"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "6",
      "proficiencyBonus": 3,
      "xp": 2300
    },
    {
      "id": "dragon_blanco_adulto",
      "name": "Dragón blanco adulto",
      "size": "Enorme",
      "type": "dragón",
      "alignment": "caótico malvado",
      "ac": 18,
      "initiative": {
        "modifier": 10,
        "score": 20
      },
      "hp": {
        "average": 200,
        "formula": "16d12 + 96"
      },
      "speed": {
        "walk": "40 pies",
        "burrow": "30 pies",
        "swim": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 22,
        "dex": 10,
        "con": 22,
        "int": 8,
        "wis": 12,
        "cha": 12
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 6
        },
        {
          "ability": "dex",
          "bonus": 5
        },
        {
          "ability": "con",
          "bonus": 6
        },
        {
          "ability": "int",
          "bonus": -1
        },
        {
          "ability": "wis",
          "bonus": 6
        },
        {
          "ability": "cha",
          "bonus": 1
        }
      ],
      "traits": [
        {
          "name": "Caminar por el hielo",
          "text": "El dragón puede moverse y trepar por superficies heladas sin tener que hacer pruebas de característica. Además, desplazarse por terreno difícil compuesto de nieve o hielo no le cuesta movimiento adicional. Resistencia legendaria (3/día o 4/día en la guarida). El dragón puede elegir tener éxito en una tirada de salvación que haya fallado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +11, alcance 10 pies. Acierto: 13 (2d6 + 6) de daño cortante más 4 (1d8) de daño de frío."
        },
        {
          "name": "Aliento gélido (recarga 5–6)",
          "text": "Tirada de salvación de Constitución: CD 19, todas las criaturas en un cono de 60 pies. Fallo: 54 (12d8) de daño de frío. Éxito: la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "cromático",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, el dragón puede emplear un uso para llevar a cabo una de las siguientes acciones. El dragón recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Abalanzarse",
          "text": "El dragón se mueve hasta la mitad de su velocidad y realiza un ataque de desgarro."
        },
        {
          "name": "Estallido helador",
          "text": "Tirada de salvación de Constitución: CD 14, todas las criaturas en una esfera de 30 pies de radio centrada en un punto que el dragón pueda ver a 120 pies o menos. Fallo: 7 (2d6) de daño de frío y la velocidad del objetivo será 0 hasta el final de su siguiente turno. Fallo o éxito: el dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        },
        {
          "name": "Presencia aterradora",
          "text": "El dragón lanza terror, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 14). El dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        }
      ],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 11
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "damageImmunities": [
        "frío"
      ],
      "senses": [
        "visión ciega 60 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 21"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "13",
      "proficiencyBonus": 5,
      "xp": 10000,
      "xpText": "10 000 PX u 11 500 en la guarida"
    },
    {
      "id": "dragon_blanco_anciano",
      "name": "Dragón blanco anciano",
      "size": "Gargantuesco",
      "type": "dragón",
      "alignment": "caótico malvado",
      "ac": 20,
      "initiative": {
        "modifier": 12,
        "score": 22
      },
      "hp": {
        "average": 333,
        "formula": "18d20 + 144"
      },
      "speed": {
        "walk": "40 pies",
        "burrow": "40 pies",
        "swim": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 26,
        "dex": 10,
        "con": 26,
        "int": 10,
        "wis": 13,
        "cha": 18
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 8
        },
        {
          "ability": "dex",
          "bonus": 6
        },
        {
          "ability": "con",
          "bonus": 8
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 7
        },
        {
          "ability": "cha",
          "bonus": 4
        }
      ],
      "traits": [
        {
          "name": "Caminar por el hielo",
          "text": "El dragón puede moverse y trepar por superficies heladas sin tener que hacer pruebas de característica. Además, desplazarse por terreno difícil compuesto de nieve o hielo no le cuesta movimiento adicional. Resistencia legendaria (4/día o 5/día en la guarida). El dragón puede elegir tener éxito en una tirada de salvación que haya fallado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +14, alcance 15 pies. Acierto: 17 (2d8 + 8) de daño cortante más 7 (2d6) de daño de frío."
        },
        {
          "name": "Aliento gélido (recarga 5–6)",
          "text": "Tirada de salvación de Constitución: CD 22, todas las criaturas en un cono de 90 pies. Fallo: 63 (14d8) de daño de frío. Éxito: la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "cromático",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, el dragón puede emplear un uso para llevar a cabo una de las siguientes acciones. El dragón recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Abalanzarse",
          "text": "El dragón se mueve hasta la mitad de su velocidad y realiza un ataque de desgarro."
        },
        {
          "name": "Estallido helador",
          "text": "Tirada de salvación de Constitución: CD 20, todas las criaturas en una esfera de 30 pies de radio centrada en un punto que el dragón pueda ver a 120 pies o menos. Fallo: 14 (4d6) de daño de frío y la velocidad del objetivo será 0 hasta el final de su siguiente turno. Fallo o éxito: el dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        },
        {
          "name": "Presencia aterradora",
          "text": "El dragón lanza terror, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 18). El dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno. Dragones de bronce"
        }
      ],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 13
        },
        {
          "name": "Sigilo",
          "bonus": 6
        }
      ],
      "damageImmunities": [
        "frío"
      ],
      "senses": [
        "visión ciega 60 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 23"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "20",
      "proficiencyBonus": 6,
      "xp": 25000,
      "xpText": "25 000 PX o 33 000 en la guarida"
    },
    {
      "id": "cria_de_dragon_de_bronce",
      "name": "Cría de dragón de bronce",
      "size": "Mediano",
      "type": "dragón",
      "alignment": "legal bueno",
      "ac": 15,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 39,
        "formula": "6d8 + 12"
      },
      "speed": {
        "walk": "30 pies",
        "swim": "30 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 17,
        "dex": 10,
        "con": 15,
        "int": 12,
        "wis": 11,
        "cha": 15
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "traits": [
        {
          "name": "Anfibio",
          "text": "El dragón puede respirar tanto dentro como fuera del agua."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza dos ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 8 (1d10 + 3) de daño cortante."
        },
        {
          "name": "Aliento de relámpago (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 12, todas las criaturas en una línea de 40 pies de largo y 5 pies de ancho. Fallo: 16 (3d10) de daño de relámpago. Éxito: la mitad del daño."
        },
        {
          "name": "Aliento repulsor",
          "text": "Tirada de salvación de Fuerza: CD 12, todas las criaturas en un cono de 30 pies. Fallo: el objetivo es empujado hasta 30 pies respecto al dragón en línea recta y tiene el estado de derribado."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "metálico",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 4
        },
        {
          "name": "Sigilo",
          "bonus": 2
        }
      ],
      "damageImmunities": [
        "relámpago"
      ],
      "senses": [
        "visión ciega 10 pies, visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "dracónico"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "dragon_de_bronce_joven",
      "name": "Dragón de bronce joven",
      "size": "Grande",
      "type": "dragón",
      "alignment": "legal bueno",
      "ac": 17,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 142,
        "formula": "15d10 + 60"
      },
      "speed": {
        "walk": "40 pies",
        "swim": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 21,
        "dex": 10,
        "con": 19,
        "int": 14,
        "wis": 13,
        "cha": 17
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 5
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": 2
        },
        {
          "ability": "wis",
          "bonus": 4
        },
        {
          "ability": "cha",
          "bonus": 3
        }
      ],
      "traits": [
        {
          "name": "Anfibio",
          "text": "El dragón puede respirar tanto dentro como fuera del agua."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro. Puede sustituir un ataque por un uso de su aliento repulsor."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +8, alcance 10 pies. Acierto: 16 (2d10 + 5) de daño cortante."
        },
        {
          "name": "Aliento de relámpago (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 15, todas las criaturas en una línea de 60 pies de largo y 5 pies de ancho. Fallo: 49 (9d10) de daño de relámpago. Éxito: la mitad del daño."
        },
        {
          "name": "Aliento repulsor",
          "text": "Tirada de salvación de Fuerza: CD 15, todas las criaturas en un cono de 30 pies. Fallo: el objetivo es empujado hasta 40 pies respecto al dragón en línea recta y tiene el estado de derribado."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "metálico",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 7
        },
        {
          "name": "Perspicacia",
          "bonus": 4
        },
        {
          "name": "Sigilo",
          "bonus": 3
        }
      ],
      "damageImmunities": [
        "relámpago"
      ],
      "senses": [
        "visión ciega 30 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 17"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "8",
      "proficiencyBonus": 3,
      "xp": 3900
    },
    {
      "id": "dragon_de_bronce_adulto",
      "name": "Dragón de bronce adulto",
      "size": "Enorme",
      "type": "dragón",
      "alignment": "legal bueno",
      "ac": 18,
      "initiative": {
        "modifier": 10,
        "score": 20
      },
      "hp": {
        "average": 212,
        "formula": "17d12 + 102"
      },
      "speed": {
        "walk": "40 pies",
        "swim": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 25,
        "dex": 10,
        "con": 23,
        "int": 16,
        "wis": 15,
        "cha": 20
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 7
        },
        {
          "ability": "dex",
          "bonus": 5
        },
        {
          "ability": "con",
          "bonus": 6
        },
        {
          "ability": "int",
          "bonus": 3
        },
        {
          "ability": "wis",
          "bonus": 7
        },
        {
          "ability": "cha",
          "bonus": 5
        }
      ],
      "traits": [
        {
          "name": "Anfibio",
          "text": "El dragón puede respirar tanto dentro como fuera del agua. Resistencia legendaria (3/día o 4/día en la guarida). El dragón puede elegir tener éxito en una tirada de salvación que haya fallado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro. Puede sustituir un ataque por un uso de (A) su aliento repulsor o de (B) su lanzamiento de conjuros para lanzar saeta guía (versión de nivel 2)."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +12, alcance 10 pies. Acierto: 16 (2d8 + 7) de daño cortante más 5 (1d10) de daño de relámpago."
        },
        {
          "name": "Aliento de relámpago (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 19, todas las criaturas en una línea de 90 pies de largo y 5 pies de ancho. Fallo: 55 (10d10) de daño de relámpago. Éxito: la mitad del daño."
        },
        {
          "name": "Aliento repulsor",
          "text": "Tirada de salvación de Fuerza: CD 19, todas las criaturas en un cono de 30 pies. Fallo: el objetivo es empujado hasta 60 pies respecto al dragón en línea recta y tiene el estado de derribado."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El dragón lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 17, +10 a acertar con ataques de conjuro): A voluntad: cambiar de forma (solo forma de bestia o humanoide, no se obtienen puntos de golpe temporales del conjuro y no se requieren concentración ni puntos de golpe temporales para mantener el conjuro), detectar magia, hablar con los animales, saeta guía (versión de nivel 2), taumaturgia 1/día cada uno: detectar pensamientos, respirar bajo el agua"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "metálico",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, el dragón puede emplear un uso para llevar a cabo una de las siguientes acciones. El dragón recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Abalanzarse",
          "text": "El dragón se mueve hasta la mitad de su velocidad y realiza un ataque de desgarro."
        },
        {
          "name": "Luz guía",
          "text": "El dragón utiliza su lanzamiento de conjuros para lanzar saeta guía (versión de nivel 2)."
        },
        {
          "name": "Trueno",
          "text": "Tirada de salvación de Constitución: CD 17, todas las criaturas en una esfera de 20 pies de radio centrada en un punto que el dragón pueda ver a 90 pies o menos. Fallo: 10 (3d6) de daño de trueno y el objetivo tendrá el estado de ensordecido hasta el final de su siguiente turno."
        }
      ],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 12
        },
        {
          "name": "Perspicacia",
          "bonus": 7
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "damageImmunities": [
        "relámpago"
      ],
      "senses": [
        "visión ciega 60 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 22"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "15",
      "proficiencyBonus": 5,
      "xp": 13000,
      "xpText": "13 000 PX o 15 000 en la guarida"
    },
    {
      "id": "dragon_de_bronce_anciano",
      "name": "Dragón de bronce anciano",
      "size": "Gargantuesco",
      "type": "dragón",
      "alignment": "legal bueno",
      "ac": 22,
      "initiative": {
        "modifier": 14,
        "score": 24
      },
      "hp": {
        "average": 444,
        "formula": "24d20 + 192"
      },
      "speed": {
        "walk": "40 pies",
        "swim": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 29,
        "dex": 10,
        "con": 27,
        "int": 18,
        "wis": 17,
        "cha": 25
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 9
        },
        {
          "ability": "dex",
          "bonus": 7
        },
        {
          "ability": "con",
          "bonus": 8
        },
        {
          "ability": "int",
          "bonus": 4
        },
        {
          "ability": "wis",
          "bonus": 10
        },
        {
          "ability": "cha",
          "bonus": 7
        }
      ],
      "traits": [
        {
          "name": "Anfibio",
          "text": "El dragón puede respirar tanto dentro como fuera del agua. Resistencia legendaria (4/día o 5/día en la guarida). El dragón puede elegir tener éxito en una tirada de salvación que haya fallado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro. Puede sustituir un ataque por un uso de (A) su aliento repulsor o de (B) su lanzamiento de conjuros para lanzar saeta guía (versión de nivel 2)."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +16, alcance 15 pies. Acierto: 18 (2d8 + 9) de daño cortante más 9 (2d8) de daño de relámpago."
        },
        {
          "name": "Aliento de relámpago (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 23, todas las criaturas en una línea de 120 pies de largo y 10 pies de ancho. Fallo: 82 (15d10) de daño de relámpago. Éxito: la mitad del daño."
        },
        {
          "name": "Aliento repulsor",
          "text": "Tirada de salvación de Fuerza:"
        },
        {
          "name": "CD 23, todas las criaturas en un cono de 30 pies",
          "text": "Fallo: el objetivo es empujado hasta 60 pies respecto al dragón en línea recta y tiene el estado de derribado."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El dragón lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 22, +14 a acertar con ataques de conjuro): A voluntad: cambiar de forma (solo forma de bestia o humanoide, no se obtienen puntos de golpe temporales del conjuro y no se requieren concentración ni puntos de golpe temporales para mantener el conjuro), detectar magia, hablar con los animales, saeta guía (versión de nivel 2), taumaturgia 1/día cada uno: controlar agua, detectar pensamientos, escudriñar, respirar bajo el agua"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "metálico",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, el dragón puede emplear un uso para llevar a cabo una de las siguientes acciones. El dragón recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Abalanzarse",
          "text": "El dragón se mueve hasta la mitad de su velocidad y realiza un ataque de desgarro."
        },
        {
          "name": "Luz guía",
          "text": "El dragón utiliza su lanzamiento de conjuros para lanzar saeta guía (versión de nivel 2)."
        },
        {
          "name": "Trueno",
          "text": "Tirada de salvación de Constitución: CD 22, todas las criaturas en una esfera de 20 pies de radio centrada en un punto que el dragón pueda ver a 120 pies o menos. Fallo: 13 (3d8) de daño de trueno y el objetivo tendrá el estado de ensordecido hasta el final de su siguiente turno. Dragones de cobre"
        }
      ],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 17
        },
        {
          "name": "Perspicacia",
          "bonus": 10
        },
        {
          "name": "Sigilo",
          "bonus": 7
        }
      ],
      "damageImmunities": [
        "relámpago"
      ],
      "senses": [
        "visión ciega 60 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 27"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "22",
      "proficiencyBonus": 7,
      "xp": 41000,
      "xpText": "41 000 PX o 50 000 en la guarida"
    },
    {
      "id": "cria_de_dragon_de_cobre",
      "name": "Cría de dragón de cobre",
      "size": "Mediano",
      "type": "dragón",
      "alignment": "caótico bueno",
      "ac": 16,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 22,
        "formula": "4d8 + 4"
      },
      "speed": {
        "walk": "30 pies",
        "climb": "30 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 15,
        "dex": 12,
        "con": 13,
        "int": 14,
        "wis": 11,
        "cha": 13
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 2
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 1
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 7 (1d10 + 2) de daño cortante."
        },
        {
          "name": "Aliento ácido (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 11, todas las criaturas en una línea de 20 pies de largo y 5 pies de ancho. Fallo: 18 (4d8) de daño de ácido. Éxito: la mitad del daño."
        },
        {
          "name": "Aliento ralentizador",
          "text": "Tirada de salvación de Constitución: CD 11, todas las criaturas en un cono de 15 pies. Fallo: el objetivo no podrá llevar a cabo reacciones, su velocidad se reducirá a la mitad y podrá realizar una acción o una acción adicional en su turno, pero no ambas. Este efecto durará hasta el final de su siguiente turno."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "metálico",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 4
        },
        {
          "name": "Sigilo",
          "bonus": 3
        }
      ],
      "damageImmunities": [
        "ácido"
      ],
      "senses": [
        "visión ciega 10 pies, visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "dracónico"
      ],
      "cr": "1",
      "proficiencyBonus": 2,
      "xp": 200
    },
    {
      "id": "dragon_de_cobre_joven",
      "name": "Dragón de cobre joven",
      "size": "Grande",
      "type": "dragón",
      "alignment": "caótico bueno",
      "ac": 17,
      "initiative": {
        "modifier": 4,
        "score": 14
      },
      "hp": {
        "average": 119,
        "formula": "14d10 + 42"
      },
      "speed": {
        "walk": "40 pies",
        "climb": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 12,
        "con": 17,
        "int": 16,
        "wis": 13,
        "cha": 15
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 4
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": 3
        },
        {
          "ability": "wis",
          "bonus": 4
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro. Puede sustituir un ataque por un uso de su aliento ralentizador."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 10 pies. Acierto: 15 (2d10 + 4) de daño cortante."
        },
        {
          "name": "Aliento ácido (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 14, todas las criaturas en una línea de 40 pies de largo y 5 pies de ancho. Fallo: 40 (9d8) de daño de ácido. Éxito: la mitad del daño."
        },
        {
          "name": "Aliento ralentizador",
          "text": "Tirada de salvación de Constitución: CD 14, todas las criaturas en un cono de 30 pies. Fallo: el objetivo no podrá llevar a cabo reacciones, su velocidad se reducirá a la mitad y podrá realizar una acción o una acción adicional en su turno, pero no ambas. Este efecto durará hasta el final de su siguiente turno."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "metálico",
      "skills": [
        {
          "name": "Engaño",
          "bonus": 5
        },
        {
          "name": "Percepción",
          "bonus": 7
        },
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "damageImmunities": [
        "ácido"
      ],
      "senses": [
        "visión ciega 30 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 17"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "7",
      "proficiencyBonus": 3,
      "xp": 2900
    },
    {
      "id": "dragon_de_cobre_adulto",
      "name": "Dragón de cobre adulto",
      "size": "Enorme",
      "type": "dragón",
      "alignment": "caótico bueno",
      "ac": 18,
      "initiative": {
        "modifier": 11,
        "score": 21
      },
      "hp": {
        "average": 184,
        "formula": "16d12 + 80"
      },
      "speed": {
        "walk": "40 pies",
        "climb": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 23,
        "dex": 12,
        "con": 21,
        "int": 18,
        "wis": 15,
        "cha": 18
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 6
        },
        {
          "ability": "dex",
          "bonus": 6
        },
        {
          "ability": "con",
          "bonus": 5
        },
        {
          "ability": "int",
          "bonus": 4
        },
        {
          "ability": "wis",
          "bonus": 7
        },
        {
          "ability": "cha",
          "bonus": 4
        }
      ],
      "traits": [
        {
          "name": "Resistencia legendaria (3/día o 4/día en la guarida)",
          "text": "El dragón puede elegir tener éxito en una tirada de salvación que haya fallado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro. Puede sustituir un ataque por un uso de (A) su aliento ralentizador o de (B) su lanzamiento de conjuros para lanzar clavo mental (versión de nivel 4)."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +11, alcance 10 pies. Acierto: 17 (2d10 + 6) de daño cortante más 4 (1d8) de daño de ácido."
        },
        {
          "name": "Aliento ácido (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 18, todas las criaturas en una línea de 60 pies de largo y 5 pies de ancho. Fallo: 54 (12d8) de daño de ácido. Éxito: la mitad del daño."
        },
        {
          "name": "Aliento ralentizador",
          "text": "Tirada de salvación de Constitución: CD 18, todas las criaturas en un cono de 60 pies. Fallo: el objetivo no podrá llevar a cabo reacciones, su velocidad se reducirá a la mitad y podrá realizar una acción o una acción adicional en su turno, pero no ambas. Este efecto durará hasta el final de su siguiente turno."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El dragón lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 17): A voluntad: cambiar de forma (solo forma de bestia o humanoide, no se obtienen puntos de golpe temporales del conjuro y no se requieren concentración ni puntos de golpe temporales para mantener el conjuro), clavo mental (versión de nivel 4), detectar magia, ilusión menor 1/día cada uno: imagen mayor, restablecimiento mayor"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "metálico",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, el dragón puede emplear un uso para llevar a cabo una de las siguientes acciones. El dragón recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Abalanzarse",
          "text": "El dragón se mueve hasta la mitad de su velocidad y realiza un ataque de desgarro."
        },
        {
          "name": "Magia de la risa",
          "text": "Tirada de salvación de Carisma: CD 17, una criatura que el dragón pueda ver a 90 pies o menos. Fallo: 24 (7d6) de daño psíquico. Hasta el final de su siguiente turno, el objetivo tirará 1d6 cada vez que haga una prueba de característica o tirada de ataque y restará el resultado a la prueba con d20. Fallo o éxito: el dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        },
        {
          "name": "Sacudida mental",
          "text": "El dragón utiliza su lanzamiento de conjuros para lanzar clavo mental (versión de nivel 4). El dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        }
      ],
      "skills": [
        {
          "name": "Engaño",
          "bonus": 9
        },
        {
          "name": "Percepción",
          "bonus": 12
        },
        {
          "name": "Sigilo",
          "bonus": 6
        }
      ],
      "damageImmunities": [
        "ácido"
      ],
      "senses": [
        "visión ciega 60 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 22"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "14",
      "proficiencyBonus": 5,
      "xp": 11500,
      "xpText": "11 500 PX o 13 000 en la guarida"
    },
    {
      "id": "dragon_de_cobre_anciano",
      "name": "Dragón de cobre anciano",
      "size": "Gargantuesco",
      "type": "dragón",
      "alignment": "caótico bueno",
      "ac": 21,
      "initiative": {
        "modifier": 15,
        "score": 25
      },
      "hp": {
        "average": 367,
        "formula": "21d20 + 147"
      },
      "speed": {
        "walk": "40 pies",
        "climb": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 27,
        "dex": 12,
        "con": 25,
        "int": 20,
        "wis": 17,
        "cha": 22
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 8
        },
        {
          "ability": "dex",
          "bonus": 8
        },
        {
          "ability": "con",
          "bonus": 7
        },
        {
          "ability": "int",
          "bonus": 5
        },
        {
          "ability": "wis",
          "bonus": 10
        },
        {
          "ability": "cha",
          "bonus": 6
        }
      ],
      "traits": [
        {
          "name": "Resistencia legendaria (4/día o 5/día en la guarida)",
          "text": "El dragón puede elegir tener éxito en una tirada de salvación que haya fallado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro. Puede sustituir un ataque por un uso de (A) su aliento ralentizador o de (B) su lanzamiento de conjuros para lanzar clavo mental (versión de nivel 5)."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +15, alcance 15 pies. Acierto: 19 (2d10 + 8) de daño cortante más 9 (2d8) de daño de ácido."
        },
        {
          "name": "Aliento ácido (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 22, todas las criaturas en una línea de 90 pies de largo y 10 pies de ancho. Fallo: 63 (14d8) de daño de ácido. Éxito: la mitad del daño."
        },
        {
          "name": "Aliento ralentizador",
          "text": "Tirada de salvación de Constitución: CD 22, todas las criaturas en un cono de 90 pies. Fallo: el objetivo no podrá llevar a cabo reacciones, su velocidad se reducirá a la mitad y podrá realizar una acción o una acción adicional en su turno, pero no ambas. Este efecto durará hasta el final de su siguiente turno."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El dragón lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 21): A voluntad: cambiar de forma (solo forma de bestia o humanoide, no se obtienen puntos de golpe temporales del conjuro y no se requieren concentración ni puntos de golpe temporales para mantener el conjuro), clavo mental (versión de nivel 5), detectar magia, ilusión menor 1/día cada uno: imagen mayor, proyectar imagen, restablecimiento mayor"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "metálico",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, el dragón puede emplear un uso para llevar a cabo una de las siguientes acciones. El dragón recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Abalanzarse",
          "text": "El dragón se mueve hasta la mitad de su velocidad y realiza un ataque de desgarro."
        },
        {
          "name": "Magia de la risa",
          "text": "Tirada de salvación de Carisma: CD 21, una criatura que el dragón pueda ver a 120 pies o menos. Fallo: 31 (9d6) de daño psíquico. Hasta el final de su siguiente turno, el objetivo tirará 1d8 cada vez que haga una prueba de característica o tirada de ataque y restará el resultado a la prueba con d20. Fallo o éxito: el dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        },
        {
          "name": "Sacudida mental",
          "text": "El dragón utiliza su lanzamiento de conjuros para lanzar clavo mental (versión de nivel 5). El dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno. Dragones de oro"
        }
      ],
      "skills": [
        {
          "name": "Engaño",
          "bonus": 13
        },
        {
          "name": "Percepción",
          "bonus": 17
        },
        {
          "name": "Sigilo",
          "bonus": 8
        }
      ],
      "damageImmunities": [
        "ácido"
      ],
      "senses": [
        "visión ciega 60 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 27"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "21",
      "proficiencyBonus": 7,
      "xp": 33000,
      "xpText": "33 000 PX o 41 000 en la guarida"
    },
    {
      "id": "cria_de_dragon_de_oro",
      "name": "Cría de dragón de oro",
      "size": "Mediano",
      "type": "dragón",
      "alignment": "legal bueno",
      "ac": 17,
      "initiative": {
        "modifier": 4,
        "score": 14
      },
      "hp": {
        "average": 60,
        "formula": "8d8 + 24"
      },
      "speed": {
        "walk": "30 pies",
        "swim": "30 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 14,
        "con": 17,
        "int": 14,
        "wis": 11,
        "cha": 16
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 4
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": 2
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 3
        }
      ],
      "traits": [
        {
          "name": "Anfibio",
          "text": "El dragón puede respirar tanto dentro como fuera del agua."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza dos ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 9 (1d10 + 4) de daño cortante."
        },
        {
          "name": "Aliento de fuego (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 13, todas las criaturas en un cono de 15 pies. Fallo: 22 (4d10) de daño de fuego. Éxito: la mitad del daño."
        },
        {
          "name": "Aliento debilitador",
          "text": "Tirada de salvación de Fuerza: CD 13, todas las criaturas que no estén afectadas ya por este aliento en un cono de 15 pies. Fallo: el objetivo tendrá desventaja en las pruebas con d20 basadas en la Fuerza y restará 2 (1d4) a sus tiradas de daño. Repetirá la tirada de salvación al final de cada uno de sus turnos y, si tiene éxito, se librará del efecto. Tras 1 minuto, tendrá éxito automáticamente."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "metálico",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 4
        },
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "damageImmunities": [
        "fuego"
      ],
      "senses": [
        "visión ciega 10 pies, visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "dracónico"
      ],
      "cr": "3",
      "proficiencyBonus": 2,
      "xp": 700
    },
    {
      "id": "dragon_de_oro_joven",
      "name": "Dragón de oro joven",
      "size": "Grande",
      "type": "dragón",
      "alignment": "legal bueno",
      "ac": 18,
      "initiative": {
        "modifier": 6,
        "score": 16
      },
      "hp": {
        "average": 178,
        "formula": "17d10 + 85"
      },
      "speed": {
        "walk": "40 pies",
        "swim": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 23,
        "dex": 14,
        "con": 21,
        "int": 16,
        "wis": 13,
        "cha": 20
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 6
        },
        {
          "ability": "dex",
          "bonus": 6
        },
        {
          "ability": "con",
          "bonus": 5
        },
        {
          "ability": "int",
          "bonus": 3
        },
        {
          "ability": "wis",
          "bonus": 5
        },
        {
          "ability": "cha",
          "bonus": 5
        }
      ],
      "traits": [
        {
          "name": "Anfibio",
          "text": "El dragón puede respirar tanto dentro como fuera del agua."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro. Puede sustituir un ataque por un uso de su aliento debilitador."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +10, alcance 10 pies. Acierto: 17 (2d10 + 6) de daño cortante."
        },
        {
          "name": "Aliento de fuego (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 17, todas las criaturas en un cono de 30 pies."
        },
        {
          "name": "Fallo: 55 (10d10) de daño de fuego",
          "text": "Éxito: la mitad del daño."
        },
        {
          "name": "Aliento debilitador",
          "text": "Tirada de salvación de Fuerza: CD 17, todas las criaturas que no estén afectadas ya por este aliento en un cono de 30 pies. Fallo: el objetivo tendrá desventaja en las pruebas con d20 basadas en la Fuerza y restará 3 (1d6) a sus tiradas de daño. Repetirá la tirada de salvación al final de cada uno de sus turnos y, si tiene éxito, se librará del efecto. Tras 1 minuto, tendrá éxito automáticamente."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "metálico",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 9
        },
        {
          "name": "Perspicacia",
          "bonus": 5
        },
        {
          "name": "Persuasión",
          "bonus": 9
        },
        {
          "name": "Sigilo",
          "bonus": 6
        }
      ],
      "damageImmunities": [
        "fuego"
      ],
      "senses": [
        "visión ciega 30 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 19"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "10",
      "proficiencyBonus": 4,
      "xp": 5900
    },
    {
      "id": "dragon_de_oro_adulto",
      "name": "Dragón de oro adulto",
      "size": "Enorme",
      "type": "dragón",
      "alignment": "legal bueno",
      "ac": 19,
      "initiative": {
        "modifier": 14,
        "score": 24
      },
      "hp": {
        "average": 243,
        "formula": "18d12 + 126"
      },
      "speed": {
        "walk": "40 pies",
        "swim": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 27,
        "dex": 14,
        "con": 25,
        "int": 16,
        "wis": 15,
        "cha": 24
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 8
        },
        {
          "ability": "dex",
          "bonus": 8
        },
        {
          "ability": "con",
          "bonus": 7
        },
        {
          "ability": "int",
          "bonus": 3
        },
        {
          "ability": "wis",
          "bonus": 8
        },
        {
          "ability": "cha",
          "bonus": 7
        }
      ],
      "traits": [
        {
          "name": "Anfibio",
          "text": "El dragón puede respirar tanto dentro como fuera del agua. Resistencia legendaria (3/día o 4/día en la guarida). El dragón puede elegir tener éxito en una tirada de salvación que haya fallado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro. Puede sustituir un ataque por un uso de (A) su lanzamiento de conjuros para lanzar saeta guía (versión de nivel 2) o de (B) su aliento debilitador."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +14, alcance 10 pies. Acierto: 17 (2d8 + 8) de daño cortante más 4 (1d8) de daño de fuego."
        },
        {
          "name": "Aliento de fuego (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 21, todas las criaturas en un cono de 60 pies. Fallo: 66 (12d10) de daño de fuego. Éxito: la mitad del daño."
        },
        {
          "name": "Aliento debilitador",
          "text": "Tirada de salvación de Fuerza: CD 21, todas las criaturas que no estén afectadas ya por este aliento en un cono de 60 pies. Fallo: el objetivo tendrá desventaja en las pruebas con d20 basadas en la Fuerza y restará 3 (1d6) a sus tiradas de daño. Repetirá la tirada de salvación al final de cada uno de sus turnos y, si tiene éxito, se librará del efecto. Tras 1 minuto, tendrá éxito automáticamente."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El dragón lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 21, +13 a acertar con ataques de conjuro): A voluntad: cambiar de forma (solo forma de bestia o humanoide, no se obtienen puntos de golpe temporales del conjuro y no se requieren concentración ni puntos de golpe temporales para mantener el conjuro), detectar magia, saeta guía (versión de nivel 2) 1/día cada uno: golpe flamígero, zona de la verdad"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "metálico",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, el dragón puede emplear un uso para llevar a cabo una de las siguientes acciones. El dragón recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Abalanzarse",
          "text": "El dragón se mueve hasta la mitad de su velocidad y realiza un ataque de desgarro."
        },
        {
          "name": "Desterrar",
          "text": "Tirada de salvación de Carisma: CD 21, una criatura que el dragón pueda ver a 120 pies o menos. Fallo: 10 (3d6) de daño de fuerza y el objetivo tendrá el estado de incapacitado y será transportado a un semiplano inofensivo hasta el principio del siguiente turno del dragón, momento en el que reaparecerá en un espacio sin ocupar a elección del dragón a 120 pies o menos de este. Fallo o éxito: el dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        },
        {
          "name": "Luz guía",
          "text": "El dragón utiliza su lanzamiento de conjuros para lanzar saeta guía (versión de nivel 2)."
        }
      ],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 14
        },
        {
          "name": "Perspicacia",
          "bonus": 8
        },
        {
          "name": "Persuasión",
          "bonus": 13
        },
        {
          "name": "Sigilo",
          "bonus": 8
        }
      ],
      "damageImmunities": [
        "fuego"
      ],
      "senses": [
        "visión ciega 60 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 24"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "17",
      "proficiencyBonus": 6,
      "xp": 18000,
      "xpText": "18 000 PX o 20 000 en la guarida"
    },
    {
      "id": "dragon_de_oro_anciano",
      "name": "Dragón de oro anciano",
      "size": "Gargantuesco",
      "type": "dragón",
      "alignment": "legal bueno",
      "ac": 22,
      "initiative": {
        "modifier": 16,
        "score": 26
      },
      "hp": {
        "average": 546,
        "formula": "28d20 + 252"
      },
      "speed": {
        "walk": "40 pies",
        "swim": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 30,
        "dex": 14,
        "con": 29,
        "int": 18,
        "wis": 17,
        "cha": 28
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 10
        },
        {
          "ability": "dex",
          "bonus": 9
        },
        {
          "ability": "con",
          "bonus": 9
        },
        {
          "ability": "int",
          "bonus": 4
        },
        {
          "ability": "wis",
          "bonus": 10
        },
        {
          "ability": "cha",
          "bonus": 9
        }
      ],
      "traits": [
        {
          "name": "Anfibio",
          "text": "El dragón puede respirar tanto dentro como fuera del agua. Resistencia legendaria (4/día o 5/día en la guarida). El dragón puede elegir tener éxito en una tirada de salvación que haya fallado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro. Puede sustituir un ataque por un uso de (A) su lanzamiento de conjuros para lanzar saeta guía (versión de nivel 4) o de (B) su aliento debilitador."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +17 a acertar, alcance 15 pies. Acierto: 19 (2d8 + 10) de daño cortante más 9 (2d8) de daño de fuego."
        },
        {
          "name": "Aliento de fuego (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 24, todas las criaturas en un cono de 90 pies. Fallo: 71 (13d10) de daño de fuego. Éxito: la mitad del daño."
        },
        {
          "name": "Aliento debilitador",
          "text": "Tirada de salvación de Fuerza: CD 24, todas las criaturas que no estén afectadas ya por este aliento en un cono de 90 pies. Fallo: el objetivo tendrá desventaja en las pruebas con d20 basadas en la Fuerza y restará 5 (1d10) a sus tiradas de daño. Repetirá la tirada de salvación al final de cada uno de sus turnos y, si tiene éxito, se librará del efecto. Tras 1 minuto, tendrá éxito automáticamente."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El dragón lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 24, +16 a acertar con ataques de conjuro): A voluntad: cambiar de forma (solo forma de bestia o humanoide, no se obtienen puntos de golpe temporales del conjuro y no se requieren concentración ni puntos de golpe temporales para mantener el conjuro), detectar magia, saeta guía (versión de nivel 4) 1/día cada uno: golpe flamígero (versión de nivel 6), palabra de regreso, zona de la verdad"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "metálico",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, el dragón puede emplear un uso para llevar a cabo una de las siguientes acciones. El dragón recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Abalanzarse",
          "text": "El dragón se mueve hasta la mitad de su velocidad y realiza un ataque de desgarro."
        },
        {
          "name": "Desterrar",
          "text": "Tirada de salvación de Carisma: CD 24, una criatura que el dragón pueda ver a 120 pies o menos. Fallo: 24 (7d6) de daño de fuerza y el objetivo tendrá el estado de incapacitado y será transportado a un semiplano inofensivo hasta el principio del siguiente turno del dragón, momento en el que reaparecerá en un espacio sin ocupar a elección del dragón a 120 pies o menos de este. Fallo o éxito: el dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        },
        {
          "name": "Luz guía",
          "text": "El dragón utiliza su lanzamiento de conjuros para lanzar saeta guía (versión de nivel 4). Dragones de oropel"
        }
      ],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 17
        },
        {
          "name": "Perspicacia",
          "bonus": 10
        },
        {
          "name": "Persuasión",
          "bonus": 16
        },
        {
          "name": "Sigilo",
          "bonus": 9
        }
      ],
      "damageImmunities": [
        "fuego"
      ],
      "senses": [
        "visión ciega 60 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 27"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "24",
      "proficiencyBonus": 7,
      "xp": 62000,
      "xpText": "62 000 PX o 75 000 en la guarida"
    },
    {
      "id": "cria_de_dragon_de_oropel",
      "name": "Cría de dragón de oropel",
      "size": "Mediano",
      "type": "dragón",
      "alignment": "caótico bueno",
      "ac": 15,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 22,
        "formula": "4d8 + 4"
      },
      "speed": {
        "walk": "30 pies",
        "burrow": "15 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 15,
        "dex": 10,
        "con": 13,
        "int": 10,
        "wis": 11,
        "cha": 13
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 1
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 7 (1d10 + 2) de daño cortante."
        },
        {
          "name": "Aliento de fuego (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 11, todas las criaturas en una línea de 20 pies de largo y 5 pies de ancho. Fallo: 14 (4d6) de daño de fuego. Éxito: la mitad del daño."
        },
        {
          "name": "Aliento somnífero",
          "text": "Tirada de salvación de Constitución:"
        },
        {
          "name": "CD 11, todas las criaturas en un cono de 15 pies",
          "text": "Fallo: el objetivo tendrá el estado de incapacitado hasta el final de su siguiente turno, momento en el que repetirá la tirada de salvación. Segundo fallo: el objetivo tendrá el estado de inconsciente durante 1 minuto. Este efecto acabará si el objetivo sufre daño o si una criatura que se encuentre a 5 pies o menos de él lleva a cabo una acción para despertarlo."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "metálico",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 4
        },
        {
          "name": "Sigilo",
          "bonus": 2
        }
      ],
      "damageImmunities": [
        "fuego"
      ],
      "senses": [
        "visión ciega 10 pies, visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "dracónico"
      ],
      "cr": "1",
      "proficiencyBonus": 2,
      "xp": 200
    },
    {
      "id": "dragon_de_oropel_joven",
      "name": "Dragón de oropel joven",
      "size": "Grande",
      "type": "dragón",
      "alignment": "caótico bueno",
      "ac": 17,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 110,
        "formula": "13d10 + 39"
      },
      "speed": {
        "walk": "40 pies",
        "burrow": "20 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 10,
        "con": 17,
        "int": 12,
        "wis": 11,
        "cha": 15
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 3
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro. Puede sustituir dos ataques por un uso de su aliento somnífero."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 10 pies. Acierto: 15 (2d10 + 4) de daño cortante."
        },
        {
          "name": "Aliento de fuego (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 14, todas las criaturas en una línea de 40 pies de largo y 5 pies de ancho. Fallo: 38 (11d6) de daño de fuego. Éxito: la mitad del daño."
        },
        {
          "name": "Aliento somnífero",
          "text": "Tirada de salvación de Constitución:"
        },
        {
          "name": "CD 14, todas las criaturas en un cono de 30 pies",
          "text": "Fallo: el objetivo tendrá el estado de incapacitado hasta el final de su siguiente turno, momento en el que repetirá la tirada de salvación. Segundo fallo: el objetivo tendrá el estado de inconsciente durante 1 minuto. Este efecto acabará si el objetivo sufre daño o si una criatura que se encuentre a 5 pies o menos de él lleva a cabo una acción para despertarlo."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "metálico",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 6
        },
        {
          "name": "Persuasión",
          "bonus": 5
        },
        {
          "name": "Sigilo",
          "bonus": 3
        }
      ],
      "damageImmunities": [
        "fuego"
      ],
      "senses": [
        "visión ciega 30 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 16"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "6",
      "proficiencyBonus": 3,
      "xp": 2300
    },
    {
      "id": "dragon_de_oropel_adulto",
      "name": "Dragón de oropel adulto",
      "size": "Enorme",
      "type": "dragón",
      "alignment": "caótico bueno",
      "ac": 18,
      "initiative": {
        "modifier": 10,
        "score": 20
      },
      "hp": {
        "average": 172,
        "formula": "15d12 + 75"
      },
      "speed": {
        "walk": "40 pies",
        "burrow": "30 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 23,
        "dex": 10,
        "con": 21,
        "int": 14,
        "wis": 13,
        "cha": 17
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 6
        },
        {
          "ability": "dex",
          "bonus": 5
        },
        {
          "ability": "con",
          "bonus": 5
        },
        {
          "ability": "int",
          "bonus": 2
        },
        {
          "ability": "wis",
          "bonus": 6
        },
        {
          "ability": "cha",
          "bonus": 3
        }
      ],
      "traits": [
        {
          "name": "Resistencia legendaria (3/día o 4/día en la guarida)",
          "text": "El dragón puede elegir tener éxito en una tirada de salvación que haya fallado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro. Puede sustituir un ataque por un uso de (A) su aliento somnífero o de (B) su lanzamiento de conjuros para lanzar rayo abrasador."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +11, alcance 10 pies. Acierto: 17 (2d10 + 6) de daño cortante más 4 (1d8) de daño de fuego."
        },
        {
          "name": "Aliento de fuego (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 18, todas las criaturas en una línea de 60 pies de largo y 5 pies de ancho. Fallo: 45 (10d8) de daño de fuego. Éxito: la mitad del daño."
        },
        {
          "name": "Aliento somnífero",
          "text": "Tirada de salvación de Constitución:"
        },
        {
          "name": "CD 18, todas las criaturas en un cono de 60 pies",
          "text": "Fallo: el objetivo tendrá el estado de incapacitado hasta el final de su siguiente turno, momento en el que repetirá la tirada de salvación. Segundo fallo: el objetivo tendrá el estado de inconsciente durante 10 minutos. Este efecto acabará si el objetivo sufre daño o si una criatura que se encuentre a 5 pies o menos de él lleva a cabo una acción para despertarlo."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El dragón lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 16): A voluntad: cambiar de forma (solo forma de bestia o humanoide, no se obtienen puntos de golpe temporales del conjuro y no se requieren concentración ni puntos de golpe temporales para mantener el conjuro), detectar magia, hablar con los animales, ilusión menor, rayo abrasador 1/día cada uno: controlar el clima, detectar pensamientos"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "metálico",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, el dragón puede emplear un uso para llevar a cabo una de las siguientes acciones. El dragón recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Abalanzarse",
          "text": "El dragón se mueve hasta la mitad de su velocidad y realiza un ataque de desgarro."
        },
        {
          "name": "Arena abrasante",
          "text": "Tirada de salvación de Destreza: CD 16, una criatura que el dragón pueda ver a 120 pies o menos. Fallo: 27 (6d8) de daño de fuego y la velocidad del objetivo se reducirá a la mitad hasta el final de su siguiente turno. Fallo o éxito: el dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        },
        {
          "name": "Luz calcinadora",
          "text": "El dragón utiliza su lanzamiento de conjuros para lanzar rayo abrasador."
        }
      ],
      "skills": [
        {
          "name": "Historia",
          "bonus": 7
        },
        {
          "name": "Percepción",
          "bonus": 11
        },
        {
          "name": "Persuasión",
          "bonus": 8
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "damageImmunities": [
        "fuego"
      ],
      "senses": [
        "visión ciega 60 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 21"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "13",
      "proficiencyBonus": 5,
      "xp": 10000,
      "xpText": "10 000 PX u 11 500 en la guarida"
    },
    {
      "id": "dragon_de_oropel_anciano",
      "name": "Dragón de oropel anciano",
      "size": "Gargantuesco",
      "type": "dragón",
      "alignment": "caótico bueno",
      "ac": 20,
      "initiative": {
        "modifier": 12,
        "score": 22
      },
      "hp": {
        "average": 332,
        "formula": "19d20 + 133"
      },
      "speed": {
        "walk": "40 pies",
        "burrow": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 27,
        "dex": 10,
        "con": 25,
        "int": 16,
        "wis": 15,
        "cha": 22
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 8
        },
        {
          "ability": "dex",
          "bonus": 6
        },
        {
          "ability": "con",
          "bonus": 7
        },
        {
          "ability": "int",
          "bonus": 3
        },
        {
          "ability": "wis",
          "bonus": 8
        },
        {
          "ability": "cha",
          "bonus": 6
        }
      ],
      "traits": [
        {
          "name": "Resistencia legendaria (4/día o 5/día en la guarida)",
          "text": "El dragón puede elegir tener éxito en una tirada de salvación que haya fallado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro. Puede sustituir un ataque por un uso de (A) su aliento somnífero o de (B) su lanzamiento de conjuros para lanzar rayo abrasador (versión de nivel 3)."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +14, alcance 15 pies. Acierto: 19 (2d10 + 8) de daño cortante más 7 (2d6) de daño de fuego."
        },
        {
          "name": "Aliento de fuego (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 21, todas las criaturas en una línea de 90 pies de largo y 5 pies de ancho. Fallo: 58 (13d8) de daño de fuego. Éxito: la mitad del daño."
        },
        {
          "name": "Aliento somnífero",
          "text": "Tirada de salvación de Constitución:"
        },
        {
          "name": "CD 21, todas las criaturas en un cono de 90 pies",
          "text": "Fallo: el objetivo tendrá el estado de incapacitado hasta el final de su siguiente turno, momento en el que repetirá la tirada de salvación. Segundo fallo: el objetivo tendrá el estado de inconsciente durante 10 minutos. Este efecto acabará si el objetivo sufre daño o si una criatura que se encuentre a 5 pies o menos de él lleva a cabo una acción para despertarlo."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El dragón lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 20): A voluntad: cambiar de forma (solo forma de bestia o humanoide, no se obtienen puntos de golpe temporales del conjuro y no se requieren concentración ni puntos de golpe temporales para mantener el conjuro), detectar magia, hablar con los animales, ilusión menor, rayo abrasador (versión de nivel 3) 1/día cada uno: controlar el clima, detectar pensamientos"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "metálico",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, el dragón puede emplear un uso para llevar a cabo una de las siguientes acciones. El dragón recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Abalanzarse",
          "text": "El dragón se mueve hasta la mitad de su velocidad y realiza un ataque de desgarro."
        },
        {
          "name": "Arena abrasante",
          "text": "Tirada de salvación de Destreza: CD 20, una criatura que el dragón pueda ver a 120 pies o menos. Fallo: 36 (8d8) de daño de fuego y la velocidad del objetivo se reducirá a la mitad hasta el final de su siguiente turno. Fallo o éxito: el dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        },
        {
          "name": "Luz calcinadora",
          "text": "El dragón utiliza su lanzamiento de conjuros para lanzar rayo abrasador (versión de nivel 3). Dragones de plata"
        }
      ],
      "skills": [
        {
          "name": "Historia",
          "bonus": 9
        },
        {
          "name": "Percepción",
          "bonus": 14
        },
        {
          "name": "Persuasión",
          "bonus": 12
        },
        {
          "name": "Sigilo",
          "bonus": 6
        }
      ],
      "damageImmunities": [
        "fuego"
      ],
      "senses": [
        "visión ciega 60 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 24"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "20",
      "proficiencyBonus": 6,
      "xp": 25000,
      "xpText": "25 000 PX o 33 000 en la guarida"
    },
    {
      "id": "cria_de_dragon_de_plata",
      "name": "Cría de dragón de plata",
      "size": "Mediano",
      "type": "dragón",
      "alignment": "legal bueno",
      "ac": 17,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 45,
        "formula": "6d8 + 18"
      },
      "speed": {
        "walk": "30 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 10,
        "con": 17,
        "int": 12,
        "wis": 11,
        "cha": 15
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza dos ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 9 (1d10 + 4) de daño perforante."
        },
        {
          "name": "Aliento gélido (recarga 5–6)",
          "text": "Tirada de salvación de Constitución: CD 13, todas las criaturas en un cono de 15 pies. Fallo: 18 (4d8) de daño de frío. Éxito: la mitad del daño."
        },
        {
          "name": "Aliento paralizante",
          "text": "Tirada de salvación de Constitución: CD 13, todas las criaturas en un cono de 15 pies. Primer fallo: el objetivo tendrá el estado de incapacitado hasta el final de su siguiente turno, momento en el que repetirá la tirada de salvación. Segundo fallo: el objetivo tendrá el estado de paralizado y repetirá la tirada de salvación al final de cada uno de sus turnos. Si tiene éxito, se librará del efecto. Tras 1 minuto, tendrá éxito automáticamente."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "metálico",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 4
        },
        {
          "name": "Sigilo",
          "bonus": 2
        }
      ],
      "damageImmunities": [
        "frío"
      ],
      "senses": [
        "visión ciega 10 pies, visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "dracónico"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "dragon_de_plata_joven",
      "name": "Dragón de plata joven",
      "size": "Grande",
      "type": "dragón",
      "alignment": "legal bueno",
      "ac": 18,
      "initiative": {
        "modifier": 4,
        "score": 14
      },
      "hp": {
        "average": 168,
        "formula": "16d10 + 80"
      },
      "speed": {
        "walk": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 23,
        "dex": 10,
        "con": 21,
        "int": 14,
        "wis": 11,
        "cha": 19
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 6
        },
        {
          "ability": "dex",
          "bonus": 4
        },
        {
          "ability": "con",
          "bonus": 5
        },
        {
          "ability": "int",
          "bonus": 2
        },
        {
          "ability": "wis",
          "bonus": 4
        },
        {
          "ability": "cha",
          "bonus": 4
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro. Puede sustituir un ataque por un uso de su aliento paralizante."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +10, alcance 10 pies. Acierto: 15 (2d8 + 6) de daño cortante."
        },
        {
          "name": "Aliento gélido (recarga 5–6)",
          "text": "Tirada de salvación de Constitución: CD 17, todas las criaturas en un cono de 30 pies. Fallo: 49 (11d8) de daño de frío. Éxito: la mitad del daño."
        },
        {
          "name": "Aliento paralizante",
          "text": "Tirada de salvación de Constitución: CD 17, todas las criaturas en un cono de 30 pies. Primer fallo: el objetivo tendrá el estado de incapacitado hasta el final de su siguiente turno, momento en el que repetirá la tirada de salvación. Segundo fallo: el objetivo tendrá el estado de paralizado y repetirá la tirada de salvación al final de cada uno de sus turnos. Si tiene éxito, se librará del efecto. Tras 1 minuto, tendrá éxito automáticamente."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "metálico",
      "skills": [
        {
          "name": "Historia",
          "bonus": 6
        },
        {
          "name": "Percepción",
          "bonus": 8
        },
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "damageImmunities": [
        "frío"
      ],
      "senses": [
        "visión ciega 30 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 18"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "9",
      "proficiencyBonus": 4,
      "xp": 5000
    },
    {
      "id": "dragon_de_plata_adulto",
      "name": "Dragón de plata adulto",
      "size": "Enorme",
      "type": "dragón",
      "alignment": "legal bueno",
      "ac": 19,
      "initiative": {
        "modifier": 10,
        "score": 20
      },
      "hp": {
        "average": 216,
        "formula": "16d12 + 112"
      },
      "speed": {
        "walk": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 27,
        "dex": 10,
        "con": 25,
        "int": 16,
        "wis": 13,
        "cha": 22
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 8
        },
        {
          "ability": "dex",
          "bonus": 5
        },
        {
          "ability": "con",
          "bonus": 7
        },
        {
          "ability": "int",
          "bonus": 3
        },
        {
          "ability": "wis",
          "bonus": 6
        },
        {
          "ability": "cha",
          "bonus": 6
        }
      ],
      "traits": [
        {
          "name": "Resistencia legendaria (3/día o 4/día en la guarida)",
          "text": "El dragón puede elegir tener éxito en una tirada de salvación que haya fallado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro. Puede sustituir un ataque por un uso de (A) su aliento paralizante o de (B) su lanzamiento de conjuros para lanzar cuchillo de hielo."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +13, alcance 10 pies. Acierto: 17 (2d8 + 8) de daño cortante más 4 (1d8) de daño de frío."
        },
        {
          "name": "Aliento gélido (recarga 5–6)",
          "text": "Tirada de salvación de Constitución: CD 20, todas las criaturas en un cono de 60 pies. Fallo: 54 (12d8) de daño de frío. Éxito: la mitad del daño."
        },
        {
          "name": "Aliento paralizante",
          "text": "Tirada de salvación de Constitución: CD 20, todas las criaturas en un cono de 60 pies. Primer fallo: el objetivo tendrá el estado de incapacitado hasta el final de su siguiente turno, momento en el que repetirá la tirada de salvación. Segundo fallo: el objetivo tendrá el estado de paralizado y repetirá la tirada de salvación al final de cada uno de sus turnos. Si tiene éxito, se librará del efecto. Tras 1 minuto, tendrá éxito automáticamente."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El dragón lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 19, +11 a acertar con ataques de conjuro): A voluntad: cambiar de forma (solo forma de bestia o humanoide, no se obtienen puntos de golpe temporales del conjuro y no se requieren concentración ni puntos de golpe temporales para mantener el conjuro), cuchillo de hielo, detectar magia, inmovilizar monstruo 1/día cada uno: tormenta de hielo (versión de nivel 5), zona de la verdad"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "metálico",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, el dragón puede emplear un uso para llevar a cabo una de las siguientes acciones. El dragón recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Abalanzarse",
          "text": "El dragón se mueve hasta la mitad de su velocidad y realiza un ataque de desgarro."
        },
        {
          "name": "Congelar",
          "text": "El dragón utiliza su lanzamiento de conjuros para lanzar inmovilizar monstruo. El dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        },
        {
          "name": "Vendaval helado",
          "text": "Tirada de salvación de Destreza: CD 19, todas las criaturas en una línea de 60 pies de largo y 10 pies de ancho. Fallo: 14 (4d6) de daño de frío y el objetivo es empujado hasta 30 pies respecto al dragón en línea recta. Éxito: solo la mitad del daño. Fallo o éxito: el dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        }
      ],
      "skills": [
        {
          "name": "Historia",
          "bonus": 8
        },
        {
          "name": "Percepción",
          "bonus": 11
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "damageImmunities": [
        "frío"
      ],
      "senses": [
        "visión ciega 60 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 21"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "16",
      "proficiencyBonus": 5,
      "xp": 15000,
      "xpText": "15 000 PX o 18 000 en la guarida"
    },
    {
      "id": "dragon_de_plata_anciano",
      "name": "Dragón de plata anciano",
      "size": "Gargantuesco",
      "type": "dragón",
      "alignment": "legal bueno",
      "ac": 22,
      "initiative": {
        "modifier": 14,
        "score": 24
      },
      "hp": {
        "average": 468,
        "formula": "24d20 + 216"
      },
      "speed": {
        "walk": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 30,
        "dex": 10,
        "con": 29,
        "int": 18,
        "wis": 15,
        "cha": 26
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 10
        },
        {
          "ability": "dex",
          "bonus": 7
        },
        {
          "ability": "con",
          "bonus": 9
        },
        {
          "ability": "int",
          "bonus": 4
        },
        {
          "ability": "wis",
          "bonus": 9
        },
        {
          "ability": "cha",
          "bonus": 8
        }
      ],
      "traits": [
        {
          "name": "Resistencia legendaria (4/día o 5/día en la guarida)",
          "text": "El dragón puede elegir tener éxito en una tirada de salvación que haya fallado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro. Puede sustituir un ataque por un uso de (A) su aliento paralizante o de (B) su lanzamiento de conjuros para lanzar cuchillo de hielo (versión de nivel 2)."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +17, alcance 15 pies. Acierto: 19 (2d8 + 10) de daño cortante más 9 (2d8) de daño de frío."
        },
        {
          "name": "Aliento gélido (recarga 5–6)",
          "text": "Tirada de salvación de Constitución: CD 24, todas las criaturas en un cono de 90 pies. Fallo: 67 (15d8) de daño de frío. Éxito: la mitad del daño."
        },
        {
          "name": "Aliento paralizante",
          "text": "Tirada de salvación de Constitución: CD 24, todas las criaturas en un cono de 90 pies. Primer fallo: el objetivo tendrá el estado de incapacitado hasta el final de su siguiente turno, momento en el que repetirá la tirada de salvación. Segundo fallo: el objetivo tendrá el estado de paralizado y repetirá la tirada de salvación al final de cada uno de sus turnos. Si tiene éxito, se librará del efecto. Tras 1 minuto, tendrá éxito automáticamente."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El dragón lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 23, +15 a acertar con ataques de conjuro): A voluntad: cambiar de forma (solo forma de bestia o humanoide, no se obtienen puntos de golpe temporales del conjuro y no se requieren concentración ni puntos de golpe temporales para mantener el conjuro), cuchillo de hielo (versión de nivel 2), detectar magia, inmovilizar monstruo 1/día cada uno: controlar el clima, teletransporte, tormenta de hielo (versión de nivel 7), zona de la verdad"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "metálico",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, el dragón puede emplear un uso para llevar a cabo una de las siguientes acciones. El dragón recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Abalanzarse",
          "text": "El dragón se mueve hasta la mitad de su velocidad y realiza un ataque de desgarro."
        },
        {
          "name": "Congelar",
          "text": "El dragón utiliza su lanzamiento de conjuros para lanzar inmovilizar monstruo. El dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        },
        {
          "name": "Vendaval helado",
          "text": "Tirada de salvación de Destreza: CD 23, todas las criaturas en una línea de 60 pies de largo y 10 pies de ancho. Fallo: 14 (4d6) de daño de frío y el objetivo es empujado hasta 30 pies respecto al dragón en línea recta. Éxito: solo la mitad del daño. Fallo o éxito: el dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno. Dragones negros"
        }
      ],
      "skills": [
        {
          "name": "Historia",
          "bonus": 11
        },
        {
          "name": "Percepción",
          "bonus": 16
        },
        {
          "name": "Sigilo",
          "bonus": 7
        }
      ],
      "damageImmunities": [
        "frío"
      ],
      "senses": [
        "visión ciega 60 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 26"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "23",
      "proficiencyBonus": 7,
      "xp": 50000,
      "xpText": "50 000 PX o 62 000 en la guarida"
    },
    {
      "id": "cria_de_dragon_negro",
      "name": "Cría de dragón negro",
      "size": "Mediano",
      "type": "dragón",
      "alignment": "caótico malvado",
      "ac": 17,
      "initiative": {
        "modifier": 4,
        "score": 14
      },
      "hp": {
        "average": 33,
        "formula": "6d8 + 6"
      },
      "speed": {
        "walk": "30 pies",
        "swim": "30 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 15,
        "dex": 14,
        "con": 13,
        "int": 10,
        "wis": 11,
        "cha": 13
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": 4
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 1
        }
      ],
      "traits": [
        {
          "name": "Anfibio",
          "text": "El dragón puede respirar tanto dentro como fuera del agua."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza dos ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 5 (1d6 + 2) de daño cortante más 2 (1d4) de daño de ácido."
        },
        {
          "name": "Aliento ácido (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 11, todas las criaturas en una línea de 15 pies de largo y 5 pies de ancho. Fallo: 22 (5d8) de daño de ácido. Éxito: la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "cromático",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 4
        },
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "damageImmunities": [
        "ácido"
      ],
      "senses": [
        "visión ciega 10 pies, visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "dracónico"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "dragon_negro_joven",
      "name": "Dragón negro joven",
      "size": "Grande",
      "type": "dragón",
      "alignment": "caótico malvado",
      "ac": 18,
      "initiative": {
        "modifier": 5,
        "score": 15
      },
      "hp": {
        "average": 127,
        "formula": "15d10 + 45"
      },
      "speed": {
        "walk": "40 pies",
        "swim": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 14,
        "con": 17,
        "int": 12,
        "wis": 11,
        "cha": 15
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 5
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 3
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "traits": [
        {
          "name": "Anfibio",
          "text": "El dragón puede respirar tanto dentro como fuera del agua."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 10 pies. Acierto: 9 (2d4 + 4) de daño cortante más 3 (1d6) de daño de ácido."
        },
        {
          "name": "Aliento ácido (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 14, todas las criaturas en una línea de 30 pies de largo y 5 pies de ancho. Fallo: 49 (14d6) de daño de ácido. Éxito: la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "cromático",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 6
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "damageImmunities": [
        "ácido"
      ],
      "senses": [
        "visión ciega 30 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 16"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "7",
      "proficiencyBonus": 3,
      "xp": 2900
    },
    {
      "id": "dragon_negro_adulto",
      "name": "Dragón negro adulto",
      "size": "Enorme",
      "type": "dragón",
      "alignment": "caótico malvado",
      "ac": 19,
      "initiative": {
        "modifier": 12,
        "score": 22
      },
      "hp": {
        "average": 195,
        "formula": "17d12 + 85"
      },
      "speed": {
        "walk": "40 pies",
        "swim": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 23,
        "dex": 14,
        "con": 21,
        "int": 14,
        "wis": 13,
        "cha": 19
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 6
        },
        {
          "ability": "dex",
          "bonus": 7
        },
        {
          "ability": "con",
          "bonus": 5
        },
        {
          "ability": "int",
          "bonus": 2
        },
        {
          "ability": "wis",
          "bonus": 6
        },
        {
          "ability": "cha",
          "bonus": 4
        }
      ],
      "traits": [
        {
          "name": "Anfibio",
          "text": "El dragón puede respirar tanto dentro como fuera del agua. Resistencia legendaria (3/día o 4/día en la guarida). El dragón puede elegir tener éxito en una tirada de salvación que haya fallado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro. Puede sustituir un ataque por un uso de su lanzamiento de conjuros para lanzar flecha ácida (versión de nivel 3)."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +11, alcance 10 pies. Acierto: 13 (2d6 + 6) de daño cortante más 4 (1d8) de daño de ácido."
        },
        {
          "name": "Aliento ácido (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 18, todas las criaturas en una línea de 60 pies de largo y 5 pies de ancho. Fallo: 54 (12d8) de daño de ácido. Éxito: la mitad del daño."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El dragón lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 17, +9 a acertar con ataques de conjuro): A voluntad: detectar magia, flecha ácida (versión de nivel 3), terror 1/día cada uno: esfera vitriólica, hablar con los muertos"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "cromático",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, el dragón puede emplear un uso para llevar a cabo una de las siguientes acciones. El dragón recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Abalanzarse",
          "text": "El dragón se mueve hasta la mitad de su velocidad y realiza un ataque de desgarro."
        },
        {
          "name": "Nubarrón de insectos",
          "text": "Tirada de salvación de Destreza: CD 17, una criatura que el dragón pueda ver a 120 pies o menos. Fallo: 22 (4d10) de daño de veneno y el objetivo tendrá desventaja en las tiradas de salvación para mantener la concentración hasta el final de su siguiente turno. Fallo o éxito: el dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        },
        {
          "name": "Presencia aterradora",
          "text": "El dragón utiliza su lanzamiento de conjuros para lanzar terror. El dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        }
      ],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 11
        },
        {
          "name": "Sigilo",
          "bonus": 7
        }
      ],
      "damageImmunities": [
        "ácido"
      ],
      "senses": [
        "visión ciega 60 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 21"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "14",
      "proficiencyBonus": 5,
      "xp": 11500,
      "xpText": "11 500 PX o 13 000 en la guarida"
    },
    {
      "id": "dragon_negro_anciano",
      "name": "Dragón negro anciano",
      "size": "Gargantuesco",
      "type": "dragón",
      "alignment": "caótico malvado",
      "ac": 22,
      "initiative": {
        "modifier": 16,
        "score": 26
      },
      "hp": {
        "average": 367,
        "formula": "21d20 + 147"
      },
      "speed": {
        "walk": "40 pies",
        "swim": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 27,
        "dex": 14,
        "con": 25,
        "int": 16,
        "wis": 15,
        "cha": 22
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 8
        },
        {
          "ability": "dex",
          "bonus": 9
        },
        {
          "ability": "con",
          "bonus": 7
        },
        {
          "ability": "int",
          "bonus": 3
        },
        {
          "ability": "wis",
          "bonus": 9
        },
        {
          "ability": "cha",
          "bonus": 6
        }
      ],
      "traits": [
        {
          "name": "Anfibio",
          "text": "El dragón puede respirar tanto dentro como fuera del agua. Resistencia legendaria (4/día o 5/día en la guarida). El dragón puede elegir tener éxito en una tirada de salvación que haya fallado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro. Puede sustituir un ataque por un uso de su lanzamiento de conjuros para lanzar flecha ácida (versión de nivel 4)."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +15, alcance 15 pies. Acierto: 17 (2d8 + 8) de daño cortante más 9 (2d8) de daño de ácido."
        },
        {
          "name": "Aliento ácido (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 22, todas las criaturas en una línea de 90 pies de largo y 10 pies de ancho. Fallo: 67 (15d8) de daño de ácido. Éxito: la mitad del daño."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El dragón lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 21, +13 a acertar con ataques de conjuro): A voluntad: detectar magia, flecha ácida (versión de nivel 4), terror 1/día cada uno: crear muerto viviente, esfera vitriólica (versión de nivel 5), hablar con los muertos"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "cromático",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, el dragón puede emplear un uso para llevar a cabo una de las siguientes acciones. El dragón recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Abalanzarse",
          "text": "El dragón se mueve hasta la mitad de su velocidad y realiza un ataque de desgarro."
        },
        {
          "name": "Nubarrón de insectos",
          "text": "Tirada de salvación de Destreza: CD 21, una criatura que el dragón pueda ver a 120 pies o menos. Fallo: 33 (6d10) de daño de veneno y el objetivo tendrá desventaja en las tiradas de salvación para mantener la concentración hasta el final de su siguiente turno. Fallo o éxito: el dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        },
        {
          "name": "Presencia aterradora",
          "text": "El dragón utiliza su lanzamiento de conjuros para lanzar terror. El dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno. Dragones rojos"
        }
      ],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 16
        },
        {
          "name": "Sigilo",
          "bonus": 9
        }
      ],
      "damageImmunities": [
        "ácido"
      ],
      "senses": [
        "visión ciega 60 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 26"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "21",
      "proficiencyBonus": 7,
      "xp": 33000,
      "xpText": "33 000 PX o 41 000 en la guarida"
    },
    {
      "id": "cria_de_dragon_rojo",
      "name": "Cría de dragón rojo",
      "size": "Mediano",
      "type": "dragón",
      "alignment": "caótico malvado",
      "ac": 17,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 75,
        "formula": "10d8 + 30"
      },
      "speed": {
        "walk": "30 pies",
        "climb": "30 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 10,
        "con": 17,
        "int": 12,
        "wis": 11,
        "cha": 15
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza dos ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 9 (1d10 + 4) de daño cortante más 3 (1d6) de daño de fuego."
        },
        {
          "name": "Aliento de fuego (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 13, todas las criaturas en un cono de 15 pies. Fallo: 24 (7d6) de daño de fuego. Éxito: la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "cromático",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 4
        },
        {
          "name": "Sigilo",
          "bonus": 2
        }
      ],
      "damageImmunities": [
        "fuego"
      ],
      "senses": [
        "visión ciega 10 pies, visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "dracónico"
      ],
      "cr": "4",
      "proficiencyBonus": 2,
      "xp": 1100
    },
    {
      "id": "dragon_rojo_joven",
      "name": "Dragón rojo joven",
      "size": "Grande",
      "type": "dragón",
      "alignment": "caótico malvado",
      "ac": 18,
      "initiative": {
        "modifier": 4,
        "score": 14
      },
      "hp": {
        "average": 178,
        "formula": "17d10 + 85"
      },
      "speed": {
        "walk": "40 pies",
        "climb": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 23,
        "dex": 10,
        "con": 21,
        "int": 14,
        "wis": 11,
        "cha": 19
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 6
        },
        {
          "ability": "dex",
          "bonus": 4
        },
        {
          "ability": "con",
          "bonus": 5
        },
        {
          "ability": "int",
          "bonus": 2
        },
        {
          "ability": "wis",
          "bonus": 4
        },
        {
          "ability": "cha",
          "bonus": 4
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +10, alcance 10 pies. Acierto: 13 (2d6 + 6) de daño cortante más 3 (1d6) de daño de fuego."
        },
        {
          "name": "Aliento de fuego (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 17, todas las criaturas en un cono de 30 pies."
        },
        {
          "name": "Fallo: 56 (16d6) de daño de fuego",
          "text": "Éxito: la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "cromático",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 8
        },
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "damageImmunities": [
        "fuego"
      ],
      "senses": [
        "visión ciega 30 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 18"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "10",
      "proficiencyBonus": 4,
      "xp": 5900
    },
    {
      "id": "dragon_rojo_adulto",
      "name": "Dragón rojo adulto",
      "size": "Enorme",
      "type": "dragón",
      "alignment": "caótico malvado",
      "ac": 19,
      "initiative": {
        "modifier": 12,
        "score": 22
      },
      "hp": {
        "average": 256,
        "formula": "19d12 + 133"
      },
      "speed": {
        "walk": "40 pies",
        "climb": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 27,
        "dex": 10,
        "con": 25,
        "int": 16,
        "wis": 13,
        "cha": 23
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 8
        },
        {
          "ability": "dex",
          "bonus": 6
        },
        {
          "ability": "con",
          "bonus": 7
        },
        {
          "ability": "int",
          "bonus": 3
        },
        {
          "ability": "wis",
          "bonus": 7
        },
        {
          "ability": "cha",
          "bonus": 6
        }
      ],
      "traits": [
        {
          "name": "Resistencia legendaria (3/día o 4/día en la guarida)",
          "text": "El dragón puede elegir tener éxito en una tirada de salvación que haya fallado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro. Puede sustituir un ataque por un uso de su lanzamiento de conjuros para lanzar rayo abrasador."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +14, alcance 10 pies. Acierto: 13 (1d10 + 8) de daño cortante más 5 (2d4) de daño de fuego."
        },
        {
          "name": "Aliento de fuego (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 21, todas las criaturas en un cono de 60 pies. Fallo: 59 (17d6) de daño de fuego. Éxito: la mitad del daño."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El dragón lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 20, +12 a acertar con ataques de conjuro): A voluntad: detectar magia, orden imperiosa (versión de nivel 2), rayo abrasador 1/día: bola de fuego"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "cromático",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, el dragón puede emplear un uso para llevar a cabo una de las siguientes acciones. El dragón recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Abalanzarse",
          "text": "El dragón se mueve hasta la mitad de su velocidad y realiza un ataque de desgarro."
        },
        {
          "name": "Presencia imponente",
          "text": "El dragón utiliza su lanzamiento de conjuros para lanzar orden imperiosa (versión de nivel 2). El dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        },
        {
          "name": "Rayos ardientes",
          "text": "El dragón utiliza su lanzamiento de conjuros para lanzar rayo abrasador. El dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        }
      ],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 13
        },
        {
          "name": "Sigilo",
          "bonus": 6
        }
      ],
      "damageImmunities": [
        "fuego"
      ],
      "senses": [
        "visión ciega 60 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 23"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "17",
      "proficiencyBonus": 6,
      "xp": 18000,
      "xpText": "18 000 PX o 20 000 en la guarida"
    },
    {
      "id": "dragon_rojo_anciano",
      "name": "Dragón rojo anciano",
      "size": "Gargantuesco",
      "type": "dragón",
      "alignment": "caótico malvado",
      "ac": 22,
      "initiative": {
        "modifier": 14,
        "score": 24
      },
      "hp": {
        "average": 507,
        "formula": "26d20 + 234"
      },
      "speed": {
        "walk": "40 pies",
        "climb": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 30,
        "dex": 10,
        "con": 29,
        "int": 18,
        "wis": 15,
        "cha": 27
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 10
        },
        {
          "ability": "dex",
          "bonus": 7
        },
        {
          "ability": "con",
          "bonus": 9
        },
        {
          "ability": "int",
          "bonus": 4
        },
        {
          "ability": "wis",
          "bonus": 9
        },
        {
          "ability": "cha",
          "bonus": 8
        }
      ],
      "traits": [
        {
          "name": "Resistencia legendaria (4/día o 5/día en la guarida)",
          "text": "El dragón puede elegir tener éxito en una tirada de salvación que haya fallado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro. Puede sustituir un ataque por un uso de su lanzamiento de conjuros para lanzar rayo abrasador (versión de nivel 3)."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +17, alcance 15 pies. Acierto: 19 (2d8 + 10) de daño cortante más 10 (3d6) de daño de fuego."
        },
        {
          "name": "Aliento de fuego (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 24, todas las criaturas en un cono de 90 pies. Fallo: 91 (26d6) de daño de fuego. Éxito: la mitad del daño."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El dragón lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 23, +15 a acertar con ataques de conjuro): A voluntad: detectar magia, orden imperiosa (versión de nivel 2), rayo abrasador (versión de nivel 3) 1/día cada uno: bola de fuego (versión de nivel 6), escudriñar"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "cromático",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, el dragón puede emplear un uso para llevar a cabo una de las siguientes acciones. El dragón recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Abalanzarse",
          "text": "El dragón se mueve hasta la mitad de su velocidad y realiza un ataque de desgarro."
        },
        {
          "name": "Presencia imponente",
          "text": "El dragón utiliza su lanzamiento de conjuros para lanzar orden imperiosa (versión de nivel 2). El dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        },
        {
          "name": "Rayos ardientes",
          "text": "El dragón utiliza su lanzamiento de conjuros para lanzar rayo abrasador (versión de nivel 3). El dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno. Dragones verdes"
        }
      ],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 16
        },
        {
          "name": "Sigilo",
          "bonus": 7
        }
      ],
      "damageImmunities": [
        "fuego"
      ],
      "senses": [
        "visión ciega 60 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 26"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "24",
      "proficiencyBonus": 7,
      "xp": 62000,
      "xpText": "62 000 PX o 75 000 en la guarida"
    },
    {
      "id": "cria_de_dragon_verde",
      "name": "Cría de dragón verde",
      "size": "Mediano",
      "type": "dragón",
      "alignment": "legal malvado",
      "ac": 17,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 38,
        "formula": "7d8 + 7"
      },
      "speed": {
        "walk": "30 pies",
        "swim": "30 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 15,
        "dex": 12,
        "con": 13,
        "int": 14,
        "wis": 11,
        "cha": 13
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 2
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 1
        }
      ],
      "traits": [
        {
          "name": "Anfibio",
          "text": "El dragón puede respirar tanto dentro como fuera del agua."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza dos ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 7 (1d10 + 2) de daño cortante más 3 (1d6) de daño de veneno."
        },
        {
          "name": "Aliento venenoso (recarga 5–6)",
          "text": "Tirada de salvación de Constitución: CD 11, todas las criaturas en un cono de 15 pies. Fallo: 21 (6d6) de daño de veneno. Éxito: la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "cromático",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 4
        },
        {
          "name": "Sigilo",
          "bonus": 3
        }
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado"
      ],
      "senses": [
        "visión ciega 10 pies, visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "dracónico"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "dragon_verde_joven",
      "name": "Dragón verde joven",
      "size": "Grande",
      "type": "dragón",
      "alignment": "legal malvado",
      "ac": 18,
      "initiative": {
        "modifier": 4,
        "score": 14
      },
      "hp": {
        "average": 136,
        "formula": "16d10 + 48"
      },
      "speed": {
        "walk": "40 pies",
        "swim": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 12,
        "con": 17,
        "int": 16,
        "wis": 13,
        "cha": 15
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 4
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": 3
        },
        {
          "ability": "wis",
          "bonus": 4
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "traits": [
        {
          "name": "Anfibio",
          "text": "El dragón puede respirar tanto dentro como fuera del agua."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 10 pies. Acierto: 11 (2d6 + 4) de daño cortante más 7 (2d6) de daño de veneno."
        },
        {
          "name": "Aliento venenoso (recarga 5–6)",
          "text": "Tirada de salvación de Constitución: CD 14, todas las criaturas en un cono de 30 pies. Fallo: 42 (12d6) de daño de veneno. Éxito: la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "cromático",
      "skills": [
        {
          "name": "Engaño",
          "bonus": 5
        },
        {
          "name": "Percepción",
          "bonus": 7
        },
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado"
      ],
      "senses": [
        "visión ciega 30 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 17"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "8",
      "proficiencyBonus": 3,
      "xp": 3900
    },
    {
      "id": "dragon_verde_adulto",
      "name": "Dragón verde adulto",
      "size": "Enorme",
      "type": "dragón",
      "alignment": "legal malvado",
      "ac": 19,
      "initiative": {
        "modifier": 11,
        "score": 21
      },
      "hp": {
        "average": 207,
        "formula": "18d12 + 90"
      },
      "speed": {
        "walk": "40 pies",
        "swim": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 23,
        "dex": 12,
        "con": 21,
        "int": 18,
        "wis": 15,
        "cha": 18
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 6
        },
        {
          "ability": "dex",
          "bonus": 6
        },
        {
          "ability": "con",
          "bonus": 5
        },
        {
          "ability": "int",
          "bonus": 4
        },
        {
          "ability": "wis",
          "bonus": 7
        },
        {
          "ability": "cha",
          "bonus": 4
        }
      ],
      "traits": [
        {
          "name": "Anfibio",
          "text": "El dragón puede respirar tanto dentro como fuera del agua. Resistencia legendaria (3/día o 4/día en la guarida). El dragón puede elegir tener éxito en una tirada de salvación que haya fallado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro. Puede sustituir un ataque por un uso de su lanzamiento de conjuros para lanzar clavo mental (versión de nivel 3)."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +11, alcance 10 pies. Acierto: 15 (2d8 + 6) de daño cortante más 7 (2d6) de daño de veneno."
        },
        {
          "name": "Aliento venenoso (recarga 5–6)",
          "text": "Tirada de salvación de Constitución: CD 18, todas las criaturas en un cono de 60 pies. Fallo: 56 (16d6) de daño de veneno. Éxito: la mitad del daño."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El dragón lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 17): A voluntad: clavo mental (versión de nivel 3), detectar magia 1/día: geas"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "cromático",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, el dragón puede emplear un uso para llevar a cabo una de las siguientes acciones. El dragón recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Abalanzarse",
          "text": "El dragón se mueve hasta la mitad de su velocidad y realiza un ataque de desgarro."
        },
        {
          "name": "Invasión mental",
          "text": "El dragón utiliza su lanzamiento de conjuros para lanzar clavo mental (versión de nivel 3)."
        },
        {
          "name": "Miasma venenoso",
          "text": "Tirada de salvación de Constitución: CD 17, todas las criaturas en una esfera de 20 pies de radio centrada en un punto que el dragón pueda ver a 90 pies o menos. Fallo: 7 (2d6) de daño de veneno y el objetivo tendrá un penalizador de −2 a la CA hasta el final de su siguiente turno. Fallo o éxito: el dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        }
      ],
      "skills": [
        {
          "name": "Engaño",
          "bonus": 9
        },
        {
          "name": "Percepción",
          "bonus": 12
        },
        {
          "name": "Persuasión",
          "bonus": 9
        },
        {
          "name": "Sigilo",
          "bonus": 6
        }
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado"
      ],
      "senses": [
        "visión ciega 60 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 22"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "15",
      "proficiencyBonus": 5,
      "xp": 13000,
      "xpText": "13 000 PX o 15 000 en la guarida"
    },
    {
      "id": "dragon_verde_anciano",
      "name": "Dragón verde anciano",
      "size": "Gargantuesco",
      "type": "dragón",
      "alignment": "legal malvado",
      "ac": 21,
      "initiative": {
        "modifier": 15,
        "score": 25
      },
      "hp": {
        "average": 402,
        "formula": "23d20 + 161"
      },
      "speed": {
        "walk": "40 pies",
        "swim": "40 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 27,
        "dex": 12,
        "con": 25,
        "int": 20,
        "wis": 17,
        "cha": 22
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 8
        },
        {
          "ability": "dex",
          "bonus": 8
        },
        {
          "ability": "con",
          "bonus": 7
        },
        {
          "ability": "int",
          "bonus": 5
        },
        {
          "ability": "wis",
          "bonus": 10
        },
        {
          "ability": "cha",
          "bonus": 6
        }
      ],
      "traits": [
        {
          "name": "Anfibio",
          "text": "El dragón puede respirar tanto dentro como fuera del agua. Resistencia legendaria (4/día o 5/día en la guarida). El dragón puede elegir tener éxito en una tirada de salvación que haya fallado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de desgarro. Puede sustituir un ataque por un uso de su lanzamiento de conjuros para lanzar clavo mental (versión de nivel 5)."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +15, alcance 15 pies. Acierto: 17 (2d8 + 8) de daño cortante más 10 (3d6) de daño de veneno."
        },
        {
          "name": "Aliento venenoso (recarga 5–6)",
          "text": "Tirada de salvación de Constitución: CD 22, todas las criaturas en un cono de 90 pies. Fallo: 77 (22d6) de daño de veneno. Éxito: la mitad del daño."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El dragón lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 21): A voluntad: clavo mental (versión de nivel 5), detectar magia 1/día cada uno: alterar los recuerdos, geas"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "cromático",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, el dragón puede emplear un uso para llevar a cabo una de las siguientes acciones. El dragón recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Abalanzarse",
          "text": "El dragón se mueve hasta la mitad de su velocidad y realiza un ataque de desgarro."
        },
        {
          "name": "Invasión mental",
          "text": "El dragón utiliza su lanzamiento de conjuros para lanzar clavo mental (versión de nivel 5)."
        },
        {
          "name": "Miasma venenoso",
          "text": "Tirada de salvación de Constitución: CD 21, todas las criaturas en una esfera de 30 pies de radio centrada en un punto que el dragón pueda ver a 90 pies o menos. Fallo: 17 (5d6) de daño de veneno y el objetivo tendrá un penalizador de −2 a la CA hasta el final de su siguiente turno. Fallo o éxito: el dragón no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        }
      ],
      "skills": [
        {
          "name": "Engaño",
          "bonus": 13
        },
        {
          "name": "Percepción",
          "bonus": 17
        },
        {
          "name": "Persuasión",
          "bonus": 13
        },
        {
          "name": "Sigilo",
          "bonus": 8
        }
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado"
      ],
      "senses": [
        "visión ciega 60 pies, visión en la oscuridad 120 pies",
        "Percepción pasiva 27"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "22",
      "proficiencyBonus": 7,
      "xp": 41000,
      "xpText": "41 000 PX o 50 000 en la guarida"
    },
    {
      "id": "dragon_tortuga",
      "name": "Dragón tortuga",
      "size": "Gargantuesco",
      "type": "dragón",
      "alignment": "neutral",
      "ac": 20,
      "initiative": {
        "modifier": 6,
        "score": 16
      },
      "hp": {
        "average": 356,
        "formula": "23d20 + 115"
      },
      "speed": {
        "walk": "20 pies",
        "swim": "50 pies"
      },
      "abilities": {
        "str": 25,
        "dex": 10,
        "con": 20,
        "int": 10,
        "wis": 12,
        "cha": 12
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 7
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 11
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 7
        },
        {
          "ability": "cha",
          "bonus": 1
        }
      ],
      "traits": [
        {
          "name": "Anfibio",
          "text": "El dragón puede respirar tanto dentro como fuera del agua."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El dragón realiza tres ataques de mordisco. Puede sustituir uno de ellos por un ataque con su cola."
        },
        {
          "name": "Cola",
          "text": "Tirada de ataque cuerpo a cuerpo: +13, alcance 15 pies. Acierto: 18 (2d10 + 7) de daño contundente. Si el objetivo es una criatura Enorme o más pequeña, tendrá el estado de derribada."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +13, alcance 15 pies. Acierto: 23 (3d10 + 7) de daño perforante más 7 (2d6) de daño de fuego. Estar bajo el agua no otorga resistencia a este daño de fuego."
        },
        {
          "name": "Aliento de vapor (recarga 5–6)",
          "text": "Tirada de salvación de Constitución: CD 19, todas las criaturas en un cono de 60 pies. Fallo: 56 (16d6) de daño de fuego. Éxito: la mitad del daño. Fallo o éxito: estar bajo el agua no otorga resistencia a este daño de fuego."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageResistances": [
        "fuego"
      ],
      "senses": [
        "visión en la oscuridad 120 pies",
        "Percepción pasiva 11"
      ],
      "languages": [
        "dracónico",
        "primordial (acuano)"
      ],
      "cr": "17",
      "proficiencyBonus": 6,
      "xp": 18000
    },
    {
      "id": "drana",
      "name": "Draña",
      "size": "Grande",
      "type": "monstruosidad",
      "alignment": "caótica malvada",
      "ac": 19,
      "initiative": {
        "modifier": 4,
        "score": 14
      },
      "hp": {
        "average": 123,
        "formula": "13d10 + 52"
      },
      "speed": {
        "walk": "30 pies",
        "climb": "30 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 19,
        "con": 18,
        "int": 13,
        "wis": 16,
        "cha": 12
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 4
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 3
        },
        {
          "ability": "cha",
          "bonus": 1
        }
      ],
      "traits": [
        {
          "name": "Caminar por telarañas",
          "text": "La draña ignora todas las restricciones de movimiento causadas por las telarañas y conoce la ubicación de cualquier otra criatura que esté en contacto con la misma telaraña."
        },
        {
          "name": "Sensibilidad a la luz solar",
          "text": "Bajo la luz del sol, la draña tiene desventaja en las pruebas de característica y las tiradas de ataque."
        },
        {
          "name": "Trepar cual arácnido",
          "text": "La draña puede trepar por superficies difíciles e incluso recorrer techos sin tener que realizar pruebas de característica."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "La draña realiza tres ataques con sus patas delanteras o su estallido venenoso en cualquier combinación."
        },
        {
          "name": "Estallido venenoso",
          "text": "Tirada de ataque a distancia: +6, alcance 120 pies. Acierto: 13 (3d6 + 3) de daño de veneno."
        },
        {
          "name": "Pata delantera",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 10 pies. Acierto: 13 (2d8 + 4) de daño perforante."
        }
      ],
      "bonusActions": [
        {
          "name": "Magia de la Reina Araña (recarga 5–6)",
          "text": "La draña lanza fuego feérico, oscuridad o telaraña, que no requieren componentes materiales y utilizan la Sabiduría como aptitud mágica (CD de salvación de conjuros 14)."
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 6
        },
        {
          "name": "Sigilo",
          "bonus": 10
        }
      ],
      "senses": [
        "visión en la oscuridad 120 pies",
        "Percepción pasiva 16"
      ],
      "languages": [
        "elfo",
        "infracomún"
      ],
      "cr": "6",
      "proficiencyBonus": 3,
      "xp": 2300
    },
    {
      "id": "dretch",
      "name": "Dretch",
      "size": "Pequeño",
      "type": "infernal",
      "alignment": "caótico malvado",
      "ac": 11,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 18,
        "formula": "4d6 + 4"
      },
      "speed": {
        "walk": "20 pies"
      },
      "abilities": {
        "str": 12,
        "dex": 11,
        "con": 12,
        "int": 5,
        "wis": 8,
        "cha": 3
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 1
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": -3
        },
        {
          "ability": "wis",
          "bonus": -1
        },
        {
          "ability": "cha",
          "bonus": -4
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +3, alcance 5 pies. Acierto: 4 (1d6 + 1) de daño cortante."
        },
        {
          "name": "Nube fétida (1/día)",
          "text": "Tirada de salvación de Constitución: CD 11, todas las criaturas en una emanación de 10 pies que se origina en el dretch. Fallo: el objetivo tendrá el estado de envenenado hasta el final de su siguiente turno. Mientras esté envenenada, la criatura podrá realizar una acción o una acción adicional en su turno, pero no ambas, y no podrá llevar a cabo reacciones."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "demonio",
      "damageResistances": [
        "frío",
        "fuego",
        "relámpago"
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 9"
      ],
      "languages": [
        "abisal",
        "telepatía 60 pies (solo funciona con criaturas que entiendan abisal)"
      ],
      "cr": "1/4",
      "proficiencyBonus": 2,
      "xp": 50
    },
    {
      "id": "driade",
      "name": "Dríade",
      "size": "Mediano",
      "type": "feérico",
      "alignment": "neutral",
      "ac": 16,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 22,
        "formula": "5d8"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 10,
        "dex": 12,
        "con": 11,
        "int": 14,
        "wis": 15,
        "cha": 18
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 0
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": 2
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 4
        }
      ],
      "traits": [
        {
          "name": "Hablar con las bestias y las plantas",
          "text": "La dríade puede comunicarse con bestias y plantas como si tuvieran un idioma en común."
        },
        {
          "name": "Resistencia mágica",
          "text": "La dríade tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "La dríade realiza un ataque con su latigazo de enredadera o su estallido de espinas y puede utilizar su lanzamiento de conjuros para lanzar hechizar monstruo."
        },
        {
          "name": "Latigazo de enredadera",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 10 pies. Acierto: 8 (1d8 + 4) de daño cortante."
        },
        {
          "name": "Estallido de espinas",
          "text": "Tirada de ataque a distancia: +6, alcance 60 pies. Acierto: 7 (1d6 + 4) de daño perforante."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "La dríade lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 14): A voluntad: encantar animal, hechizar monstruo (dura 24 horas; termina antes de tiempo si la dríade vuelve a lanzarlo), saber druídico 1/día cada uno: enmarañar, pasar sin rastro"
        }
      ],
      "bonusActions": [
        {
          "name": "Paso arbóreo",
          "text": "Si se encuentra a 5 pies o menos de un árbol Grande o de mayor tamaño, la dríade se teletransporta a un espacio sin ocupar a 5 pies o menos de un segundo árbol Grande o de mayor tamaño que esté a 60 pies o menos del otro."
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 4
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "elfo",
        "silvano"
      ],
      "cr": "1",
      "proficiencyBonus": 2,
      "xp": 200
    },
    {
      "id": "druida",
      "name": "Druida",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 13,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 44,
        "formula": "8d8 + 8"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 10,
        "dex": 12,
        "con": 13,
        "int": 12,
        "wis": 16,
        "cha": 11
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 0
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 3
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El druida realiza dos ataques con su bastón de enredaderas o con su voluta verdeante en cualquier combinación."
        },
        {
          "name": "Bastón de enredaderas",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 7 (1d8 + 3) de daño contundente más 2 (1d4) de daño de veneno."
        },
        {
          "name": "Voluta verdeante",
          "text": "Tirada de ataque a distancia: +5, alcance 90 pies. Acierto: 10 (3d6) de daño radiante."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El druida lanza uno de los siguientes conjuros, que utiliza la Sabiduría como aptitud mágica (CD de salvación de conjuros 13): A voluntad: hablar con los animales, saber druídico 2/día cada uno: enmarañar, ola atronadora 1/día cada uno: mensajero animal, rayo de luna, zancada prodigiosa"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "druida",
      "skills": [
        {
          "name": "Medicina",
          "bonus": 5
        },
        {
          "name": "Naturaleza",
          "bonus": 3
        },
        {
          "name": "Percepción",
          "bonus": 5
        }
      ],
      "equipment": [
        "armadura de cuero tachonado"
      ],
      "senses": [
        "Percepción pasiva 15"
      ],
      "languages": [
        "común",
        "druídico",
        "silvano"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "duende",
      "name": "Duende",
      "size": "Diminuto",
      "type": "feérico",
      "alignment": "neutral bueno",
      "ac": 15,
      "initiative": {
        "modifier": 4,
        "score": 14
      },
      "hp": {
        "average": 10,
        "formula": "4d4"
      },
      "speed": {
        "walk": "10 pies",
        "fly": "40 pies"
      },
      "abilities": {
        "str": 3,
        "dex": 18,
        "con": 10,
        "int": 14,
        "wis": 13,
        "cha": 11
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -4
        },
        {
          "ability": "dex",
          "bonus": 4
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": 2
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Espada aguja",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 6 (1d4 + 4) de daño perforante."
        },
        {
          "name": "Arco encantador",
          "text": "Tirada de ataque a distancia: +6, alcance 12/157 pies. Acierto: 1 de daño perforante y el objetivo tendrá el estado de hechizado hasta el principio del siguiente turno del duende."
        },
        {
          "name": "Invisibilidad",
          "text": "El duende lanza invisibilidad sobre sí mismo sin necesidad de componentes y utiliza el Carisma como aptitud mágica."
        },
        {
          "name": "Visión del corazón",
          "text": "Tirada de salvación de Carisma: CD 10, una criatura que el duende pueda ver a 5 pies o menos (los celestiales, infernales y muertos vivientes fallan automáticamente la tirada). Fallo: el duende descubre las emociones y el alineamiento del objetivo."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 3
        },
        {
          "name": "Sigilo",
          "bonus": 8
        }
      ],
      "senses": [
        "Percepción pasiva 13"
      ],
      "languages": [
        "común",
        "elfo",
        "silvano"
      ],
      "cr": "1/4",
      "proficiencyBonus": 2,
      "xp": 50
    },
    {
      "id": "elemental_de_agua",
      "name": "Elemental de agua",
      "size": "Grande",
      "type": "elemental",
      "alignment": "neutral",
      "ac": 14,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 114,
        "formula": "12d10 + 48"
      },
      "speed": {
        "walk": "30 pies",
        "swim": "90 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 14,
        "con": 18,
        "int": 5,
        "wis": 10,
        "cha": 8
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": -3
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [
        {
          "name": "Congelarse",
          "text": "Si el elemental recibe daño de frío, su velocidad se reducirá en 20 pies hasta el final de su siguiente turno."
        },
        {
          "name": "Forma de agua",
          "text": "El elemental puede entrar en el espacio de un enemigo y detenerse allí. Puede moverse a través de un espacio de solo 1 pulgada de ancho sin gastar movimiento adicional para hacerlo."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El elemental realiza dos ataques con su golpe."
        },
        {
          "name": "Golpe",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 13 (2d8 + 4) de daño contundente. Si el objetivo es una criatura Mediana o más pequeña, tendrá el estado de derribada."
        },
        {
          "name": "Anegar (recarga 4–6)",
          "text": "Tirada de salvación de Fuerza: CD 15, todas las criaturas en el espacio del elemental."
        },
        {
          "name": "Fallo: 22 (4d8 + 4) de daño contundente",
          "text": "Si el objetivo es una criatura Grande o más pequeña, tendrá el estado de agarrada (CD 14 para escapar). Hasta que el agarre termine, el objetivo tendrá el estado de apresado, sufrirá asfixia salvo que pueda respirar en el agua y recibirá 9 (2d8) de daño contundente al principio de cada turno del elemental. El elemental puede agarrar a una criatura Grande o hasta a dos criaturas Medianas o más pequeñas al mismo tiempo con la acción de anegar. Como acción, una criatura a 5 pies o menos del elemental puede sacar a una criatura de él si supera una prueba de Fuerza (Atletismo) con CD 14. Éxito: solo la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageResistances": [
        "ácido",
        "fuego"
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "agarrado",
        "apresado",
        "cansancio",
        "derribado",
        "envenenado",
        "inconsciente",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "primordial (acuano)"
      ],
      "cr": "5",
      "proficiencyBonus": 3,
      "xp": 1800
    },
    {
      "id": "elemental_de_aire",
      "name": "Elemental de aire",
      "size": "Grande",
      "type": "elemental",
      "alignment": "neutral",
      "ac": 15,
      "initiative": {
        "modifier": 5,
        "score": 15
      },
      "hp": {
        "average": 90,
        "formula": "12d10 + 24"
      },
      "speed": {
        "walk": "10 pies",
        "fly": "90 pies (levitar)"
      },
      "abilities": {
        "str": 14,
        "dex": 20,
        "con": 14,
        "int": 6,
        "wis": 10,
        "cha": 6
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": 5
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [
        {
          "name": "Forma de aire",
          "text": "El elemental puede entrar en el espacio de una criatura y detenerse allí. Puede moverse a través de un espacio de solo 1 pulgada de ancho sin gastar movimiento adicional para hacerlo."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El elemental realiza dos ataques con su golpe atronador."
        },
        {
          "name": "Golpe atronador",
          "text": "Tirada de ataque cuerpo a cuerpo: +8, alcance 10 pies. Acierto: 14 (2d8 + 5) de daño de trueno."
        },
        {
          "name": "Torbellino (recarga 4–6)",
          "text": "Tirada de salvación de Fuerza: CD 13, una criatura Mediana o más pequeña en el espacio del elemental. Fallo: 24 (4d10 +2) de daño de trueno y el objetivo es empujado hasta 20 pies respecto al elemental en línea recta y tiene el estado de derribado. Éxito: solo la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageResistances": [
        "contundente",
        "cortante",
        "perforante",
        "relámpago"
      ],
      "damageImmunities": [
        "trueno",
        "veneno"
      ],
      "conditionImmunities": [
        "agarrado",
        "apresado",
        "cansancio",
        "derribado",
        "envenenado",
        "inconsciente",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "primordial (aurano)"
      ],
      "cr": "5",
      "proficiencyBonus": 3,
      "xp": 1800
    },
    {
      "id": "elemental_de_fuego",
      "name": "Elemental de fuego",
      "size": "Grande",
      "type": "elemental",
      "alignment": "neutral",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 93,
        "formula": "11d10 + 33"
      },
      "speed": {
        "walk": "50 pies"
      },
      "abilities": {
        "str": 10,
        "dex": 17,
        "con": 16,
        "int": 6,
        "wis": 10,
        "cha": 7
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 0
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [
        {
          "name": "Aura de fuego",
          "text": "Al final de cada turno del elemental, todas las criaturas en una emanación de 10 pies que se origina en él reciben 5 (1d10) de daño de fuego y las criaturas y objetos inflamables en ella empiezan a arder."
        },
        {
          "name": "Forma de fuego",
          "text": "El elemental puede moverse a través de un espacio de solo 1 pulgada de ancho sin gastar movimiento adicional para hacerlo y puede entrar en el espacio de una criatura y detenerse allí. La primera vez que entre en el espacio de una criatura durante un turno, la criatura recibirá 5 (1d10) de daño de fuego."
        },
        {
          "name": "Iluminación",
          "text": "El elemental emite luz brillante en un radio de 30 pies y luz tenue 30 pies más allá."
        },
        {
          "name": "Susceptibilidad al agua",
          "text": "El elemental sufre 3 (1d6) de daño de frío por cada 5 pies que se mueva en el agua o por cada 4 litros de agua que se viertan sobre él."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El elemental realiza dos ataques de quemadura."
        },
        {
          "name": "Quemadura",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 10 (2d6 + 3) de daño de fuego. Si el objetivo es una criatura o un objeto inflamable, empezará a arder."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageResistances": [
        "contundente",
        "cortante",
        "perforante"
      ],
      "damageImmunities": [
        "fuego",
        "veneno"
      ],
      "conditionImmunities": [
        "agarrado",
        "apresado",
        "cansancio",
        "derribado",
        "envenenado",
        "inconsciente",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "primordial (ígneo)"
      ],
      "cr": "5",
      "proficiencyBonus": 3,
      "xp": 1800
    },
    {
      "id": "elemental_de_tierra",
      "name": "Elemental de tierra",
      "size": "Grande",
      "type": "elemental",
      "alignment": "neutral",
      "ac": 17,
      "initiative": {
        "modifier": -1,
        "score": 9
      },
      "hp": {
        "average": 147,
        "formula": "14d10 + 70"
      },
      "speed": {
        "walk": "30 pies",
        "burrow": "30 pies"
      },
      "abilities": {
        "str": 20,
        "dex": 8,
        "con": 20,
        "int": 5,
        "wis": 10,
        "cha": 5
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 5
        },
        {
          "ability": "dex",
          "bonus": -1
        },
        {
          "ability": "con",
          "bonus": 5
        },
        {
          "ability": "int",
          "bonus": -3
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -3
        }
      ],
      "traits": [
        {
          "name": "Deslizarse por la tierra",
          "text": "El elemental puede excavar a través de la tierra y la piedra que no sean mágicas ni estén trabajadas. Al hacer esto, no desplaza ni perturba la materia a través de la que se mueve."
        },
        {
          "name": "Monstruo de asedio",
          "text": "El elemental inflige el doble de daño a objetos y estructuras."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El elemental realiza dos ataques con su golpe o su lanzamiento de rocas en cualquier combinación."
        },
        {
          "name": "Golpe",
          "text": "Tirada de ataque cuerpo a cuerpo: +8, alcance 10 pies. Acierto: 14 (2d8 + 5) de daño contundente."
        },
        {
          "name": "Lanzamiento de rocas",
          "text": "Tirada de ataque a distancia: +8, alcance 60 pies. Acierto: 8 (1d6 + 5) de daño contundente. Si el objetivo es una criatura Grande o más pequeña, tendrá el estado de derribada."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageVulnerabilities": [
        "trueno"
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "cansancio",
        "envenenado",
        "inconsciente",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "sentir vibraciones 60 pies, visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "primordial (terrano)"
      ],
      "cr": "5",
      "proficiencyBonus": 3,
      "xp": 1800
    },
    {
      "id": "ent",
      "name": "Ent",
      "size": "Enorme",
      "type": "planta",
      "alignment": "caótica buena",
      "ac": 16,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 138,
        "formula": "12d12 + 60"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 23,
        "dex": 8,
        "con": 21,
        "int": 12,
        "wis": 16,
        "cha": 12
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 6
        },
        {
          "ability": "dex",
          "bonus": -1
        },
        {
          "ability": "con",
          "bonus": 5
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 3
        },
        {
          "ability": "cha",
          "bonus": 1
        }
      ],
      "traits": [
        {
          "name": "Monstruo de asedio",
          "text": "El ent inflige el doble de daño a objetos y estructuras."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El ent realiza dos ataques con su golpe."
        },
        {
          "name": "Golpe",
          "text": "Tirada de ataque cuerpo a cuerpo: +10, alcance 5 pies. Acierto: 16 (3d6 + 6) de daño contundente."
        },
        {
          "name": "Lluvia de corteza",
          "text": "Tirada de ataque a distancia: +10, alcance 180 pies. Acierto: 28 (4d10 + 6) de daño perforante."
        },
        {
          "name": "Animar árboles (1/día)",
          "text": "El ent anima mágicamente hasta dos árboles que pueda ver a 60 pies o menos de él. Cada árbol usa el perfil del ent, salvo que sus puntuaciones de Inteligencia y Carisma son de 1, no puede hablar y no tiene esta acción. El árbol juega su turno justo después del ent en el mismo orden de iniciativa y obedece al ent. Un árbol permanece animado durante 1 día o hasta que muera, hasta que muera el ent o hasta que esté a 120 pies o más de distancia de él. Luego, el árbol echa raíces si es posible."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageVulnerabilities": [
        "fuego"
      ],
      "damageResistances": [
        "contundente",
        "perforante"
      ],
      "senses": [
        "Percepción pasiva 13"
      ],
      "languages": [
        "común",
        "druídico",
        "elfo",
        "silvano"
      ],
      "cr": "9",
      "proficiencyBonus": 4,
      "xp": 5000
    },
    {
      "id": "erinia",
      "name": "Erinia",
      "size": "Mediano",
      "type": "infernal",
      "alignment": "legal malvado",
      "ac": 18,
      "initiative": {
        "modifier": 7,
        "score": 17
      },
      "hp": {
        "average": 178,
        "formula": "21d8 + 84"
      },
      "speed": {
        "walk": "30 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 16,
        "con": 18,
        "int": 14,
        "wis": 14,
        "cha": 18
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 7
        },
        {
          "ability": "con",
          "bonus": 8
        },
        {
          "ability": "int",
          "bonus": 2
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 8
        }
      ],
      "traits": [
        {
          "name": "Cuerda mágica",
          "text": "La erinia tiene una cuerda mágica. Mientras la empuñe, puede utilizar la acción de cuerda enmarañadora. La cuerda tiene una CA de 20, 90 pg e inmunidad al daño psíquico y de veneno. La cuerda se convierte en polvo si sus puntos de golpe se reducen a 0, si está a más de 5 pies de la erinia durante 1 hora o más o si la erinia muere. Si la cuerda sufre daño o se destruye, la erinia puede restaurarla por completo al finalizar un descanso corto o largo."
        },
        {
          "name": "Recuperación diabólica",
          "text": "Si la erinia muere fuera de los Nueve Infiernos, su cuerpo se desvanece en un humo sulfuroso, obtiene un cuerpo nuevo al instante y revive con todos sus puntos de golpe en algún lugar de los Nueve Infiernos."
        },
        {
          "name": "Resistencia mágica",
          "text": "La erinia tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "La erinia realiza tres ataques con su espada marchitadora y puede emplear su cuerda enmarañadora."
        },
        {
          "name": "Espada marchitadora",
          "text": "Tirada de ataque cuerpo a cuerpo: +8, alcance 5 pies. Acierto: 13 (2d8 + 4) de daño cortante más 11 (2d10) de daño necrótico. Cuerda enmarañadora (requiere la cuerda mágica). Tirada de salvación de Fuerza: CD 16, una criatura que la erinia pueda ver a 120 pies o menos. Fallo: 14 (4d6) de daño de fuerza y el objetivo tendrá el estado de apresado hasta que se destruya la cuerda, que la erinia use una acción adicional para soltarlo o que vuelva a usar la cuerda enmarañadora."
        }
      ],
      "bonusActions": [],
      "reactions": [
        {
          "name": "Parada",
          "text": "Detonante: una tirada de ataque cuerpo a cuerpo acierta a la erinia mientras sostiene un arma. Respuesta: la erinia suma 4 a su CA contra ese ataque, lo que puede hacer que falle. Esfinges"
        }
      ],
      "subtype": "diablo",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 6
        },
        {
          "name": "Persuasión",
          "bonus": 8
        }
      ],
      "damageResistances": [
        "frío"
      ],
      "damageImmunities": [
        "fuego",
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado"
      ],
      "senses": [
        "visión verdadera 120 pies",
        "Percepción pasiva 16"
      ],
      "languages": [
        "infernal",
        "telepatía 120 pies"
      ],
      "cr": "12",
      "proficiencyBonus": 4,
      "xp": 8400
    },
    {
      "id": "esfinge_de_las_maravillas",
      "name": "Esfinge de las maravillas",
      "size": "Diminuto",
      "type": "celestial",
      "alignment": "legal bueno",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 24,
        "formula": "7d4 + 7"
      },
      "speed": {
        "walk": "20 pies",
        "fly": "40 pies"
      },
      "abilities": {
        "str": 6,
        "dex": 17,
        "con": 13,
        "int": 15,
        "wis": 12,
        "cha": 11
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -2
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 2
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [
        {
          "name": "Resistencia mágica",
          "text": "La esfinge tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 5 (1d4 + 3) de daño cortante más 7 (2d6) de daño radiante."
        }
      ],
      "bonusActions": [],
      "reactions": [
        {
          "name": "Arranque de ingenio (2/día)",
          "text": "Detonante: la esfinge u otra criatura a 30 pies o menos hace una prueba de característica o una tirada de salvación. Respuesta: la esfinge suma 2 a la tirada."
        }
      ],
      "skills": [
        {
          "name": "Conocimiento arcano",
          "bonus": 4
        },
        {
          "name": "Religión",
          "bonus": 4
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "damageResistances": [
        "necrótico",
        "psíquico",
        "radiante"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 11"
      ],
      "languages": [
        "celestial",
        "común"
      ],
      "cr": "1",
      "proficiencyBonus": 2,
      "xp": 200
    },
    {
      "id": "esfinge_del_conocimiento",
      "name": "Esfinge del conocimiento",
      "size": "Grande",
      "type": "celestial",
      "alignment": "legal neutral",
      "ac": 17,
      "initiative": {
        "modifier": 10,
        "score": 20
      },
      "hp": {
        "average": 170,
        "formula": "20d10 + 60"
      },
      "speed": {
        "walk": "40 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 15,
        "con": 16,
        "int": 18,
        "wis": 18,
        "cha": 18
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": 4
        },
        {
          "ability": "wis",
          "bonus": 4
        },
        {
          "ability": "cha",
          "bonus": 4
        }
      ],
      "traits": [
        {
          "name": "Inescrutable",
          "text": "La magia no puede observar desde lejos a la esfinge ni detectar sus pensamientos sin su permiso. Las pruebas de Sabiduría (Perspicacia) realizadas para determinar sus intenciones tienen desventaja. Resistencia legendaria (3/día o 4/día en la guarida). La esfinge puede elegir tener éxito en una tirada de salvación que haya fallado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "La esfinge realiza tres ataques con sus garras."
        },
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +8, alcance 5 pies. Acierto: 14 (3d6 + 4) de daño cortante."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "La esfinge lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza la Inteligencia como aptitud mágica (CD de salvación de conjuros 16): A voluntad: detectar magia, identificar, ilusión menor, mano de mago, prestidigitación 1/día cada uno: conocer las leyendas, desplazamiento entre planos, disipar magia, don de lenguas, levantar maldición, localizar objeto"
        },
        {
          "name": "Rugido desgarramentes (recarga 5–6)",
          "text": "Tirada de salvación de Sabiduría: CD 16, todos los enemigos en una emanación de 300 pies que se origina en la esfinge. Fallo: 35 (10d6) de daño psíquico y el objetivo tendrá el estado de incapacitado hasta el principio del siguiente turno de la esfinge."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, la esfinge puede emplear un uso para llevar a cabo una de las siguientes acciones. La esfinge recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Merodeo arcano",
          "text": "La esfinge puede teletransportarse hasta 30 pies a un espacio sin ocupar que pueda ver y realiza un ataque con sus garras."
        },
        {
          "name": "Peso de los años",
          "text": "Tirada de salvación de Constitución: CD 16, una criatura que la esfinge pueda ver a 120 pies o menos. Fallo: el objetivo suma 1 nivel de cansancio. Mientras el objetivo tenga al menos 1 nivel de cansancio, parecerá 3d10 años más viejo. Fallo o éxito: la esfinge no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        }
      ],
      "skills": [
        {
          "name": "Conocimiento arcano",
          "bonus": 12
        },
        {
          "name": "Historia",
          "bonus": 12
        },
        {
          "name": "Percepción",
          "bonus": 8
        },
        {
          "name": "Religión",
          "bonus": 12
        }
      ],
      "damageResistances": [
        "necrótico",
        "radiante"
      ],
      "damageImmunities": [
        "psíquico"
      ],
      "conditionImmunities": [
        "asustado",
        "hechizado"
      ],
      "senses": [
        "visión verdadera 120 pies",
        "Percepción pasiva 18"
      ],
      "languages": [
        "celestial",
        "común"
      ],
      "cr": "11",
      "proficiencyBonus": 4,
      "xp": 7200,
      "xpText": "7200 PX u 8400 en la guarida"
    },
    {
      "id": "esfinge_del_valor",
      "name": "Esfinge del valor",
      "size": "Grande",
      "type": "celestial",
      "alignment": "legal neutral",
      "ac": 17,
      "initiative": {
        "modifier": 12,
        "score": 22
      },
      "hp": {
        "average": 199,
        "formula": "19d10 + 95"
      },
      "speed": {
        "walk": "40 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 22,
        "dex": 10,
        "con": 20,
        "int": 16,
        "wis": 23,
        "cha": 18
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 6
        },
        {
          "ability": "dex",
          "bonus": 6
        },
        {
          "ability": "con",
          "bonus": 11
        },
        {
          "ability": "int",
          "bonus": 9
        },
        {
          "ability": "wis",
          "bonus": 12
        },
        {
          "ability": "cha",
          "bonus": 4
        }
      ],
      "traits": [
        {
          "name": "Inescrutable",
          "text": "La magia no puede observar desde lejos a la esfinge ni detectar sus pensamientos sin su permiso. Las pruebas de Sabiduría (Perspicacia) realizadas para determinar sus intenciones tienen desventaja. Resistencia legendaria (3/día o 4/día en la guarida). La esfinge puede elegir tener éxito en una tirada de salvación que haya fallado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "La esfinge realiza dos ataques con sus garras y emplea su rugido."
        },
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +12, alcance 5 pies. Acierto: 20 (4d6 + 6) de daño cortante."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "La esfinge lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza la Sabiduría como aptitud mágica (CD de salvación de conjuros 20): A voluntad: detectar el bien y el mal, taumaturgia 1/día cada uno: detectar magia, disipar magia, festín de héroes, restablecimiento mayor, zona de la verdad"
        },
        {
          "name": "Rugido (3/día)",
          "text": "La esfinge emite un rugido mágico. Cada vez que ruja, el rugido tendrá un efecto distinto, como se detalla a continuación (la secuencia se reinicia cada vez que haga un descanso largo):"
        },
        {
          "name": "Primer rugido",
          "text": "Tirada de salvación de Sabiduría: CD 20, todos los enemigos en una emanación de 500 pies que se origina en la esfinge. Fallo: el objetivo tendrá el estado de asustado durante 1 minuto."
        },
        {
          "name": "Segundo rugido",
          "text": "Tirada de salvación de Sabiduría: CD 20, todos los enemigos en una emanación de 500 pies que se origina en la esfinge. Fallo: el objetivo tendrá el estado de paralizado y repetirá la tirada de salvación al final de cada uno de sus turnos. Si tiene éxito, se librará del efecto. Tras 1 minuto, tendrá éxito automáticamente."
        },
        {
          "name": "Tercer rugido",
          "text": "Tirada de salvación de Constitución: CD 20, todos los enemigos en una emanación de 500 pies que se origina en la esfinge. Fallo: 44 (8d10) de daño de trueno y el objetivo tendrá el estado de derribado. Éxito: solo la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, la esfinge puede emplear un uso para llevar a cabo una de las siguientes acciones. La esfinge recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Merodeo arcano",
          "text": "La esfinge puede teletransportarse hasta 30 pies a un espacio sin ocupar que pueda ver y realiza un ataque con sus garras."
        },
        {
          "name": "Peso de los años",
          "text": "Tirada de salvación de Constitución: CD 16, una criatura que la esfinge pueda ver a 120 pies o menos. Fallo: el objetivo suma 1 nivel de cansancio. Mientras el objetivo tenga al menos 1 nivel de cansancio, parecerá 3d10 años más viejo. Fallo o éxito: la esfinge no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        }
      ],
      "skills": [
        {
          "name": "Conocimiento arcano",
          "bonus": 9
        },
        {
          "name": "Percepción",
          "bonus": 12
        },
        {
          "name": "Religión",
          "bonus": 15
        }
      ],
      "damageResistances": [
        "necrótico",
        "radiante"
      ],
      "damageImmunities": [
        "psíquico"
      ],
      "conditionImmunities": [
        "asustado",
        "hechizado"
      ],
      "senses": [
        "visión verdadera 120 pies",
        "Percepción pasiva 22"
      ],
      "languages": [
        "celestial",
        "común"
      ],
      "cr": "17",
      "proficiencyBonus": 6,
      "xp": 18000,
      "xpText": "18 000 PX o 20 000 en la guarida"
    },
    {
      "id": "espectro",
      "name": "Espectro",
      "size": "Mediano",
      "type": "muerto viviente",
      "alignment": "caótico malvado",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 22,
        "formula": "5d8"
      },
      "speed": {
        "walk": "30 pies",
        "fly": "50 pies (levitar)"
      },
      "abilities": {
        "str": 1,
        "dex": 14,
        "con": 11,
        "int": 10,
        "wis": 10,
        "cha": 11
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -5
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [
        {
          "name": "Movimiento incorpóreo",
          "text": "El espectro puede moverse a través de otras criaturas y objetos como si fueran terreno difícil. Recibe 5 (1d10) de daño de fuerza si acaba su turno dentro de un objeto."
        },
        {
          "name": "Sensibilidad a la luz solar",
          "text": "Bajo la luz del sol, el espectro tiene desventaja en las pruebas de característica y las tiradas de ataque."
        }
      ],
      "actions": [
        {
          "name": "Consumir vida",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 7 (2d6) de daño necrótico. Si el objetivo es una criatura, sus puntos de golpe máximos se reducen en una cantidad igual al daño sufrido."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageResistances": [
        "ácido",
        "contundente",
        "cortante",
        "frío",
        "fuego",
        "perforante",
        "relámpago",
        "trueno"
      ],
      "damageImmunities": [
        "necrótico",
        "veneno"
      ],
      "conditionImmunities": [
        "agarrado",
        "apresado",
        "cansancio",
        "derribado",
        "envenenado",
        "hechizado",
        "inconsciente",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "entiende común y otro idioma, pero no puede hablar"
      ],
      "cr": "1",
      "proficiencyBonus": 2,
      "xp": 200
    },
    {
      "id": "espia",
      "name": "Espía",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 12,
      "initiative": {
        "modifier": 4,
        "score": 14
      },
      "hp": {
        "average": 27,
        "formula": "6d8"
      },
      "speed": {
        "walk": "30 pies",
        "climb": "30 pies"
      },
      "abilities": {
        "str": 10,
        "dex": 15,
        "con": 10,
        "int": 12,
        "wis": 14,
        "cha": 16
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 0
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 3
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Espada corta",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 5 (1d6 + 2) de daño perforante más 7 (2d6) de daño de veneno."
        },
        {
          "name": "Ballesta de mano",
          "text": "Tirada de ataque a distancia: +4, alcance 9/120 pies. Acierto: 5 (1d6 + 2) de daño perforante más 7 (2d6) de daño de veneno."
        }
      ],
      "bonusActions": [
        {
          "name": "Acción astuta",
          "text": "El espía realiza las acciones de correr, destrabarse o esconderse. Esqueletos"
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Engaño",
          "bonus": 5
        },
        {
          "name": "Investigación",
          "bonus": 5
        },
        {
          "name": "Juego de manos",
          "bonus": 4
        },
        {
          "name": "Percepción",
          "bonus": 6
        },
        {
          "name": "Perspicacia",
          "bonus": 4
        },
        {
          "name": "Sigilo",
          "bonus": 6
        }
      ],
      "equipment": [
        "ballesta de mano",
        "espada corta",
        "herramientas de ladrón"
      ],
      "senses": [
        "Percepción pasiva 16"
      ],
      "languages": [
        "común y otro cualquiera"
      ],
      "cr": "1",
      "proficiencyBonus": 2,
      "xp": 200
    },
    {
      "id": "esqueleto",
      "name": "Esqueleto",
      "size": "Mediano",
      "type": "muerto viviente",
      "alignment": "legal malvado",
      "ac": 14,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 13,
        "formula": "2d8 + 4"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 10,
        "dex": 16,
        "con": 15,
        "int": 6,
        "wis": 8,
        "cha": 5
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 0
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": -1
        },
        {
          "ability": "cha",
          "bonus": -3
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Espada corta",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 6 (1d6 + 3) de daño perforante."
        },
        {
          "name": "Arco corto",
          "text": "Tirada de ataque a distancia: +5, alcance 24/315 pies. Acierto: 6 (1d6 + 3) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageVulnerabilities": [
        "contundente"
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "cansancio",
        "envenenado"
      ],
      "equipment": [
        "arco corto",
        "espada corta"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 9"
      ],
      "languages": [
        "entiende común y otro idioma, pero no puede hablar"
      ],
      "cr": "1/4",
      "proficiencyBonus": 2,
      "xp": 50
    },
    {
      "id": "caballo_de_guerra_esqueleto",
      "name": "Caballo de guerra esqueleto",
      "size": "Grande",
      "type": "muerto viviente",
      "alignment": "legal malvado",
      "ac": 13,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 22,
        "formula": "3d10 + 6"
      },
      "speed": {
        "walk": "60 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 12,
        "con": 15,
        "int": 2,
        "wis": 8,
        "cha": 5
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": -1
        },
        {
          "ability": "cha",
          "bonus": -3
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Cascos",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 7 (1d6 + 4) de daño contundente. Si el objetivo es una criatura Grande o más pequeña y el esqueleto recorre al menos 20 pies en línea recta hacia ella justo antes de acertarle, tendrá el estado de derribada."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageVulnerabilities": [
        "contundente"
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "cansancio",
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 9"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/2",
      "proficiencyBonus": 2,
      "xp": 100
    },
    {
      "id": "minotauro_esqueleto",
      "name": "Minotauro esqueleto",
      "size": "Grande",
      "type": "muerto viviente",
      "alignment": "legal malvado",
      "ac": 12,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 45,
        "formula": "6d10 + 12"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 11,
        "con": 15,
        "int": 6,
        "wis": 8,
        "cha": 5
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": -1
        },
        {
          "ability": "cha",
          "bonus": -3
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Cornada",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 11 (2d6 + 4) de daño perforante. Si el objetivo es una criatura Grande o más pequeña y el esqueleto recorre al menos 20 pies en línea recta hacia ella justo antes de acertarle, esta recibirá 9 (2d8) de daño perforante adicional y tendrá el estado de derribada."
        },
        {
          "name": "Golpe",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 15 (2d10 + 4) de daño contundente."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageVulnerabilities": [
        "contundente"
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "cansancio",
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 9"
      ],
      "languages": [
        "entiende abisal, pero no puede hablar"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "estirge",
      "name": "Estirge",
      "size": "Diminuta",
      "type": "monstruosidad",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 5,
        "formula": "2d4"
      },
      "speed": {
        "walk": "10 pies",
        "fly": "40 pies"
      },
      "abilities": {
        "str": 4,
        "dex": 16,
        "con": 11,
        "int": 2,
        "wis": 8,
        "cha": 6
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -3
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": -1
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Probóscide",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 6 (1d6 + 3) de daño perforante y la estirge se engancha al objetivo. Mientras esté enganchada, no podrá hacer ataques con su probóscide y el objetivo sufrirá 5 (2d4) de daño necrótico al principio de cada turno de la estirge. La estirge puede usar 5 pies de su movimiento para desengancharse. Como acción, el objetivo o una criatura a 5 pies o menos de él puede desenganchar a la estirge."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 9"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/8",
      "proficiencyBonus": 2,
      "xp": 25
    },
    {
      "id": "ettercap",
      "name": "Ettercap",
      "size": "Mediana",
      "type": "monstruosidad",
      "alignment": "neutral malvada",
      "ac": 13,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 44,
        "formula": "8d8 + 8"
      },
      "speed": {
        "walk": "30 pies",
        "climb": "30 pies"
      },
      "abilities": {
        "str": 14,
        "dex": 15,
        "con": 13,
        "int": 7,
        "wis": 12,
        "cha": 8
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [
        {
          "name": "Caminar por telarañas",
          "text": "El ettercap ignora todas las restricciones de movimiento causadas por las telarañas y conoce la ubicación de cualquier otra criatura que esté en contacto con la misma telaraña."
        },
        {
          "name": "Trepar cual arácnido",
          "text": "El ettercap puede trepar por superficies difíciles e incluso recorrer techos sin tener que realizar pruebas de característica."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El ettercap realiza un ataque de mordisco y uno con sus garras."
        },
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 7 (2d4 + 2) de daño cortante."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 5 (1d6 + 2) de daño perforante más 2 (1d4) de daño de veneno y el objetivo tendrá el estado de envenenado hasta el principio del siguiente turno del ettercap."
        },
        {
          "name": "Hebra de telaraña (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 12, una criatura Grande o más pequeña que el ettercap pueda ver a 30 pies o menos. Fallo: el objetivo tendrá el estado de apresado hasta que se destruya la telaraña (CA 10, 5 pg, vulnerabilidad a daño de fuego e inmunidad a daño contundente, psíquico y de veneno)."
        }
      ],
      "bonusActions": [
        {
          "name": "Atraer",
          "text": "El ettercap atrae hasta 25 pies en línea recta hacia él a una criatura a 30 pies o menos de él que esté apresada por su hebra de telaraña."
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 3
        },
        {
          "name": "Sigilo",
          "bonus": 4
        },
        {
          "name": "Supervivencia",
          "bonus": 3
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 13"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "ettin",
      "name": "Ettin",
      "size": "Grande",
      "type": "gigante",
      "alignment": "caótico malvado",
      "ac": 12,
      "initiative": {
        "modifier": -1,
        "score": 9
      },
      "hp": {
        "average": 85,
        "formula": "10d10 + 30"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 21,
        "dex": 8,
        "con": 17,
        "int": 6,
        "wis": 10,
        "cha": 8
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 5
        },
        {
          "ability": "dex",
          "bonus": -1
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El ettin realiza un ataque con su hacha de guerra y uno con su lucero del alba."
        },
        {
          "name": "Hacha de guerra",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 14 (2d8 + 5) de daño cortante. Si el objetivo es una criatura Grande o más pequeña, tendrá el estado de derribada."
        },
        {
          "name": "Lucero del alba",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 14 (2d8 + 5) de daño perforante y el objetivo tendrá desventaja en la siguiente tirada de ataque que haga antes del final de su siguiente turno."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 4
        }
      ],
      "conditionImmunities": [
        "asustado",
        "aturdido",
        "cegado",
        "ensordecido",
        "hechizado",
        "inconsciente"
      ],
      "equipment": [
        "hacha de guerra",
        "lucero del alba"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "gigante"
      ],
      "cr": "4",
      "proficiencyBonus": 2,
      "xp": 1100
    },
    {
      "id": "fantasma",
      "name": "Fantasma",
      "size": "Mediano",
      "type": "muerto viviente",
      "alignment": "neutral",
      "ac": 11,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 45,
        "formula": "10d8"
      },
      "speed": {
        "walk": "5 pies",
        "fly": "40 pies (levitar)"
      },
      "abilities": {
        "str": 7,
        "dex": 13,
        "con": 10,
        "int": 10,
        "wis": 12,
        "cha": 17
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -2
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": 3
        }
      ],
      "traits": [
        {
          "name": "Movimiento incorpóreo",
          "text": "El fantasma puede moverse a través de otras criaturas y objetos como si fueran terreno difícil. Recibe 5 (1d10) de daño de fuerza si acaba su turno dentro de un objeto."
        },
        {
          "name": "Visión etérea",
          "text": "El fantasma puede ver a 60 pies de distancia en el Plano Etéreo cuando se encuentra en el Plano Material."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El fantasma realiza dos ataques de toque marchitador."
        },
        {
          "name": "Toque marchitador",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 19 (3d10 + 3) de daño necrótico."
        },
        {
          "name": "Etéreo",
          "text": "El fantasma lanza el conjuro excursión etérea, que no requiere componentes y utiliza el Carisma como aptitud mágica. El fantasma es visible en el Plano Material mientras está en la Frontera Etérea y viceversa, pero no puede afectar a nada en el otro plano ni ser afectado por nada del otro plano."
        },
        {
          "name": "Poseer (recarga 6)",
          "text": "Tirada de salvación de Carisma: CD 13, un humanoide que el fantasma pueda ver a 5 pies o menos. Fallo: el objetivo será poseído por el fantasma, que desaparecerá. El objetivo tendrá el estado de incapacitado y perderá el control de su cuerpo. Desde ese momento, el fantasma controlará el cuerpo, pero el objetivo conservará su consciencia. El fantasma no podrá ser objetivo de ningún ataque, conjuro u otro efecto, salvo los que hagan objetivo a muertos vivientes de forma específica. El perfil del fantasma permanecerá igual, salvo que empleará la velocidad y modificadores por Fuerza, Destreza y Constitución del objetivo poseído. La posesión durará hasta que los puntos de golpe del cuerpo se reduzcan a 0 o el fantasma lo abandone como acción adicional. Cuando termine la posesión, el fantasma aparecerá en un espacio sin ocupar a 5 pies del objetivo, que será inmune a la posesión de este fantasma durante 24 horas. Éxito: el objetivo será inmune a la posesión de este fantasma durante 24 horas."
        },
        {
          "name": "Rostro horripilante",
          "text": "Tirada de salvación de Sabiduría: CD 13, todas las criaturas en un cono de 60 pies que el fantasma pueda ver y no sean muertos vivientes. Fallo: 10 (2d6 + 3) de daño psíquico y el objetivo tendrá el estado de asustado hasta el principio del siguiente turno del fantasma. Éxito: el objetivo será inmune al rostro horripilante de este fantasma durante 24 horas."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageResistances": [
        "ácido",
        "contundente",
        "cortante",
        "frío",
        "fuego",
        "perforante",
        "relámpago",
        "trueno"
      ],
      "damageImmunities": [
        "necrótico",
        "veneno"
      ],
      "conditionImmunities": [
        "agarrado",
        "apresado",
        "asustado",
        "cansancio",
        "derribado",
        "envenenado",
        "hechizado",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 11"
      ],
      "languages": [
        "común y otro cualquiera"
      ],
      "cr": "4",
      "proficiencyBonus": 2,
      "xp": 1100
    },
    {
      "id": "fuego_fatuo",
      "name": "Fuego fatuo",
      "size": "Diminuto",
      "type": "muerto viviente",
      "alignment": "caótico malvado",
      "ac": 19,
      "initiative": {
        "modifier": 9,
        "score": 19
      },
      "hp": {
        "average": 27,
        "formula": "11d4"
      },
      "speed": {
        "walk": "5 pies",
        "fly": "50 pies (levitar)"
      },
      "abilities": {
        "str": 1,
        "dex": 28,
        "con": 10,
        "int": 13,
        "wis": 14,
        "cha": 11
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -5
        },
        {
          "ability": "dex",
          "bonus": 9
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [
        {
          "name": "Efímero",
          "text": "El fuego fatuo no puede llevar puesto ni transportar nada."
        },
        {
          "name": "Iluminación",
          "text": "El fuego fatuo emite luz brillante en un radio de 20 pies y luz tenue 20 pies más allá."
        },
        {
          "name": "Movimiento incorpóreo",
          "text": "El fuego fatuo puede moverse a través de otras criaturas y objetos como si fueran terreno difícil. Recibe 5 (1d10) de daño de fuerza si acaba su turno dentro de un objeto."
        }
      ],
      "actions": [
        {
          "name": "Descarga",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 11 (2d8 + 2) de daño de relámpago."
        }
      ],
      "bonusActions": [
        {
          "name": "Desvanecerse",
          "text": "El fuego fatuo y su luz tienen el estado de invisibles hasta que el fuego fatuo deje de concentrarse en este efecto, que terminará antes de tiempo inmediatamente después de que el fuego fatuo haga una tirada de ataque o use su acción de devorar vida."
        },
        {
          "name": "Devorar vida",
          "text": "Tirada de salvación de Constitución: CD 10, una criatura viva que el fuego fatuo pueda ver a 5 pies o menos y tenga 0 puntos de golpe. Fallo: el objetivo muere y el fuego fatuo recupera 10 (3d6) puntos de golpe."
        }
      ],
      "reactions": [],
      "damageResistances": [
        "ácido",
        "contundente",
        "cortante",
        "frío",
        "fuego",
        "necrótico",
        "perforante"
      ],
      "damageImmunities": [
        "relámpago",
        "veneno"
      ],
      "conditionImmunities": [
        "agarrado",
        "apresado",
        "cansancio",
        "derribado",
        "envenenado",
        "inconsciente",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión en la oscuridad 120 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "común y otro cualquiera"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "gargola",
      "name": "Gárgola",
      "size": "Mediano",
      "type": "elemental",
      "alignment": "caótico malvado",
      "ac": 15,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 67,
        "formula": "9d8 + 27"
      },
      "speed": {
        "walk": "30 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 15,
        "dex": 11,
        "con": 16,
        "int": 6,
        "wis": 11,
        "cha": 7
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [
        {
          "name": "Pasar volando",
          "text": "La gárgola no provoca ataques de oportunidad cuando vuela para ponerse fuera del alcance de un enemigo."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "La gárgola realiza dos ataques con sus garras."
        },
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 7 (2d4 + 2) de daño cortante."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "cansancio",
        "envenenado",
        "petrificado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "primordial (terrano)"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "garra_reptante",
      "name": "Garra reptante",
      "size": "Mediano",
      "type": "muerto viviente",
      "subtype": "enjambre",
      "alignment": "neutral malvado",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 49,
        "formula": "11d8"
      },
      "speed": {
        "walk": "30 pies",
        "climb": "30 pies"
      },
      "abilities": {
        "str": 14,
        "dex": 14,
        "con": 11,
        "int": 5,
        "wis": 10,
        "cha": 4
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": -3
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -3
        }
      ],
      "damageResistances": [
        "contundente",
        "cortante",
        "perforante"
      ],
      "damageImmunities": [
        "necrótico",
        "veneno"
      ],
      "conditionImmunities": [
        "agarrado",
        "apresado",
        "asustado",
        "aturdido",
        "cansancio",
        "derribado",
        "envenenado",
        "hechizado",
        "incapacitado",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión ciega 30 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "entiende común, pero no puede hablar"
      ],
      "cr": "3",
      "xp": 700,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Enjambre",
          "text": "El enjambre puede ocupar el espacio de otra criatura y viceversa, y es capaz de atravesar cualquier abertura por la que quepa una criatura Diminuta. El enjambre no puede recuperar puntos de golpe ni obtener puntos de golpe temporales."
        }
      ],
      "actions": [
        {
          "name": "Enjambre de manos apresadoras",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 20 (4d8 + 2) de daño necrótico u 11 (2d8 + 2) de daño necrótico si el enjambre está maltrecho. Si el objetivo es una criatura Mediana o más pequeña, tendrá el estado de derribada."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "gelatina_ocre",
      "name": "Gelatina ocre",
      "size": "Grande",
      "type": "cieno",
      "alignment": "sin alineamiento",
      "ac": 8,
      "initiative": {
        "modifier": -2,
        "score": 8
      },
      "hp": {
        "average": 52,
        "formula": "7d10 + 14"
      },
      "speed": {
        "walk": "20 pies",
        "climb": "20 pies"
      },
      "abilities": {
        "str": 15,
        "dex": 6,
        "con": 14,
        "int": 2,
        "wis": 6,
        "cha": 1
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": -2
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": -2
        },
        {
          "ability": "cha",
          "bonus": -5
        }
      ],
      "traits": [
        {
          "name": "Amorfa",
          "text": "La gelatina puede moverse a través de un espacio de solo 1 pulgada de ancho sin gastar movimiento adicional para hacerlo."
        },
        {
          "name": "Trepar cual arácnido",
          "text": "La gelatina puede trepar por superficies difíciles e incluso recorrer techos sin tener que realizar pruebas de característica."
        }
      ],
      "actions": [
        {
          "name": "Pseudópodo",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 12 (3d6 + 2) de daño de ácido."
        }
      ],
      "bonusActions": [],
      "reactions": [
        {
          "name": "Dividirse",
          "text": "Detonante: mientras sea Grande o Mediana y tenga 10 o más puntos de golpe, la gelatina pasa a estar maltrecha o recibe daño cortante o de relámpago. Respuesta: la gelatina se divide en dos nuevas gelatinas ocres. Cada nueva gelatina tiene un tamaño inferior al de la gelatina original y actúa en su orden de iniciativa. Los puntos de golpe de la gelatina original se dividen a partes iguales entre las nuevas gelatinas (redondeados hacia abajo)."
        }
      ],
      "damageResistances": [
        "ácido"
      ],
      "damageImmunities": [
        "cortante",
        "relámpago"
      ],
      "conditionImmunities": [
        "agarrado",
        "apresado",
        "asustado",
        "cansancio",
        "derribado",
        "ensordecido",
        "hechizado"
      ],
      "senses": [
        "visión ciega 60 pies",
        "Percepción pasiva 8"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "ghast",
      "name": "Ghast",
      "size": "Mediano",
      "type": "muerto viviente",
      "alignment": "caótico malvado",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 36,
        "formula": "8d8"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 17,
        "con": 10,
        "int": 11,
        "wis": 10,
        "cha": 8
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [
        {
          "name": "Hedor",
          "text": "Tirada de salvación de Constitución: CD 10, cualquier criatura que empiece su turno en una emanación de 5 pies que se origina en el ghast. Fallo: el objetivo tendrá el estado de envenenado hasta el principio de su siguiente turno. Éxito: el objetivo será inmune al hedor de este ghast durante 24 horas."
        }
      ],
      "actions": [
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 10 (2d6 + 3) de daño cortante. Si el objetivo es una criatura que no sea un muerto viviente, sufre el siguiente efecto. Tirada de salvación de Constitución: CD 10. Fallo: el objetivo tendrá el estado de paralizado hasta el final de su siguiente turno."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 7 (1d8 + 3) de daño perforante más 9 (2d8) de daño necrótico."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageResistances": [
        "necrótico"
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "cansancio",
        "envenenado",
        "hechizado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "común"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "gigante_de_escarcha",
      "name": "Gigante de escarcha",
      "size": "Enorme",
      "type": "gigante",
      "alignment": "neutral malvado",
      "ac": 15,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 149,
        "formula": "13d12 + 65"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 23,
        "dex": 9,
        "con": 21,
        "int": 9,
        "wis": 10,
        "cha": 12
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 6
        },
        {
          "ability": "dex",
          "bonus": -1
        },
        {
          "ability": "con",
          "bonus": 8
        },
        {
          "ability": "int",
          "bonus": -1
        },
        {
          "ability": "wis",
          "bonus": 3
        },
        {
          "ability": "cha",
          "bonus": 4
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El gigante realiza dos ataques con su hacha escarchada o su gran arco en cualquier combinación."
        },
        {
          "name": "Hacha escarchada",
          "text": "Tirada de ataque cuerpo a cuerpo: +9, alcance 10 pies. Acierto: 19 (2d12 + 6) de daño cortante más 9 (2d8) de daño de frío."
        },
        {
          "name": "Gran arco",
          "text": "Tirada de ataque a distancia: +9, alcance 45/600 pies. Acierto: 17 (2d10 + 6) de daño perforante más 7 (2d6) de daño de frío y la velocidad del objetivo se reducirá en 10 pies hasta el final de su siguiente turno."
        }
      ],
      "bonusActions": [
        {
          "name": "Grito de guerra (recarga 5–6)",
          "text": "El gigante o una criatura de su elección que pueda verlo u oírlo obtiene 16 (2d10 + 5) puntos de golpe temporales y ventaja en las tiradas de ataque hasta el principio del siguiente turno del gigante."
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Atletismo",
          "bonus": 9
        },
        {
          "name": "Percepción",
          "bonus": 3
        }
      ],
      "damageImmunities": [
        "frío"
      ],
      "senses": [
        "Percepción pasiva 13"
      ],
      "languages": [
        "gigante"
      ],
      "cr": "8",
      "proficiencyBonus": 3,
      "xp": 3900
    },
    {
      "id": "gigante_de_fuego",
      "name": "Gigante de fuego",
      "size": "Enorme",
      "type": "gigante",
      "alignment": "legal malvado",
      "ac": 18,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 162,
        "formula": "13d12 + 78"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 25,
        "dex": 9,
        "con": 23,
        "int": 10,
        "wis": 14,
        "cha": 13
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 7
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 10
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 5
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El gigante realiza dos ataques con su espada flamígera o su lanzamiento de martillo en cualquier combinación."
        },
        {
          "name": "Espada flamígera",
          "text": "Tirada de ataque cuerpo a cuerpo: +11, alcance 10 pies. Acierto: 21 (4d6 + 7) de daño cortante más 10 (3d6) de daño de fuego."
        },
        {
          "name": "Lanzamiento de martillo",
          "text": "Tirada de ataque a distancia: +11, alcance 18/236 pies. Acierto: 23 (3d10 + 7) de daño contundente más 4 (1d8) de daño de fuego y el objetivo será empujado hasta 15 pies respecto al gigante en línea recta y tendrá desventaja en la próxima tirada de ataque que haga antes del final de su siguiente turno."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Atletismo",
          "bonus": 11
        },
        {
          "name": "Percepción",
          "bonus": 6
        }
      ],
      "damageImmunities": [
        "fuego"
      ],
      "senses": [
        "Percepción pasiva 16"
      ],
      "languages": [
        "gigante"
      ],
      "cr": "9",
      "proficiencyBonus": 4,
      "xp": 5000
    },
    {
      "id": "gigante_de_las_colinas",
      "name": "Gigante de las colinas",
      "size": "Enorme",
      "type": "gigante",
      "alignment": "caótico malvado",
      "ac": 13,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 105,
        "formula": "10d12 + 40"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 21,
        "dex": 8,
        "con": 19,
        "int": 5,
        "wis": 9,
        "cha": 6
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 5
        },
        {
          "ability": "dex",
          "bonus": -1
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": -3
        },
        {
          "ability": "wis",
          "bonus": -1
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El gigante hace dos ataques con su árbol garrote o su lanzamiento de basura en cualquier combinación."
        },
        {
          "name": "Árbol garrote",
          "text": "Tirada de ataque cuerpo a cuerpo: +8, alcance 10 pies. Acierto: 18 (3d8 + 5) de daño contundente. Si el objetivo es una criatura Grande o más pequeña, tendrá el estado de derribada."
        },
        {
          "name": "Lanzamiento de basura",
          "text": "Tirada de ataque a distancia: +8, alcance 18/236 pies. Acierto: 16 (2d10 + 5) de daño contundente y el objetivo tendrá el estado de envenenado hasta el final de su siguiente turno."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 2
        }
      ],
      "senses": [
        "Percepción pasiva 12"
      ],
      "languages": [
        "gigante"
      ],
      "cr": "5",
      "proficiencyBonus": 3,
      "xp": 1800
    },
    {
      "id": "gigante_de_las_nubes",
      "name": "Gigante de las nubes",
      "size": "Enorme",
      "type": "gigante",
      "alignment": "neutral",
      "ac": 14,
      "initiative": {
        "modifier": 4,
        "score": 14
      },
      "hp": {
        "average": 200,
        "formula": "16d12 + 96"
      },
      "speed": {
        "walk": "40 pies",
        "fly": "20 pies (levitar)"
      },
      "abilities": {
        "str": 27,
        "dex": 10,
        "con": 22,
        "int": 12,
        "wis": 16,
        "cha": 16
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 8
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 10
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 7
        },
        {
          "ability": "cha",
          "bonus": 3
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El gigante realiza dos ataques con su maza atronadora o su nube de tormenta en cualquier combinación. Puede sustituir un ataque por un uso de su lanzamiento de conjuros para lanzar nube de oscurecimiento."
        },
        {
          "name": "Maza atronadora",
          "text": "Tirada de ataque cuerpo a cuerpo: +12, alcance 10 pies. Acierto: 21 (3d8 + 8) de daño contundente más 7 (2d6) de daño de trueno."
        },
        {
          "name": "Nube de tormenta",
          "text": "Tirada de ataque a distancia: +12, alcance 236 pies. Acierto: 18 (3d6 + 8) de daño de trueno y el objetivo tendrá el estado de incapacitado hasta el final de su siguiente turno."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El gigante lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 15): A voluntad: detectar magia, luz, nube de oscurecimiento 1/día cada uno: controlar el clima, forma gaseosa, telequinesis"
        }
      ],
      "bonusActions": [
        {
          "name": "Paso brumoso",
          "text": "El gigante lanza el conjuro paso brumoso usando la misma aptitud mágica que para su lanzamiento de conjuros."
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 11
        },
        {
          "name": "Perspicacia",
          "bonus": 7
        }
      ],
      "senses": [
        "Percepción pasiva 21"
      ],
      "languages": [
        "común",
        "gigante"
      ],
      "cr": "9",
      "proficiencyBonus": 4,
      "xp": 5000
    },
    {
      "id": "gigante_de_las_tormentas",
      "name": "Gigante de las tormentas",
      "size": "Enorme",
      "type": "gigante",
      "alignment": "caótico bueno",
      "ac": 16,
      "initiative": {
        "modifier": 7,
        "score": 17
      },
      "hp": {
        "average": 230,
        "formula": "20d12 + 100"
      },
      "speed": {
        "walk": "50 pies",
        "swim": "50 pies",
        "fly": "25 pies (levitar)"
      },
      "abilities": {
        "str": 29,
        "dex": 14,
        "con": 20,
        "int": 16,
        "wis": 20,
        "cha": 18
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 14
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 10
        },
        {
          "ability": "int",
          "bonus": 3
        },
        {
          "ability": "wis",
          "bonus": 10
        },
        {
          "ability": "cha",
          "bonus": 9
        }
      ],
      "traits": [
        {
          "name": "Anfibio",
          "text": "El gigante puede respirar tanto dentro como fuera del agua."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El gigante realiza dos ataques con su espada tormentosa o su rayo en cualquier combinación."
        },
        {
          "name": "Espada tormentosa",
          "text": "Tirada de ataque cuerpo a cuerpo: +14, alcance 10 pies. Acierto: 23 (4d6 + 9) de daño cortante más 13 (3d8) de daño de relámpago."
        },
        {
          "name": "Rayo",
          "text": "Tirada de ataque a distancia: +14, alcance 500 pies. Acierto: 22 (2d12 + 9) de daño de relámpago y el objetivo tendrá los estados de cegado y ensordecido hasta el principio del siguiente turno del gigante."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El gigante lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza la Sabiduría como aptitud mágica (CD de salvación de conjuros 18): A voluntad: detectar magia, luz 1/día: controlar el clima"
        },
        {
          "name": "Tormenta de relámpagos (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 18, todas las criaturas en un cilindro de 10 pies de radio y 40 pies de alto que se origina en un punto que el gigante pueda ver a 500 pies o menos."
        },
        {
          "name": "Fallo: 55 (10d10) de daño de relámpago",
          "text": "Éxito: la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Atletismo",
          "bonus": 14
        },
        {
          "name": "Conocimiento arcano",
          "bonus": 8
        },
        {
          "name": "Historia",
          "bonus": 8
        },
        {
          "name": "Percepción",
          "bonus": 10
        }
      ],
      "damageResistances": [
        "frío"
      ],
      "damageImmunities": [
        "relámpago",
        "trueno"
      ],
      "senses": [
        "visión en la oscuridad 120 pies, visión verdadera 30 pies",
        "Percepción pasiva 20"
      ],
      "languages": [
        "común",
        "gigante"
      ],
      "cr": "13",
      "proficiencyBonus": 5,
      "xp": 10000
    },
    {
      "id": "gigante_de_piedra",
      "name": "Gigante de piedra",
      "size": "Enorme",
      "type": "gigante",
      "alignment": "neutral",
      "ac": 17,
      "initiative": {
        "modifier": 5,
        "score": 15
      },
      "hp": {
        "average": 126,
        "formula": "11d12 + 55"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 23,
        "dex": 15,
        "con": 20,
        "int": 10,
        "wis": 12,
        "cha": 9
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 6
        },
        {
          "ability": "dex",
          "bonus": 5
        },
        {
          "ability": "con",
          "bonus": 8
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 4
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El gigante realiza dos ataques con su garrote de piedra o pedrusco en cualquier combinación."
        },
        {
          "name": "Garrote de piedra",
          "text": "Tirada de ataque cuerpo a cuerpo: +9, alcance 15 pies. Acierto: 22 (3d10 + 6) de daño contundente."
        },
        {
          "name": "Pedrusco",
          "text": "Tirada de ataque a distancia: +9, alcance 18/236 pies. Acierto: 15 (2d8 + 6) de daño contundente. Si el objetivo es una criatura Grande o más pequeña, tendrá el estado de derribada."
        }
      ],
      "bonusActions": [],
      "reactions": [
        {
          "name": "Desviar proyectiles (recarga 5–6)",
          "text": "Detonante: una tirada de ataque a distancia acierta al gigante y le hace daño contundente, cortante o perforante. Respuesta: el gigante reduce en 11 (1d10 + 6) el daño que recibe del ataque. Si lo reduce a 0, el gigante puede redirigir una parte de la fuerza del ataque. Tirada de salvación de Destreza: CD 17, una criatura que el gigante pueda ver a 60 pies o menos. Fallo: 11 (1d10 + 6) de daño de fuerza."
        }
      ],
      "skills": [
        {
          "name": "Atletismo",
          "bonus": 12
        },
        {
          "name": "Percepción",
          "bonus": 4
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "gigante"
      ],
      "cr": "7",
      "proficiencyBonus": 3,
      "xp": 2900
    },
    {
      "id": "glabrezu",
      "name": "Glabrezu",
      "size": "Grande",
      "type": "infernal",
      "alignment": "caótico malvado",
      "ac": 17,
      "initiative": {
        "modifier": 6,
        "score": 16
      },
      "hp": {
        "average": 189,
        "formula": "18d10 + 90"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 20,
        "dex": 15,
        "con": 21,
        "int": 19,
        "wis": 17,
        "cha": 16
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 9
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 9
        },
        {
          "ability": "int",
          "bonus": 4
        },
        {
          "ability": "wis",
          "bonus": 7
        },
        {
          "ability": "cha",
          "bonus": 7
        }
      ],
      "traits": [
        {
          "name": "Recuperación demoníaca",
          "text": "Si el glabrezu muere fuera del Abismo, su cuerpo se disuelve en icor, obtiene un cuerpo nuevo al instante y revive con todos sus puntos de golpe en algún lugar del Abismo."
        },
        {
          "name": "Resistencia mágica",
          "text": "El glabrezu tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El glabrezu realiza dos ataques con sus tenazas y usa su acción de aporrear o de lanzamiento de conjuros."
        },
        {
          "name": "Tenaza",
          "text": "Tirada de ataque cuerpo a cuerpo: +9, alcance 10 pies. Acierto: 16 (2d10 + 5) de daño cortante. Si el objetivo es una criatura Mediana o más pequeña, tendrá el estado de agarrada (CD 15 para escapar) por una de las dos tenazas."
        },
        {
          "name": "Aporrear",
          "text": "Tirada de salvación de Destreza: CD 17, una criatura agarrada por el glabrezu. Fallo: 15 (3d6 + 5) de daño contundente. Éxito: la mitad del daño."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El glabrezu lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza la Inteligencia como aptitud mágica (CD de salvación de conjuros 16): A voluntad: detectar magia, disipar magia, oscuridad 1/día cada uno: confusión, palabra de poder: aturdir, volar"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "demonio",
      "skills": [
        {
          "name": "Engaño",
          "bonus": 7
        },
        {
          "name": "Percepción",
          "bonus": 7
        }
      ],
      "damageResistances": [
        "frío",
        "fuego",
        "relámpago"
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado"
      ],
      "senses": [
        "visión verdadera 120 pies",
        "Percepción pasiva 17"
      ],
      "languages": [
        "abisal",
        "telepatía 120 pies"
      ],
      "cr": "9",
      "proficiencyBonus": 4,
      "xp": 5000
    },
    {
      "id": "gladiador",
      "name": "Gladiador",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 16,
      "initiative": {
        "modifier": 5,
        "score": 15
      },
      "hp": {
        "average": 112,
        "formula": "15d8 + 45"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 15,
        "con": 16,
        "int": 10,
        "wis": 12,
        "cha": 15
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 7
        },
        {
          "ability": "dex",
          "bonus": 5
        },
        {
          "ability": "con",
          "bonus": 6
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 4
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El gladiador realiza tres ataques con sus lanzas. Puede sustituir un ataque por un uso de su golpe con escudo."
        },
        {
          "name": "Lanza",
          "text": "Tirada de ataque cuerpo a cuerpo o a distancia: +7, alcance 5 pies o 6/60 pies a distancia. Acierto: 11 (2d6 + 4) de daño perforante."
        },
        {
          "name": "Golpe con escudo",
          "text": "Tirada de salvación de Fuerza: CD 15, una criatura a 5 pies o menos que el gladiador pueda ver. Fallo: 9 (2d4 + 4) de daño contundente. Si el objetivo es una criatura Mediana o más pequeña, tendrá el estado de derribada."
        }
      ],
      "bonusActions": [],
      "reactions": [
        {
          "name": "Parada",
          "text": "Detonante: una tirada de ataque cuerpo a cuerpo acierta al gladiador mientras sostiene un arma. Respuesta: el gladiador suma 3 a su CA contra ese ataque, lo que puede hacer que falle. Gnoll"
        }
      ],
      "skills": [
        {
          "name": "Atletismo",
          "bonus": 10
        },
        {
          "name": "Interpretación",
          "bonus": 5
        }
      ],
      "equipment": [
        "armadura de cuero tachonado",
        "escudo",
        "lanzas (3)"
      ],
      "senses": [
        "Percepción pasiva 11"
      ],
      "languages": [
        "común"
      ],
      "cr": "5",
      "proficiencyBonus": 3,
      "xp": 1800
    },
    {
      "id": "guerrero_gnoll",
      "name": "Guerrero gnoll",
      "size": "Mediano",
      "type": "infernal",
      "alignment": "caótico malvado",
      "ac": 15,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 27,
        "formula": "6d8"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 14,
        "dex": 12,
        "con": 11,
        "int": 6,
        "wis": 10,
        "cha": 7
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 5 (1d6 + 2) de daño perforante."
        },
        {
          "name": "Arco óseo",
          "text": "Tirada de ataque a distancia: +3, alcance 45/600 pies. Acierto: 6 (1d10 + 1) de daño perforante."
        }
      ],
      "bonusActions": [
        {
          "name": "Rabia (1/día)",
          "text": "Inmediatamente después de hacer daño a una criatura que ya esté maltrecha, el gnoll se moverá hasta la mitad de su velocidad y realizará un ataque de desgarro. Goblins"
        }
      ],
      "reactions": [],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "gnoll"
      ],
      "cr": "1/2",
      "proficiencyBonus": 2,
      "xp": 100
    },
    {
      "id": "secuaz_goblin",
      "name": "Secuaz goblin",
      "size": "Pequeño",
      "type": "feérico",
      "alignment": "caótico neutral",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 7,
        "formula": "2d6"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 8,
        "dex": 15,
        "con": 10,
        "int": 10,
        "wis": 8,
        "cha": 8
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -1
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": -1
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Daga",
          "text": "Tirada de ataque cuerpo a cuerpo o a distancia: +4, alcance 5 pies o 6/60 pies a distancia. Acierto: 4 (1d4 + 2) de daño perforante."
        }
      ],
      "bonusActions": [
        {
          "name": "Huida veloz",
          "text": "El goblin realiza las acciones de destrabarse o esconderse."
        }
      ],
      "reactions": [],
      "subtype": "trasgo",
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 6
        }
      ],
      "equipment": [
        "dagas (3)"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 9"
      ],
      "languages": [
        "común",
        "goblin"
      ],
      "cr": "1/8",
      "proficiencyBonus": 2,
      "xp": 25
    },
    {
      "id": "guerrero_goblin",
      "name": "Guerrero goblin",
      "size": "Pequeño",
      "type": "feérico",
      "alignment": "caótico neutral",
      "ac": 15,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 10,
        "formula": "3d6"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 8,
        "dex": 15,
        "con": 10,
        "int": 10,
        "wis": 8,
        "cha": 8
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -1
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": -1
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Cimitarra",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 5 (1d6 + 2) de daño cortante más 2 (1d4) de daño cortante si la tirada de ataque tenía ventaja."
        },
        {
          "name": "Arco corto",
          "text": "Tirada de ataque a distancia: +4, alcance 24/315 pies. Acierto: 5 (1d6 + 2) de daño perforante más 2 (1d4) de daño perforante si la tirada de ataque tenía ventaja."
        }
      ],
      "bonusActions": [
        {
          "name": "Huida veloz",
          "text": "El goblin realiza las acciones de destrabarse o esconderse."
        }
      ],
      "reactions": [],
      "subtype": "trasgo",
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 6
        }
      ],
      "equipment": [
        "arco corto",
        "armadura de cuero",
        "cimitarra",
        "escudo"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 9"
      ],
      "languages": [
        "común",
        "goblin"
      ],
      "cr": "1/4",
      "proficiencyBonus": 2,
      "xp": 50
    },
    {
      "id": "jefe_goblin",
      "name": "Jefe goblin",
      "size": "Pequeño",
      "type": "feérico",
      "alignment": "caótico neutral",
      "ac": 17,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 21,
        "formula": "6d6"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 10,
        "dex": 15,
        "con": 10,
        "int": 10,
        "wis": 8,
        "cha": 10
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 0
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": -1
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El goblin realiza dos ataques con su arco corto o su cimitarra en cualquier combinación."
        },
        {
          "name": "Cimitarra",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 5 (1d6 + 2) de daño cortante más 2 (1d4) de daño cortante si la tirada de ataque tenía ventaja."
        },
        {
          "name": "Arco corto",
          "text": "Tirada de ataque a distancia: +4, alcance 24/315 pies. Acierto: 5 (1d6 + 2) de daño perforante más 2 (1d4) de daño perforante si la tirada de ataque tenía ventaja."
        }
      ],
      "bonusActions": [
        {
          "name": "Huida veloz",
          "text": "El goblin realiza las acciones de destrabarse o esconderse."
        }
      ],
      "reactions": [
        {
          "name": "Redirigir ataque",
          "text": "Detonante: una criatura que el goblin pueda ver hace una tirada de ataque contra él. Respuesta: el goblin elige a un aliado Pequeño o Mediano a 5 pies o menos de él. El goblin y ese aliado intercambian su posición y el aliado se convierte en el objetivo del ataque."
        }
      ],
      "subtype": "trasgo",
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 6
        }
      ],
      "equipment": [
        "arco corto",
        "camisa de malla",
        "cimitarra",
        "escudo"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 9"
      ],
      "languages": [
        "común",
        "goblin"
      ],
      "cr": "1",
      "proficiencyBonus": 2,
      "xp": 200
    },
    {
      "id": "golem_de_arcilla",
      "name": "Gólem de arcilla",
      "size": "Grande",
      "type": "autómata",
      "alignment": "sin alineamiento",
      "ac": 14,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 123,
        "formula": "13d10 + 52"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 20,
        "dex": 9,
        "con": 18,
        "int": 3,
        "wis": 8,
        "cha": 1
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 5
        },
        {
          "ability": "dex",
          "bonus": -1
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": -1
        },
        {
          "ability": "cha",
          "bonus": -5
        }
      ],
      "traits": [
        {
          "name": "Absorción de ácido",
          "text": "Siempre que fuese a recibir daño de ácido, el gólem no sufre ese daño y recupera una cantidad de puntos de golpe igual al daño de ácido infligido."
        },
        {
          "name": "Berserk",
          "text": "Siempre que el gólem comience su turno maltrecho, tira 1d6. Si sacas un 6, el gólem se ve poseído por una furia berserk. En cada uno de los turnos que pase en este estado, el gólem atacará a la criatura más cercana que pueda ver. Si no hay ninguna criatura lo bastante próxima como para que se mueva hasta ella y la ataque, el gólem atacará a un objeto. Una vez que el gólem se ve poseído por la furia berserk, continuará así hasta que sea destruido o deje de estar maltrecho."
        },
        {
          "name": "Forma inmutable",
          "text": "El gólem no puede cambiar de forma."
        },
        {
          "name": "Resistencia mágica",
          "text": "El gólem tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El gólem realiza dos ataques con su golpe o tres si ha utilizado la acción adicional de prisa en este turno."
        },
        {
          "name": "Golpe",
          "text": "Tirada de ataque cuerpo a cuerpo: +9, alcance 5 pies. Acierto: 10 (1d10 + 5) de daño contundente más 6 (1d12) de daño de ácido y los puntos de golpe máximos del objetivo se reducen en una cantidad igual al daño de ácido sufrido."
        }
      ],
      "bonusActions": [
        {
          "name": "Prisa (recarga 5–6)",
          "text": "El gólem realiza las acciones de correr y destrabarse."
        }
      ],
      "reactions": [],
      "damageResistances": [
        "contundente",
        "cortante",
        "perforante"
      ],
      "damageImmunities": [
        "ácido",
        "psíquico",
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "cansancio",
        "envenenado",
        "hechizado",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 9"
      ],
      "languages": [
        "común y otro cualquiera"
      ],
      "cr": "9",
      "proficiencyBonus": 4,
      "xp": 5000
    },
    {
      "id": "golem_de_carne",
      "name": "Gólem de carne",
      "size": "Mediano",
      "type": "autómata",
      "alignment": "neutral",
      "ac": 9,
      "initiative": {
        "modifier": -1,
        "score": 9
      },
      "hp": {
        "average": 127,
        "formula": "15d8 + 60"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 9,
        "con": 18,
        "int": 6,
        "wis": 10,
        "cha": 5
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": -1
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -3
        }
      ],
      "traits": [
        {
          "name": "Absorción de relámpago",
          "text": "Siempre que fuese a recibir daño de relámpago, el gólem recupera una cantidad de puntos de golpe igual al daño de relámpago infligido."
        },
        {
          "name": "Aversión al fuego",
          "text": "Si el gólem recibe daño de fuego, tendrá desventaja en las tiradas de ataque y las pruebas de característica hasta el final de su siguiente turno."
        },
        {
          "name": "Berserk",
          "text": "Siempre que el gólem comience su turno maltrecho, tira 1d6. Si sacas un 6, el gólem se ve poseído por una furia berserk. En cada uno de los turnos que pase en este estado, el gólem atacará a la criatura más cercana que pueda ver. Si no hay ninguna criatura lo bastante próxima como para que se mueva hasta ella y la ataque, el gólem atacará a un objeto. Una vez que el gólem se ve poseído por la furia berserk, continuará así hasta que sea destruido o deje de estar maltrecho. Si el creador del gólem está a 60 pies o menos de este, podrá intentar calmarlo empleando una acción para realizar una prueba de Carisma (Persuasión) con CD 15; el gólem deberá ser capaz de oír a su creador. Si supera la prueba, el gólem dejará de estar en estado berserk hasta el principio de su siguiente turno. En ese momento, volverá a tirar según su atributo Berserk si sigue maltrecho."
        },
        {
          "name": "Forma inmutable",
          "text": "El gólem no puede cambiar de forma."
        },
        {
          "name": "Resistencia mágica",
          "text": "El gólem tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El gólem realiza dos ataques con su golpe."
        },
        {
          "name": "Golpe",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 13 (2d8 + 4) de daño contundente más 4 (1d8) de daño de relámpago."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageImmunities": [
        "relámpago",
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "cansancio",
        "envenenado",
        "hechizado",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "entiende común y otro idioma, pero no puede hablar"
      ],
      "cr": "5",
      "proficiencyBonus": 3,
      "xp": 1800
    },
    {
      "id": "golem_de_hierro",
      "name": "Gólem de hierro",
      "size": "Grande",
      "type": "autómata",
      "alignment": "sin alineamiento",
      "ac": 20,
      "initiative": {
        "modifier": 9,
        "score": 19
      },
      "hp": {
        "average": 252,
        "formula": "24d10 + 120"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 24,
        "dex": 9,
        "con": 20,
        "int": 3,
        "wis": 11,
        "cha": 1
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 7
        },
        {
          "ability": "dex",
          "bonus": -1
        },
        {
          "ability": "con",
          "bonus": 5
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -5
        }
      ],
      "traits": [
        {
          "name": "Absorción de fuego",
          "text": "Siempre que fuese a recibir daño de fuego, el gólem recupera una cantidad de puntos de golpe igual al daño de fuego infligido."
        },
        {
          "name": "Forma inmutable",
          "text": "El gólem no puede cambiar de forma."
        },
        {
          "name": "Resistencia mágica",
          "text": "El gólem tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El gólem realiza dos ataques con su brazo cuchilla o su rayo ardiente en cualquier combinación."
        },
        {
          "name": "Brazo cuchilla",
          "text": "Tirada de ataque cuerpo a cuerpo: +12, alcance 10 pies. Acierto: 20 (3d8 + 7) de daño cortante más 10 (3d6) de daño de fuego."
        },
        {
          "name": "Rayo ardiente",
          "text": "Tirada de ataque a distancia: +10, alcance 120 pies. Acierto: 36 (8d8) de daño de fuego."
        },
        {
          "name": "Aliento venenoso (recarga 6)",
          "text": "Tirada de salvación de Constitución: CD 18, todas las criaturas en un cono de 60 pies. Fallo: 55 (10d10) de daño de veneno. Éxito: la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageImmunities": [
        "fuego",
        "psíquico",
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "cansancio",
        "envenenado",
        "hechizado",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión en la oscuridad 120 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "entiende común y otros dos idiomas, pero no puede hablar"
      ],
      "cr": "16",
      "proficiencyBonus": 5,
      "xp": 15000
    },
    {
      "id": "golem_de_piedra",
      "name": "Gólem de piedra",
      "size": "Grande",
      "type": "autómata",
      "alignment": "sin alineamiento",
      "ac": 18,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 220,
        "formula": "21d10 + 105"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 22,
        "dex": 9,
        "con": 20,
        "int": 3,
        "wis": 11,
        "cha": 1
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 6
        },
        {
          "ability": "dex",
          "bonus": -1
        },
        {
          "ability": "con",
          "bonus": 5
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -5
        }
      ],
      "traits": [
        {
          "name": "Forma inmutable",
          "text": "El gólem no puede cambiar de forma."
        },
        {
          "name": "Resistencia mágica",
          "text": "El gólem tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El gólem realiza dos ataques con su golpe o su rayo de fuerza en cualquier combinación."
        },
        {
          "name": "Golpe",
          "text": "Tirada de ataque cuerpo a cuerpo: +10, alcance 5 pies. Acierto: 15 (2d8 + 6) de daño contundente más 9 (2d8) de daño de fuerza."
        },
        {
          "name": "Rayo de fuerza",
          "text": "Tirada de ataque a distancia: +9, alcance 120 pies. Acierto: 22 (4d10) de daño de fuerza."
        }
      ],
      "bonusActions": [
        {
          "name": "Ralentizar (recarga 5–6)",
          "text": "El gólem lanza el conjuro ralentizar, que no requiere componentes y utiliza la Constitución como aptitud mágica (CD de salvación de conjuros 17)."
        }
      ],
      "reactions": [],
      "damageImmunities": [
        "psíquico",
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "cansancio",
        "envenenado",
        "hechizado",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión en la oscuridad 120 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "entiende común y otros dos idiomas, pero no puede hablar"
      ],
      "cr": "10",
      "proficiencyBonus": 4,
      "xp": 5900
    },
    {
      "id": "gorgon",
      "name": "Gorgon",
      "size": "Grande",
      "type": "autómata",
      "alignment": "sin alineamiento",
      "ac": 19,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 114,
        "formula": "12d10 + 48"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 20,
        "dex": 11,
        "con": 18,
        "int": 2,
        "wis": 12,
        "cha": 7
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 5
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Cornada",
          "text": "Tirada de ataque cuerpo a cuerpo: +8, alcance 5 pies. Acierto: 18 (2d12 + 5) de daño perforante. Si el objetivo es una criatura Grande o más pequeña y el gorgon recorre al menos 20 pies en línea recta hacia ella justo antes de acertarle, tendrá el estado de derribada."
        },
        {
          "name": "Aliento petrificador (recarga 5–6)",
          "text": "Tirada de salvación de Constitución: CD 15, todas las criaturas en un cono de 30 pies. Primer fallo: el objetivo tendrá el estado de apresado. Si al final de su siguiente turno sigue apresado, repetirá la tirada de salvación y se librará del efecto si la supera. Segundo fallo: el objetivo tendrá el estado de petrificado en vez del de apresado."
        }
      ],
      "bonusActions": [
        {
          "name": "Arrollar",
          "text": "Tirada de salvación de Destreza: CD 16, una criatura a 5 pies o menos que tenga el estado de derribada. Fallo: 16 (2d10 + 5) de daño contundente. Éxito: la mitad del daño."
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 7
        }
      ],
      "conditionImmunities": [
        "cansancio",
        "petrificado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 17"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "5",
      "proficiencyBonus": 3,
      "xp": 1800
    },
    {
      "id": "grick",
      "name": "Grick",
      "size": "Mediana",
      "type": "aberración",
      "alignment": "sin alineamiento",
      "ac": 14,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 54,
        "formula": "12d8"
      },
      "speed": {
        "walk": "30 pies",
        "climb": "30 pies"
      },
      "abilities": {
        "str": 14,
        "dex": 14,
        "con": 11,
        "int": 3,
        "wis": 14,
        "cha": 5
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": -3
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El grick realiza un ataque con su pico y uno con sus tentáculos."
        },
        {
          "name": "Pico",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 9 (2d6 + 2) de daño perforante."
        },
        {
          "name": "Tentáculos",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 7 (1d10 + 2) de daño cortante. Si el objetivo es una criatura Mediana o más pequeña, tendrá el estado de agarrada (CD 12 para escapar) por los cuatro tentáculos."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "grifo",
      "name": "Grifo",
      "size": "Grande",
      "type": "monstruosidad",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 59,
        "formula": "7d10 + 21"
      },
      "speed": {
        "walk": "30 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 15,
        "con": 16,
        "int": 2,
        "wis": 13,
        "cha": 8
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El grifo realiza dos ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 8 (1d8 + 4) de daño perforante. Si el objetivo es una criatura Mediana o más pequeña, tendrá el estado de agarrada (CD 14 para escapar) por ambas garras delanteras del grifo."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 5
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 15"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "grimlock",
      "name": "Grimlock",
      "size": "Mediana",
      "type": "aberración",
      "alignment": "neutral malvada",
      "ac": 11,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 11,
        "formula": "2d8 + 2"
      },
      "speed": {
        "walk": "30 pies",
        "climb": "30 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 12,
        "con": 12,
        "int": 9,
        "wis": 8,
        "cha": 6
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": -1
        },
        {
          "ability": "wis",
          "bonus": -1
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Garrote óseo",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 6 (1d6 + 3) de daño contundente más 2 (1d4) de daño psíquico."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Atletismo",
          "bonus": 5
        },
        {
          "name": "Percepción",
          "bonus": 3
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "senses": [
        "visión ciega 30 pies",
        "Percepción pasiva 13"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/4",
      "proficiencyBonus": 2,
      "xp": 50
    },
    {
      "id": "guardian_escudo",
      "name": "Guardián escudo",
      "size": "Grande",
      "type": "autómata",
      "alignment": "sin alineamiento",
      "ac": 17,
      "initiative": {
        "modifier": -1,
        "score": 9
      },
      "hp": {
        "average": 142,
        "formula": "15d10 + 60"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 8,
        "con": 18,
        "int": 7,
        "wis": 10,
        "cha": 3
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": -1
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -4
        }
      ],
      "traits": [
        {
          "name": "Almacenar conjuros",
          "text": "El lanzador de conjuros que porte el amuleto del guardián podrá hacer que el guardián almacene un conjuro de nivel 4 o menos. Para ello, el portador deberá lanzar el conjuro sobre el guardián estando a 5 pies o menos. Este conjuro, en vez de tener efecto, se almacenará en él. Cualquier conjuro almacenado anteriormente se perderá cuando se almacene uno nuevo. El guardián puede lanzar el conjuro almacenado siguiendo los parámetros definidos por el lanzador original sin necesidad de componentes y empleará la aptitud mágica del lanzador. Luego, el conjuro almacenado se perderá."
        },
        {
          "name": "Regeneración",
          "text": "El guardián recupera 10 puntos de golpe al principio de cada uno de sus turnos si tiene al menos 1 punto de golpe."
        },
        {
          "name": "Vínculo",
          "text": "El guardián está vinculado mágicamente a un amuleto. Mientras ambos se encuentren en el mismo plano de existencia, el portador del amuleto podrá llamar telepáticamente al guardián para que acuda a su lado, y el guardián conocerá la distancia que le separa del amuleto y en qué dirección se halla. Si el guardián está situado a 60 pies o menos del portador del amuleto, la mitad del daño que reciba este (redondeado hacia arriba) será transferido al guardián."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El guardián realiza dos ataques de puñetazo."
        },
        {
          "name": "Puñetazo",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 10 pies. Acierto: 11 (2d6 + 4) de daño contundente más 7 (2d6) de daño de fuerza."
        }
      ],
      "bonusActions": [],
      "reactions": [
        {
          "name": "Protección",
          "text": "Detonante: una tirada de ataque acierta al portador del amuleto del guardián mientras está a 5 pies o menos de él. Respuesta: hasta el principio del siguiente turno del guardián, el portador obtiene un bonificador de +5 a la CA, incluido contra el ataque al que reacciona, lo que puede hacer que falle. Guardias"
        }
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "cansancio",
        "envenenado",
        "hechizado",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión ciega 10 pies, visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "entiende las órdenes recibidas en cualquier idioma, pero no puede hablar"
      ],
      "cr": "7",
      "proficiencyBonus": 3,
      "xp": 2900
    },
    {
      "id": "guardia",
      "name": "Guardia",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 16,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 11,
        "formula": "2d8 + 2"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 13,
        "dex": 12,
        "con": 12,
        "int": 10,
        "wis": 11,
        "cha": 10
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 1
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Lanza",
          "text": "Tirada de ataque cuerpo a cuerpo o a distancia: +3, alcance 5 pies o 6/60 pies a distancia. Acierto: 4 (1d6 + 1) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 2
        }
      ],
      "equipment": [
        "camisa de malla",
        "escudo",
        "lanza"
      ],
      "senses": [
        "Percepción pasiva 12"
      ],
      "languages": [
        "común"
      ],
      "cr": "1/8",
      "proficiencyBonus": 2,
      "xp": 25
    },
    {
      "id": "capitan_de_la_guardia",
      "name": "Capitán de la guardia",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 18,
      "initiative": {
        "modifier": 4,
        "score": 14
      },
      "hp": {
        "average": 75,
        "formula": "10d8 + 30"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 14,
        "con": 16,
        "int": 12,
        "wis": 14,
        "cha": 13
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 1
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El guardia realiza dos ataques con su espada larga o sus jabalinas en cualquier combinación."
        },
        {
          "name": "Espada larga",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 15 (2d10 + 4) de daño cortante."
        },
        {
          "name": "Jabalina",
          "text": "Tirada de ataque cuerpo a cuerpo o a distancia: +6, alcance 5 pies o 9/120 pies a distancia. Acierto: 14 (3d6 + 4) de daño perforante. Guerreros"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Atletismo",
          "bonus": 6
        },
        {
          "name": "Percepción",
          "bonus": 4
        }
      ],
      "equipment": [
        "coraza",
        "escudo",
        "espada larga",
        "jabalinas (6)"
      ],
      "senses": [
        "Percepción pasiva 14"
      ],
      "languages": [
        "común"
      ],
      "cr": "4",
      "proficiencyBonus": 2,
      "xp": 1100
    },
    {
      "id": "guerrero_de_infanteria",
      "name": "Guerrero de infantería",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 13,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 9,
        "formula": "2d8"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 13,
        "dex": 11,
        "con": 11,
        "int": 8,
        "wis": 11,
        "cha": 8
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 1
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": -1
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [
        {
          "name": "Atacar en grupo",
          "text": "El guerrero tiene ventaja en una tirada de ataque contra una criatura si al menos uno de los aliados del guerrero se encuentra a 5 pies o menos de la criatura y no tiene el estado de incapacitado."
        }
      ],
      "actions": [
        {
          "name": "Lanza",
          "text": "Tirada de ataque cuerpo a cuerpo o a distancia: +3, alcance 5 pies o 6/60 pies a distancia. Acierto: 4 (1d6 + 1) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "equipment": [
        "camisa de malla",
        "lanza"
      ],
      "senses": [
        "Percepción pasiva 10"
      ],
      "languages": [
        "común"
      ],
      "cr": "1/8",
      "proficiencyBonus": 2,
      "xp": 25
    },
    {
      "id": "guerrero_veterano",
      "name": "Guerrero veterano",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 17,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 65,
        "formula": "10d8 + 20"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 13,
        "con": 14,
        "int": 10,
        "wis": 11,
        "cha": 10
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El guerrero realiza dos ataques con su espadón o su ballesta pesada."
        },
        {
          "name": "Espadón",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 10 (2d6 + 3) de daño cortante."
        },
        {
          "name": "Ballesta pesada",
          "text": "Tirada de ataque a distancia: +3, alcance 30/400 pies. Acierto: 12 (2d10 + 1) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": [
        {
          "name": "Parada",
          "text": "Detonante: una tirada de ataque cuerpo a cuerpo acierta al guerrero mientras sostiene un arma. Respuesta: el guerrero suma 2 a su CA contra ese ataque, lo que puede hacer que falle."
        }
      ],
      "skills": [
        {
          "name": "Atletismo",
          "bonus": 5
        },
        {
          "name": "Percepción",
          "bonus": 2
        }
      ],
      "equipment": [
        "armadura de bandas",
        "ballesta pesada",
        "espadón"
      ],
      "senses": [
        "Percepción pasiva 12"
      ],
      "languages": [
        "común y otro cualquiera"
      ],
      "cr": "3",
      "proficiencyBonus": 2,
      "xp": 700
    },
    {
      "id": "guiverno",
      "name": "Guiverno",
      "size": "Grande",
      "type": "dragón",
      "alignment": "sin alineamiento",
      "ac": 14,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 127,
        "formula": "15d10 + 45"
      },
      "speed": {
        "walk": "30 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 10,
        "con": 16,
        "int": 5,
        "wis": 12,
        "cha": 6
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": -3
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El guiverno realiza un ataque de mordisco y uno con su aguijón."
        },
        {
          "name": "Aguijón",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 10 pies. Acierto: 11 (2d6 + 4) de daño perforante más 24 (7d6) de daño de veneno y el objetivo tendrá el estado de envenenado hasta el principio del siguiente turno del guiverno."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 13 (2d8 + 4) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 4
        }
      ],
      "senses": [
        "visión en la oscuridad 120 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "6",
      "proficiencyBonus": 3,
      "xp": 2300
    },
    {
      "id": "gul",
      "name": "Gul",
      "size": "Mediano",
      "type": "muerto viviente",
      "alignment": "caótico malvado",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 22,
        "formula": "5d8"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 13,
        "dex": 15,
        "con": 10,
        "int": 7,
        "wis": 10,
        "cha": 6
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 1
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El gul realiza dos ataques de mordisco."
        },
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 4 (1d4 + 2) de daño cortante. Si el objetivo es una criatura que no sea un muerto viviente o un elfo, sufre el siguiente efecto. Tirada de salvación de Constitución: CD 10. Fallo: el objetivo tendrá el estado de paralizado hasta el final de su siguiente turno."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 5 (1d6 + 2) de daño perforante más 3 (1d6) de daño necrótico."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "cansancio",
        "envenenado",
        "hechizado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "común"
      ],
      "cr": "1",
      "proficiencyBonus": 2,
      "xp": 200
    },
    {
      "id": "gusano_purpura",
      "name": "Gusano púrpura",
      "size": "Gargantuesca",
      "type": "monstruosidad",
      "alignment": "sin alineamiento",
      "ac": 18,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 247,
        "formula": "15d20 + 90"
      },
      "speed": {
        "walk": "50 pies",
        "burrow": "50 pies"
      },
      "abilities": {
        "str": 28,
        "dex": 7,
        "con": 22,
        "int": 1,
        "wis": 8,
        "cha": 4
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 9
        },
        {
          "ability": "dex",
          "bonus": -2
        },
        {
          "ability": "con",
          "bonus": 11
        },
        {
          "ability": "int",
          "bonus": -5
        },
        {
          "ability": "wis",
          "bonus": 4
        },
        {
          "ability": "cha",
          "bonus": -3
        }
      ],
      "traits": [
        {
          "name": "Excavador",
          "text": "El gusano puede excavar a través de roca sólida a la mitad de su velocidad excavando y deja a su paso un túnel de 10 pies de diámetro."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El gusano realiza un ataque de mordisco y uno con su aguijón de la cola."
        },
        {
          "name": "Aguijón de la cola",
          "text": "Tirada de ataque cuerpo a cuerpo: +14, alcance 10 pies. Acierto: 16 (2d6 + 9) de daño perforante más 35 (10d6) de daño de veneno."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +14, alcance 10 pies. Acierto: 22 (3d8 + 9) de daño perforante. Si el objetivo es una criatura Grande o más pequeña, tendrá el estado de agarrada (CD 19 para escapar) y el de apresada hasta que el agarre termine."
        }
      ],
      "bonusActions": [
        {
          "name": "Engullir",
          "text": "Tirada de salvación de Fuerza: CD 19, una criatura Grande o más pequeña agarrada por el gusano (puede tener hasta tres criaturas engullidas a la vez). Fallo: el objetivo será engullido por el gusano y se pondrá fin al estado de agarrado. Una criatura engullida tendrá los estados de apresada y cegada, tendrá cobertura completa contra los ataques y otros efectos fuera del gusano y recibirá 17 (5d6) de daño de ácido al principio de cada turno del gusano. Si el gusano sufre 30 o más de daño en un solo turno por parte de una criatura que esté dentro de él, deberá superar una tirada de salvación de Constitución con CD 21 al final de ese turno o regurgitará a todas las criaturas engullidas, que caerán en espacios a 5 pies o menos del gusano y tendrán el estado de derribadas. Si el gusano muere, cualquier criatura engullida dejará de tener el estado de apresada y podrá gastar 20 pies de movimiento para escapar del cadáver, del que saldrá con el estado de derribada."
        }
      ],
      "reactions": [],
      "senses": [
        "sentir vibraciones 60 pies, visión ciega 30 pies",
        "Percepción pasiva 9"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "15",
      "proficiencyBonus": 5,
      "xp": 13000
    },
    {
      "id": "hezrou",
      "name": "Hezrou",
      "size": "Grande",
      "type": "infernal",
      "alignment": "caótico malvado",
      "ac": 18,
      "initiative": {
        "modifier": 6,
        "score": 16
      },
      "hp": {
        "average": 157,
        "formula": "15d10 + 75"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 17,
        "con": 20,
        "int": 5,
        "wis": 12,
        "cha": 13
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 7
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 8
        },
        {
          "ability": "int",
          "bonus": -3
        },
        {
          "ability": "wis",
          "bonus": 4
        },
        {
          "ability": "cha",
          "bonus": 1
        }
      ],
      "traits": [
        {
          "name": "Hedor",
          "text": "Tirada de salvación de Constitución: CD 16, cualquier criatura que empiece su turno en una emanación de 10 pies que se origina en el hezrou. Fallo: el objetivo tendrá el estado de envenenado hasta el principio de su siguiente turno."
        },
        {
          "name": "Recuperación demoníaca",
          "text": "Si el hezrou muere fuera del Abismo, su cuerpo se disuelve en icor, obtiene un cuerpo nuevo al instante y revive con todos sus puntos de golpe en algún lugar del Abismo."
        },
        {
          "name": "Resistencia mágica",
          "text": "El hezrou tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El hezrou hace tres ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 6 (1d4 + 4) de daño cortante más 9 (2d8) de daño de veneno."
        }
      ],
      "bonusActions": [
        {
          "name": "Salto",
          "text": "El hezrou gasta 10 pies de movimiento para saltar hasta 30 pies."
        }
      ],
      "reactions": [],
      "subtype": "demonio",
      "damageResistances": [
        "frío",
        "fuego",
        "relámpago"
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 120 pies",
        "Percepción pasiva 11"
      ],
      "languages": [
        "abisal",
        "telepatía 120 pies"
      ],
      "cr": "8",
      "proficiencyBonus": 3,
      "xp": 3900
    },
    {
      "id": "hidra",
      "name": "Hidra",
      "size": "Enorme",
      "type": "monstruosidad",
      "alignment": "sin alineamiento",
      "ac": 15,
      "initiative": {
        "modifier": 4,
        "score": 14
      },
      "hp": {
        "average": 184,
        "formula": "16d12 + 80"
      },
      "speed": {
        "walk": "40 pies",
        "swim": "40 pies"
      },
      "abilities": {
        "str": 20,
        "dex": 12,
        "con": 20,
        "int": 2,
        "wis": 10,
        "cha": 7
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 5
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 5
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [
        {
          "name": "Aguantar la respiración",
          "text": "La hidra puede aguantar la respiración durante 1 hora."
        },
        {
          "name": "Cabezas reactivas",
          "text": "Por cada cabeza que tenga además de la primera, la hidra obtiene una reacción adicional que solo puede usar para realizar ataques de oportunidad."
        },
        {
          "name": "Múltiples cabezas",
          "text": "La hidra tiene cinco cabezas. Si recibe 25 o más de daño en un solo turno, perderá una de sus cabezas. Si todas sus cabezas mueren, la hidra morirá. Al final de cada uno de sus turnos, mientras tenga al menos una cabeza viva, a la hidra le crecerán dos cabezas por cada cabeza que haya muerto desde su último turno, a menos que haya recibido daño de fuego desde su último turno. Cuando le crecen nuevas cabezas, la hidra recupera 20 puntos de golpe."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "La hidra realiza un ataque de mordisco por cada cabeza que tenga."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +8, alcance 10 pies. Acierto: 10 (1d10 + 5) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 6
        }
      ],
      "conditionImmunities": [
        "asustado",
        "aturdido",
        "cegado",
        "ensordecido",
        "hechizado",
        "inconsciente"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 16"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "8",
      "proficiencyBonus": 3,
      "xp": 3900
    },
    {
      "id": "hipogrifo",
      "name": "Hipogrifo",
      "size": "Grande",
      "type": "monstruosidad",
      "alignment": "sin alineamiento",
      "ac": 11,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 26,
        "formula": "4d10 + 4"
      },
      "speed": {
        "walk": "40 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 17,
        "dex": 13,
        "con": 13,
        "int": 2,
        "wis": 12,
        "cha": 8
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [
        {
          "name": "Pasar volando",
          "text": "El hipogrifo no provoca ataques de oportunidad cuando vuela para ponerse fuera del alcance de un enemigo."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El hipogrifo realiza dos ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 7 (1d8 + 3) de daño cortante. Hobgoblins"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 5
        }
      ],
      "senses": [
        "Percepción pasiva 15"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1",
      "proficiencyBonus": 2,
      "xp": 200
    },
    {
      "id": "guerrero_hobgoblin",
      "name": "Guerrero hobgoblin",
      "size": "Mediano",
      "type": "feérico",
      "alignment": "legal malvado",
      "ac": 18,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 11,
        "formula": "2d8 + 2"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 13,
        "dex": 12,
        "con": 12,
        "int": 10,
        "wis": 10,
        "cha": 9
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 1
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [
        {
          "name": "Atacar en grupo",
          "text": "El hobgoblin tiene ventaja en una tirada de ataque contra una criatura si al menos uno de los aliados del hobgoblin se encuentra a 5 pies o menos de la criatura y no tiene el estado de incapacitado."
        }
      ],
      "actions": [
        {
          "name": "Espada larga",
          "text": "Tirada de ataque cuerpo a cuerpo: +3, alcance 5 pies. Acierto: 12 (2d10 + 1) de daño cortante."
        },
        {
          "name": "Arco largo",
          "text": "Tirada de ataque a distancia: +3, alcance 45/600 pies. Acierto: 5 (1d8 + 1) de daño perforante más 7 (3d4) de daño de veneno."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "trasgo",
      "equipment": [
        "arco largo",
        "escudo",
        "espada larga",
        "media armadura"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "común",
        "goblin"
      ],
      "cr": "1/2",
      "proficiencyBonus": 2,
      "xp": 100
    },
    {
      "id": "capitan_hobgoblin",
      "name": "Capitán hobgoblin",
      "size": "Mediano",
      "type": "feérico",
      "alignment": "legal malvado",
      "ac": 17,
      "initiative": {
        "modifier": 4,
        "score": 14
      },
      "hp": {
        "average": 58,
        "formula": "9d8 + 18"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 15,
        "dex": 14,
        "con": 14,
        "int": 12,
        "wis": 10,
        "cha": 13
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 1
        }
      ],
      "traits": [
        {
          "name": "Aura de autoridad",
          "text": "Mientras estén en una emanación de 10 pies que se origina en el hobgoblin, este y sus aliados tendrán ventaja en las tiradas de ataque y las tiradas de salvación, siempre que el hobgoblin no tenga el estado de incapacitado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El hobgoblin realiza dos ataques con su arco largo o su espadón en cualquier combinación."
        },
        {
          "name": "Espadón",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 9 (2d6 + 2) de daño cortante más 3 (1d6) de daño de veneno."
        },
        {
          "name": "Arco largo",
          "text": "Tirada de ataque a distancia: +4, alcance 45/600 pies. Acierto: 6 (1d8 + 2) de daño perforante más 5 (2d4) de daño de veneno."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "trasgo",
      "equipment": [
        "arco largo",
        "espadón",
        "media armadura"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "común",
        "goblin"
      ],
      "cr": "3",
      "proficiencyBonus": 2,
      "xp": 700
    },
    {
      "id": "hombre_jabali",
      "name": "Hombre jabalí",
      "size": "Mediana o Pequeña",
      "type": "monstruosidad",
      "alignment": "neutral malvada",
      "ac": 15,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 97,
        "formula": "15d8 + 30"
      },
      "speed": {
        "walk": "30 pies",
        "special": [
          "40 pies (solo en forma de jabalí)"
        ]
      },
      "abilities": {
        "str": 17,
        "dex": 10,
        "con": 15,
        "int": 10,
        "wis": 11,
        "cha": 8
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El hombre jabalí realiza dos ataques con sus colmillos o sus jabalinas en cualquier combinación. Puede sustituir uno de ellos por un ataque de mordisco."
        },
        {
          "name": "Colmillos (solo en forma de jabalí o híbrida)",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 10 (2d6 + 3) de daño perforante. Si el objetivo es una criatura Mediana o más pequeña y el hombre jabalí recorre al menos 20 pies en línea recta hacia ella justo antes de acertarle, esta recibirá 7 (2d6) de daño perforante adicional y tendrá el estado de derribada."
        },
        {
          "name": "Mordisco (solo en forma de jabalí o híbrida)",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 12 (2d8 + 3) de daño perforante. Si el objetivo es un humanoide, sufre el siguiente efecto. Tirada de salvación de Constitución: CD 12. Fallo: el objetivo estará maldito. Si los puntos de golpe del objetivo maldito se reducen a 0, en vez de ello, se convertirá en un hombre jabalí controlado por el GM y tendrá 10 puntos de golpe. Éxito: el objetivo será inmune a la maldición de este hombre jabalí durante 24 horas."
        },
        {
          "name": "Jabalina (solo en forma humanoide o híbrida)",
          "text": "Tirada de ataque cuerpo a cuerpo o a distancia: +5, alcance 5 pies o 9/120 pies a distancia. Acierto: 13 (3d6 + 3) de daño perforante."
        }
      ],
      "bonusActions": [
        {
          "name": "Cambio de forma",
          "text": "El hombre jabalí adopta la forma de un híbrido de jabalí-humanoide Mediano o de un jabalí Pequeño, o recupera su verdadera forma humanoide. Su perfil, salvo por el tamaño, es el mismo en todas las formas. Cualquier equipo que vista o lleve no se transformará."
        }
      ],
      "reactions": [],
      "subtype": "licántropo",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 2
        }
      ],
      "equipment": [
        "jabalinas (6)"
      ],
      "senses": [
        "Percepción pasiva 12"
      ],
      "languages": [
        "común (no puede hablar en forma de jabalí)"
      ],
      "cr": "4",
      "proficiencyBonus": 2,
      "xp": 1100
    },
    {
      "id": "hombre_lobo",
      "name": "Hombre lobo",
      "size": "Mediana o Pequeña",
      "type": "monstruosidad",
      "alignment": "caótica malvada",
      "ac": 15,
      "initiative": {
        "modifier": 4,
        "score": 14
      },
      "hp": {
        "average": 71,
        "formula": "11d8 + 22"
      },
      "speed": {
        "walk": "30 pies",
        "special": [
          "40 pies (solo en forma de lobo)"
        ]
      },
      "abilities": {
        "str": 16,
        "dex": 14,
        "con": 14,
        "int": 10,
        "wis": 11,
        "cha": 10
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [
        {
          "name": "Atacar en manada",
          "text": "El hombre lobo tiene ventaja en una tirada de ataque contra una criatura si al menos uno de los aliados del hombre lobo se encuentra a 5 pies o menos de la criatura y no tiene el estado de incapacitado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El hombre lobo realiza dos ataques con su arañazo o su arco largo en cualquier combinación. Puede sustituir uno de ellos por un ataque de mordisco."
        },
        {
          "name": "Arañazo",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 10 (2d6 + 3) de daño cortante."
        },
        {
          "name": "Mordisco (solo en forma de lobo o híbrida)",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 12 (2d8 + 3) de daño perforante. Si el objetivo es un humanoide, sufre el siguiente efecto. Tirada de salvación de Constitución: CD 12. Fallo: el objetivo estará maldito. Si los puntos de golpe del objetivo maldito se reducen a 0, en vez de ello, se convertirá en un hombre lobo controlado por el GM y tendrá 10 puntos de golpe. Éxito: el objetivo será inmune a la maldición de este hombre lobo durante 24 horas. Arco largo (solo en forma humanoide o híbrida). Tirada de ataque a distancia: +4, alcance 45/600 pies. Acierto: 11 (2d8 + 2) de daño perforante."
        }
      ],
      "bonusActions": [
        {
          "name": "Cambio de forma",
          "text": "El hombre lobo adopta la forma de un híbrido de lobo-humanoide Grande o de un lobo Mediano, o recupera su verdadera forma humanoide. Su perfil, salvo por el tamaño, es el mismo en todas las formas. Cualquier equipo que vista o lleve no se transformará."
        }
      ],
      "reactions": [],
      "subtype": "licántropo",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 4
        },
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "equipment": [
        "arco largo"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "común (no puede hablar en forma de lobo)"
      ],
      "cr": "3",
      "proficiencyBonus": 2,
      "xp": 700
    },
    {
      "id": "hombre_oso",
      "name": "Hombre oso",
      "size": "Mediana o Pequeña",
      "type": "monstruosidad",
      "alignment": "neutral buena",
      "ac": 15,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 135,
        "formula": "18d8 + 54"
      },
      "speed": {
        "walk": "30 pies",
        "climb": "30 pies (solo en forma de oso)",
        "special": [
          "40 pies (solo en forma de oso)"
        ]
      },
      "abilities": {
        "str": 19,
        "dex": 10,
        "con": 17,
        "int": 11,
        "wis": 12,
        "cha": 12
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": 1
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El hombre oso realiza dos ataques de desgarro o con sus hachas de mano en cualquier combinación. Puede sustituir uno de ellos por un ataque de mordisco."
        },
        {
          "name": "Desgarro (solo en forma de oso o híbrida)",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 13 (2d8 + 4) de daño cortante. Hacha de mano (solo en forma humanoide o híbrida). Tirada de ataque cuerpo a cuerpo o a distancia: +7, alcance 5 pies o 6/60 pies a distancia. Acierto: 14 (3d6 + 4) de daño cortante."
        },
        {
          "name": "Mordisco (solo en forma de oso o híbrida)",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 17 (2d12 + 4) de daño perforante. Si el objetivo es un humanoide, sufre el siguiente efecto. Tirada de salvación de Constitución: CD 14. Fallo: el objetivo estará maldito. Si los puntos de golpe del objetivo maldito se reducen a 0, en vez de ello, se convertirá en un hombre oso controlado por el GM y tendrá 10 puntos de golpe. Éxito: el objetivo será inmune a la maldición de este hombre oso durante 24 horas."
        }
      ],
      "bonusActions": [
        {
          "name": "Cambio de forma",
          "text": "El hombre oso adopta la forma de un híbrido de oso-humanoide Grande o de un oso Grande, o recupera su verdadera forma humanoide. Su perfil, salvo por el tamaño, es el mismo en todas las formas. Cualquier equipo que vista o lleve no se transformará."
        }
      ],
      "reactions": [],
      "subtype": "licántropo",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 7
        }
      ],
      "equipment": [
        "hachas de mano (4)"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 17"
      ],
      "languages": [
        "común (no puede hablar en forma de oso)"
      ],
      "cr": "5",
      "proficiencyBonus": 3,
      "xp": 1800
    },
    {
      "id": "hombre_rata",
      "name": "Hombre rata",
      "size": "Mediana o Pequeña",
      "type": "monstruosidad",
      "alignment": "legal malvada",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 60,
        "formula": "11d8 + 11"
      },
      "speed": {
        "walk": "30 pies",
        "climb": "30 pies"
      },
      "abilities": {
        "str": 10,
        "dex": 16,
        "con": 12,
        "int": 11,
        "wis": 10,
        "cha": 8
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 0
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El hombre rata realiza dos ataques con su arañazo o su ballesta de mano en cualquier combinación. Puede sustituir uno de ellos por un ataque de mordisco."
        },
        {
          "name": "Arañazo",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 6 (1d6 + 3) de daño cortante."
        },
        {
          "name": "Mordisco (solo en forma de rata o híbrida)",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 8 (2d4 + 3) de daño perforante. Si el objetivo es un humanoide, sufre el siguiente efecto. Tirada de salvación de Constitución: CD 11. Fallo: el objetivo estará maldito. Si los puntos de golpe del objetivo maldito se reducen a 0, en vez de ello, se convertirá en un hombre rata controlado por el GM y tendrá 10 puntos de golpe. Éxito: el objetivo será inmune a la maldición de este hombre rata durante 24 horas. Ballesta de mano (solo en forma humanoide o híbrida). Tirada de ataque a distancia: +5, alcance 9/120 pies. Acierto: 6 (1d6 + 3) de daño perforante."
        }
      ],
      "bonusActions": [
        {
          "name": "Cambio de forma",
          "text": "El hombre rata adopta la forma de un híbrido de rata-humanoide Mediano o de una rata Pequeña, o recupera su verdadera forma humanoide. Su perfil, salvo por el tamaño, es el mismo en todas las formas. Cualquier equipo que vista o lleve no se transformará."
        }
      ],
      "reactions": [],
      "subtype": "licántropo",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 4
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "equipment": [
        "ballesta de mano"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "común (no puede hablar en forma de rata)"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "hombre_tigre",
      "name": "Hombre tigre",
      "size": "Mediana o Pequeña",
      "type": "monstruosidad",
      "alignment": "neutral",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 120,
        "formula": "16d8 + 48"
      },
      "speed": {
        "walk": "30 pies",
        "special": [
          "40 pies (solo en forma de tigre)"
        ]
      },
      "abilities": {
        "str": 17,
        "dex": 15,
        "con": 16,
        "int": 10,
        "wis": 13,
        "cha": 11
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El hombre tigre realiza dos ataques con su arañazo o su arco largo en cualquier combinación. Puede sustituir uno de ellos por un ataque de mordisco."
        },
        {
          "name": "Arañazo",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 10 (2d6 + 3) de daño cortante."
        },
        {
          "name": "Mordisco (solo en forma de tigre o híbrida)",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 12 (2d8 + 3) de daño perforante. Si el objetivo es un humanoide, sufre el siguiente efecto. Tirada de salvación de Constitución: CD 13. Fallo: el objetivo estará maldito. Si los puntos de golpe del objetivo maldito se reducen a 0, en vez de ello, se convertirá en un hombre tigre controlado por el GM y tendrá 10 puntos de golpe. Éxito: el objetivo será inmune a la maldición de este hombre tigre durante 24 horas. Arco largo (solo en forma humanoide o híbrida). Tirada de ataque a distancia: +4, alcance 45/600 pies. Acierto: 11 (2d8 + 2) de daño perforante."
        }
      ],
      "bonusActions": [
        {
          "name": "Cambio de forma",
          "text": "El hombre tigre adopta la forma de un híbrido de tigre-humanoide Grande o de un tigre Grande, o recupera su verdadera forma humanoide. Su perfil, salvo por el tamaño, es el mismo en todas las formas. Cualquier equipo que vista o lleve no se transformará."
        },
        {
          "name": "Merodear (solo en forma de tigre o híbrida)",
          "text": "El hombre tigre se mueve hasta su velocidad sin provocar ataques de oportunidad. Al final de este movimiento, puede usar la acción de esconderse."
        }
      ],
      "reactions": [],
      "subtype": "licántropo",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 5
        },
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "equipment": [
        "arco largo"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 15"
      ],
      "languages": [
        "común (no puede hablar en forma de tigre)"
      ],
      "cr": "4",
      "proficiencyBonus": 2,
      "xp": 1100
    },
    {
      "id": "homunculo",
      "name": "Homúnculo",
      "size": "Diminuto",
      "type": "autómata",
      "alignment": "neutral",
      "ac": 13,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 4,
        "formula": "1d4 + 2"
      },
      "speed": {
        "walk": "20 pies",
        "fly": "40 pies"
      },
      "abilities": {
        "str": 4,
        "dex": 15,
        "con": 14,
        "int": 10,
        "wis": 10,
        "cha": 7
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -3
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [
        {
          "name": "Enlace telepático",
          "text": "Mientras el homúnculo se encuentre en el mismo plano de existencia que su amo, los dos pueden comunicarse telepáticamente entre sí."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 1 de daño perforante y el objetivo sufrirá el siguiente efecto. Tirada de salvación de"
        },
        {
          "name": "Constitución: CD 12",
          "text": "Fallo: el objetivo tendrá el estado de envenenado hasta el final del siguiente turno del homúnculo. Fallo por 5 o más: el objetivo tendrá el estado de envenenado durante 1 minuto. Mientras esté envenenado, tendrá el estado de inconsciente, que terminará antes si recibe cualquier daño. Hongos"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado",
        "hechizado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "entiende común y otro idioma, pero no puede hablar"
      ],
      "cr": "0",
      "proficiencyBonus": 2,
      "xp": 10
    },
    {
      "id": "hongo_chillon",
      "name": "Hongo chillón",
      "size": "Mediana",
      "type": "planta",
      "alignment": "sin alineamiento",
      "ac": 5,
      "initiative": {
        "modifier": -5,
        "score": 5
      },
      "hp": {
        "average": 13,
        "formula": "3d8"
      },
      "speed": {
        "walk": "5 pies"
      },
      "abilities": {
        "str": 1,
        "dex": 1,
        "con": 10,
        "int": 1,
        "wis": 3,
        "cha": 1
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -5
        },
        {
          "ability": "dex",
          "bonus": -5
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": -5
        },
        {
          "ability": "wis",
          "bonus": -4
        },
        {
          "ability": "cha",
          "bonus": -5
        }
      ],
      "traits": [],
      "actions": [],
      "bonusActions": [],
      "reactions": [
        {
          "name": "Chillar",
          "text": "Detonante: una criatura o una fuente de luz brillante se acerca a 30 pies o menos del chillón. Respuesta: el chillón emite un grito audible a 300 pies de él durante 1 minuto o hasta que muera."
        }
      ],
      "conditionImmunities": [
        "asustado",
        "cegado",
        "ensordecido",
        "hechizado"
      ],
      "senses": [
        "visión ciega 30 pies",
        "Percepción pasiva 6"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "proficiencyBonus": 2,
      "xp": 0
    },
    {
      "id": "hongo_violeta",
      "name": "Hongo violeta",
      "size": "Mediana",
      "type": "planta",
      "alignment": "sin alineamiento",
      "ac": 5,
      "initiative": {
        "modifier": -5,
        "score": 5
      },
      "hp": {
        "average": 18,
        "formula": "4d8"
      },
      "speed": {
        "walk": "5 pies"
      },
      "abilities": {
        "str": 3,
        "dex": 1,
        "con": 10,
        "int": 1,
        "wis": 3,
        "cha": 1
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -4
        },
        {
          "ability": "dex",
          "bonus": -5
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": -5
        },
        {
          "ability": "wis",
          "bonus": -4
        },
        {
          "ability": "cha",
          "bonus": -5
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El hongo realiza dos ataques con su toque putrefacto."
        },
        {
          "name": "Toque putrefacto",
          "text": "Tirada de ataque cuerpo a cuerpo: +2, alcance 10 pies. Acierto: 4 (1d8) de daño necrótico."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "conditionImmunities": [
        "asustado",
        "cegado",
        "ensordecido",
        "hechizado"
      ],
      "senses": [
        "visión ciega 30 pies",
        "Percepción pasiva 6"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/4",
      "proficiencyBonus": 2,
      "xp": 50
    },
    {
      "id": "huargo",
      "name": "Huargo",
      "size": "Grande",
      "type": "feérico",
      "alignment": "neutral malvado",
      "ac": 13,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 26,
        "formula": "4d10 + 4"
      },
      "speed": {
        "walk": "50 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 13,
        "con": 13,
        "int": 7,
        "wis": 11,
        "cha": 8
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 7 (1d8 + 3) de daño perforante y la siguiente tirada de ataque realizada contra el objetivo antes del principio del siguiente turno del huargo tendrá ventaja."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 4
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "goblin",
        "huargo"
      ],
      "cr": "1/2",
      "proficiencyBonus": 2,
      "xp": 100
    },
    {
      "id": "ifrit",
      "name": "Ifrit",
      "size": "Grande",
      "type": "elemental",
      "alignment": "neutral",
      "ac": 17,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 212,
        "formula": "17d10 + 119"
      },
      "speed": {
        "walk": "40 pies",
        "fly": "60 pies (levitar)"
      },
      "abilities": {
        "str": 22,
        "dex": 12,
        "con": 24,
        "int": 16,
        "wis": 15,
        "cha": 19
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 6
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 7
        },
        {
          "ability": "int",
          "bonus": 3
        },
        {
          "ability": "wis",
          "bonus": 6
        },
        {
          "ability": "cha",
          "bonus": 8
        }
      ],
      "traits": [
        {
          "name": "Deseos",
          "text": "El ifrit tiene un 30 % de probabilidad de conocer el conjuro deseo. Si es así, puede lanzarlo en nombre de una criatura que no sea un genio y que pida un deseo de tal modo que el ifrit pueda entenderlo. Si el ifrit lanza el conjuro para esa criatura, no sufrirá los efectos de la tensión del conjuro. Cuando lo haya lanzado tres veces, el ifrit no podrá volver a hacerlo hasta pasados 365 días."
        },
        {
          "name": "Recuperación elemental",
          "text": "Si el ifrit muere fuera del Plano Elemental del Fuego, su cuerpo se convierte en ceniza, obtiene un cuerpo nuevo tras 1d4 días y revive con todos sus puntos de golpe en algún lugar del Plano del Fuego."
        },
        {
          "name": "Resistencia mágica",
          "text": "El ifrit tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El ifrit realiza tres ataques con su hoja candente o su acción de arrojar llama en cualquier combinación."
        },
        {
          "name": "Hoja candente",
          "text": "Tirada de ataque cuerpo a cuerpo: +10, alcance 5 pies. Acierto: 13 (2d6 + 6) de daño cortante más 13 (2d12) de daño de fuego."
        },
        {
          "name": "Arrojar llama",
          "text": "Tirada de ataque a distancia: +8, alcance 120 pies. Acierto: 24 (7d6) de daño de fuego."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El ifrit lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 16): A voluntad: detectar magia, elementalismo 1/día cada uno: desplazamiento entre planos, don de lenguas, forma gaseosa, imagen mayor, invisibilidad, muro de fuego (versión de nivel 7)"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "genio",
      "damageImmunities": [
        "fuego"
      ],
      "senses": [
        "visión en la oscuridad 120 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "primordial (ígneo)"
      ],
      "cr": "11",
      "proficiencyBonus": 4,
      "xp": 7200
    },
    {
      "id": "incubo",
      "name": "Íncubo",
      "size": "Mediano",
      "type": "infernal",
      "alignment": "neutral malvado",
      "ac": 15,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 66,
        "formula": "12d8 + 12"
      },
      "speed": {
        "walk": "30 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 8,
        "dex": 17,
        "con": 13,
        "int": 15,
        "wis": 12,
        "cha": 20
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -1
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 2
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": 5
        }
      ],
      "traits": [
        {
          "name": "Forma de súcubo",
          "text": "Cuando el íncubo finaliza un descanso largo, puede adoptar la forma de un súcubo y pasar a utilizar ese perfil en lugar de este. Cualquier equipo que vista o lleve no se transformará."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El íncubo realiza dos ataques con su toque inquietante."
        },
        {
          "name": "Toque inquietante",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 15 (3d6 + 5) de daño psíquico y el objetivo estará maldito durante 24 horas o hasta que el íncubo muera. Hasta que la maldición termine, el objetivo no obtendrá ningún beneficio al finalizar descansos cortos."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El íncubo lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 15): A voluntad: disfrazarse, excursión etérea 1/día cada uno: ensueño, patrón hipnótico"
        }
      ],
      "bonusActions": [
        {
          "name": "Pesadilla (recarga 6)",
          "text": "Tirada de salvación de Sabiduría: CD 15, una criatura que el íncubo pueda ver a 60 pies o menos. Fallo: si el objetivo tiene 20 puntos de golpe o menos, tendrá el estado de inconsciente durante 1 hora, hasta que reciba daño o hasta que una criatura a 5 pies o menos lleve a cabo una acción para despertarlo. De lo contrario, el objetivo recibe 18 (4d8) de daño psíquico. Kobold"
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Engaño",
          "bonus": 9
        },
        {
          "name": "Percepción",
          "bonus": 5
        },
        {
          "name": "Perspicacia",
          "bonus": 5
        },
        {
          "name": "Persuasión",
          "bonus": 9
        },
        {
          "name": "Sigilo",
          "bonus": 7
        }
      ],
      "damageResistances": [
        "frío",
        "fuego",
        "psíquico",
        "veneno"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 15"
      ],
      "languages": [
        "abisal",
        "común",
        "infernal",
        "telepatía 60 pies"
      ],
      "cr": "4",
      "proficiencyBonus": 2,
      "xp": 1100
    },
    {
      "id": "guerrero_kobold",
      "name": "Guerrero kobold",
      "size": "Pequeño",
      "type": "dragón",
      "alignment": "neutral",
      "ac": 14,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 7,
        "formula": "3d6 - 3"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 7,
        "dex": 15,
        "con": 9,
        "int": 8,
        "wis": 7,
        "cha": 8
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -2
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": -1
        },
        {
          "ability": "int",
          "bonus": -1
        },
        {
          "ability": "wis",
          "bonus": -2
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [
        {
          "name": "Atacar en manada",
          "text": "El kobold tiene ventaja en una tirada de ataque contra una criatura si al menos uno de los aliados del kobold se encuentra a 5 pies o menos de la criatura y no tiene el estado de incapacitado."
        },
        {
          "name": "Sensibilidad a la luz solar",
          "text": "Bajo la luz del sol, el kobold tiene desventaja en las pruebas de característica y las tiradas de ataque."
        }
      ],
      "actions": [
        {
          "name": "Daga",
          "text": "Tirada de ataque cuerpo a cuerpo o a distancia: +4, alcance 5 pies o 6/60 pies a distancia. Acierto: 4 (1d4 + 2) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "equipment": [
        "dagas (3)"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 8"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "1/8",
      "proficiencyBonus": 2,
      "xp": 25
    },
    {
      "id": "kraken",
      "name": "Kraken",
      "size": "Gargantuesca",
      "type": "monstruosidad",
      "alignment": "caótica malvada",
      "ac": 18,
      "initiative": {
        "modifier": 14,
        "score": 24
      },
      "hp": {
        "average": 481,
        "formula": "26d20 + 208"
      },
      "speed": {
        "walk": "30 pies",
        "swim": "120 pies"
      },
      "abilities": {
        "str": 30,
        "dex": 11,
        "con": 26,
        "int": 22,
        "wis": 18,
        "cha": 20
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 17
        },
        {
          "ability": "dex",
          "bonus": 7
        },
        {
          "ability": "con",
          "bonus": 15
        },
        {
          "ability": "int",
          "bonus": 6
        },
        {
          "ability": "wis",
          "bonus": 11
        },
        {
          "ability": "cha",
          "bonus": 5
        }
      ],
      "traits": [
        {
          "name": "Anfibio",
          "text": "El kraken puede respirar tanto dentro como fuera del agua."
        },
        {
          "name": "Monstruo de asedio",
          "text": "El kraken inflige el doble de daño a objetos y estructuras. Resistencia legendaria (4/día o 5/día en la guarida). El kraken puede elegir tener éxito en una tirada de salvación que haya fallado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El kraken realiza dos ataques con sus tentáculos y lleva a cabo una acción de engullir, lanzar o relámpago."
        },
        {
          "name": "Tentáculo",
          "text": "Tirada de ataque cuerpo a cuerpo: +17, alcance 30 pies. Acierto: 24 (4d6 + 10) de daño contundente. El objetivo tendrá el estado de agarrado (CD 20 para escapar) por uno de los diez tentáculos y el de apresado hasta que el agarre termine."
        },
        {
          "name": "Engullir",
          "text": "Tirada de salvación de Destreza: CD 25, una criatura agarrada por el kraken (puede tener hasta cuatro criaturas engullidas a la vez). Fallo: 23 (3d8 + 10) de daño perforante. Si el objetivo es Grande o más pequeño, será engullido y dejará de estar agarrado. Una criatura engullida tendrá el estado de apresada, tendrá cobertura completa contra los ataques y otros efectos fuera del kraken y recibirá 24 (7d6) de daño de ácido al principio de cada uno de sus propios turnos. Si el kraken sufre 50 o más de daño en un solo turno por parte de una criatura que esté dentro de él, deberá superar una tirada de salvación de Constitución con CD 25 al final de ese turno o regurgitará a todas las criaturas engullidas, que caerán en espacios a 10 pies o menos del kraken y tendrán el estado de derribadas. Si el kraken muere, cualquier criatura engullida dejará de tener el estado de apresada y podrá gastar 15 pies de movimiento para escapar del cadáver, del que saldrá con el estado de derribada."
        },
        {
          "name": "Lanzar",
          "text": "El kraken lanza una criatura Grande o más pequeña que tenga agarrada a un espacio que pueda ver a 60 pies o menos de él que no esté en el aire. Tirada de salvación de Destreza: CD 25, la criatura lanzada y todas las criaturas en el espacio de destino. Fallo: 18 (4d8) de daño contundente y el objetivo tiene el estado de derribado. Éxito: solo la mitad del daño."
        },
        {
          "name": "Relámpago",
          "text": "Tirada de salvación de Destreza: CD 23, una criatura que el kraken pueda ver a 120 pies o menos."
        },
        {
          "name": "Fallo: 33 (6d10) de daño de relámpago",
          "text": "Éxito: la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "titán",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, el kraken puede emplear un uso para llevar a cabo una de las siguientes acciones. El kraken recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Golpe de tormenta",
          "text": "El kraken utiliza su relámpago."
        },
        {
          "name": "Tinta tóxica",
          "text": "Tirada de salvación de Constitución: CD 23, todas las criaturas en una emanación de 15 pies que se origina en el kraken mientras esté bajo el agua. Fallo: el objetivo tendrá los estados de cegado y envenenado hasta el final del siguiente turno del kraken."
        },
        {
          "name": "Después, el kraken se mueve hasta su velocidad",
          "text": "Fallo o éxito: el kraken no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        }
      ],
      "skills": [
        {
          "name": "Historia",
          "bonus": 13
        },
        {
          "name": "Percepción",
          "bonus": 11
        }
      ],
      "damageImmunities": [
        "frío",
        "relámpago"
      ],
      "conditionImmunities": [
        "agarrado",
        "apresado",
        "asustado",
        "paralizado"
      ],
      "senses": [
        "visión verdadera 120 pies",
        "Percepción pasiva 21"
      ],
      "languages": [
        "entiende abisal, celestial, infernal y primordial, pero no puede hablar",
        "telepatía 120 pies"
      ],
      "cr": "23",
      "proficiencyBonus": 7,
      "xp": 50000,
      "xpText": "50 000 PX o 62 000 en la guarida"
    },
    {
      "id": "lacero",
      "name": "Lacero",
      "size": "Grande",
      "type": "aberración",
      "alignment": "neutral malvada",
      "ac": 20,
      "initiative": {
        "modifier": 5,
        "score": 15
      },
      "hp": {
        "average": 93,
        "formula": "11d10 + 33"
      },
      "speed": {
        "walk": "10 pies",
        "climb": "20 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 8,
        "con": 17,
        "int": 7,
        "wis": 16,
        "cha": 6
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": -1
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 3
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [
        {
          "name": "Trepar cual arácnido",
          "text": "El lacero puede trepar por superficies difíciles e incluso recorrer techos sin tener que realizar pruebas de característica."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El lacero realiza dos ataques con sus tentáculos, usa la acción de atraer y hace dos ataques de mordisco."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 17 (3d8 + 4) de daño perforante."
        },
        {
          "name": "Tentáculo",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 60 pies. Acierto: el objetivo tendrá el estado de agarrado (CD 14 para escapar) por uno de los seis tentáculos y el de envenenado hasta que el agarre termine. El tentáculo se puede dañar y soltará a una criatura agarrada cuando se destruya (CA de 20, 10 pg e inmunidad al daño psíquico y de veneno). Dañar el tentáculo no daña al lacero y un tentáculo destruido vuelve a crecer al principio del siguiente turno del lacero."
        },
        {
          "name": "Atraer",
          "text": "El lacero arrastra a todas las criaturas que tenga agarradas hasta 30 pies en línea recta hacia él."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 6
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 16"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "5",
      "proficiencyBonus": 3,
      "xp": 1800
    },
    {
      "id": "lamia",
      "name": "Lamia",
      "size": "Grande",
      "type": "infernal",
      "alignment": "caótico malvado",
      "ac": 13,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 97,
        "formula": "13d10 + 26"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 13,
        "con": 15,
        "int": 14,
        "wis": 15,
        "cha": 16
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": 2
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 3
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "La lamia realiza dos ataques con sus garras. Puede sustituir un ataque por un uso de su toque corruptor."
        },
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 7 (1d8 + 3) de daño cortante más 7 (2d6) de daño psíquico."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "La lamia lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 13): A voluntad: disfrazarse (puede presentarse como un bípedo Grande o Mediano), ilusión menor 1/día cada uno: escudriñar, geas, imagen mayor"
        },
        {
          "name": "Toque corruptor",
          "text": "Tirada de salvación de Sabiduría: CD 13, una criatura que la lamia pueda ver a 5 pies o menos. Fallo: 13 (3d8) de daño psíquico y el objetivo estará maldito durante 1 hora. Hasta que se levante la maldición, el objetivo tendrá los estados de envenenado y hechizado."
        }
      ],
      "bonusActions": [
        {
          "name": "Salto",
          "text": "La lamia gasta 10 pies de movimiento para saltar hasta 30 pies."
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Engaño",
          "bonus": 7
        },
        {
          "name": "Perspicacia",
          "bonus": 4
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "abisal",
        "común"
      ],
      "cr": "4",
      "proficiencyBonus": 2,
      "xp": 1100
    },
    {
      "id": "lemur",
      "name": "Lémur",
      "size": "Mediano",
      "type": "infernal",
      "alignment": "legal malvado",
      "ac": 9,
      "initiative": {
        "modifier": -3,
        "score": 7
      },
      "hp": {
        "average": 9,
        "formula": "2d8"
      },
      "speed": {
        "walk": "20 pies"
      },
      "abilities": {
        "str": 10,
        "dex": 5,
        "con": 11,
        "int": 1,
        "wis": 11,
        "cha": 3
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 0
        },
        {
          "ability": "dex",
          "bonus": -3
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": -5
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -4
        }
      ],
      "traits": [
        {
          "name": "Recuperación en los Infiernos",
          "text": "Si el lémur muere en los Nueve Infiernos, revive con todos sus puntos de golpe al cabo de 1d10 días salvo si lo mata una criatura bajo los efectos de un conjuro bendición o si se rocían sus restos con agua bendita."
        }
      ],
      "actions": [
        {
          "name": "Baba repulsiva",
          "text": "Tirada de ataque cuerpo a cuerpo: +2, alcance 5 pies. Acierto: 2 (1d4) de daño de veneno."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "diablo",
      "damageResistances": [
        "frío"
      ],
      "damageImmunities": [
        "fuego",
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "envenenado",
        "hechizado"
      ],
      "senses": [
        "visión en la oscuridad 120 pies (no afectada por la oscuridad mágica)",
        "Percepción pasiva 10"
      ],
      "languages": [
        "entiende infernal, pero no puede hablar"
      ],
      "cr": "0",
      "proficiencyBonus": 2,
      "xp": 10
    },
    {
      "id": "liche",
      "name": "Liche",
      "size": "Mediano",
      "type": "muerto viviente",
      "alignment": "neutral malvado",
      "ac": 20,
      "initiative": {
        "modifier": 17,
        "score": 27
      },
      "hp": {
        "average": 315,
        "formula": "42d8 + 126"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 11,
        "dex": 16,
        "con": 16,
        "int": 21,
        "wis": 14,
        "cha": 16
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 0
        },
        {
          "ability": "dex",
          "bonus": 10
        },
        {
          "ability": "con",
          "bonus": 10
        },
        {
          "ability": "int",
          "bonus": 12
        },
        {
          "ability": "wis",
          "bonus": 9
        },
        {
          "ability": "cha",
          "bonus": 3
        }
      ],
      "traits": [
        {
          "name": "Recipiente espiritual",
          "text": "Si lo destruyen, el liche se recompondrá al cabo de 1d10 días si tiene un recipiente espiritual y revivirá con todos sus puntos de golpe. El nuevo cuerpo aparecerá en un espacio sin ocupar en la guarida del liche. Resistencia legendaria (4/día o 5/día en la guarida). El liche puede elegir tener éxito en una tirada de salvación que haya fallado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El liche realiza tres ataques con su estallido sobrenatural o su toque paralizante en cualquier combinación."
        },
        {
          "name": "Estallido sobrenatural",
          "text": "Tirada de ataque cuerpo a cuerpo o a distancia: +12, alcance 5 pies o 120 pies a distancia. Acierto: 31 (4d12 + 5) de daño de fuerza."
        },
        {
          "name": "Toque paralizante",
          "text": "Tirada de ataque cuerpo a cuerpo: +12, alcance 5 pies. Acierto: 15 (3d6 + 5) de daño de frío y el objetivo tendrá el estado de paralizado hasta el principio del siguiente turno del liche."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El liche lanza uno de los siguientes conjuros, que utiliza la Inteligencia como aptitud mágica (CD de salvación de conjuros 20): A voluntad: bola de fuego (versión de nivel 5), detectar magia, detectar pensamientos, disipar magia, invisibilidad, mano de mago, prestidigitación, relámpago (versión de nivel 5) 2/día cada uno: animar a los muertos, desplazamiento entre planos, puerta dimensional 1/día cada uno: dedo de la muerte, escudriñar, palabra de poder: matar, relámpago en cadena"
        }
      ],
      "bonusActions": [],
      "reactions": [
        {
          "name": "Magia protectora",
          "text": "El liche lanza contrahechizo o escudo en respuesta al desencadenante de esos conjuros, usando la misma aptitud mágica que para su lanzamiento de conjuros."
        }
      ],
      "subtype": "mago",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, el liche puede emplear un uso para llevar a cabo una de las siguientes acciones. El liche recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Mirada aterradora",
          "text": "El liche lanza terror usando la misma aptitud mágica que para su lanzamiento de conjuros. el liche no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        },
        {
          "name": "Perturbar vida",
          "text": "Tirada de salvación de Constitución: CD 20, todas las criaturas que no sean muertos vivientes en una emanación de 20 pies que se origina en el liche."
        },
        {
          "name": "Fallo: 31 (9d6) de daño necrótico",
          "text": "Éxito: la mitad del daño. Fallo o éxito: el liche no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        },
        {
          "name": "Teletransporte letal",
          "text": "El liche se teletransporta hasta 60 pies a un espacio sin ocupar que pueda ver y todas las criaturas a 10 pies o menos del espacio que abandonó reciben 11 (2d10) de daño necrótico."
        }
      ],
      "skills": [
        {
          "name": "Conocimiento arcano",
          "bonus": 19
        },
        {
          "name": "Historia",
          "bonus": 12
        },
        {
          "name": "Percepción",
          "bonus": 9
        },
        {
          "name": "Perspicacia",
          "bonus": 9
        }
      ],
      "damageResistances": [
        "frío",
        "relámpago"
      ],
      "damageImmunities": [
        "necrótico",
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "cansancio",
        "envenenado",
        "hechizado",
        "paralizado"
      ],
      "equipment": [
        "saquito de componentes"
      ],
      "senses": [
        "visión verdadera 120 pies",
        "Percepción pasiva 19"
      ],
      "languages": [
        "todos"
      ],
      "cr": "21",
      "proficiencyBonus": 7,
      "xp": 33000,
      "xpText": "33 000 PX o 41 000 en la guarida"
    },
    {
      "id": "lobo_invernal",
      "name": "Lobo invernal",
      "size": "Grande",
      "type": "monstruosidad",
      "alignment": "neutral malvada",
      "ac": 13,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 75,
        "formula": "10d10 + 20"
      },
      "speed": {
        "walk": "50 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 13,
        "con": 14,
        "int": 7,
        "wis": 12,
        "cha": 8
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [
        {
          "name": "Atacar en manada",
          "text": "El lobo tiene ventaja en una tirada de ataque contra una criatura si al menos uno de los aliados del lobo se encuentra a 5 pies o menos de la criatura y no tiene el estado de incapacitado."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 11 (2d6 + 4) de daño perforante. Si el objetivo es una criatura Grande o más pequeña, tendrá el estado de derribada."
        },
        {
          "name": "Aliento gélido (recarga 5–6)",
          "text": "Tirada de salvación de Constitución: CD 12, todas las criaturas en un cono de 15 pies. Fallo: 18 (4d8) de daño de frío. Éxito: la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 5
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "damageImmunities": [
        "frío"
      ],
      "senses": [
        "Percepción pasiva 15"
      ],
      "languages": [
        "común",
        "gigante"
      ],
      "cr": "3",
      "proficiencyBonus": 2,
      "xp": 700
    },
    {
      "id": "magmin",
      "name": "Magmin",
      "size": "Pequeño",
      "type": "elemental",
      "alignment": "caótico neutral",
      "ac": 14,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 13,
        "formula": "3d6 + 3"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 7,
        "dex": 15,
        "con": 12,
        "int": 8,
        "wis": 11,
        "cha": 10
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -2
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": -1
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [
        {
          "name": "Explotar al morir",
          "text": "El magmin explota cuando muere. Tirada de salvación de Destreza: CD 11, todas las criaturas en una emanación de 10 pies que se origina en el magmin. Fallo: 7 (2d6) de daño de fuego. Éxito: la mitad del daño."
        }
      ],
      "actions": [
        {
          "name": "Toque",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 7 (2d4 + 2) de daño de fuego. Si el objetivo es una criatura u objeto inflamable que no lleve o vista nadie, empieza a arder."
        }
      ],
      "bonusActions": [
        {
          "name": "Iluminación ardiente",
          "text": "El magmin se prende fuego o extingue sus llamas. Mientras esté ardiendo, emitirá luz brillante en un radio de 10 pies y luz tenue 10 pies más allá. Magos"
        }
      ],
      "reactions": [],
      "damageImmunities": [
        "fuego"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "primordial (ígneo)"
      ],
      "cr": "1/2",
      "proficiencyBonus": 2,
      "xp": 100
    },
    {
      "id": "mago",
      "name": "Mago",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 15,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 81,
        "formula": "18d8"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 9,
        "dex": 14,
        "con": 11,
        "int": 17,
        "wis": 12,
        "cha": 11
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -1
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": 6
        },
        {
          "ability": "wis",
          "bonus": 4
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El mago realiza tres ataques con su estallido arcano."
        },
        {
          "name": "Estallido arcano",
          "text": "Tirada de ataque cuerpo a cuerpo o a distancia: +6, alcance 5 pies o 120 pies a distancia. Acierto: 16 (3d8 + 3) de daño de fuerza."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El mago lanza uno de los siguientes conjuros, que utiliza la Inteligencia como aptitud mágica (CD de salvación de conjuros 14): A voluntad: armadura de mago (incluido en la CA), detectar magia, luz, mano de mago, prestidigitación 2/día cada uno: bola de fuego (versión de nivel 4), invisibilidad 1/día cada uno: cono de frío, volar"
        }
      ],
      "bonusActions": [
        {
          "name": "Paso brumoso (3/día)",
          "text": "El mago lanza paso brumoso usando la misma aptitud mágica que para su lanzamiento de conjuros."
        }
      ],
      "reactions": [
        {
          "name": "Magia protectora (3/día)",
          "text": "El mago lanza contrahechizo o escudo en respuesta al desencadenante de esos conjuros, usando la misma aptitud mágica que para su lanzamiento de conjuros."
        }
      ],
      "subtype": "mago",
      "skills": [
        {
          "name": "Conocimiento arcano",
          "bonus": 6
        },
        {
          "name": "Historia",
          "bonus": 6
        },
        {
          "name": "Percepción",
          "bonus": 4
        }
      ],
      "equipment": [
        "varita"
      ],
      "senses": [
        "Percepción pasiva 14"
      ],
      "languages": [
        "común y otros tres idiomas"
      ],
      "cr": "6",
      "proficiencyBonus": 3,
      "xp": 2300
    },
    {
      "id": "archimago",
      "name": "Archimago",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 17,
      "initiative": {
        "modifier": 7,
        "score": 17
      },
      "hp": {
        "average": 170,
        "formula": "31d8 + 31"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 10,
        "dex": 14,
        "con": 12,
        "int": 20,
        "wis": 15,
        "cha": 16
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 0
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 9
        },
        {
          "ability": "wis",
          "bonus": 6
        },
        {
          "ability": "cha",
          "bonus": 3
        }
      ],
      "traits": [
        {
          "name": "Resistencia mágica",
          "text": "El archimago tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El archimago realiza cuatro ataques con su estallido arcano."
        },
        {
          "name": "Estallido arcano",
          "text": "Tirada de ataque cuerpo a cuerpo o a distancia: +9, alcance 5 pies o 150 pies a distancia. Acierto: 27 (4d10 + 5) de daño de fuerza."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El archimago lanza uno de los siguientes conjuros, que utiliza la Inteligencia como aptitud mágica (CD de salvación de conjuros 17): A voluntad: armadura de mago (incluido en la CA), detectar magia, detectar pensamientos, disfrazarse, invisibilidad, luz, mano de mago, prestidigitación 2/día cada uno: relámpago (versión de nivel 7), volar 1/día cada uno: cono de frío (versión de nivel 9), escudriñar, mente en blanco (lanzado antes del combate), teletransporte"
        }
      ],
      "bonusActions": [
        {
          "name": "Paso brumoso (3/día)",
          "text": "El mago lanza paso brumoso usando la misma aptitud mágica que para su lanzamiento de conjuros."
        }
      ],
      "reactions": [
        {
          "name": "Magia protectora (3/día)",
          "text": "El archimago lanza contrahechizo o escudo en respuesta al desencadenante de esos conjuros, usando la misma aptitud mágica que para su lanzamiento de conjuros."
        }
      ],
      "subtype": "mago",
      "skills": [
        {
          "name": "Conocimiento arcano",
          "bonus": 13
        },
        {
          "name": "Historia",
          "bonus": 9
        },
        {
          "name": "Percepción",
          "bonus": 6
        }
      ],
      "damageImmunities": [
        "psíquico",
        "hechizado (con mente en blanco)"
      ],
      "equipment": [
        "varita"
      ],
      "senses": [
        "Percepción pasiva 16"
      ],
      "languages": [
        "común y otros cinco idiomas"
      ],
      "cr": "12",
      "proficiencyBonus": 4,
      "xp": 8000
    },
    {
      "id": "manticora",
      "name": "Mantícora",
      "size": "Grande",
      "type": "monstruosidad",
      "alignment": "legal malvada",
      "ac": 14,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 68,
        "formula": "8d10 + 24"
      },
      "speed": {
        "walk": "30 pies",
        "fly": "50 pies"
      },
      "abilities": {
        "str": 17,
        "dex": 16,
        "con": 17,
        "int": 7,
        "wis": 12,
        "cha": 8
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "La mantícora realiza tres ataques de desgarro o con sus púas de cola en cualquier combinación."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 7 (1d8 + 3) de daño cortante."
        },
        {
          "name": "Púas de cola",
          "text": "Tirada de ataque a distancia: +5, alcance 30/200 pies. Acierto: 7 (1d8 + 3) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 11"
      ],
      "languages": [
        "común"
      ],
      "cr": "3",
      "proficiencyBonus": 2,
      "xp": 700
    },
    {
      "id": "manto",
      "name": "Manto",
      "size": "Grande",
      "type": "aberración",
      "alignment": "caótica neutral",
      "ac": 14,
      "initiative": {
        "modifier": 5,
        "score": 15
      },
      "hp": {
        "average": 91,
        "formula": "14d10 + 14"
      },
      "speed": {
        "walk": "10 pies",
        "fly": "40 pies"
      },
      "abilities": {
        "str": 17,
        "dex": 15,
        "con": 12,
        "int": 13,
        "wis": 14,
        "cha": 7
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [
        {
          "name": "Sensibilidad a la luz",
          "text": "Bajo la luz brillante, el manto tiene desventaja en las tiradas de ataque."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El manto realiza la acción de adherirse y lleva a cabo dos ataques con su cola."
        },
        {
          "name": "Adherirse",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 13 (3d6 + 3) de daño perforante. Si el objetivo es una criatura Grande o más pequeña, el manto se adhiere a ella. Mientras el manto esté adherido, el objetivo tendrá el estado de cegado y el manto no podrá realizar la acción de adherirse contra otros objetivos. Asimismo, el manto reduce a la mitad el daño que reciba (redondeando hacia abajo) y el objetivo sufre la misma cantidad de daño. El manto puede usar 5 pies de movimiento para soltarse. El objetivo o una criatura que esté a 5 pies o menos de él puede llevar a cabo una acción para tratar de desenganchar al manto, lo que logrará si supera una prueba de Fuerza (Atletismo) con CD 14."
        },
        {
          "name": "Cola",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 10 pies. Acierto: 8 (1d10 + 3) de daño cortante."
        }
      ],
      "bonusActions": [
        {
          "name": "Fantasmas (se recarga tras un descanso corto o largo)",
          "text": "El manto lanza el conjuro imagen múltiple, que no requiere componentes y utiliza la Sabiduría como aptitud mágica. El conjuro termina antes de tiempo si el manto comienza o termina su turno en una zona de luz brillante."
        },
        {
          "name": "Gemido",
          "text": "Tirada de salvación de Sabiduría: CD 13, todas las criaturas en una emanación de 60 pies que se origina en el manto. Fallo: el objetivo tendrá el estado de asustado hasta el final del siguiente turno del manto. Éxito: el objetivo será inmune al gemido de este manto durante las siguientes 24 horas."
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "conditionImmunities": [
        "asustado"
      ],
      "senses": [
        "visión en la oscuridad 120 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "habla de las profundidades",
        "infracomún"
      ],
      "cr": "8",
      "proficiencyBonus": 3,
      "xp": 3900
    },
    {
      "id": "mantoscuro",
      "name": "Mantoscuro",
      "size": "Pequeña",
      "type": "aberración",
      "alignment": "sin alineamiento",
      "ac": 11,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 22,
        "formula": "5d6 + 5"
      },
      "speed": {
        "walk": "10 pies",
        "fly": "30 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 12,
        "con": 13,
        "int": 2,
        "wis": 10,
        "cha": 5
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -3
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Aplastar",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 6 (1d6 + 3) de daño contundente y el mantoscuro se engancha al objetivo. Si el objetivo es una criatura Mediana o más pequeña y el mantoscuro tenía ventaja en la tirada de ataque, cubrirá al objetivo, que tendrá el estado de cegado y se asfixiará mientras el mantoscuro esté enganchado de esta forma. Mientras esté enganchado a un objetivo, el mantoscuro solo podrá atacarlo a él, pero tendrá ventaja en las tiradas de ataque. Su velocidad pasará a ser 0, no podrá beneficiarse de ningún bonificador a su velocidad y se moverá con el objetivo. Una criatura puede emplear una acción para intentar quitarse de encima al mantoscuro superando una prueba de Fuerza (Atletismo) con CD 13. En su turno, el mantoscuro puede separarse gastando 5 pies de movimiento."
        },
        {
          "name": "Aura de oscuridad (1/día)",
          "text": "Una oscuridad mágica llena una emanación de 15 pies que se origina en el mantoscuro. Este efecto dura mientras el mantoscuro mantenga la concentración en él, hasta 10 minutos. La visión en la oscuridad no puede penetrar en esta zona y ninguna luz puede alumbrarla."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 3
        }
      ],
      "senses": [
        "visión ciega 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/2",
      "proficiencyBonus": 2,
      "xp": 100
    },
    {
      "id": "marilith",
      "name": "Marilith",
      "size": "Grande",
      "type": "infernal",
      "alignment": "caótico malvado",
      "ac": 16,
      "initiative": {
        "modifier": 10,
        "score": 20
      },
      "hp": {
        "average": 220,
        "formula": "21d10 + 105"
      },
      "speed": {
        "walk": "40 pies",
        "climb": "40 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 20,
        "con": 20,
        "int": 18,
        "wis": 16,
        "cha": 20
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 9
        },
        {
          "ability": "dex",
          "bonus": 5
        },
        {
          "ability": "con",
          "bonus": 10
        },
        {
          "ability": "int",
          "bonus": 4
        },
        {
          "ability": "wis",
          "bonus": 8
        },
        {
          "ability": "cha",
          "bonus": 10
        }
      ],
      "traits": [
        {
          "name": "Reactiva",
          "text": "La marilith puede llevar a cabo una reacción en cada turno de combate."
        },
        {
          "name": "Recuperación demoníaca",
          "text": "Si la marilith muere fuera del Abismo, su cuerpo se disuelve en icor, obtiene un cuerpo nuevo al instante y revive con todos sus puntos de golpe en algún lugar del Abismo."
        },
        {
          "name": "Resistencia mágica",
          "text": "La marilith tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "La marilith realiza seis ataques con sus cuchillas de pacto y emplea su acción de constreñir."
        },
        {
          "name": "Cuchilla de pacto",
          "text": "Tirada de ataque cuerpo a cuerpo: +10, alcance 5 pies. Acierto: 10 (1d10 + 5) de daño cortante más 7 (2d6) de daño necrótico."
        },
        {
          "name": "Constreñir",
          "text": "Tirada de salvación de Fuerza: CD 17, una criatura Mediana o más pequeña que la marilith pueda ver a 5 pies o menos. Fallo: 15 (2d10 + 4) de daño contundente. El objetivo tendrá el estado de agarrado (CD 14 para escapar) y el de apresado hasta que el agarre termine."
        }
      ],
      "bonusActions": [
        {
          "name": "Teletransporte (recarga 5–6)",
          "text": "La marilith se teletransporta hasta 120 pies a un espacio sin ocupar que pueda ver."
        }
      ],
      "reactions": [
        {
          "name": "Parada",
          "text": "Detonante: una tirada de ataque cuerpo a cuerpo acierta a la marilith mientras sostiene un arma. Respuesta: la marilith suma 5 a su CA contra ese ataque, lo que puede hacer que falle."
        }
      ],
      "subtype": "demonio",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 8
        }
      ],
      "damageResistances": [
        "frío",
        "fuego",
        "relámpago"
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado"
      ],
      "senses": [
        "visión verdadera 120 pies",
        "Percepción pasiva 18"
      ],
      "languages": [
        "abisal",
        "telepatía 120 pies"
      ],
      "cr": "16",
      "proficiencyBonus": 5,
      "xp": 15000
    },
    {
      "id": "medusa",
      "name": "Medusa",
      "size": "Mediana",
      "type": "monstruosidad",
      "alignment": "legal malvada",
      "ac": 15,
      "initiative": {
        "modifier": 6,
        "score": 16
      },
      "hp": {
        "average": 127,
        "formula": "17d8 + 51"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 10,
        "dex": 17,
        "con": 16,
        "int": 12,
        "wis": 13,
        "cha": 15
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 0
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 4
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "La medusa realiza dos ataques con sus garras y uno con su pelo de serpientes, o realiza tres con su rayo venenoso."
        },
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 10 (2d6 + 3) de daño cortante."
        },
        {
          "name": "Pelo de serpientes",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 5 (1d4 + 3) de daño perforante más 14 (4d6) de daño de veneno."
        },
        {
          "name": "Rayo venenoso",
          "text": "Tirada de ataque a distancia: +5, alcance 150 pies. Acierto: 11 (2d8 + 2) de daño de veneno."
        }
      ],
      "bonusActions": [
        {
          "name": "Mirada petrificadora (recarga 5–6)",
          "text": "Tirada de salvación de Constitución: CD 13, todas las criaturas en un cono de 30 pies. Si la medusa ve su reflejo en alguna parte del cono, deberá hacer esta tirada. Primer fallo: el objetivo tendrá el estado de apresado. Si al final de su siguiente turno sigue apresado, repetirá la tirada de salvación y se librará del efecto si la supera. Segundo fallo: el objetivo tendrá el estado de petrificado en vez del de apresado. Mephits"
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Engaño",
          "bonus": 5
        },
        {
          "name": "Percepción",
          "bonus": 4
        },
        {
          "name": "Sigilo",
          "bonus": 6
        }
      ],
      "senses": [
        "visión en la oscuridad 150 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "común y otro cualquiera"
      ],
      "cr": "6",
      "proficiencyBonus": 3,
      "xp": 2300
    },
    {
      "id": "mephit_de_hielo",
      "name": "Mephit de hielo",
      "size": "Pequeño",
      "type": "elemental",
      "alignment": "neutral malvado",
      "ac": 11,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 21,
        "formula": "6d6"
      },
      "speed": {
        "walk": "30 pies",
        "fly": "30 pies"
      },
      "abilities": {
        "str": 7,
        "dex": 13,
        "con": 10,
        "int": 9,
        "wis": 11,
        "cha": 12
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -2
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": -1
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 1
        }
      ],
      "traits": [
        {
          "name": "Explotar al morir",
          "text": "El mephit explota cuando muere. Tirada de salvación de Constitución: CD 10, todas las criaturas en una emanación de 5 pies que se origina en el mephit. Fallo: 5 (2d4) de daño de frío. Éxito: la mitad del daño."
        }
      ],
      "actions": [
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +3, alcance 5 pies. Acierto: 3 (1d4 + 1) de daño cortante más 2 (1d4) de daño de frío."
        },
        {
          "name": "Aliento de escarcha (recarga 6)",
          "text": "Tirada de salvación de Constitución: CD 10, todas las criaturas en un cono de 15 pies. Fallo: 7 (3d4) de daño de frío. Éxito: la mitad del daño."
        },
        {
          "name": "Nube de oscurecimiento (1/día)",
          "text": "El mephit lanza nube de oscurecimiento, que no requiere componentes y utiliza el Carisma como aptitud mágica."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 2
        },
        {
          "name": "Sigilo",
          "bonus": 3
        }
      ],
      "damageVulnerabilities": [
        "fuego"
      ],
      "damageImmunities": [
        "frío",
        "veneno"
      ],
      "conditionImmunities": [
        "cansancio",
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "primordial (acuano",
        "aurano)"
      ],
      "cr": "1/2",
      "proficiencyBonus": 2,
      "xp": 100
    },
    {
      "id": "mephit_de_magma",
      "name": "Mephit de magma",
      "size": "Pequeño",
      "type": "elemental",
      "alignment": "neutral malvado",
      "ac": 11,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 18,
        "formula": "4d6 + 4"
      },
      "speed": {
        "walk": "30 pies",
        "fly": "30 pies"
      },
      "abilities": {
        "str": 8,
        "dex": 12,
        "con": 12,
        "int": 7,
        "wis": 10,
        "cha": 10
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -1
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [
        {
          "name": "Explotar al morir",
          "text": "El mephit explota cuando muere. Tirada de salvación de Destreza: CD 11, todas las criaturas en una emanación de 5 pies que se origina en el mephit. Fallo: 7 (2d6) de daño de fuego. Éxito: la mitad del daño."
        }
      ],
      "actions": [
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +3, alcance 5 pies. Acierto: 3 (1d4 + 1) de daño cortante más 3 (1d6) de daño de fuego."
        },
        {
          "name": "Aliento de fuego (recarga 6)",
          "text": "Tirada de salvación de Destreza: CD 11, todas las criaturas en un cono de 15 pies. Fallo: 7 (2d6) de daño de fuego. Éxito: la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 3
        }
      ],
      "damageVulnerabilities": [
        "frío"
      ],
      "damageImmunities": [
        "fuego",
        "veneno"
      ],
      "conditionImmunities": [
        "cansancio",
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "primordial (ígneo",
        "terrano)"
      ],
      "cr": "1/2",
      "proficiencyBonus": 2,
      "xp": 100
    },
    {
      "id": "mephit_de_polvo",
      "name": "Mephit de polvo",
      "size": "Pequeño",
      "type": "elemental",
      "alignment": "neutral malvado",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 17,
        "formula": "5d6"
      },
      "speed": {
        "walk": "30 pies",
        "fly": "30 pies"
      },
      "abilities": {
        "str": 5,
        "dex": 14,
        "con": 10,
        "int": 9,
        "wis": 11,
        "cha": 10
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -3
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": -1
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [
        {
          "name": "Explotar al morir",
          "text": "El mephit explota cuando muere. Tirada de salvación de Destreza: CD 10, todas las criaturas en una emanación de 5 pies que se origina en el mephit. Fallo: 5 (2d4) de daño contundente. Éxito: la mitad del daño."
        }
      ],
      "actions": [
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 4 (1d4 + 2) de daño cortante."
        },
        {
          "name": "Aliento cegador (recarga 6)",
          "text": "Tirada de salvación de Destreza: CD 10, todas las criaturas en un cono de 15 pies. Fallo: el objetivo tendrá el estado de cegado hasta el final del siguiente turno del mephit."
        },
        {
          "name": "Dormir (1/día)",
          "text": "El mephit lanza el conjuro dormir, que no requiere componentes y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 10)."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 2
        },
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "damageVulnerabilities": [
        "fuego"
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "cansancio",
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "primordial (aurano",
        "terrano)"
      ],
      "cr": "1/2",
      "proficiencyBonus": 2,
      "xp": 100
    },
    {
      "id": "mephit_de_vapor",
      "name": "Mephit de vapor",
      "size": "Pequeño",
      "type": "elemental",
      "alignment": "neutral malvado",
      "ac": 10,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 17,
        "formula": "5d6"
      },
      "speed": {
        "walk": "30 pies",
        "fly": "30 pies"
      },
      "abilities": {
        "str": 5,
        "dex": 11,
        "con": 10,
        "int": 11,
        "wis": 10,
        "cha": 12
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -3
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 1
        }
      ],
      "traits": [
        {
          "name": "Explotar al morir",
          "text": "El mephit explota cuando muere. Tirada de salvación de Destreza: CD 10, todas las criaturas en una emanación de 5 pies que se origina en el mephit. Fallo: 5 (2d4) de daño de fuego. Éxito: la mitad del daño."
        },
        {
          "name": "Forma borrosa",
          "text": "Las tiradas de ataque contra el mephit se harán con desventaja a menos que tenga el estado de incapacitado."
        }
      ],
      "actions": [
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +2, alcance 5 pies. Acierto: 2 (1d4) de daño cortante más 2 (1d4) de daño de fuego."
        },
        {
          "name": "Aliento de vapor (recarga 6)",
          "text": "Tirada de salvación de Constitución: CD 10, todas las criaturas en un cono de 15 pies. Fallo: 5 (2d4) de daño de fuego y la velocidad del objetivo se reducirá en 10 pies hasta el final del siguiente turno del mephit. Éxito: solo la mitad del daño. Fallo o éxito: estar bajo el agua no otorga resistencia a este daño de fuego."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 2
        }
      ],
      "damageImmunities": [
        "fuego",
        "veneno"
      ],
      "conditionImmunities": [
        "cansancio",
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "primordial (acuano",
        "ígneo)"
      ],
      "cr": "1/4",
      "proficiencyBonus": 2,
      "xp": 50
    },
    {
      "id": "merrow",
      "name": "Merrow",
      "size": "Grande",
      "type": "monstruosidad",
      "alignment": "caótica malvada",
      "ac": 13,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 45,
        "formula": "6d10 + 12"
      },
      "speed": {
        "walk": "10 pies",
        "swim": "40 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 15,
        "con": 15,
        "int": 8,
        "wis": 10,
        "cha": 9
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": -1
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [
        {
          "name": "Anfibio",
          "text": "El merrow puede respirar tanto dentro como fuera del agua."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El merrow realiza dos ataques con su arpón, sus garras o su mordisco en cualquier combinación."
        },
        {
          "name": "Arpón",
          "text": "Tirada de ataque cuerpo a cuerpo o a distancia: +6, alcance 5 pies o 6/60 pies a distancia. Acierto: 11 (2d6 + 4) de daño perforante. Si el objetivo es una criatura Grande o más pequeña, el merrow la atrae hasta 15 pies en línea recta hacia él."
        },
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 9 (2d4 + 4) de daño cortante."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 6 (1d4 + 4) de daño perforante y el objetivo tendrá el estado de envenenado hasta el final del siguiente turno del merrow."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "abisal",
        "primordial (acuano)"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "mimeto",
      "name": "Mimeto",
      "size": "Mediana",
      "type": "monstruosidad",
      "alignment": "neutral",
      "ac": 12,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 58,
        "formula": "9d8 + 18"
      },
      "speed": {
        "walk": "20 pies"
      },
      "abilities": {
        "str": 17,
        "dex": 12,
        "con": 15,
        "int": 5,
        "wis": 13,
        "cha": 8
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": -3
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [
        {
          "name": "Adhesivo (solo con forma de objeto)",
          "text": "El mimeto se adhiere a cualquiera que lo toque. Las criaturas Enormes o más pequeñas a las que se adhiera el mimeto tendrán el estado de agarradas (CD 13 para escapar). Las pruebas de característica para escapar de este agarre tienen desventaja."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +5 (con ventaja si el mimeto tiene agarrado al objetivo), alcance 5 pies. Acierto: 7 (1d8 + 3) de daño perforante o 12 (2d8 + 3) de daño perforante si el mimeto tiene agarrado al objetivo, más 4 (1d8) de daño de ácido."
        },
        {
          "name": "Pseudópodo",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 7 (1d8 + 3) de daño contundente más 4 (1d8) de daño de ácido. Si el objetivo es una criatura Grande o más pequeña, tendrá el estado de agarrada (CD 13 para escapar). Las pruebas de característica para escapar de este agarre tienen desventaja."
        }
      ],
      "bonusActions": [
        {
          "name": "Cambio de forma",
          "text": "El mimeto cambia de forma para parecer un objeto Mediano o Pequeño, pero conservando su perfil, o recupera su auténtica forma de amasijo. Cualquier equipo que vista o lleve no se transformará."
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "damageImmunities": [
        "ácido"
      ],
      "conditionImmunities": [
        "derribado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 11"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "minotauro_de_bafomet",
      "name": "Minotauro de Bafomet",
      "size": "Grande",
      "type": "monstruosidad",
      "alignment": "caótica malvada",
      "ac": 14,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 85,
        "formula": "10d10 + 30"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 11,
        "con": 16,
        "int": 6,
        "wis": 16,
        "cha": 9
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 3
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Guja abisal",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 10 pies. Acierto: 10 (1d12 + 4) de daño cortante más 10 (3d6) de daño necrótico."
        },
        {
          "name": "Cornada (recarga 5–6)",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 18 (4d6 + 4) de daño perforante. Si el objetivo es una criatura Grande o más pequeña y el minotauro recorre al menos 10 pies en línea recta hacia ella justo antes de acertarle, esta recibirá 10 (3d6) de daño perforante adicional y tendrá el estado de derribada. Momias"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 7
        },
        {
          "name": "Supervivencia",
          "bonus": 7
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 17"
      ],
      "languages": [
        "abisal"
      ],
      "cr": "3",
      "proficiencyBonus": 2,
      "xp": 700
    },
    {
      "id": "momia",
      "name": "Momia",
      "size": "Mediano o Pequeño",
      "type": "muerto viviente",
      "alignment": "legal malvado",
      "ac": 11,
      "initiative": {
        "modifier": -1,
        "score": 9
      },
      "hp": {
        "average": 58,
        "formula": "9d8 + 18"
      },
      "speed": {
        "walk": "20 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 8,
        "con": 15,
        "int": 6,
        "wis": 12,
        "cha": 12
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": -1
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 3
        },
        {
          "ability": "cha",
          "bonus": 1
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "La momia realiza dos ataques con su puño putrefacto y utiliza su mirada espantosa."
        },
        {
          "name": "Puño putrefacto",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 8 (1d10 + 3) de daño contundente más 10 (3d6) de daño necrótico. Si el objetivo es una criatura, quedará maldita. Mientras el objetivo esté maldito, no podrá recuperar puntos de golpe, sus puntos de golpe máximos no volverán a la normalidad cuando termine un descanso largo y estos se reducirán en 10 (3d6) cada 24 horas. Una criatura morirá y se convertirá en polvo si este ataque reduce sus puntos de golpe a 0."
        },
        {
          "name": "Mirada espantosa",
          "text": "Tirada de salvación de Sabiduría: CD 11, una criatura que la momia pueda ver a 60 pies o menos. Fallo: el objetivo tendrá el estado de asustado hasta el final del siguiente turno de la momia. Éxito: el objetivo será inmune a la mirada espantosa de esta momia durante 24 horas."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageVulnerabilities": [
        "fuego"
      ],
      "damageImmunities": [
        "necrótico",
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "cansancio",
        "envenenado",
        "hechizado",
        "paralizado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 11"
      ],
      "languages": [
        "común y otros dos idiomas"
      ],
      "cr": "3",
      "proficiencyBonus": 2,
      "xp": 700
    },
    {
      "id": "senor_de_las_momias",
      "name": "Señor de las momias",
      "size": "Mediano o Pequeño",
      "type": "muerto viviente",
      "alignment": "legal malvado",
      "ac": 17,
      "initiative": {
        "modifier": 10,
        "score": 20
      },
      "hp": {
        "average": 187,
        "formula": "25d8 + 75"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 10,
        "con": 17,
        "int": 11,
        "wis": 19,
        "cha": 16
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": 5
        },
        {
          "ability": "wis",
          "bonus": 9
        },
        {
          "ability": "cha",
          "bonus": 3
        }
      ],
      "traits": [
        {
          "name": "Recuperación de muerto viviente",
          "text": "Si la destruyen, la momia obtendrá un cuerpo nuevo al cabo de 24 horas si su corazón permanece intacto y revivirá con todos sus puntos de golpe. El nuevo cuerpo aparecerá en un espacio sin ocupar en la guarida de la momia. El corazón es un objeto Diminuto con una CA de 17, 10 pg e inmunidad a todo el daño excepto al de fuego. Resistencia legendaria (3/día o 4/día en la guarida). La momia puede elegir tener éxito en una tirada de salvación que haya fallado."
        },
        {
          "name": "Resistencia mágica",
          "text": "La momia tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "La momia realiza un ataque con su puño putrefacto o de canalizar energía negativa y utiliza su mirada espantosa."
        },
        {
          "name": "Puño putrefacto",
          "text": "Tirada de ataque cuerpo a cuerpo: +9, alcance 5 pies. Acierto: 15 (2d10 + 4) de daño contundente más 10 (3d6) de daño necrótico. Si el objetivo es una criatura, quedará maldita. Mientras el objetivo esté maldito, no podrá recuperar puntos de golpe, no obtendrá beneficio alguno por finalizar un descanso largo y sus puntos de golpe máximos se reducirán en 10 (3d6) cada 24 horas. Una criatura morirá y se convertirá en polvo si este ataque reduce sus puntos de golpe a 0."
        },
        {
          "name": "Canalizar energía negativa",
          "text": "Tirada de ataque a distancia: +9, alcance 60 pies. Acierto: 25 (6d6 + 4) de daño necrótico."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "La momia lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza la Sabiduría como aptitud mágica (CD de salvación de conjuros 17, +9 a acertar con ataques de conjuro): A voluntad: disipar magia, taumaturgia 1/día cada uno: animar a los muertos, dañar, plaga de insectos (versión de nivel 7)"
        },
        {
          "name": "Mirada espantosa",
          "text": "Tirada de salvación de Sabiduría: CD 17, una criatura que la momia pueda ver a 60 pies o menos. Fallo: 25 (6d6 + 4) de daño psíquico y el objetivo tendrá el estado de paralizado hasta el final del siguiente turno de la momia."
        }
      ],
      "bonusActions": [],
      "reactions": [
        {
          "name": "Torbellino de arena",
          "text": "Detonante: una tirada de ataque acierta a la momia. Respuesta: la momia suma 2 a su CA contra ese ataque, lo que puede hacer que falle. Además, la momia se teletransporta hasta 60 pies a un espacio sin ocupar que pueda ver. Todas las criaturas de su elección que pueda ver a 5 pies o menos de su espacio de destino tendrán el estado de cegadas hasta el final del siguiente turno de la momia."
        }
      ],
      "subtype": "clérigo",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, la momia puede emplear un uso para llevar a cabo una de las siguientes acciones. La momia recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Golpe necrótico",
          "text": "La momia realiza un ataque con su puño putrefacto o de canalizar energía negativa."
        },
        {
          "name": "Mirar con furia",
          "text": "La momia utiliza su mirada espantosa. La momia no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        },
        {
          "name": "Orden terrorífica",
          "text": "La momia lanza orden imperiosa (versión de nivel 2) usando la misma aptitud mágica que para su lanzamiento de conjuros. La momia no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        }
      ],
      "skills": [
        {
          "name": "Historia",
          "bonus": 5
        },
        {
          "name": "Percepción",
          "bonus": 9
        },
        {
          "name": "Religión",
          "bonus": 5
        }
      ],
      "damageVulnerabilities": [
        "fuego"
      ],
      "damageImmunities": [
        "necrótico",
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "cansancio",
        "envenenado",
        "hechizado",
        "paralizado"
      ],
      "senses": [
        "visión verdadera 60 pies",
        "Percepción pasiva 19"
      ],
      "languages": [
        "común y otros tres idiomas"
      ],
      "cr": "15",
      "proficiencyBonus": 5,
      "xp": 13000,
      "xpText": "13 000 PX o 15 000 en la guarida"
    },
    {
      "id": "monstruo_corrosivo",
      "name": "Monstruo corrosivo",
      "size": "Mediana",
      "type": "monstruosidad",
      "alignment": "sin alineamiento",
      "ac": 14,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 33,
        "formula": "6d8 + 6"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 13,
        "dex": 12,
        "con": 13,
        "int": 2,
        "wis": 13,
        "cha": 6
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 1
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [
        {
          "name": "Olfatear hierro",
          "text": "El monstruo corrosivo puede identificar con exactitud la ubicación de los metales férricos situados a 30 pies o menos de él."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El monstruo corrosivo realiza un ataque de mordisco y utiliza sus antenas dos veces."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +3, alcance 5 pies. Acierto: 5 (1d8 + 1) de daño perforante."
        },
        {
          "name": "Antenas",
          "text": "El monstruo corrosivo hace objetivo a un objeto no mágico de metal (un arma o una armadura) que lleve o vista una criatura a 5 pies o menos de él. Tirada de salvación de Destreza: CD 11, la criatura con el objeto. Fallo: el objeto tendrá un penalizador de −1 a las tiradas de ataque (arma) o a la CA que ofrece (armadura). Un arma se destruirá si el penalizador llega a −5; una armadura, si el penalizador reduce su CA hasta 10. El penalizador se puede eliminar lanzando el conjuro reparar sobre el arma o la armadura."
        },
        {
          "name": "Destruir metal",
          "text": "El monstruo corrosivo toca un objeto no mágico de metal a 5 pies o menos de él que no vista o lleve nadie. El contacto destruye un cubo de 12 pulgadas de lado del objeto."
        }
      ],
      "bonusActions": [],
      "reactions": [
        {
          "name": "Antenas reflexivas",
          "text": "Detonante: una tirada de ataque acierta al monstruo corrosivo. Respuesta: el monstruo corrosivo utiliza sus antenas."
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 11"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/2",
      "proficiencyBonus": 2,
      "xp": 100
    },
    {
      "id": "naga_espiritual",
      "name": "Naga espiritual",
      "size": "Grande",
      "type": "infernal",
      "alignment": "caótico malvado",
      "ac": 17,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 135,
        "formula": "18d10 + 36"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 17,
        "con": 14,
        "int": 16,
        "wis": 15,
        "cha": 16
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 6
        },
        {
          "ability": "con",
          "bonus": 5
        },
        {
          "ability": "int",
          "bonus": 3
        },
        {
          "ability": "wis",
          "bonus": 5
        },
        {
          "ability": "cha",
          "bonus": 6
        }
      ],
      "traits": [
        {
          "name": "Recuperación infernal",
          "text": "Si muere, la naga volverá a la vida tras 1d6 días y recuperará todos sus puntos de golpe. Solo un conjuro deseo puede evitar que este atributo tenga efecto."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "La naga realiza tres ataques de mordisco o rayo necrótico en cualquier combinación."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 10 pies. Acierto: 7 (1d6 + 4) de daño perforante más 14 (4d6) de daño de veneno."
        },
        {
          "name": "Rayo necrótico",
          "text": "Tirada de ataque a distancia: +6, alcance 60 pies. Acierto: 21 (6d6) de daño necrótico."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "La naga lanza uno de los siguientes conjuros, que no requiere componentes somáticos o materiales y utiliza la Inteligencia como aptitud mágica (CD de salvación de conjuros 14): A voluntad: detectar magia, ilusión menor, mano de mago, respirar bajo el agua 2/día cada uno: detectar pensamientos, inmovilizar persona (versión de nivel 3), puerta dimensional, relámpago (versión de nivel 4)"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado",
        "hechizado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "abisal",
        "común"
      ],
      "cr": "8",
      "proficiencyBonus": 3,
      "xp": 3900
    },
    {
      "id": "naga_guardiana",
      "name": "Naga guardiana",
      "size": "Grande",
      "type": "celestial",
      "alignment": "legal bueno",
      "ac": 18,
      "initiative": {
        "modifier": 4,
        "score": 14
      },
      "hp": {
        "average": 136,
        "formula": "16d10 + 48"
      },
      "speed": {
        "walk": "40 pies",
        "swim": "40 pies",
        "climb": "40 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 18,
        "con": 16,
        "int": 16,
        "wis": 19,
        "cha": 18
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 8
        },
        {
          "ability": "con",
          "bonus": 7
        },
        {
          "ability": "int",
          "bonus": 7
        },
        {
          "ability": "wis",
          "bonus": 8
        },
        {
          "ability": "cha",
          "bonus": 8
        }
      ],
      "traits": [
        {
          "name": "Recuperación celestial",
          "text": "Si la naga muere, regresará a la vida tras 1d6 días y recuperará todos sus puntos de golpe salvo que se lance el conjuro disipar el bien y el mal sobre sus restos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "La naga realiza dos ataques de mordisco. Puede sustituir cualquier ataque por un uso de su saliva venenosa."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +8, alcance 10 pies. Acierto: 17 (2d12 + 4) de daño perforante más 22 (4d10) de daño de veneno."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "La naga lanza uno de los siguientes conjuros, que no requiere componentes somáticos o materiales y utiliza la Sabiduría como aptitud mágica (CD de salvación de conjuros 16): A voluntad: taumaturgia 1/día cada uno: clarividencia, curar heridas (versión de nivel 6), geas, golpe flamígero (versión de nivel 6), visión veraz"
        },
        {
          "name": "Saliva venenosa",
          "text": "Tirada de salvación de Constitución: CD 16, una criatura que la naga pueda ver a 60 pies o menos. Fallo: 31 (7d8) de daño de veneno y el objetivo tendrá el estado de cegado hasta el principio del siguiente turno de la naga. Éxito: solo la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Conocimiento arcano",
          "bonus": 11
        },
        {
          "name": "Historia",
          "bonus": 11
        },
        {
          "name": "Religión",
          "bonus": 11
        }
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "apresado",
        "envenenado",
        "hechizado",
        "paralizado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "celestial",
        "común"
      ],
      "cr": "10",
      "proficiencyBonus": 4,
      "xp": 5900
    },
    {
      "id": "nalfeshnee",
      "name": "Nalfeshnee",
      "size": "Grande",
      "type": "infernal",
      "alignment": "caótico malvado",
      "ac": 18,
      "initiative": {
        "modifier": 5,
        "score": 15
      },
      "hp": {
        "average": 184,
        "formula": "16d10 + 96"
      },
      "speed": {
        "walk": "20 pies",
        "fly": "30 pies"
      },
      "abilities": {
        "str": 21,
        "dex": 10,
        "con": 22,
        "int": 19,
        "wis": 12,
        "cha": 15
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 5
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 11
        },
        {
          "ability": "int",
          "bonus": 9
        },
        {
          "ability": "wis",
          "bonus": 6
        },
        {
          "ability": "cha",
          "bonus": 7
        }
      ],
      "traits": [
        {
          "name": "Recuperación demoníaca",
          "text": "Si el nalfeshnee muere fuera del Abismo, su cuerpo se disuelve en icor, obtiene un cuerpo nuevo al instante y revive con todos sus puntos de golpe en algún lugar del Abismo."
        },
        {
          "name": "Resistencia mágica",
          "text": "El nalfeshnee tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El nalfeshnee realiza tres ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +10, alcance 10 pies. Acierto: 16 (2d10 + 5) de daño cortante más 11 (2d10) de daño de fuerza."
        },
        {
          "name": "Teletransporte",
          "text": "El nalfeshnee se teletransporta hasta 120 pies a un espacio sin ocupar que pueda ver."
        }
      ],
      "bonusActions": [
        {
          "name": "Nimbo horrible (recarga 5–6)",
          "text": "Tirada de salvación de Sabiduría: CD 15, todas las criaturas en una emanación de 15 pies que se origina en el nalfeshnee. Fallo: 28 (8d6) de daño psíquico y el objetivo tendrá el estado de asustado durante 1 minuto, hasta que reciba daño o termine su turno con el nalfeshnee fuera de su línea de visión. Éxito: el objetivo será inmune al nimbo horrible de este nalfeshnee durante 24 horas."
        }
      ],
      "reactions": [
        {
          "name": "Persecución",
          "text": "Detonante: otra criatura que el nalfeshnee pueda ver termina su movimiento a 120 pies o menos de él. Respuesta: el nalfeshnee utiliza su teletransporte, pero el espacio de destino debe estar a 10 pies o menos de la criatura detonante."
        }
      ],
      "subtype": "demonio",
      "damageResistances": [
        "frío",
        "fuego",
        "relámpago"
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "envenenado"
      ],
      "senses": [
        "visión verdadera 120 pies",
        "Percepción pasiva 11"
      ],
      "languages": [
        "abisal",
        "telepatía 120 pies"
      ],
      "cr": "13",
      "proficiencyBonus": 5,
      "xp": 10000
    },
    {
      "id": "noble",
      "name": "Noble",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 15,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 9,
        "formula": "2d8"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 11,
        "dex": 12,
        "con": 11,
        "int": 12,
        "wis": 14,
        "cha": 16
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 0
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 3
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Estoque",
          "text": "Tirada de ataque cuerpo a cuerpo: +3, alcance 5 pies. Acierto: 5 (1d8 + 1) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": [
        {
          "name": "Parada",
          "text": "Detonante: una tirada de ataque cuerpo a cuerpo acierta al noble mientras sostiene un arma. Respuesta: el noble suma 2 a su CA contra ese ataque, lo que puede hacer que falle. Objetos animados"
        }
      ],
      "skills": [
        {
          "name": "Engaño",
          "bonus": 5
        },
        {
          "name": "Perspicacia",
          "bonus": 4
        },
        {
          "name": "Persuasión",
          "bonus": 5
        }
      ],
      "equipment": [
        "coraza",
        "estoque"
      ],
      "senses": [
        "Percepción pasiva 12"
      ],
      "languages": [
        "común y otros dos idiomas"
      ],
      "cr": "1/8",
      "proficiencyBonus": 2,
      "xp": 25
    },
    {
      "id": "alfombra_asfixiante_animada",
      "name": "Alfombra asfixiante animada",
      "size": "Grande",
      "type": "autómata",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 4,
        "score": 14
      },
      "hp": {
        "average": 27,
        "formula": "5d10"
      },
      "speed": {
        "walk": "10 pies"
      },
      "abilities": {
        "str": 17,
        "dex": 14,
        "con": 10,
        "int": 1,
        "wis": 3,
        "cha": 1
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": -5
        },
        {
          "ability": "wis",
          "bonus": -4
        },
        {
          "ability": "cha",
          "bonus": -5
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ahogar",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 10 (2d6 + 3) de daño contundente. Si el objetivo es una criatura Mediana o más pequeña, la alfombra puede imponerle el estado de agarrada (CD 13 para escapar) en vez de causarle daño. Hasta que el agarre termine, el objetivo tendrá los estados de apresado y cegado, se asfixiará y recibirá 10 (2d6 + 3) de daño contundente al principio de cada uno de sus turnos. La alfombra solo puede ahogar a una criatura a la vez. Mientras esté agarrando al objetivo, la alfombra no podrá realizar esta acción y reducirá a la mitad el daño que reciba (redondeado hacia abajo), y el objetivo recibirá la misma cantidad de daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageImmunities": [
        "psíquico",
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "cansancio",
        "ensordecido",
        "envenenado",
        "hechizado",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión ciega 60 pies",
        "Percepción pasiva 6"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "armadura_animada",
      "name": "Armadura animada",
      "size": "Mediano",
      "type": "autómata",
      "alignment": "sin alineamiento",
      "ac": 18,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 33,
        "formula": "6d8 + 6"
      },
      "speed": {
        "walk": "25 pies"
      },
      "abilities": {
        "str": 14,
        "dex": 11,
        "con": 13,
        "int": 1,
        "wis": 3,
        "cha": 1
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": -5
        },
        {
          "ability": "wis",
          "bonus": -4
        },
        {
          "ability": "cha",
          "bonus": -5
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "La armadura realiza dos ataques con su golpe."
        },
        {
          "name": "Golpe",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 5 (1d6 + 2) de daño contundente."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageImmunities": [
        "psíquico",
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "cansancio",
        "ensordecido",
        "envenenado",
        "hechizado",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión ciega 60 pies",
        "Percepción pasiva 6"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1",
      "proficiencyBonus": 2,
      "xp": 200
    },
    {
      "id": "espada_voladora_animada",
      "name": "Espada voladora animada",
      "size": "Pequeño",
      "type": "autómata",
      "alignment": "sin alineamiento",
      "ac": 17,
      "initiative": {
        "modifier": 4,
        "score": 14
      },
      "hp": {
        "average": 14,
        "formula": "4d6"
      },
      "speed": {
        "walk": "5 pies",
        "fly": "50 pies (levitar)"
      },
      "abilities": {
        "str": 12,
        "dex": 15,
        "con": 11,
        "int": 1,
        "wis": 5,
        "cha": 1
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 1
        },
        {
          "ability": "dex",
          "bonus": 4
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": -5
        },
        {
          "ability": "wis",
          "bonus": -3
        },
        {
          "ability": "cha",
          "bonus": -5
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Corte",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 6 (1d8 + 2) de daño cortante."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageImmunities": [
        "psíquico",
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "cansancio",
        "ensordecido",
        "envenenado",
        "hechizado",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión ciega 60 pies",
        "Percepción pasiva 7"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/4",
      "proficiencyBonus": 2,
      "xp": 50
    },
    {
      "id": "ogro",
      "name": "Ogro",
      "size": "Grande",
      "type": "gigante",
      "alignment": "caótico malvado",
      "ac": 11,
      "initiative": {
        "modifier": -1,
        "score": 9
      },
      "hp": {
        "average": 68,
        "formula": "8d10 + 24"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 8,
        "con": 16,
        "int": 5,
        "wis": 7,
        "cha": 7
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": -1
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": -3
        },
        {
          "ability": "wis",
          "bonus": -2
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Garrote grande",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 13 (2d8 + 4) de daño contundente."
        },
        {
          "name": "Jabalina",
          "text": "Tirada de ataque cuerpo a cuerpo o a distancia: +6, alcance 5 pies o 9/120 pies a distancia. Acierto: 11 (2d6 + 4) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "equipment": [
        "garrote grande",
        "jabalinas (3)"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 8"
      ],
      "languages": [
        "común",
        "gigante"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "oni",
      "name": "Oni",
      "size": "Grande",
      "type": "infernal",
      "alignment": "legal malvado",
      "ac": 17,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 119,
        "formula": "14d10 + 42"
      },
      "speed": {
        "walk": "30 pies",
        "fly": "30 pies (levitar)"
      },
      "abilities": {
        "str": 19,
        "dex": 11,
        "con": 16,
        "int": 14,
        "wis": 12,
        "cha": 15
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 6
        },
        {
          "ability": "int",
          "bonus": 2
        },
        {
          "ability": "wis",
          "bonus": 4
        },
        {
          "ability": "cha",
          "bonus": 5
        }
      ],
      "traits": [
        {
          "name": "Regeneración",
          "text": "El oni recupera 10 puntos de golpe al principio de cada uno de sus turnos si tiene al menos 1 punto de golpe."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El oni realiza dos ataques con sus garras o su rayo de pesadilla. Puede sustituir un ataque por un uso de su lanzamiento de conjuros."
        },
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 10 pies. Acierto: 10 (1d12 + 4) de daño cortante más 9 (2d8) de daño necrótico."
        },
        {
          "name": "Rayo de pesadilla",
          "text": "Tirada de ataque a distancia: +5, alcance 60 pies. Acierto: 9 (2d6 + 2) de daño psíquico y el objetivo tendrá el estado de asustado hasta el principio del siguiente turno del oni."
        },
        {
          "name": "Cambio de forma",
          "text": "El oni se convierte en un humanoide Pequeño o Mediano, un gigante Grande o recupera su auténtica forma. Su perfil, salvo por el tamaño, es el mismo en todas las formas. Cualquier equipo que vista o lleve no se transformará."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El oni lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 13): 1/día cada uno: dormir, forma gaseosa, hechizar persona (versión de nivel 2), oscuridad"
        }
      ],
      "bonusActions": [
        {
          "name": "Invisibilidad",
          "text": "El oni lanza invisibilidad sobre sí mismo, que no requiere componentes y utiliza la misma aptitud mágica que para su lanzamiento de conjuros. Osgos"
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Conocimiento arcano",
          "bonus": 5
        },
        {
          "name": "Engaño",
          "bonus": 8
        },
        {
          "name": "Percepción",
          "bonus": 4
        }
      ],
      "damageResistances": [
        "frío"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "común",
        "gigante"
      ],
      "cr": "7",
      "proficiencyBonus": 3,
      "xp": 2900
    },
    {
      "id": "acechador_osgo",
      "name": "Acechador osgo",
      "size": "Mediano",
      "type": "feérico",
      "alignment": "caótico malvado",
      "ac": 15,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 65,
        "formula": "10d8 + 20"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 17,
        "dex": 14,
        "con": 14,
        "int": 11,
        "wis": 12,
        "cha": 11
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 3
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [
        {
          "name": "Rapto",
          "text": "El osgo no necesita gastar movimiento adicional para desplazar a una criatura que tenga agarrada."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El osgo realiza dos ataques con sus jabalinas o su lucero del alba."
        },
        {
          "name": "Jabalina",
          "text": "Tirada de ataque cuerpo a cuerpo o a distancia: +5, alcance 10 pies o 9/120 pies a distancia. Acierto: 13 (3d6 + 3) de daño perforante."
        },
        {
          "name": "Lucero del alba",
          "text": "Tirada de ataque cuerpo a cuerpo: +5 (con ventaja si el osgo tiene agarrado al objetivo), alcance 10 pies. Acierto: 12 (2d8 + 3) de daño perforante."
        }
      ],
      "bonusActions": [
        {
          "name": "Agarre rápido",
          "text": "Tirada de salvación de Destreza: CD 13, una criatura Mediana o más pequeña que el osgo pueda ver a 10 pies o menos. Fallo: el objetivo tendrá el estado de agarrado (CD 13 para escapar)."
        }
      ],
      "reactions": [],
      "subtype": "trasgo",
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 6
        },
        {
          "name": "Supervivencia",
          "bonus": 3
        }
      ],
      "equipment": [
        "camisa de malla",
        "jabalinas (6)",
        "lucero del alba"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 11"
      ],
      "languages": [
        "común",
        "goblin"
      ],
      "cr": "3",
      "proficiencyBonus": 2,
      "xp": 700
    },
    {
      "id": "guerrero_osgo",
      "name": "Guerrero osgo",
      "size": "Mediano",
      "type": "feérico",
      "alignment": "caótico malvado",
      "ac": 14,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 33,
        "formula": "6d8 + 6"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 15,
        "dex": 14,
        "con": 13,
        "int": 8,
        "wis": 11,
        "cha": 9
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": -1
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [
        {
          "name": "Rapto",
          "text": "El osgo no necesita gastar movimiento adicional para desplazar a una criatura que tenga agarrada."
        }
      ],
      "actions": [
        {
          "name": "Agarre",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 10 pies. Acierto: 9 (2d6 + 2) de daño contundente. Si el objetivo es una criatura Mediana o más pequeña, tendrá el estado de agarrada (CD 12 para escapar)."
        },
        {
          "name": "Martillo ligero",
          "text": "Tirada de ataque cuerpo a cuerpo o a distancia: +4 (con ventaja si el osgo tiene agarrado al objetivo), alcance 10 pies o 6/60 pies a distancia. Acierto: 9 (3d4 + 2) de daño contundente."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "trasgo",
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 6
        },
        {
          "name": "Supervivencia",
          "bonus": 2
        }
      ],
      "equipment": [
        "armadura de pieles",
        "martillos ligeros (3)"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "común",
        "goblin"
      ],
      "cr": "1",
      "proficiencyBonus": 2,
      "xp": 200
    },
    {
      "id": "oso_lechuza",
      "name": "Oso lechuza",
      "size": "Grande",
      "type": "monstruosidad",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 59,
        "formula": "7d10 + 21"
      },
      "speed": {
        "walk": "40 pies",
        "climb": "40 pies"
      },
      "abilities": {
        "str": 20,
        "dex": 12,
        "con": 17,
        "int": 3,
        "wis": 12,
        "cha": 7
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 5
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El oso lechuza realiza dos ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 14 (2d8 + 5) de daño cortante."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 5
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 15"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "3",
      "proficiencyBonus": 2,
      "xp": 700
    },
    {
      "id": "otyugh",
      "name": "Otyugh",
      "size": "Grande",
      "type": "aberración",
      "alignment": "neutral",
      "ac": 14,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 104,
        "formula": "11d10 + 44"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 11,
        "con": 19,
        "int": 6,
        "wis": 13,
        "cha": 6
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 7
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El otyugh realiza un ataque de mordisco y dos con sus tentáculos."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 12 (2d8 + 3) de daño perforante y el objetivo tendrá el estado de envenenado. Siempre que el objetivo envenenado termine un descanso largo, sufrirá el siguiente efecto. Tirada de salvación de Constitución: CD 15. Fallo: los puntos de golpe máximos del objetivo se reducirán en 5 (1d10) y no volverán a la normalidad hasta que deje de tener el estado de envenenado. Éxito: el estado de envenenado termina."
        },
        {
          "name": "Tentáculo",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 10 pies. Acierto: 12 (2d8 + 3) de daño perforante. Si el objetivo es una criatura Mediana o más pequeña, tendrá el estado de agarrada (CD 13 para escapar) por uno de los dos tentáculos."
        },
        {
          "name": "Golpe con tentáculo",
          "text": "Tirada de salvación de Constitución: CD 14, todas las criaturas agarradas por el otyugh. Fallo: 16 (3d8 + 3) de daño contundente y el objetivo tendrá el estado de aturdido hasta el principio del siguiente turno del otyugh. Éxito: solo la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "senses": [
        "visión en la oscuridad 120 pies",
        "Percepción pasiva 11"
      ],
      "languages": [
        "otyugh",
        "telepatía 120 pies (no permite que la criatura receptora responda telepáticamente)"
      ],
      "cr": "5",
      "proficiencyBonus": 3,
      "xp": 1800
    },
    {
      "id": "pegaso",
      "name": "Pegaso",
      "size": "Grande",
      "type": "celestial",
      "alignment": "caótico bueno",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 59,
        "formula": "7d10 + 21"
      },
      "speed": {
        "walk": "60 pies",
        "fly": "90 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 15,
        "con": 16,
        "int": 10,
        "wis": 15,
        "cha": 13
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 4
        },
        {
          "ability": "con",
          "bonus": 5
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 4
        },
        {
          "ability": "cha",
          "bonus": 3
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Cascos",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 7 (1d6 + 4) de daño contundente más 5 (2d4) de daño radiante. Pendencieros"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 6
        }
      ],
      "senses": [
        "Percepción pasiva 16"
      ],
      "languages": [
        "entiende celestial, común, elfo y silvano, pero no puede hablar"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "pendenciero",
      "name": "Pendenciero",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 12,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 32,
        "formula": "5d8 + 10"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 15,
        "dex": 12,
        "con": 14,
        "int": 10,
        "wis": 10,
        "cha": 11
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [
        {
          "name": "Atacar en grupo",
          "text": "El pendenciero tiene ventaja en una tirada de ataque contra una criatura si al menos uno de los aliados del pendenciero se encuentra a 5 pies de la criatura y no tiene el estado de incapacitado."
        }
      ],
      "actions": [
        {
          "name": "Maza",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 5 (1d6 + 2) de daño contundente."
        },
        {
          "name": "Ballesta pesada",
          "text": "Tirada de ataque a distancia: +3, alcance 30/400 pies. Acierto: 6 (1d10 + 1) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "equipment": [
        "armadura de cuero",
        "ballesta pesada",
        "maza"
      ],
      "senses": [
        "Percepción pasiva 10"
      ],
      "languages": [
        "común"
      ],
      "cr": "1/2",
      "proficiencyBonus": 2,
      "xp": 100
    },
    {
      "id": "jefe_pendenciero",
      "name": "Jefe pendenciero",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 16,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 82,
        "formula": "11d8 + 33"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 17,
        "dex": 14,
        "con": 16,
        "int": 11,
        "wis": 10,
        "cha": 11
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 5
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 5
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "traits": [
        {
          "name": "Atacar en grupo",
          "text": "El pendenciero tiene ventaja en una tirada de ataque contra una criatura si al menos uno de los aliados del pendenciero se encuentra a 5 pies de la criatura y no tiene el estado de incapacitado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El pendenciero realiza dos ataques con su martillo de guerra o su ballesta pesada en cualquier combinación."
        },
        {
          "name": "Martillo de guerra",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 12 (2d8 + 3) de daño contundente. Si el objetivo es una criatura Grande o más pequeña, el pendenciero la empujará hasta 10 pies respecto a él en línea recta."
        },
        {
          "name": "Ballesta pesada",
          "text": "Tirada de ataque a distancia: +4, alcance 30/400 pies. Acierto: 13 (2d10 + 2) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "equipment": [
        "ballesta pesada",
        "cota de malla",
        "martillo de guerra"
      ],
      "senses": [
        "Percepción pasiva 10"
      ],
      "languages": [
        "común y otro cualquiera"
      ],
      "cr": "4",
      "proficiencyBonus": 2,
      "xp": 1100
    },
    {
      "id": "perro_del_inframundo",
      "name": "Perro del inframundo",
      "size": "Mediana",
      "type": "monstruosidad",
      "alignment": "neutral malvada",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 39,
        "formula": "6d8 + 12"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 15,
        "dex": 14,
        "con": 14,
        "int": 3,
        "wis": 13,
        "cha": 6
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El perro del inframundo realiza dos ataques de mordisco."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 4 (1d4 + 2) de daño perforante. Si el objetivo es una criatura, sufre el siguiente efecto."
        },
        {
          "name": "Tirada de salvación de Constitución: CD 12",
          "text": "Primer fallo: el objetivo tendrá el estado de envenenado. Mientras el objetivo esté envenenado, sus puntos de golpe máximos no volverán a la normalidad cuando termine un descanso largo. Repetirá la tirada de salvación cada vez que pasen 24 horas y, si tiene éxito, se librará del efecto. Fallos posteriores: los puntos de golpe máximos del objetivo envenenado se reducirán en 5 (1d10)."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 5
        },
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "conditionImmunities": [
        "asustado",
        "aturdido",
        "cegado",
        "ensordecido",
        "hechizado",
        "inconsciente"
      ],
      "senses": [
        "visión en la oscuridad 120 pies",
        "Percepción pasiva 15"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1",
      "proficiencyBonus": 2,
      "xp": 200
    },
    {
      "id": "perro_intermitente",
      "name": "Perro intermitente",
      "size": "Mediano",
      "type": "feérico",
      "alignment": "legal bueno",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 22,
        "formula": "4d8 + 4"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 12,
        "dex": 17,
        "con": 12,
        "int": 10,
        "wis": 13,
        "cha": 11
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 1
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 5 (1d4 + 3) de daño perforante."
        }
      ],
      "bonusActions": [
        {
          "name": "Teletransporte (recarga 4–6)",
          "text": "El perro se teletransporta hasta 40 pies a un espacio sin ocupar que pueda ver."
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 5
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 15"
      ],
      "languages": [
        "perro intermitente",
        "entiende el elfo y el silvano, pero no puede hablarlos"
      ],
      "cr": "1/4",
      "proficiencyBonus": 2,
      "xp": 50
    },
    {
      "id": "pesadilla",
      "name": "Pesadilla",
      "size": "Grande",
      "type": "infernal",
      "alignment": "neutral malvado",
      "ac": 13,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 68,
        "formula": "8d10 + 24"
      },
      "speed": {
        "walk": "60 pies",
        "fly": "90 pies (levitar)"
      },
      "abilities": {
        "str": 18,
        "dex": 15,
        "con": 16,
        "int": 10,
        "wis": 13,
        "cha": 15
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "traits": [
        {
          "name": "Iluminación",
          "text": "La pesadilla emite luz brillante en un radio de 10 pies y luz tenue 10 pies más allá."
        },
        {
          "name": "Otorgar resistencia al fuego",
          "text": "La pesadilla puede conferir resistencia al daño de fuego a cualquiera que monte sobre ella."
        }
      ],
      "actions": [
        {
          "name": "Cascos",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 13 (2d8 + 4) de daño contundente más 10 (3d6) de daño de fuego."
        },
        {
          "name": "Trote etéreo",
          "text": "La pesadilla y hasta tres criaturas voluntarias situadas a 5 pies o menos de ella se teletransportan del Plano Etéreo al Plano Material, o viceversa."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageImmunities": [
        "fuego"
      ],
      "senses": [
        "Percepción pasiva 11"
      ],
      "languages": [
        "entiende abisal, común e infernal, pero no puede hablar"
      ],
      "cr": "3",
      "proficiencyBonus": 2,
      "xp": 700
    },
    {
      "id": "pico_de_hacha",
      "name": "Pico de hacha",
      "size": "Grande",
      "type": "monstruosidad",
      "alignment": "sin alineamiento",
      "ac": 11,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 19,
        "formula": "3d10 + 3"
      },
      "speed": {
        "walk": "50 pies"
      },
      "abilities": {
        "str": 14,
        "dex": 12,
        "con": 12,
        "int": 2,
        "wis": 10,
        "cha": 5
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -3
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Pico",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 6 (1d8 + 2) de daño cortante. Piratas"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "senses": [
        "Percepción pasiva 10"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/4",
      "proficiencyBonus": 2,
      "xp": 50
    },
    {
      "id": "pirata",
      "name": "Pirata",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 14,
      "initiative": {
        "modifier": 5,
        "score": 15
      },
      "hp": {
        "average": 33,
        "formula": "6d8 + 6"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 10,
        "dex": 16,
        "con": 12,
        "int": 8,
        "wis": 12,
        "cha": 14
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 0
        },
        {
          "ability": "dex",
          "bonus": 5
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": -1
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": 4
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El pirata realiza dos ataques con sus dagas. Puede sustituir un ataque por un uso de su garbo cautivador."
        },
        {
          "name": "Daga",
          "text": "Tirada de ataque cuerpo a cuerpo o a distancia: +5, alcance 5 pies o 6/60 pies a distancia. Acierto: 5 (1d4 + 3) de daño perforante."
        },
        {
          "name": "Garbo cautivador",
          "text": "Tirada de salvación de Sabiduría: CD 12, una criatura que el pirata pueda ver a 30 pies o menos. Fallo: el objetivo tendrá el estado de hechizado hasta el principio del siguiente turno del pirata."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "equipment": [
        "armadura de cuero",
        "dagas (6)"
      ],
      "senses": [
        "Percepción pasiva 11"
      ],
      "languages": [
        "común y otro cualquiera"
      ],
      "cr": "1",
      "proficiencyBonus": 2,
      "xp": 200
    },
    {
      "id": "capitan_pirata",
      "name": "Capitán pirata",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 17,
      "initiative": {
        "modifier": 7,
        "score": 17
      },
      "hp": {
        "average": 84,
        "formula": "13d8 + 26"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 10,
        "dex": 18,
        "con": 14,
        "int": 10,
        "wis": 14,
        "cha": 17
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 7
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 5
        },
        {
          "ability": "cha",
          "bonus": 6
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El pirata realiza tres ataques con su estoque o pistola en cualquier combinación."
        },
        {
          "name": "Estoque",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 13 (2d8 + 4) de daño perforante y el pirata tendrá ventaja en la siguiente tirada de ataque que haga antes del final de este turno."
        },
        {
          "name": "Pistola",
          "text": "Tirada de ataque a distancia: +7, alcance 9/90 pies. Acierto: 15 (2d10 + 4) de daño perforante."
        }
      ],
      "bonusActions": [
        {
          "name": "Encanto de capitán",
          "text": "Tirada de salvación de Sabiduría: CD 14, una criatura que el pirata pueda ver a 30 pies o menos. Fallo: el objetivo tendrá el estado de hechizado hasta el principio del siguiente turno del pirata."
        }
      ],
      "reactions": [
        {
          "name": "Contraataque",
          "text": "Detonante: una tirada de ataque cuerpo a cuerpo acierta al pirata mientras sostiene un arma. Respuesta: el pirata suma 3 a su CA contra ese ataque, lo que puede hacer que falle. Si falla, el pirata realiza un ataque con su estoque contra la criatura a la que reacciona si está dentro del alcance."
        }
      ],
      "skills": [
        {
          "name": "Acrobacias",
          "bonus": 7
        },
        {
          "name": "Percepción",
          "bonus": 5
        }
      ],
      "equipment": [
        "estoque",
        "pistola"
      ],
      "senses": [
        "Percepción pasiva 15"
      ],
      "languages": [
        "común y otro cualquiera"
      ],
      "cr": "6",
      "proficiencyBonus": 3,
      "xp": 2300
    },
    {
      "id": "planetar",
      "name": "Planetar",
      "size": "Grande",
      "type": "celestial",
      "alignment": "legal bueno",
      "ac": 19,
      "initiative": {
        "modifier": 10,
        "score": 20
      },
      "hp": {
        "average": 262,
        "formula": "21d10 + 147"
      },
      "speed": {
        "walk": "40 pies",
        "fly": "120 pies (levitar)"
      },
      "abilities": {
        "str": 24,
        "dex": 20,
        "con": 24,
        "int": 19,
        "wis": 22,
        "cha": 25
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 12
        },
        {
          "ability": "dex",
          "bonus": 5
        },
        {
          "ability": "con",
          "bonus": 12
        },
        {
          "ability": "int",
          "bonus": 4
        },
        {
          "ability": "wis",
          "bonus": 11
        },
        {
          "ability": "cha",
          "bonus": 12
        }
      ],
      "traits": [
        {
          "name": "Percepción divina",
          "text": "El planetar reconoce cualquier mentira que escuche."
        },
        {
          "name": "Recuperación exaltada",
          "text": "Si el planetar muere fuera del Monte Celestia, su cuerpo desaparece, obtiene un cuerpo nuevo al instante y revive con todos sus puntos de golpe en algún lugar del Monte Celestia."
        },
        {
          "name": "Resistencia mágica",
          "text": "El planetar tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El planetar realiza tres ataques con su espada radiante o emplea su estallido sagrado dos veces."
        },
        {
          "name": "Espada radiante",
          "text": "Tirada de ataque cuerpo a cuerpo: +12, alcance 10 pies. Acierto: 14 (2d6 + 7) de daño cortante más 18 (4d8) de daño radiante."
        },
        {
          "name": "Estallido sagrado",
          "text": "Tirada de salvación de Destreza: CD 20, todos los enemigos en una esfera de 20 pies de radio centrada en un punto que el planetar pueda ver a 120 pies o menos. Fallo: 24 (7d6) de daño radiante. Éxito: la mitad del daño."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El planetar lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 20): A voluntad: detectar el bien y el mal 1/día cada uno: alzar a los muertos, comunión, controlar el clima, disipar el bien y el mal"
        }
      ],
      "bonusActions": [
        {
          "name": "Auxilio divino (2/día)",
          "text": "El planetar lanza curar heridas, invisibilidad, levantar maldición o restablecimiento menor usando la misma aptitud mágica que para su lanzamiento de conjuros. Plantas despertadas"
        }
      ],
      "reactions": [],
      "subtype": "ángel",
      "skills": [
        {
          "name": "Percepción",
          "bonus": 11
        }
      ],
      "damageResistances": [
        "radiante"
      ],
      "conditionImmunities": [
        "asustado",
        "cansancio",
        "hechizado"
      ],
      "senses": [
        "visión verdadera 120 pies",
        "Percepción pasiva 21"
      ],
      "languages": [
        "todos",
        "telepatía 120 pies"
      ],
      "cr": "16",
      "proficiencyBonus": 5,
      "xp": 15000
    },
    {
      "id": "arbol_despertado",
      "name": "Árbol despertado",
      "size": "Enorme",
      "type": "planta",
      "alignment": "neutral",
      "ac": 13,
      "initiative": {
        "modifier": -2,
        "score": 8
      },
      "hp": {
        "average": 59,
        "formula": "7d12 + 14"
      },
      "speed": {
        "walk": "20 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 6,
        "con": 15,
        "int": 10,
        "wis": 10,
        "cha": 7
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": -2
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Golpe",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 10 pies. Acierto: 14 (3d6 + 4) de daño contundente."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageVulnerabilities": [
        "fuego"
      ],
      "damageResistances": [
        "contundente",
        "perforante"
      ],
      "senses": [
        "Percepción pasiva 10"
      ],
      "languages": [
        "común y otro cualquiera"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "arbusto_despertado",
      "name": "Arbusto despertado",
      "size": "Pequeña",
      "type": "planta",
      "alignment": "neutral",
      "ac": 9,
      "initiative": {
        "modifier": -1,
        "score": 9
      },
      "hp": {
        "average": 10,
        "formula": "3d6"
      },
      "speed": {
        "walk": "20 pies"
      },
      "abilities": {
        "str": 3,
        "dex": 8,
        "con": 11,
        "int": 10,
        "wis": 10,
        "cha": 6
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -4
        },
        {
          "ability": "dex",
          "bonus": -1
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Desgarrar",
          "text": "Tirada de ataque cuerpo a cuerpo: +1, alcance 5 pies. Acierto: 1 de daño cortante."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageVulnerabilities": [
        "fuego"
      ],
      "damageResistances": [
        "perforante"
      ],
      "senses": [
        "Percepción pasiva 10"
      ],
      "languages": [
        "común y otro cualquiera"
      ],
      "cr": "0",
      "proficiencyBonus": 2,
      "xp": 10
    },
    {
      "id": "plebeyo",
      "name": "Plebeyo",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 10,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 4,
        "formula": "1d8"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 10,
        "dex": 10,
        "con": 10,
        "int": 10,
        "wis": 10,
        "cha": 10
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 0
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [
        {
          "name": "Entrenamiento",
          "text": "El plebeyo es competente en una habilidad a elección de cada GM y tiene ventaja siempre que realice una prueba de característica con esa habilidad."
        }
      ],
      "actions": [
        {
          "name": "Garrote",
          "text": "Tirada de ataque cuerpo a cuerpo: +2, alcance 5 pies. Acierto: 2 (1d4) de daño contundente."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "equipment": [
        "garrote"
      ],
      "senses": [
        "Percepción pasiva 10"
      ],
      "languages": [
        "común"
      ],
      "cr": "0",
      "proficiencyBonus": 2,
      "xp": 10
    },
    {
      "id": "pseudodragon",
      "name": "Pseudodragón",
      "size": "Diminuto",
      "type": "dragón",
      "alignment": "neutral bueno",
      "ac": 14,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 10,
        "formula": "3d4 + 3"
      },
      "speed": {
        "walk": "15 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 6,
        "dex": 15,
        "con": 13,
        "int": 10,
        "wis": 12,
        "cha": 10
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -2
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [
        {
          "name": "Resistencia mágica",
          "text": "El pseudodragón tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El pseudodragón realiza dos ataques de mordisco."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 4 (1d4 + 2) de daño perforante."
        },
        {
          "name": "Aguijón",
          "text": "Tirada de salvación de Constitución: CD 12, una criatura que el pseudodragón pueda ver a 5 pies o menos. Fallo: 5 (2d4) de daño de veneno y el objetivo tendrá el estado de envenenado durante 1 hora. Fallo por 5 o más: mientras esté envenenado, el objetivo también tendrá el estado de inconsciente, que terminará antes si recibe daño o una criatura a 5 pies o menos de él utiliza una acción para despertarlo."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 5
        },
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "senses": [
        "visión ciega 10 pies, visión en la oscuridad 60 pies",
        "Percepción pasiva 15"
      ],
      "languages": [
        "entiende común y dracónico, pero no puede hablar"
      ],
      "cr": "1/4",
      "proficiencyBonus": 2,
      "xp": 50
    },
    {
      "id": "pudin_negro",
      "name": "Pudin negro",
      "size": "Grande",
      "type": "cieno",
      "alignment": "sin alineamiento",
      "ac": 7,
      "initiative": {
        "modifier": -3,
        "score": 7
      },
      "hp": {
        "average": 68,
        "formula": "8d10 + 24"
      },
      "speed": {
        "walk": "20 pies",
        "climb": "20 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 5,
        "con": 16,
        "int": 1,
        "wis": 6,
        "cha": 1
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": -3
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": -5
        },
        {
          "ability": "wis",
          "bonus": -2
        },
        {
          "ability": "cha",
          "bonus": -5
        }
      ],
      "traits": [
        {
          "name": "Amorfo",
          "text": "El pudin puede moverse a través de un espacio de solo 1 pulgada de ancho sin gastar movimiento adicional para hacerlo."
        },
        {
          "name": "Forma corrosiva",
          "text": "Una criatura que acierte al pudin con una tirada de ataque cuerpo a cuerpo recibirá 4 (1d8) de daño de ácido. La munición no mágica se destruirá de inmediato tras impactar en el pudin y causarle daño. Cualquier arma no mágica recibirá un penalizador acumulativo de −1 a las tiradas de ataque inmediatamente después de causar daño al pudin y entrar en contacto con él. Si el penalizador llega a −5, el arma se destruirá. El penalizador se puede eliminar lanzando el conjuro reparar sobre el arma. En 1 minuto, el pudin puede devorar y atravesar 24 pulgadas de madera o metal no mágicos."
        },
        {
          "name": "Trepar cual arácnido",
          "text": "El pudin puede trepar por superficies difíciles e incluso recorrer techos sin tener que realizar pruebas de característica."
        }
      ],
      "actions": [
        {
          "name": "Pseudópodo disolvente",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 10 pies. Acierto: 17 (4d6 + 3) de daño de ácido. La armadura no mágica que lleve el objetivo recibirá un penalizador de −1 a la CA que ofrece. La armadura se destruirá si el penalizador reduce su CA hasta 10. El penalizador se puede eliminar lanzando el conjuro reparar sobre la armadura."
        }
      ],
      "bonusActions": [],
      "reactions": [
        {
          "name": "Dividirse",
          "text": "Detonante: mientras sea Grande o Mediano y tenga 10 o más puntos de golpe, el pudin pasa a estar maltrecho o recibe daño cortante o de relámpago. Respuesta: el pudin se divide en dos nuevos púdines negros. Cada nuevo pudin tiene un tamaño inferior al del pudin original y actúa en su orden de iniciativa. Los puntos de golpe del pudin original se dividen a partes iguales entre los nuevos púdines (redondeados hacia abajo)."
        }
      ],
      "damageImmunities": [
        "ácido",
        "cortante",
        "frío",
        "relámpago"
      ],
      "conditionImmunities": [
        "agarrado",
        "apresado",
        "asustado",
        "cansancio",
        "derribado",
        "ensordecido",
        "hechizado"
      ],
      "senses": [
        "visión ciega 60 pies",
        "Percepción pasiva 8"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "4",
      "proficiencyBonus": 2,
      "xp": 1100
    },
    {
      "id": "quasit",
      "name": "Quasit",
      "size": "Diminuto",
      "type": "infernal",
      "alignment": "caótico malvado",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 25,
        "formula": "10d4"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 5,
        "dex": 17,
        "con": 10,
        "int": 7,
        "wis": 10,
        "cha": 10
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -3
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [
        {
          "name": "Resistencia mágica",
          "text": "El quasit tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 5 (1d4 + 3) de daño cortante y el objetivo tendrá el estado de envenenado hasta el principio del siguiente turno del quasit."
        },
        {
          "name": "Asustar (1/día)",
          "text": "Tirada de salvación de Sabiduría:"
        },
        {
          "name": "CD 10, una criatura a 20 pies o menos",
          "text": "Fallo: el objetivo tendrá el estado de asustado. Al final de cada uno de sus turnos, el objetivo repetirá la tirada de salvación y, si tiene éxito, se librará del efecto. Tras 1 minuto, tendrá éxito automáticamente."
        },
        {
          "name": "Cambio de forma",
          "text": "El quasit cambia de forma para parecerse a un ciempiés (velocidad 40 pies, trepar 40 pies), un murciélago (10 pies, volar 40 pies) o un sapo (40 pies, nadar 40 pies), o recupera su auténtica forma. Su perfil es el mismo en todas las formas, excepto por su velocidad. Cualquier equipo que vista o lleve no se transformará."
        },
        {
          "name": "Invisibilidad",
          "text": "El quasit lanza invisibilidad sobre sí mismo sin necesidad de componentes y utiliza el Carisma como aptitud mágica."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "demonio",
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "damageResistances": [
        "frío",
        "fuego",
        "relámpago"
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 120 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "abisal",
        "común"
      ],
      "cr": "1",
      "proficiencyBonus": 2,
      "xp": 200
    },
    {
      "id": "quimera",
      "name": "Quimera",
      "size": "Grande",
      "type": "monstruosidad",
      "alignment": "caótica malvada",
      "ac": 14,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 114,
        "formula": "12d10 + 48"
      },
      "speed": {
        "walk": "30 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 11,
        "con": 19,
        "int": 3,
        "wis": 14,
        "cha": 10
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "La quimera embiste una vez y realiza un ataque de mordisco y uno con sus garras. Puede sustituir el ataque con sus garras por un uso de su aliento de fuego, si está disponible."
        },
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 7 (1d6 + 4) de daño cortante."
        },
        {
          "name": "Embestir",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 10 (1d12 + 4) de daño contundente. Si el objetivo es una criatura Mediana o más pequeña, tendrá el estado de derribada."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 11 (2d6 + 4) de daño perforante o 18 (4d6 + 4) de daño perforante si la quimera tenía ventaja en la tirada de ataque."
        },
        {
          "name": "Aliento de fuego (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 15, todas las criaturas en un cono de 15 pies. Fallo: 31 (7d8) de daño de fuego. Éxito: la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 8
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 18"
      ],
      "languages": [
        "entiende dracónico, pero no puede hablar"
      ],
      "cr": "6",
      "proficiencyBonus": 3,
      "xp": 2300
    },
    {
      "id": "rakshasa",
      "name": "Rakshasa",
      "size": "Mediano",
      "type": "infernal",
      "alignment": "legal malvado",
      "ac": 17,
      "initiative": {
        "modifier": 8,
        "score": 18
      },
      "hp": {
        "average": 221,
        "formula": "26d8 + 104"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 14,
        "dex": 17,
        "con": 18,
        "int": 13,
        "wis": 16,
        "cha": 20
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 3
        },
        {
          "ability": "cha",
          "bonus": 5
        }
      ],
      "traits": [
        {
          "name": "Recuperación infernal",
          "text": "Si el rakshasa muere fuera de los Nueve Infiernos, su cuerpo se convierte en icor, obtiene un cuerpo nuevo al instante y revive con todos sus puntos de golpe en algún lugar de los Nueve Infiernos."
        },
        {
          "name": "Resistencia mágica superior",
          "text": "El rakshasa supera automáticamente las tiradas de salvación contra conjuros y otros efectos mágicos, y las tiradas de ataque de conjuros contra él fallan automáticamente. Sin el permiso del rakshasa, ningún conjuro puede observarlo desde lejos ni detectar sus pensamientos, tipo de criatura o alineamiento."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El rakshasa realiza tres ataques con su toque maldito."
        },
        {
          "name": "Toque maldito",
          "text": "Tirada de ataque cuerpo a cuerpo: +10, alcance 5 pies. Acierto: 12 (2d6 + 5) de daño cortante más 19 (3d12) de daño necrótico. Si el objetivo es una criatura, quedará maldita. Mientras esté maldita, la criatura no obtendrá beneficio alguno por finalizar un descanso corto o largo."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El rakshasa lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 18): A voluntad: detectar magia, detectar pensamientos, disfrazarse, ilusión menor, mano de mago 1/día cada uno: desplazamiento entre planos, imagen mayor, invisibilidad, volar"
        },
        {
          "name": "Orden siniestra (recarga 5–6)",
          "text": "Tirada de salvación de Sabiduría: CD 18, todos los enemigos en una emanación de 30 pies que se origina en el rakshasa. Fallo: 28 (8d6) de daño psíquico y el objetivo tendrá los estados de asustado e incapacitado hasta el principio del siguiente turno del rakshasa."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Engaño",
          "bonus": 10
        },
        {
          "name": "Percepción",
          "bonus": 8
        },
        {
          "name": "Perspicacia",
          "bonus": 8
        }
      ],
      "damageVulnerabilities": [
        "daño perforante de armas empuñadas por criaturas bajo el efecto de un conjuro bendición"
      ],
      "conditionImmunities": [
        "asustado",
        "hechizado"
      ],
      "senses": [
        "visión verdadera 60 pies",
        "Percepción pasiva 18"
      ],
      "languages": [
        "común",
        "infernal"
      ],
      "cr": "13",
      "proficiencyBonus": 5,
      "xp": 10000
    },
    {
      "id": "remorhaz",
      "name": "Remorhaz",
      "size": "Enorme",
      "type": "monstruosidad",
      "alignment": "sin alineamiento",
      "ac": 17,
      "initiative": {
        "modifier": 5,
        "score": 15
      },
      "hp": {
        "average": 195,
        "formula": "17d12 + 85"
      },
      "speed": {
        "walk": "40 pies",
        "burrow": "30 pies"
      },
      "abilities": {
        "str": 24,
        "dex": 13,
        "con": 21,
        "int": 4,
        "wis": 10,
        "cha": 5
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 7
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 5
        },
        {
          "ability": "int",
          "bonus": -3
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -3
        }
      ],
      "traits": [
        {
          "name": "Aura de calor",
          "text": "Al final de cada turno del remorhaz, todas las criaturas en una emanación de 5 pies que se origina en él reciben 16 (3d10) de daño de fuego."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +11, alcance 10 pies. Acierto: 18 (2d10 + 7) de daño perforante más 14 (4d6) de daño de fuego. Si el objetivo es una criatura Grande o más pequeña, tendrá el estado de agarrada (CD 17 para escapar) y el de apresada hasta que el agarre termine."
        }
      ],
      "bonusActions": [
        {
          "name": "Engullir",
          "text": "Tirada de salvación de Fuerza: CD 19, una criatura Grande o más pequeña agarrada por el remorhaz (puede tener hasta dos criaturas engullidas a la vez). Fallo: el objetivo será engullido por el remorhaz y se pondrá fin al estado de agarrado. Una criatura engullida tendrá los estados de apresada y cegada, tendrá cobertura completa contra los ataques y otros efectos fuera del remorhaz y recibirá 10 (3d6) de daño de ácido más 10 (3d6) de daño de fuego al principio de cada turno del remorhaz. Si el remorhaz sufre 30 o más de daño en un solo turno por parte de una criatura que esté dentro de él, deberá superar una tirada de salvación de Constitución con CD 15 al final de ese turno o regurgitará a todas las criaturas engullidas, que caerán en espacios a 5 pies o menos del remorhaz y tendrán el estado de derribadas. Si el remorhaz muere, cualquier criatura engullida dejará de tener el estado de apresada y podrá gastar 15 pies de movimiento para escapar del cadáver, del que saldrá con el estado de derribada."
        }
      ],
      "reactions": [],
      "damageImmunities": [
        "frío",
        "fuego"
      ],
      "senses": [
        "sentir vibraciones 60 pies, visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "11",
      "proficiencyBonus": 4,
      "xp": 7200
    },
    {
      "id": "roc",
      "name": "Roc",
      "size": "Gargantuesca",
      "type": "monstruosidad",
      "alignment": "sin alineamiento",
      "ac": 15,
      "initiative": {
        "modifier": 8,
        "score": 18
      },
      "hp": {
        "average": 248,
        "formula": "16d20 + 80"
      },
      "speed": {
        "walk": "20 pies",
        "fly": "120 pies"
      },
      "abilities": {
        "str": 28,
        "dex": 10,
        "con": 20,
        "int": 3,
        "wis": 10,
        "cha": 9
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 9
        },
        {
          "ability": "dex",
          "bonus": 4
        },
        {
          "ability": "con",
          "bonus": 5
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": 4
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El roc hace dos ataques con su pico. Puede sustituir uno de ellos por un ataque con sus garras."
        },
        {
          "name": "Garras",
          "text": "Tirada de ataque cuerpo a cuerpo: +13, alcance 5 pies. Acierto: 23 (4d6 + 9) de daño cortante. Si el objetivo es una criatura Enorme o más pequeña, tendrá el estado de agarrada (CD 19 para escapar) por las dos garras y el de apresada hasta que el agarre termine."
        },
        {
          "name": "Pico",
          "text": "Tirada de ataque cuerpo a cuerpo: +13, alcance 10 pies. Acierto: 28 (3d12 + 9) de daño perforante."
        }
      ],
      "bonusActions": [
        {
          "name": "Caída en picado (recarga 5–6)",
          "text": "Si el roc tiene a una criatura agarrada, vuela hasta la mitad de su velocidad volando sin provocar ataques de oportunidad y suelta a la criatura."
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 8
        }
      ],
      "senses": [
        "Percepción pasiva 18"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "11",
      "proficiencyBonus": 4,
      "xp": 7200
    },
    {
      "id": "sabueso_infernal",
      "name": "Sabueso infernal",
      "size": "Mediano",
      "type": "infernal",
      "alignment": "legal malvado",
      "ac": 15,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 58,
        "formula": "9d8 + 18"
      },
      "speed": {
        "walk": "50 pies"
      },
      "abilities": {
        "str": 17,
        "dex": 12,
        "con": 14,
        "int": 6,
        "wis": 13,
        "cha": 6
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [
        {
          "name": "Atacar en manada",
          "text": "El sabueso tiene ventaja en una tirada de ataque contra una criatura si al menos uno de los aliados del sabueso se encuentra a 5 pies o menos de la criatura y no tiene el estado de incapacitado."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El sabueso realiza dos ataques de mordisco."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 7 (1d8 + 3) de daño perforante más 3 (1d6) de daño de fuego."
        },
        {
          "name": "Aliento de fuego (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 12, todas las criaturas en un cono de 15 pies. Fallo: 17 (5d6) de daño de fuego. Éxito: la mitad del daño. Sacerdotes"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 5
        }
      ],
      "damageImmunities": [
        "fuego"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 15"
      ],
      "languages": [
        "entiende infernal, pero no puede hablar"
      ],
      "cr": "3",
      "proficiencyBonus": 2,
      "xp": 700
    },
    {
      "id": "sacerdote_acolito",
      "name": "Sacerdote acólito",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 13,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 11,
        "formula": "2d8 + 2"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 14,
        "dex": 10,
        "con": 12,
        "int": 10,
        "wis": 14,
        "cha": 11
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Maza",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 5 (1d6 + 2) de daño contundente más 2 (1d4) de daño radiante."
        },
        {
          "name": "Llama radiante",
          "text": "Tirada de ataque a distancia: +4, alcance 60 pies. Acierto: 7 (2d6) de daño radiante."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El sacerdote lanza uno de los siguientes conjuros, que utiliza la Sabiduría como aptitud mágica: A voluntad: luz, taumaturgia"
        }
      ],
      "bonusActions": [
        {
          "name": "Auxilio divino (1/día)",
          "text": "El sacerdote lanza bendición, palabra de curación o santuario usando la misma aptitud mágica que para su lanzamiento de conjuros."
        }
      ],
      "reactions": [],
      "subtype": "clérigo",
      "skills": [
        {
          "name": "Medicina",
          "bonus": 4
        },
        {
          "name": "Religión",
          "bonus": 2
        }
      ],
      "equipment": [
        "camisa de malla",
        "maza",
        "símbolo sagrado"
      ],
      "senses": [
        "Percepción pasiva 12"
      ],
      "languages": [
        "común"
      ],
      "cr": "1/4",
      "proficiencyBonus": 2,
      "xp": 50
    },
    {
      "id": "sacerdote",
      "name": "Sacerdote",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 13,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 38,
        "formula": "7d8 + 7"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 10,
        "con": 12,
        "int": 13,
        "wis": 16,
        "cha": 13
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 3
        },
        {
          "ability": "cha",
          "bonus": 1
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El sacerdote realiza dos ataques con su maza o su llama radiante en cualquier combinación."
        },
        {
          "name": "Maza",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 6 (1d6 + 3) de daño contundente más 5 (2d4) de daño radiante."
        },
        {
          "name": "Llama radiante",
          "text": "Tirada de ataque a distancia: +5, alcance 60 pies. Acierto: 11 (2d10) de daño radiante."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El sacerdote lanza uno de los siguientes conjuros, que utiliza la Sabiduría como aptitud mágica (CD de salvación de conjuros 13): A voluntad: luz, taumaturgia 1/día: espíritus guardianes"
        }
      ],
      "bonusActions": [
        {
          "name": "Auxilio divino (3/día)",
          "text": "El sacerdote lanza bendición, disipar magia, palabra de curación o restablecimiento menor usando la misma aptitud mágica que para su lanzamiento de conjuros."
        }
      ],
      "reactions": [],
      "subtype": "clérigo",
      "skills": [
        {
          "name": "Medicina",
          "bonus": 7
        },
        {
          "name": "Percepción",
          "bonus": 5
        },
        {
          "name": "Religión",
          "bonus": 5
        }
      ],
      "equipment": [
        "camisa de malla",
        "maza",
        "símbolo sagrado"
      ],
      "senses": [
        "Percepción pasiva 15"
      ],
      "languages": [
        "común y otro cualquiera"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "saga_cetrina",
      "name": "Saga cetrina",
      "size": "Mediano",
      "type": "feérico",
      "alignment": "neutral malvado",
      "ac": 17,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 82,
        "formula": "11d8 + 33"
      },
      "speed": {
        "walk": "30 pies",
        "swim": "30 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 12,
        "con": 16,
        "int": 13,
        "wis": 14,
        "cha": 14
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "traits": [
        {
          "name": "Anfibia",
          "text": "La saga puede respirar tanto dentro como fuera del agua."
        },
        {
          "name": "Imitación",
          "text": "La saga puede imitar sonidos de animales y voces de humanoides. Una criatura que oiga estos sonidos solo puede darse cuenta de que son imitaciones si supera una prueba de Sabiduría (Perspicacia) con CD 14."
        },
        {
          "name": "Magia del aquelarre",
          "text": "Mientras esté a 30 pies o menos de un mínimo de dos sagas aliadas, la saga puede lanzar uno de los siguientes conjuros, que no requiere componentes materiales, emplea el tiempo de lanzamiento normal y usa la Inteligencia como aptitud mágica (CD de salvación de conjuros 11): augurio, encontrar familiar, escudriñar, identificar, localizar objeto o sirviente invisible. La saga debe finalizar un descanso largo antes de usar este atributo para lanzar ese conjuro otra vez."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "La saga realiza dos ataques con sus garras."
        },
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 8 (1d8 + 4) de daño cortante más 3 (1d6) de daño de veneno."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "La saga lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza la Sabiduría como aptitud mágica (CD de salvación de conjuros 12, +4 a acertar con ataques de conjuro): A voluntad: disfrazarse (24 horas de duración), ilusión menor, invisibilidad (solo lanzador y la saga no deja huellas mientras es invisible), luces danzantes, rayo nauseabundo (versión de nivel 3)"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Conocimiento arcano",
          "bonus": 5
        },
        {
          "name": "Engaño",
          "bonus": 4
        },
        {
          "name": "Percepción",
          "bonus": 4
        },
        {
          "name": "Sigilo",
          "bonus": 3
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "común",
        "elfo",
        "silvano"
      ],
      "cr": "3",
      "proficiencyBonus": 2,
      "xp": 700
    },
    {
      "id": "saga_de_la_noche",
      "name": "Saga de la noche",
      "size": "Mediano",
      "type": "infernal",
      "alignment": "neutral malvado",
      "ac": 17,
      "initiative": {
        "modifier": 5,
        "score": 15
      },
      "hp": {
        "average": 112,
        "formula": "15d8 + 45"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 15,
        "con": 16,
        "int": 16,
        "wis": 14,
        "cha": 16
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": 3
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 3
        }
      ],
      "traits": [
        {
          "name": "Bolsa de almas",
          "text": "La saga tiene una bolsa de almas. Mientras la sostenga o lleve consigo, puede usar su acción de provocar pesadillas. La bolsa tiene una CA de 15, 20 pg y resistencia a todo el daño. Se convertirá en polvo si sus puntos de golpe se reducen a 0. Si se destruye, las almas que contenga la bolsa quedarán libres. La saga puede crear una bolsa nueva tras 7 días."
        },
        {
          "name": "Magia del aquelarre",
          "text": "Mientras esté a 30 pies o menos de un mínimo de dos sagas aliadas, la saga puede lanzar uno de los siguientes conjuros, que no requiere componentes materiales, emplea el tiempo de lanzamiento normal y usa la Inteligencia como aptitud mágica (CD de salvación de conjuros 14): augurio, encontrar familiar, escudriñar, identificar, localizar objeto o sirviente invisible. La saga debe finalizar un descanso largo antes de usar este atributo para lanzar ese conjuro otra vez."
        },
        {
          "name": "Resistencia mágica",
          "text": "La saga tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "La saga realiza dos ataques con sus garras."
        },
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 13 (2d8 + 4) de daño cortante."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "La saga lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza la Inteligencia como aptitud mágica (CD de salvación de conjuros 14): A voluntad: detectar magia, excursión etérea, proyectil mágico (versión de nivel 4) 2/día cada uno: asesino fantasmal, desplazamiento entre planos (solo lanzador) Provocar pesadillas (1/día; requiere una bolsa de almas). Mientras está en el Plano Etéreo, la saga lanza ensueño usando la misma aptitud mágica que para su lanzamiento de conjuros. Solo la saga puede actuar como mensajera del conjuro y el objetivo debe ser una criatura que la saga pueda ver en el Plano Material. El conjuro fallará y se desperdiciará si el objetivo se encuentra bajo el efecto de un conjuro protección contra el bien y el mal o dentro de un conjuro círculo mágico. Si el objetivo recibe daño del conjuro ensueño, sus puntos de golpe máximos se reducirán en una cantidad igual a ese daño. Si el conjuro mata al objetivo, su alma quedará atrapada en la bolsa de almas de la saga y el objetivo no podrá volver a la vida hasta que se libere su alma."
        }
      ],
      "bonusActions": [
        {
          "name": "Cambio de forma",
          "text": "La saga se convierte en un humanoide Pequeño o Mediano, o recupera su auténtica forma. Su perfil, salvo por el tamaño, es el mismo en todas las formas. Cualquier equipo que vista o lleve no se transformará."
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Engaño",
          "bonus": 6
        },
        {
          "name": "Percepción",
          "bonus": 5
        },
        {
          "name": "Perspicacia",
          "bonus": 5
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "damageResistances": [
        "frío",
        "fuego"
      ],
      "conditionImmunities": [
        "hechizado"
      ],
      "senses": [
        "visión en la oscuridad 120 pies",
        "Percepción pasiva 15"
      ],
      "languages": [
        "abisal",
        "común",
        "infernal",
        "primordial"
      ],
      "cr": "5",
      "proficiencyBonus": 3,
      "xp": 1800
    },
    {
      "id": "saga_de_los_mares",
      "name": "Saga de los mares",
      "size": "Mediano",
      "type": "feérico",
      "alignment": "caótico malvado",
      "ac": 14,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 52,
        "formula": "7d8 + 21"
      },
      "speed": {
        "walk": "30 pies",
        "swim": "40 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 13,
        "con": 16,
        "int": 12,
        "wis": 12,
        "cha": 13
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": 1
        }
      ],
      "traits": [
        {
          "name": "Anfibia",
          "text": "La saga puede respirar tanto dentro como fuera del agua."
        },
        {
          "name": "Apariencia vil",
          "text": "Tirada de salvación de Sabiduría: CD 11, cualquier bestia o humanoide que empiece su turno a 30 pies o menos de la saga y pueda verla en su auténtica forma. Fallo: el objetivo tendrá el estado de asustado hasta el principio de su siguiente turno. Éxito: el objetivo será inmune a la Apariencia vil de esta saga durante 24 horas."
        },
        {
          "name": "Magia del aquelarre",
          "text": "Mientras esté a 30 pies o menos de un mínimo de dos sagas aliadas, la saga puede lanzar uno de los siguientes conjuros, que no requiere componentes materiales, emplea el tiempo de lanzamiento normal y usa la Inteligencia como aptitud mágica (CD de salvación de conjuros 11): augurio, encontrar familiar, escudriñar, identificar, localizar objeto o sirviente invisible. La saga debe finalizar un descanso largo antes de usar este atributo para lanzar ese conjuro otra vez."
        }
      ],
      "actions": [
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 10 (2d6 + 3) de daño cortante."
        },
        {
          "name": "Apariencia ilusoria",
          "text": "La saga lanza disfrazarse, que utiliza la Constitución como aptitud mágica (CD de salvación de conjuros 13). El conjuro dura 24 horas."
        },
        {
          "name": "Mirada mortal (recarga 5–6)",
          "text": "Tirada de salvación de Sabiduría: CD 11, una criatura asustada que la saga pueda ver a 30 pies o menos. Fallo: si el objetivo tiene 20 puntos de golpe o menos, estos se reducen a 0. De lo contrario, el objetivo recibe 13 (3d8) de daño psíquico. Sahuagin"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 11"
      ],
      "languages": [
        "común",
        "gigante",
        "primordial (acuano)"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "guerrero_sahuagin",
      "name": "Guerrero sahuagin",
      "size": "Mediano",
      "type": "infernal",
      "alignment": "legal malvado",
      "ac": 12,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 22,
        "formula": "4d8 + 4"
      },
      "speed": {
        "walk": "30 pies",
        "swim": "40 pies"
      },
      "abilities": {
        "str": 13,
        "dex": 11,
        "con": 12,
        "int": 12,
        "wis": 13,
        "cha": 9
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 1
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [
        {
          "name": "Frenesí sangriento",
          "text": "El sahuagin tiene ventaja en las tiradas de ataque contra cualquier criatura que no posea todos sus puntos de golpe."
        },
        {
          "name": "Parcialmente anfibio",
          "text": "El sahuagin puede respirar tanto dentro del agua como fuera de ella, pero necesita sumergirse cada 4 horas para evitar asfixiarse fuera del agua."
        },
        {
          "name": "Telepatía con tiburones",
          "text": "El sahuagin puede controlar mágicamente a los tiburones a 120 pies o menos de él usando una telepatía especial."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El sahuagin realiza dos ataques con sus garras."
        },
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +3, alcance 5 pies. Acierto: 4 (1d6 + 1) de daño cortante."
        }
      ],
      "bonusActions": [
        {
          "name": "Carga acuática",
          "text": "El sahuagin nada hasta la mitad de su velocidad nadando en línea recta hacia un enemigo que pueda ver."
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 5
        }
      ],
      "damageResistances": [
        "ácido",
        "frío"
      ],
      "senses": [
        "visión en la oscuridad 120 pies",
        "Percepción pasiva 15"
      ],
      "languages": [
        "sahuagin"
      ],
      "cr": "1/2",
      "proficiencyBonus": 2,
      "xp": 100
    },
    {
      "id": "salamandra",
      "name": "Salamandra",
      "size": "Grande",
      "type": "elemental",
      "alignment": "neutral malvado",
      "ac": 15,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 90,
        "formula": "12d10 + 24"
      },
      "speed": {
        "walk": "30 pies",
        "climb": "30 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 14,
        "con": 15,
        "int": 11,
        "wis": 10,
        "cha": 12
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 1
        }
      ],
      "traits": [
        {
          "name": "Aura de fuego",
          "text": "Al final de cada turno de la salamandra, todas las criaturas a su elección en una emanación de 5 pies que se origina en ella reciben 7 (2d6) de daño de fuego."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "La salamandra realiza dos ataques con su lanza de llamas. Puede sustituir un ataque por una acción de constreñir."
        },
        {
          "name": "Lanza de llamas",
          "text": "Tirada de ataque cuerpo a cuerpo o a distancia: +7, alcance 5 pies o 6/60 pies a distancia. Acierto: 13 (2d8 + 4) de daño perforante más 7 (2d6) de daño de fuego. Acierto o fallo: la lanza regresa mágicamente a la mano de la salamandra inmediatamente después de un ataque a distancia."
        },
        {
          "name": "Constreñir",
          "text": "Tirada de salvación de Fuerza: CD 15, una criatura Grande o más pequeña que la salamandra pueda ver a 10 pies o menos. Fallo: 11 (2d6 + 4) de daño contundente más 7 (2d6) de daño de fuego. El objetivo tendrá el estado de agarrado (CD 14 para escapar) y el de apresado hasta que el agarre termine."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageVulnerabilities": [
        "frío"
      ],
      "damageImmunities": [
        "fuego"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "primordial (ígneo)"
      ],
      "cr": "5",
      "proficiencyBonus": 3,
      "xp": 1800
    },
    {
      "id": "satiro",
      "name": "Sátiro",
      "size": "Mediano",
      "type": "feérico",
      "alignment": "caótico neutral",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 31,
        "formula": "7d8"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 12,
        "dex": 16,
        "con": 11,
        "int": 12,
        "wis": 10,
        "cha": 14
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 1
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": 1
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "traits": [
        {
          "name": "Resistencia mágica",
          "text": "El sátiro tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Cascos",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 5 (1d4 + 3) de daño contundente. Si el objetivo es una criatura Mediana o más pequeña, el sátiro la empujará hasta 10 pies respecto a él en línea recta."
        },
        {
          "name": "Burla",
          "text": "Tirada de salvación de Sabiduría: CD 12, una criatura que el sátiro pueda ver a 90 pies o menos. Fallo: 5 (1d6 + 2) de daño psíquico. Sectarios"
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Interpretación",
          "bonus": 6
        },
        {
          "name": "Percepción",
          "bonus": 2
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "senses": [
        "Percepción pasiva 12"
      ],
      "languages": [
        "común",
        "elfo",
        "silvano"
      ],
      "cr": "1/2",
      "proficiencyBonus": 2,
      "xp": 100
    },
    {
      "id": "sectario",
      "name": "Sectario",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 12,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 9,
        "formula": "2d8"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 11,
        "dex": 12,
        "con": 10,
        "int": 10,
        "wis": 11,
        "cha": 10
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 0
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Hoz ritual",
          "text": "Tirada de ataque cuerpo a cuerpo: +3, alcance 5 pies. Acierto: 3 (1d4 + 1) de daño cortante más 1 de daño necrótico."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Engaño",
          "bonus": 2
        },
        {
          "name": "Religión",
          "bonus": 2
        }
      ],
      "equipment": [
        "armadura de cuero",
        "hoz"
      ],
      "senses": [
        "Percepción pasiva 10"
      ],
      "languages": [
        "común"
      ],
      "cr": "1/8",
      "proficiencyBonus": 2,
      "xp": 25
    },
    {
      "id": "fanatico_sectario",
      "name": "Fanático sectario",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral",
      "ac": 13,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 44,
        "formula": "8d8 + 8"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 11,
        "dex": 14,
        "con": 12,
        "int": 10,
        "wis": 14,
        "cha": 13
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 0
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 4
        },
        {
          "ability": "cha",
          "bonus": 1
        }
      ],
      "traits": [],
      "actions": [
        {
          "name": "Cuchilla de pacto",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 6 (1d8 + 2) de daño cortante más 7 (2d6) de daño necrótico."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El sectario lanza uno de los siguientes conjuros, que utiliza la Sabiduría como aptitud mágica (CD de salvación de conjuros 12, +4 a acertar con ataques de conjuro): A voluntad: luz, taumaturgia 2/día: orden imperiosa 1/día: inmovilizar persona"
        }
      ],
      "bonusActions": [
        {
          "name": "Arma espiritual (2/día)",
          "text": "El sectario lanza el conjuro arma espiritual usando la misma aptitud mágica que para su lanzamiento de conjuros."
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Engaño",
          "bonus": 3
        },
        {
          "name": "Persuasión",
          "bonus": 3
        },
        {
          "name": "Religión",
          "bonus": 2
        }
      ],
      "equipment": [
        "armadura de cuero",
        "símbolo sagrado"
      ],
      "senses": [
        "Percepción pasiva 12"
      ],
      "languages": [
        "común"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    },
    {
      "id": "semidragon",
      "name": "Semidragón",
      "size": "Mediano",
      "type": "dragón",
      "alignment": "neutral",
      "ac": 18,
      "initiative": {
        "modifier": 5,
        "score": 15
      },
      "hp": {
        "average": 105,
        "formula": "14d8 + 42"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 14,
        "con": 16,
        "int": 10,
        "wis": 15,
        "cha": 14
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 5
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 5
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "traits": [
        {
          "name": "Origen dracónico",
          "text": "El semidragón está relacionado con un tipo de dragón asociado con uno de los siguientes tipos de daño (a elección de cada GM): ácido, frío, fuego, relámpago o veneno. Esta elección afecta a otros aspectos del perfil."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El semidragón realiza dos ataques con sus garras."
        },
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 10 pies. Acierto: 6 (1d4 + 4) de daño cortante más 7 (2d6) de daño del tipo elegido para el atributo Origen dracónico."
        },
        {
          "name": "Aliento de dragón (recarga 5–6)",
          "text": "Tirada de salvación de Destreza: CD 14, todas las criaturas en un cono de 30 pies. Fallo: 28 (8d6) de daño del tipo elegido para el atributo Origen dracónico. Éxito: la mitad del daño."
        }
      ],
      "bonusActions": [
        {
          "name": "Salto",
          "text": "El semidragón gasta 10 pies de movimiento para saltar hasta 30 pies. Sirénido"
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Atletismo",
          "bonus": 7
        },
        {
          "name": "Percepción",
          "bonus": 5
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "damageResistances": [
        "tipo de daño elegido para el atributo origen dracónico más adelante"
      ],
      "senses": [
        "visión ciega 10 pies, visión en la oscuridad 60 pies",
        "Percepción pasiva 15"
      ],
      "languages": [
        "común",
        "dracónico"
      ],
      "cr": "5",
      "proficiencyBonus": 3,
      "xp": 1800
    },
    {
      "id": "experto_en_escaramuzas_sirenido",
      "name": "Experto en escaramuzas sirénido",
      "size": "Mediano",
      "type": "elemental",
      "alignment": "neutral",
      "ac": 11,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 11,
        "formula": "2d8 + 2"
      },
      "speed": {
        "walk": "10 pies",
        "swim": "40 pies"
      },
      "abilities": {
        "str": 10,
        "dex": 13,
        "con": 12,
        "int": 11,
        "wis": 14,
        "cha": 12
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 0
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 1
        }
      ],
      "traits": [
        {
          "name": "Anfibio",
          "text": "El sirénido puede respirar tanto dentro como fuera del agua."
        }
      ],
      "actions": [
        {
          "name": "Lanza marina",
          "text": "Tirada de ataque cuerpo a cuerpo o a distancia: +2, alcance 5 pies o 6/60 pies a distancia. Acierto: 3 (1d6) de daño perforante más 2 (1d4) de daño de frío. Si el objetivo es una criatura, su velocidad se reducirá en 10 pies hasta el final de su siguiente turno. Acierto o fallo: la lanza regresa mágicamente a la mano del sirénido inmediatamente después de un ataque a distancia."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "senses": [
        "Percepción pasiva 12"
      ],
      "languages": [
        "común",
        "primordial (acuano)"
      ],
      "cr": "1/8",
      "proficiencyBonus": 2,
      "xp": 25
    },
    {
      "id": "solar",
      "name": "Solar",
      "size": "Grande",
      "type": "celestial",
      "alignment": "legal bueno",
      "ac": 21,
      "initiative": {
        "modifier": 20,
        "score": 30
      },
      "hp": {
        "average": 297,
        "formula": "22d10 + 176"
      },
      "speed": {
        "walk": "50 pies",
        "fly": "150 pies (levitar)"
      },
      "abilities": {
        "str": 26,
        "dex": 22,
        "con": 26,
        "int": 25,
        "wis": 25,
        "cha": 30
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 8
        },
        {
          "ability": "dex",
          "bonus": 6
        },
        {
          "ability": "con",
          "bonus": 8
        },
        {
          "ability": "int",
          "bonus": 7
        },
        {
          "ability": "wis",
          "bonus": 7
        },
        {
          "ability": "cha",
          "bonus": 10
        }
      ],
      "traits": [
        {
          "name": "Percepción divina",
          "text": "El solar reconoce cualquier mentira que escuche."
        },
        {
          "name": "Recuperación exaltada",
          "text": "Si el solar muere fuera del Monte Celestia, su cuerpo desaparece, obtiene un cuerpo nuevo al instante y revive con todos sus puntos de golpe en algún lugar del Monte Celestia."
        },
        {
          "name": "Resistencia legendaria (4/día)",
          "text": "El solar puede elegir tener éxito en una tirada de salvación que haya fallado."
        },
        {
          "name": "Resistencia mágica",
          "text": "El solar tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El solar realiza dos ataques con su espada voladora. Puede sustituir un ataque por un uso de su arco asesino."
        },
        {
          "name": "Espada voladora",
          "text": "Tirada de ataque cuerpo a cuerpo o a distancia: +15, alcance 10 pies o 120 pies a distancia. Acierto: 22 (4d6 + 8) de daño cortante más 36 (8d8) de daño radiante. Acierto o fallo: la espada regresa mágicamente a la mano del solar o levita a 5 pies o menos de él inmediatamente después de un ataque a distancia."
        },
        {
          "name": "Arco asesino",
          "text": "Tirada de salvación de Destreza: CD 21, una criatura que el solar pueda ver a 600 pies o menos. Fallo: si la criatura tiene 100 puntos de golpe o menos, morirá. De lo contrario, sufrirá 24 (4d8 + 6) de daño perforante más 36 (8d8) de daño radiante."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El solar lanza uno de los siguientes conjuros, que no requiere componentes materiales y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 25): A voluntad: detectar el bien y el mal 1/día cada uno: comunión, controlar el clima, disipar el bien y el mal, resurrección"
        }
      ],
      "bonusActions": [
        {
          "name": "Auxilio divino (3/día)",
          "text": "El solar lanza curar heridas (versión de nivel 2), levantar maldición o restablecimiento menor usando la misma aptitud mágica que para su lanzamiento de conjuros."
        }
      ],
      "reactions": [],
      "subtype": "ángel",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3. Justo después del turno de otra criatura, el solar puede emplear un uso para llevar a cabo una de las siguientes acciones. El solar recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Mirada cegadora",
          "text": "Tirada de salvación de Constitución: CD 25, una criatura que el solar pueda ver a 120 pies o menos. Fallo: el objetivo tendrá el estado de cegado durante 1 minuto. Fallo o éxito: el solar no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        },
        {
          "name": "Teletransporte radiante",
          "text": "El solar se teletransporta hasta 60 pies a un espacio sin ocupar que pueda ver. Tirada de salvación de Destreza: CD 25, todas las criaturas en una emanación de 10 pies que se origina en el espacio de destino del solar. Fallo: 11 (2d10) de daño radiante. Éxito: la mitad del daño."
        }
      ],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 14
        }
      ],
      "damageImmunities": [
        "veneno",
        "radiante"
      ],
      "conditionImmunities": [
        "asustado",
        "cansancio",
        "envenenado",
        "hechizado"
      ],
      "senses": [
        "visión verdadera 120 pies",
        "Percepción pasiva 24"
      ],
      "languages": [
        "todos",
        "telepatía 120 pies"
      ],
      "cr": "21",
      "proficiencyBonus": 7,
      "xp": 33000
    },
    {
      "id": "sombra",
      "name": "Sombra",
      "size": "Mediano",
      "type": "muerto viviente",
      "alignment": "caótico malvado",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 27,
        "formula": "5d8 + 5"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 6,
        "dex": 14,
        "con": 13,
        "int": 6,
        "wis": 10,
        "cha": 8
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -2
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "traits": [
        {
          "name": "Amorfa",
          "text": "La sombra puede moverse a través de un espacio de solo 1 pulgada de ancho sin gastar movimiento adicional para hacerlo."
        },
        {
          "name": "Debilidad a la luz solar",
          "text": "Bajo la luz del sol, la sombra tiene desventaja en las pruebas con d20."
        }
      ],
      "actions": [
        {
          "name": "Zarpazo debilitador",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 5 (1d6 + 2) de daño necrótico y la puntuación de Fuerza del objetivo se reduce en 1d4. Si su Fuerza se reduce a 0, morirá. Si un humanoide muere a causa de este ataque, una sombra surgirá de su cadáver tras 1d4 horas."
        }
      ],
      "bonusActions": [
        {
          "name": "Esconderse en las sombras",
          "text": "Con luz tenue o en la oscuridad, la sombra realiza la acción de esconderse."
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 6
        }
      ],
      "damageVulnerabilities": [
        "radiante"
      ],
      "damageResistances": [
        "ácido",
        "frío",
        "fuego",
        "relámpago",
        "trueno"
      ],
      "damageImmunities": [
        "necrótico",
        "veneno"
      ],
      "conditionImmunities": [
        "agarrado",
        "apresado",
        "asustado",
        "cansancio",
        "derribado",
        "envenenado",
        "inconsciente",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/2",
      "proficiencyBonus": 2,
      "xp": 100
    },
    {
      "id": "sucubo",
      "name": "Súcubo",
      "size": "Mediano",
      "type": "infernal",
      "alignment": "neutral malvado",
      "ac": 15,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 71,
        "formula": "13d8 + 13"
      },
      "speed": {
        "walk": "30 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 8,
        "dex": 17,
        "con": 13,
        "int": 15,
        "wis": 12,
        "cha": 20
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -1
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 2
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": 5
        }
      ],
      "traits": [
        {
          "name": "Forma de íncubo",
          "text": "Cuando el súcubo finaliza un descanso largo, puede adoptar la forma de un íncubo y pasar a utilizar ese perfil en lugar de este."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El súcubo realiza un ataque con su toque infernal y emplea su beso debilitador o su acción de hechizar."
        },
        {
          "name": "Toque infernal",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 16 (2d10 + 5) de daño psíquico."
        },
        {
          "name": "Beso debilitador",
          "text": "Tirada de salvación de Constitución: CD 15, una criatura hechizada por el súcubo a 5 pies o menos. Fallo: 13 (3d8) de daño psíquico. Éxito: la mitad del daño. Fallo o éxito: los puntos de golpe máximos del objetivo se reducirán en una cantidad igual al daño sufrido."
        },
        {
          "name": "Hechizar",
          "text": "El súcubo lanza dominar persona (versión de nivel 8), que no requiere componentes y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 15)."
        }
      ],
      "bonusActions": [
        {
          "name": "Cambio de forma",
          "text": "El súcubo adopta la forma de un humanoide Mediano o Pequeño, o recupera su verdadera forma. Su perfil es el mismo en todas las formas, excepto porque su velocidad volando solo está disponible en su forma verdadera. Cualquier equipo que vista o lleve no se transformará."
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Engaño",
          "bonus": 9
        },
        {
          "name": "Percepción",
          "bonus": 5
        },
        {
          "name": "Perspicacia",
          "bonus": 5
        },
        {
          "name": "Persuasión",
          "bonus": 9
        },
        {
          "name": "Sigilo",
          "bonus": 7
        }
      ],
      "damageResistances": [
        "frío",
        "fuego",
        "psíquico",
        "veneno"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 15"
      ],
      "languages": [
        "abisal",
        "común",
        "infernal",
        "telepatía 60 pies"
      ],
      "cr": "4",
      "proficiencyBonus": 2,
      "xp": 1100
    },
    {
      "id": "tarasca",
      "name": "Tarasca",
      "size": "Gargantuesca",
      "type": "monstruosidad",
      "alignment": "sin alineamiento",
      "ac": 25,
      "initiative": {
        "modifier": 18,
        "score": 28
      },
      "hp": {
        "average": 697,
        "formula": "34d20 + 340"
      },
      "speed": {
        "walk": "60 pies",
        "burrow": "40 pies",
        "climb": "60 pies"
      },
      "abilities": {
        "str": 30,
        "dex": 11,
        "con": 30,
        "int": 3,
        "wis": 11,
        "cha": 11
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 10
        },
        {
          "ability": "dex",
          "bonus": 9
        },
        {
          "ability": "con",
          "bonus": 10
        },
        {
          "ability": "int",
          "bonus": 5
        },
        {
          "ability": "wis",
          "bonus": 9
        },
        {
          "ability": "cha",
          "bonus": 9
        }
      ],
      "traits": [
        {
          "name": "Caparazón reflectante",
          "text": "Si la tarasca es el objetivo de un conjuro proyectil mágico o de un conjuro que requiera una tirada de ataque a distancia, tira 1d6. Con un resultado de 1 a 5, la tarasca no se verá afectada. Con un 6, la tarasca no se verá afectada y reflejará el conjuro, convirtiendo al lanzador en el objetivo."
        },
        {
          "name": "Monstruo de asedio",
          "text": "La tarasca inflige el doble de daño a objetos y estructuras."
        },
        {
          "name": "Resistencia legendaria (6/día)",
          "text": "La tarasca puede elegir tener éxito en una tirada de salvación que haya fallado."
        },
        {
          "name": "Resistencia mágica",
          "text": "La tarasca tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "La tarasca realiza un ataque de mordisco y otros tres ataques con sus garras o su cola en cualquier combinación."
        },
        {
          "name": "Cola",
          "text": "Tirada de ataque cuerpo a cuerpo: +19, alcance 30 pies. Acierto: 23 (3d8 + 10) de daño contundente. Si el objetivo es una criatura Enorme o más pequeña, tendrá el estado de derribada."
        },
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +19, alcance 15 pies. Acierto: 28 (4d8 + 10) de daño cortante."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +19, alcance 15 pies. Acierto: 36 (4d12 + 10) de daño perforante y el objetivo tendrá el estado de agarrado (CD 20 para escapar). Hasta que el agarre termine, el objetivo tendrá el estado de apresado y no podrá teletransportarse."
        },
        {
          "name": "Bramido atronador (recarga 5–6)",
          "text": "Tirada de salvación de Constitución: CD 27, todas las criaturas y todos los objetos que no lleve o vista alguna criatura en un cono de 150 pies. Fallo: 78 (12d12) de daño de trueno y el objetivo tendrá los estados de asustado y ensordecido hasta el final de su siguiente turno. Éxito: solo la mitad del daño."
        }
      ],
      "bonusActions": [
        {
          "name": "Engullir",
          "text": "Tirada de salvación de Fuerza: CD 27, una criatura Grande o más pequeña agarrada por la tarasca (puede tener hasta seis criaturas engullidas a la vez). Fallo: el objetivo será engullido y se pondrá fin al estado de agarrado. Una criatura engullida tendrá los estados de apresada y cegada y no podrá teletransportarse, tendrá cobertura completa contra los ataques y otros efectos fuera de la tarasca y recibirá 56 (16d6) de daño de ácido al principio de cada turno de la tarasca. Si la tarasca sufre 60 o más de daño en un solo turno por parte de una criatura que esté dentro de ella, deberá superar una tirada de salvación de Constitución con CD 20 al final de ese turno o regurgitará a todas las criaturas engullidas, que caerán en espacios a 10 pies o menos de la tarasca y tendrán el estado de derribadas. Si la tarasca muere, cualquier criatura engullida dejará de tener el estado de apresada y podrá gastar 20 pies de movimiento para escapar del cadáver, del que saldrá con el estado de derribada."
        }
      ],
      "reactions": [],
      "subtype": "titán",
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3. Justo después del turno de otra criatura, la tarasca puede emplear un uso para llevar a cabo una de las siguientes acciones. La tarasca recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Arremetida",
          "text": "La tarasca se mueve hasta la mitad de su velocidad y realiza un ataque con sus garras o su cola."
        },
        {
          "name": "Movimiento estremecedor",
          "text": "La tarasca se mueve hasta su velocidad. Al final de este movimiento, crea una onda sísmica instantánea en una emanación de 60 pies que se origina en ella. Las criaturas situadas en esa zona perderán la concentración y, si son Medianas o más pequeñas, tendrán el estado de derribadas. La tarasca no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        }
      ],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 9
        }
      ],
      "damageResistances": [
        "contundente",
        "cortante",
        "perforante"
      ],
      "damageImmunities": [
        "fuego",
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "ensordecido",
        "envenenado",
        "hechizado",
        "paralizado"
      ],
      "senses": [
        "visión ciega 120 pies",
        "Percepción pasiva 19"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "30",
      "proficiencyBonus": 9,
      "xp": 155000
    },
    {
      "id": "troll",
      "name": "Troll",
      "size": "Grande",
      "type": "gigante",
      "alignment": "caótico malvado",
      "ac": 15,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 94,
        "formula": "9d10 + 45"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 13,
        "con": 20,
        "int": 7,
        "wis": 9,
        "cha": 7
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 5
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": -1
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "traits": [
        {
          "name": "Miembros repugnantes (4/día)",
          "text": "Si el troll termina cualquier turno maltrecho y ha sufrido 15 o más de daño cortante durante ese turno, uno de los miembros del troll será amputado, caerá en el espacio del trol y se convertirá en una extremidad de troll. La extremidad actuará inmediatamente después del turno del troll. El troll tendrá 1 nivel de cansancio por cada extremidad que le falte y le crecerán miembros de repuesto la siguiente vez que recupere puntos de golpe."
        },
        {
          "name": "Regeneración",
          "text": "El troll recupera 15 puntos de golpe al principio de cada uno de sus turnos. Si recibe daño de ácido o de fuego, este atributo no funcionará en su siguiente turno. El troll solo morirá si empieza su turno con 0 puntos de golpe y no se regenera."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El troll realiza tres ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 10 pies. Acierto: 11 (2d6 + 4) de daño cortante."
        }
      ],
      "bonusActions": [
        {
          "name": "Carga",
          "text": "El troll se mueve hasta la mitad de su velocidad en línea recta hacia un enemigo que pueda ver."
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 5
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 15"
      ],
      "languages": [
        "gigante"
      ],
      "cr": "5",
      "proficiencyBonus": 3,
      "xp": 1800
    },
    {
      "id": "extremidad_de_troll",
      "name": "Extremidad de troll",
      "size": "Pequeño",
      "type": "gigante",
      "alignment": "caótico malvado",
      "ac": 13,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 14,
        "formula": "4d6"
      },
      "speed": {
        "walk": "20 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 12,
        "con": 10,
        "int": 1,
        "wis": 9,
        "cha": 1
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": -5
        },
        {
          "ability": "wis",
          "bonus": -1
        },
        {
          "ability": "cha",
          "bonus": -5
        }
      ],
      "traits": [
        {
          "name": "Engendro de troll",
          "text": "Asombrosamente, la extremidad tiene los mismos sentidos que un troll entero. Si la extremidad no se destruye en 24 horas, tira 1d12. Si el resultado es 12, la extremidad se convierte en un troll. Si no, la extremidad se atrofia y muere."
        },
        {
          "name": "Regeneración",
          "text": "La extremidad recupera 5 puntos de golpe al principio de cada uno de sus turnos. Si recibe daño de ácido o de fuego, este atributo no funcionará en su siguiente turno. La extremidad solo morirá si empieza su turno con 0 puntos de golpe y no se regenera."
        }
      ],
      "actions": [
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 9 (2d4 + 4) de daño cortante."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 9"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/2",
      "proficiencyBonus": 2,
      "xp": 100
    },
    {
      "id": "tumulario",
      "name": "Tumulario",
      "size": "Mediano",
      "type": "muerto viviente",
      "alignment": "neutral malvado",
      "ac": 14,
      "initiative": {
        "modifier": 4,
        "score": 14
      },
      "hp": {
        "average": 82,
        "formula": "11d8 + 33"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 15,
        "dex": 14,
        "con": 16,
        "int": 10,
        "wis": 13,
        "cha": 15
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "traits": [
        {
          "name": "Sensibilidad a la luz solar",
          "text": "Bajo la luz del sol, el tumulario tiene desventaja en las pruebas de característica y las tiradas de ataque."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El tumulario realiza dos ataques con su espada necrótica o su arco necrótico en cualquier combinación. Puede sustituir un ataque por una acción de consumir vida."
        },
        {
          "name": "Espada necrótica",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 6 (1d8 + 2) de daño cortante más 4 (1d8) de daño necrótico."
        },
        {
          "name": "Arco necrótico",
          "text": "Tirada de ataque a distancia: +4, alcance 45/600 pies. Acierto: 6 (1d8 + 2) de daño perforante más 4 (1d8) de daño necrótico."
        },
        {
          "name": "Consumir vida",
          "text": "Tirada de salvación de Constitución:"
        },
        {
          "name": "CD 13, una criatura a 5 pies o menos",
          "text": "Fallo: 6 (1d8 + 2) de daño necrótico y los puntos de golpe máximos del objetivo se reducirán en una cantidad igual al daño sufrido. Un humanoide que muera por este ataque se alzará 24 horas después como un zombi bajo el control del tumulario, a menos que se le devuelva a la vida o su cuerpo sea destruido. El tumulario no puede tener más de doce zombis bajo su control a la vez."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 3
        },
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "damageResistances": [
        "necrótico"
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "cansancio",
        "envenenado"
      ],
      "equipment": [
        "armadura de cuero tachonado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 13"
      ],
      "languages": [
        "común y otro cualquiera"
      ],
      "cr": "3",
      "proficiencyBonus": 2,
      "xp": 700
    },
    {
      "id": "unicornio",
      "name": "Unicornio",
      "size": "Grande",
      "type": "celestial",
      "alignment": "legal bueno",
      "ac": 12,
      "initiative": {
        "modifier": 8,
        "score": 18
      },
      "hp": {
        "average": 97,
        "formula": "13d10 + 26"
      },
      "speed": {
        "walk": "50 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 14,
        "con": 15,
        "int": 11,
        "wis": 17,
        "cha": 16
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 3
        },
        {
          "ability": "cha",
          "bonus": 3
        }
      ],
      "traits": [
        {
          "name": "Resistencia legendaria (3/día)",
          "text": "El unicornio puede elegir tener éxito en una tirada de salvación que haya fallado."
        },
        {
          "name": "Resistencia mágica",
          "text": "El unicornio tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El unicornio realiza un ataque con sus cascos y uno con su cuerno radiante."
        },
        {
          "name": "Cascos",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 11 (2d6 + 4) de daño contundente."
        },
        {
          "name": "Cuerno radiante",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 9 (1d10 + 4) de daño radiante."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El unicornio lanza uno de los siguientes conjuros, que no requiere componentes y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 14): A voluntad: detectar el bien y el mal, saber druídico 1/día cada uno: calmar emociones, disipar el bien y el mal, enmarañar, palabra de regreso, pasar sin rastro"
        }
      ],
      "bonusActions": [
        {
          "name": "Bendición de unicornio (3/día)",
          "text": "El unicornio toca a otra criatura con su cuerno y lanza curar heridas o restablecimiento menor sobre esa criatura usando la misma aptitud mágica que para su lanzamiento de conjuros."
        }
      ],
      "reactions": [],
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3. Justo después del turno de otra criatura, el unicornio puede emplear un uso para llevar a cabo una de las siguientes acciones. El unicornio recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Cuerno embestidor",
          "text": "El unicornio se mueve hasta la mitad de su velocidad sin provocar ataques de oportunidad y realiza un ataque con su cuerno radiante."
        },
        {
          "name": "Escudo resplandeciente",
          "text": "El unicornio se hace objetivo a sí mismo o hace objetivo a una criatura que pueda ver a 60 pies o menos de él. El objetivo obtiene 10 (3d6) puntos de golpe temporales y su CA aumenta en 2 hasta el final del siguiente turno del unicornio. El unicornio no puede volver a realizar esta acción hasta el principio de su siguiente turno. Vampiros"
        }
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado",
        "hechizado",
        "paralizado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 13"
      ],
      "languages": [
        "celestial",
        "elfo",
        "silvano",
        "telepatía 120 pies"
      ],
      "cr": "5",
      "proficiencyBonus": 3,
      "xp": 1800
    },
    {
      "id": "siervo_de_vampiro",
      "name": "Siervo de vampiro",
      "size": "Mediano o Pequeño",
      "type": "humanoide",
      "alignment": "neutral malvado",
      "ac": 15,
      "initiative": {
        "modifier": 5,
        "score": 15
      },
      "hp": {
        "average": 65,
        "formula": "10d8 + 20"
      },
      "speed": {
        "walk": "30 pies",
        "climb": "30 pies"
      },
      "abilities": {
        "str": 17,
        "dex": 16,
        "con": 15,
        "int": 10,
        "wis": 10,
        "cha": 14
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 5
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "traits": [
        {
          "name": "Conexión vampírica",
          "text": "Mientras el siervo de vampiro y su amo estén en el mismo plano de existencia, el vampiro puede comunicarse con el siervo telepáticamente y percibir el mundo a través de sus sentidos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El siervo realiza dos ataques con sus dagas sombrías."
        },
        {
          "name": "Daga sombría",
          "text": "Tirada de ataque cuerpo a cuerpo o a distancia: +5, alcance 5 pies o 6/60 pies a distancia. Acierto: 5 (1d4 + 3) de daño perforante más 7 (3d4) de daño necrótico. Si este ataque reduce a 0 los puntos de golpe del objetivo, pasará a estar estable, pero tendrá el estado de envenenado durante 1 hora. Mientras tenga el estado de envenenado, tendrá también el estado de paralizado."
        }
      ],
      "bonusActions": [
        {
          "name": "Agilidad de inmortal",
          "text": "El siervo realiza las acciones de correr o destrabarse."
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 4
        },
        {
          "name": "Persuasión",
          "bonus": 4
        },
        {
          "name": "Sigilo",
          "bonus": 7
        }
      ],
      "damageResistances": [
        "necrótico"
      ],
      "damageImmunities": [
        "hechizado (salvo por parte de su amo vampiro)"
      ],
      "equipment": [
        "dagas (10)"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "común y otro cualquiera"
      ],
      "cr": "3",
      "proficiencyBonus": 2,
      "xp": 700
    },
    {
      "id": "engendro_vampirico",
      "name": "Engendro vampírico",
      "size": "Mediano o Pequeño",
      "type": "muerto viviente",
      "alignment": "neutral malvado",
      "ac": 16,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 90,
        "formula": "12d8 + 36"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 16,
        "con": 16,
        "int": 11,
        "wis": 10,
        "cha": 12
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 6
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 3
        },
        {
          "ability": "cha",
          "bonus": 1
        }
      ],
      "traits": [
        {
          "name": "Debilidad vampírica",
          "text": "El vampiro tiene estas debilidades:"
        },
        {
          "name": "Agua corriente",
          "text": "El vampiro sufre 20 de daño de ácido si termina su turno en agua corriente."
        },
        {
          "name": "Estaca en el corazón",
          "text": "El vampiro es destruido si se le clava en el corazón un arma que cause daño perforante mientras tiene el estado de incapacitado."
        },
        {
          "name": "Luz solar",
          "text": "El vampiro sufre 20 de daño radiante si empieza su turno bajo la luz solar. Además, tiene desventaja en las tiradas de ataque y las pruebas de característica hechas bajo la luz del sol."
        },
        {
          "name": "Prohibición",
          "text": "El vampiro no puede entrar en una residencia sin invitación de un habitante."
        },
        {
          "name": "Trepar cual arácnido",
          "text": "El vampiro puede trepar por superficies difíciles e incluso recorrer techos sin tener que realizar pruebas de característica."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El vampiro realiza dos ataques con sus garras y uno de mordisco."
        },
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 8 (2d4 + 3) de daño cortante. Si el objetivo es una criatura Mediana o más pequeña, tendrá el estado de agarrada (CD 13 para escapar) por una de las dos garras."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de salvación de Constitución: CD 14, una criatura voluntaria a 5 pies o menos o que tenga los estados de agarrada, apresada o incapacitada. Fallo: 5 (1d4 + 3) de daño perforante más 10 (3d6) de daño necrótico. Los puntos de golpe máximos del objetivo se reducirán en una cantidad igual al daño necrótico recibido y el vampiro recuperará esa misma cantidad de puntos de golpe."
        }
      ],
      "bonusActions": [
        {
          "name": "Agilidad de inmortal",
          "text": "El vampiro realiza las acciones de correr o destrabarse."
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 3
        },
        {
          "name": "Sigilo",
          "bonus": 6
        }
      ],
      "damageResistances": [
        "necrótico"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 13"
      ],
      "languages": [
        "común y otro cualquiera"
      ],
      "cr": "5",
      "proficiencyBonus": 3,
      "xp": 1800
    },
    {
      "id": "vampiro",
      "name": "Vampiro",
      "size": "Mediano o Pequeño",
      "type": "muerto viviente",
      "alignment": "legal malvado",
      "ac": 16,
      "initiative": {
        "modifier": 14,
        "score": 24
      },
      "hp": {
        "average": 195,
        "formula": "23d8 + 92"
      },
      "speed": {
        "walk": "40 pies",
        "climb": "40 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 18,
        "con": 18,
        "int": 17,
        "wis": 15,
        "cha": 18
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 9
        },
        {
          "ability": "con",
          "bonus": 9
        },
        {
          "ability": "int",
          "bonus": 3
        },
        {
          "ability": "wis",
          "bonus": 7
        },
        {
          "ability": "cha",
          "bonus": 9
        }
      ],
      "traits": [
        {
          "name": "Debilidad vampírica",
          "text": "El vampiro tiene estas debilidades:"
        },
        {
          "name": "Agua corriente",
          "text": "El vampiro sufre 20 de daño de ácido si termina su turno en agua corriente."
        },
        {
          "name": "Estaca en el corazón",
          "text": "Si al vampiro se le clava en el corazón un arma que cause daño perforante mientras tiene el estado de incapacitado en su lugar de descanso, tendrá el estado de paralizado hasta que se retire el arma."
        },
        {
          "name": "Luz solar",
          "text": "El vampiro sufre 20 de daño radiante si empieza su turno bajo la luz solar. Además, tiene desventaja en las tiradas de ataque y las pruebas de característica hechas bajo la luz del sol."
        },
        {
          "name": "Prohibición",
          "text": "El vampiro no puede entrar en una residencia sin invitación de un habitante."
        },
        {
          "name": "Escape brumoso",
          "text": "Si los puntos de golpe del vampiro se reducen a 0 fuera de su lugar de descanso, utilizará su cambio de forma para convertirse en niebla (no requiere acción). Si no puede cambiar de forma, será destruido. Mientras esté en forma de niebla y sus puntos de golpe sean 0, no podrá volver a su forma de vampiro y deberá llegar a su lugar de descanso en 2 horas o será destruido. Una vez que esté en su lugar de descanso, recuperará la forma de vampiro y tendrá el estado de paralizado hasta que recupere algún punto de golpe; recuperará 1 punto de golpe tras pasar 1 hora allí. Resistencia legendaria (3/día o 4/día en la guarida). El vampiro puede elegir tener éxito en una tirada de salvación que haya fallado."
        },
        {
          "name": "Trepar cual arácnido",
          "text": "El vampiro puede trepar por superficies difíciles e incluso recorrer techos sin tener que realizar pruebas de característica."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple (solo en forma de vampiro)",
          "text": "El vampiro realiza dos ataques con su golpe sepulcral y uno de mordisco."
        },
        {
          "name": "Golpe sepulcral (solo en forma de vampiro)",
          "text": "Tirada de ataque cuerpo a cuerpo: +9, alcance 5 pies. Acierto: 8 (1d8 + 4) de daño contundente más 7 (2d6) de daño necrótico. Si el objetivo es una criatura Grande o más pequeña, tendrá el estado de agarrada (CD 14 para escapar) por una de las manos."
        },
        {
          "name": "Mordisco (solo en forma de murciélago o vampiro)",
          "text": "Tirada de salvación de Constitución: CD 17, una criatura voluntaria a 5 pies o menos o que tenga los estados de agarrada, apresada o incapacitada. Fallo: 6 (1d4 + 4) de daño perforante más 13 (3d8) de daño necrótico. Los puntos de golpe máximos del objetivo se reducirán en una cantidad igual al daño necrótico recibido y el vampiro recuperará esa misma cantidad de puntos de golpe. Si este daño reduce a 0 los puntos de golpe de un humanoide y luego lo entierran, se alzará como un engendro vampírico bajo el control del vampiro en la próxima puesta de sol."
        }
      ],
      "bonusActions": [
        {
          "name": "Cambio de forma",
          "text": "Si el vampiro no se encuentra bajo la luz solar ni en agua corriente, adoptará la forma de un murciélago Diminuto (velocidad 5 pies, velocidad volando 30 pies) o de una nube de niebla Mediana (velocidad 5 pies, velocidad volando 20 pies [levitar]), o recuperará su forma de vampiro. Todo lo que lleve puesto se transformará con él. Mientras tenga la forma de murciélago, no podrá hablar. Su perfil, salvo por el tamaño y la velocidad, no cambiará. En forma de niebla, el vampiro no podrá realizar acciones, hablar o manipular objetos. No pesará nada y podrá entrar en el espacio de un enemigo y detenerse allí. Será capaz de atravesar cualquier espacio por el que pueda pasar el aire, aunque no podrá pasar a través de líquidos. Tendrá resistencia a todo el daño, salvo el daño que sufra de la luz solar."
        },
        {
          "name": "Hechizar (recarga 5–6)",
          "text": "El vampiro lanza hechizar persona, que no requiere componentes, utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 17) y dura 24 horas. El objetivo hechizado es un receptor voluntario del mordisco del vampiro, cuyo daño no pone fin al conjuro. Cuando el conjuro termina, el objetivo no sabe que ha sido hechizado por el vampiro."
        }
      ],
      "reactions": [],
      "legendaryActions": [
        {
          "name": "Usos de acciones legendarias",
          "text": "3 (4 en la guarida). Justo después del turno de otra criatura, el vampiro puede emplear un uso para llevar a cabo una de las siguientes acciones. El vampiro recupera todos los usos al principio de cada uno de sus turnos."
        },
        {
          "name": "Cautivar",
          "text": "El vampiro lanza orden imperiosa, que no requiere componentes y utiliza el Carisma como aptitud mágica (CD de salvación de conjuros 17). El vampiro no puede volver a realizar esta acción hasta el principio de su siguiente turno."
        },
        {
          "name": "Golpe inmortal",
          "text": "El vampiro se mueve hasta la mitad de su velocidad y realiza un ataque con su golpe sepulcral."
        }
      ],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 7
        },
        {
          "name": "Sigilo",
          "bonus": 9
        }
      ],
      "damageResistances": [
        "necrótico"
      ],
      "senses": [
        "visión en la oscuridad 120 pies",
        "Percepción pasiva 17"
      ],
      "languages": [
        "común y otros dos idiomas"
      ],
      "cr": "13",
      "proficiencyBonus": 5,
      "xp": 10000,
      "xpText": "10 000 PX u 11 500 en la guarida"
    },
    {
      "id": "vrock",
      "name": "Vrock",
      "size": "Grande",
      "type": "infernal",
      "alignment": "caótico malvado",
      "ac": 15,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 152,
        "formula": "16d10 + 64"
      },
      "speed": {
        "walk": "40 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 17,
        "dex": 15,
        "con": 18,
        "int": 8,
        "wis": 13,
        "cha": 8
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 5
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": -1
        },
        {
          "ability": "wis",
          "bonus": 4
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "traits": [
        {
          "name": "Recuperación demoníaca",
          "text": "Si el vrock muere fuera del Abismo, su cuerpo se disuelve en icor, obtiene un cuerpo nuevo al instante y revive con todos sus puntos de golpe en algún lugar del Abismo."
        },
        {
          "name": "Resistencia mágica",
          "text": "El vrock tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El vrock realiza dos ataques de desgarrar."
        },
        {
          "name": "Desgarrar",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 10 (2d6 + 3) de daño perforante más 10 (3d6) de daño de veneno."
        },
        {
          "name": "Chillido aturdidor (1/día)",
          "text": "Tirada de salvación de Constitución: CD 15, todas las criaturas en una emanación de 20 pies que se origina en el vrock (los demonios la superan automáticamente). Fallo: 10 (3d6) de daño de trueno y el objetivo tendrá el estado de aturdido hasta el final del siguiente turno del vrock."
        },
        {
          "name": "Esporas (recarga 6)",
          "text": "Tirada de salvación de Constitución: CD 15, todas las criaturas en una emanación de 20 pies que se origina en el vrock. Fallo: el objetivo tendrá el estado de envenenado y repetirá la tirada de salvación al final de cada uno de sus turnos. Si tiene éxito, se librará del efecto. Mientras el objetivo esté envenenado, sufrirá 5 (1d10) de daño de veneno al principio de cada uno de sus turnos. Si se vacía un frasco de agua bendita sobre el objetivo, el efecto cesará."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "subtype": "demonio",
      "damageResistances": [
        "frío",
        "fuego",
        "relámpago"
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 120 pies",
        "Percepción pasiva 11"
      ],
      "languages": [
        "abisal",
        "telepatía 120 pies"
      ],
      "cr": "6",
      "proficiencyBonus": 3,
      "xp": 2300
    },
    {
      "id": "xorn",
      "name": "Xorn",
      "size": "Mediano",
      "type": "elemental",
      "alignment": "neutral",
      "ac": 19,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 84,
        "formula": "8d8 + 48"
      },
      "speed": {
        "walk": "20 pies",
        "burrow": "20 pies"
      },
      "abilities": {
        "str": 17,
        "dex": 10,
        "con": 22,
        "int": 11,
        "wis": 10,
        "cha": 11
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 6
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "traits": [
        {
          "name": "Deslizarse por la tierra",
          "text": "El xorn puede excavar a través de la tierra y la piedra que no sean mágicas ni estén trabajadas. Al hacer esto, no desplaza ni perturba la materia a través de la que se mueve."
        },
        {
          "name": "Sentir tesoros",
          "text": "El xorn puede localizar la ubicación de metales preciosos y piedras a 60 pies o menos de él."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El xorn realiza un ataque de mordisco y tres con sus garras."
        },
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 8 (1d10 + 3) de daño cortante."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 17 (4d6 + 3) de daño perforante."
        }
      ],
      "bonusActions": [
        {
          "name": "Carga",
          "text": "El xorn se mueve hasta su velocidad o hasta su velocidad excavando en línea recta hacia un enemigo que pueda sentir. Zombis"
        }
      ],
      "reactions": [],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 6
        },
        {
          "name": "Sigilo",
          "bonus": 6
        }
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "sentir vibraciones 60 pies, visión en la oscuridad 60 pies",
        "Percepción pasiva 16"
      ],
      "languages": [
        "primordial (terrano)"
      ],
      "cr": "5",
      "proficiencyBonus": 3,
      "xp": 1800
    },
    {
      "id": "zombi",
      "name": "Zombi",
      "size": "Mediano",
      "type": "muerto viviente",
      "alignment": "neutral malvado",
      "ac": 8,
      "initiative": {
        "modifier": -2,
        "score": 8
      },
      "hp": {
        "average": 15,
        "formula": "2d8 + 6"
      },
      "speed": {
        "walk": "20 pies"
      },
      "abilities": {
        "str": 13,
        "dex": 6,
        "con": 16,
        "int": 3,
        "wis": 6,
        "cha": 5
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 1
        },
        {
          "ability": "dex",
          "bonus": -2
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -3
        }
      ],
      "traits": [
        {
          "name": "Fortaleza de muerto viviente",
          "text": "Si el daño reduce a 0 los puntos de golpe del zombi, hará una tirada de salvación de Constitución (CD 5 más el daño sufrido), siempre que el daño no sea radiante o proceda de un crítico. Si la supera, el zombi se queda con 1 punto de golpe."
        }
      ],
      "actions": [
        {
          "name": "Golpe",
          "text": "Tirada de ataque cuerpo a cuerpo: +3, alcance 5 pies. Acierto: 5 (1d8 + 1) de daño contundente."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "cansancio",
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 8"
      ],
      "languages": [
        "entiende común y otro idioma, pero no puede hablar"
      ],
      "cr": "1/4",
      "proficiencyBonus": 2,
      "xp": 50
    },
    {
      "id": "ogro_zombi",
      "name": "Ogro zombi",
      "size": "Grande",
      "type": "muerto viviente",
      "alignment": "neutral malvado",
      "ac": 8,
      "initiative": {
        "modifier": -2,
        "score": 8
      },
      "hp": {
        "average": 85,
        "formula": "9d10 + 36"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 6,
        "con": 18,
        "int": 3,
        "wis": 6,
        "cha": 5
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": -2
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -3
        }
      ],
      "traits": [
        {
          "name": "Fortaleza de muerto viviente",
          "text": "Si el daño reduce a 0 los puntos de golpe del zombi, hará una tirada de salvación de Constitución (CD 5 más el daño sufrido), siempre que el daño no sea radiante o proceda de un crítico. Si la supera, el zombi se queda con 1 punto de golpe."
        }
      ],
      "actions": [
        {
          "name": "Golpe",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 13 (2d8 + 4) de daño contundente."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "cansancio",
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 8"
      ],
      "languages": [
        "entiende común y gigante, pero no puede hablar"
      ],
      "cr": "2",
      "proficiencyBonus": 2,
      "xp": 450
    }
  ]
};
