window.PLAYER_BESTIARY_DATA = {
  "creatures": [
    {
      "id": "aguila",
      "name": "Águila",
      "size": "Pequeña",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 4,
        "formula": "1d6 + 1"
      },
      "speed": {
        "walk": "10 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 6,
        "dex": 15,
        "con": 12,
        "int": 2,
        "wis": 14,
        "cha": 7
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 6
        }
      ],
      "senses": [
        "Percepción pasiva 16"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "xp": 10,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Garras",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 4 (1d4 + 2) de daño cortante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "aguila_gigante",
      "name": "Águila gigante",
      "size": "Grande",
      "type": "celestial",
      "alignment": "neutral bueno",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 26,
        "formula": "4d10 + 4"
      },
      "speed": {
        "walk": "10 pies",
        "fly": "80 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 17,
        "con": 13,
        "int": 8,
        "wis": 14,
        "cha": 10
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 6
        }
      ],
      "damageResistances": [
        "necrótico",
        "radiante"
      ],
      "senses": [
        "Percepción pasiva 16"
      ],
      "languages": [
        "celestial",
        "entiende común y primordial (aurano), pero no puede hablarlos"
      ],
      "cr": "1",
      "xp": 200,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El águila realiza dos ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 5 (1d4 + 3) de daño cortante más 3 (1d6) de daño radiante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "alce",
      "name": "Alce",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 10,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 11,
        "formula": "2d10"
      },
      "speed": {
        "walk": "50 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 10,
        "con": 11,
        "int": 2,
        "wis": 10,
        "cha": 6
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 2
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/4",
      "xp": 50,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Embestir",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 6 (1d6 + 3) de daño contundente. Si el objetivo es una criatura Grande o más pequeña y el alce recorre al menos 20 pies en línea recta hacia ella justo antes de acertarle, esta recibirá 3 (1d6) de daño contundente adicional y tendrá el estado de derribada."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "alce_gigante",
      "name": "Alce gigante",
      "size": "Enorme",
      "type": "celestial",
      "alignment": "neutral bueno",
      "ac": 14,
      "initiative": {
        "modifier": 6,
        "score": 16
      },
      "hp": {
        "average": 42,
        "formula": "5d12 + 10"
      },
      "speed": {
        "walk": "60 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 18,
        "con": 14,
        "int": 7,
        "wis": 14,
        "cha": 10
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 4
        }
      ],
      "damageResistances": [
        "necrótico",
        "radiante"
      ],
      "senses": [
        "visión en la oscuridad 90 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "celestial",
        "entiende común, elfo y silvano, pero no puede hablarlos"
      ],
      "cr": "2",
      "xp": 450,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Embestir",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 10 pies. Acierto: 11 (2d6 + 4) de daño contundente más 5 (2d4) de daño radiante. Si el objetivo es una criatura Enorme o más pequeña y el alce recorre al menos 20 pies en línea recta hacia ella justo antes de acertarle, esta recibirá 5 (2d4) de daño contundente adicional y tendrá el estado de derribada."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "alosaurio",
      "name": "Alosaurio",
      "size": "Grande",
      "type": "bestia",
      "subtype": "dinosaurio",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 51,
        "formula": "6d10 + 18"
      },
      "speed": {
        "walk": "60 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 13,
        "con": 17,
        "int": 2,
        "wis": 12,
        "cha": 5
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 5
        }
      ],
      "senses": [
        "Percepción pasiva 15"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "2",
      "xp": 450,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Garras",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 8 (1d8 + 4) de daño cortante. Si el objetivo es una criatura Grande o más pequeña y el alosaurio recorre al menos 30 pies en línea recta hacia ella justo antes de acertarle, tendrá el estado de derribada y el alosaurio podrá realizar un ataque de mordisco contra ella."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 15 (2d10 + 4) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "anquilosaurio",
      "name": "Anquilosaurio",
      "size": "Enorme",
      "type": "bestia",
      "subtype": "dinosaurio",
      "alignment": "sin alineamiento",
      "ac": 15,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 68,
        "formula": "8d12 + 16"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 11,
        "con": 15,
        "int": 2,
        "wis": 12,
        "cha": 5
      },
      "skills": [],
      "senses": [
        "Percepción pasiva 11"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "3",
      "xp": 700,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El anquilosaurio realiza dos ataques con su cola."
        },
        {
          "name": "Cola",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 10 pies. Acierto: 9 (1d10 + 4) de daño contundente. Si el objetivo es una criatura Enorme o más pequeña, tendrá el estado de derribada."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "arana",
      "name": "Araña",
      "size": "Diminuta",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 1,
        "formula": "1d4 - 1"
      },
      "speed": {
        "walk": "20 pies",
        "climb": "20 pies"
      },
      "abilities": {
        "str": 2,
        "dex": 14,
        "con": 8,
        "int": 1,
        "wis": 10,
        "cha": 2
      },
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "senses": [
        "visión en la oscuridad 30 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "xp": 10,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Caminar por telarañas",
          "text": "La araña ignora todas las restricciones de movimiento causadas por las telarañas y conoce la ubicación de cualquier otra criatura que esté en contacto con la misma telaraña."
        },
        {
          "name": "Trepar cual arácnido",
          "text": "La araña puede trepar por superficies difíciles e incluso recorrer techos sin tener que realizar pruebas de característica."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 1 de daño perforante más 2 (1d4) de daño de veneno."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "arana_gigante",
      "name": "Araña gigante",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 14,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 26,
        "formula": "4d10 + 4"
      },
      "speed": {
        "walk": "30 pies",
        "climb": "30 pies"
      },
      "abilities": {
        "str": 14,
        "dex": 16,
        "con": 12,
        "int": 2,
        "wis": 11,
        "cha": 4
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 4
        },
        {
          "name": "Sigilo",
          "bonus": 7
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1",
      "xp": 200,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Caminar por telarañas",
          "text": "La araña ignora todas las restricciones de movimiento causadas por las telarañas y conoce la ubicación de cualquier otra criatura que esté en contacto con la misma telaraña."
        },
        {
          "name": "Trepar cual arácnido",
          "text": "La araña puede trepar por superficies difíciles e incluso recorrer techos sin tener que realizar pruebas de característica."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 7 (1d8 + 3) de daño perforante más 7 (2d6) de daño de veneno."
        },
        {
          "name": "Telaraña (Recarga 5-6)",
          "text": "Tirada de salvación de Destreza CD 13, una criatura que la araña pueda ver a 60 pies o menos. Fallo: el objetivo tendrá el estado de apresado hasta que se destruya la telaraña (CA 10, 5 PG, vulnerabilidad al daño de fuego e inmunidad al daño psíquico y de veneno)."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "archelon",
      "name": "Archelon",
      "size": "Enorme",
      "type": "bestia",
      "subtype": "dinosaurio",
      "alignment": "sin alineamiento",
      "ac": 17,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 90,
        "formula": "12d12 + 12"
      },
      "speed": {
        "walk": "20 pies",
        "swim": "80 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 16,
        "con": 13,
        "int": 4,
        "wis": 14,
        "cha": 6
      },
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "senses": [
        "Percepción pasiva 12"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "4",
      "xp": 1100,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Anfibio",
          "text": "El archelon puede respirar tanto dentro como fuera del agua."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El archelon realiza dos ataques de mordisco."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 14 (3d6 + 4) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "avispa_gigante",
      "name": "Avispa gigante",
      "size": "Mediana",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 22,
        "formula": "5d8"
      },
      "speed": {
        "walk": "10 pies",
        "fly": "50 pies"
      },
      "abilities": {
        "str": 10,
        "dex": 14,
        "con": 10,
        "int": 1,
        "wis": 10,
        "cha": 3
      },
      "skills": [],
      "senses": [
        "Percepción pasiva 10"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/2",
      "xp": 100,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Pasar volando",
          "text": "La avispa no provoca ataques de oportunidad cuando vuela para ponerse fuera del alcance de un enemigo."
        }
      ],
      "actions": [
        {
          "name": "Aguijón",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 5 (1d6 + 2) de daño perforante más 5 (2d4) de daño de veneno."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "babuino",
      "name": "Babuino",
      "size": "Pequeña",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 3,
        "formula": "1d6"
      },
      "speed": {
        "walk": "30 pies",
        "climb": "30 pies"
      },
      "abilities": {
        "str": 8,
        "dex": 14,
        "con": 11,
        "int": 4,
        "wis": 12,
        "cha": 6
      },
      "skills": [],
      "senses": [
        "Percepción pasiva 11"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "xp": 10,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Atacar en manada",
          "text": "El babuino tiene ventaja en una tirada de ataque contra una criatura si al menos uno de los aliados del babuino se encuentra a 5 pies o menos de la criatura y no tiene el estado de incapacitado."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +1, alcance 5 pies. Acierto: 1 (1d4 - 1) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "bestia_de_los_mares",
      "name": "Bestia de los mares",
      "size": "Mediana",
      "type": "bestia",
      "alignment": "neutral",
      "ac": "13 + modificador de Sabiduría del explorador",
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": "5 + (5 × nivel de explorador)",
        "formula": "d8 × nivel de explorador + 5"
      },
      "speed": {
        "walk": "5 pies",
        "swim": "60 pies"
      },
      "abilities": {
        "str": 14,
        "dex": 14,
        "con": 15,
        "int": 8,
        "wis": 14,
        "cha": 11
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": -1
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "skills": [],
      "senses": [
        "visión en la oscuridad 90 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "entiende los idiomas que conoces"
      ],
      "cr": "variable",
      "xp": 0,
      "proficiencyBonus": "igual a tu bonificador por competencia",
      "traits": [
        {
          "name": "Anfibia",
          "text": "La bestia puede respirar tanto dentro como fuera del agua."
        },
        {
          "name": "Vínculo primigenio",
          "text": "Suma tu bonificador por competencia a cualquier prueba de característica o tirada de salvación que realice la bestia."
        }
      ],
      "actions": [
        {
          "name": "Golpe de bestia",
          "text": "Tirada de ataque cuerpo a cuerpo: bonificador igual a tu modificador de ataque de conjuros, alcance 5 pies. Acierto: 1d6 + 2 más tu modificador por Sabiduría de daño contundente o perforante (a tu elección cuando invocas a la bestia) y el objetivo tendrá el estado de agarrado (CD para escapar igual a tu CD de salvación de conjuros)."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "bestia_de_tierra_firme",
      "name": "Bestia de tierra firme",
      "size": "Mediana",
      "type": "bestia",
      "alignment": "neutral",
      "ac": "13 + modificador de Sabiduría del explorador",
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": "5 + (5 × nivel de explorador)",
        "formula": "d8 × nivel de explorador + 5"
      },
      "speed": {
        "walk": "40 pies",
        "climb": "40 pies"
      },
      "abilities": {
        "str": 14,
        "dex": 14,
        "con": 15,
        "int": 8,
        "wis": 14,
        "cha": 11
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": -1
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "skills": [],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "entiende los idiomas que conoces"
      ],
      "cr": "variable",
      "xp": 0,
      "proficiencyBonus": "igual a tu bonificador por competencia",
      "traits": [
        {
          "name": "Vínculo primigenio",
          "text": "Suma tu bonificador por competencia a cualquier prueba de característica o tirada de salvación que realice la bestia."
        }
      ],
      "actions": [
        {
          "name": "Golpe de bestia",
          "text": "Tirada de ataque cuerpo a cuerpo: bonificador igual a tu modificador de ataque de conjuros, alcance 5 pies. Acierto: 1d8 + 2 más tu modificador por Sabiduría de daño contundente, cortante o perforante (a tu elección cuando invocas a la bestia). Si la bestia recorrió al menos 20 pies en línea recta hacia el objetivo antes de acertarle, este recibe 1d6 de daño adicional del mismo tipo y, si es una criatura Grande o más pequeña, tendrá el estado de derribada."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "bestia_del_cielo",
      "name": "Bestia del cielo",
      "size": "Pequeña",
      "type": "bestia",
      "alignment": "neutral",
      "ac": "13 + modificador de Sabiduría del explorador",
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": "4 + (4 × nivel de explorador)",
        "formula": "d6 × nivel de explorador + 4"
      },
      "speed": {
        "walk": "10 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 6,
        "dex": 16,
        "con": 13,
        "int": 8,
        "wis": 14,
        "cha": 11
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -2
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": -1
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "skills": [],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "entiende los idiomas que conoces"
      ],
      "cr": "variable",
      "xp": 0,
      "proficiencyBonus": "igual a tu bonificador por competencia",
      "traits": [
        {
          "name": "Pasar volando",
          "text": "La bestia no provoca ataques de oportunidad cuando vuela para ponerse fuera del alcance de un enemigo."
        },
        {
          "name": "Vínculo primigenio",
          "text": "Suma tu bonificador por competencia a cualquier prueba de característica o tirada de salvación que realice la bestia."
        }
      ],
      "actions": [
        {
          "name": "Golpe de bestia",
          "text": "Tirada de ataque cuerpo a cuerpo: bonificador igual a tu modificador de ataque de conjuros, alcance 5 pies. Acierto: 1d4 + 3 más tu modificador por Sabiduría de daño cortante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "buho",
      "name": "Búho",
      "size": "Diminuta",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 11,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 1,
        "formula": "1d4 - 1"
      },
      "speed": {
        "walk": "5 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 3,
        "dex": 13,
        "con": 8,
        "int": 2,
        "wis": 12,
        "cha": 7
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 5
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "senses": [
        "visión en la oscuridad 120 pies",
        "Percepción pasiva 15"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "xp": 10,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Pasar volando",
          "text": "El búho no provoca ataques de oportunidad cuando vuela para ponerse fuera del alcance de un enemigo."
        }
      ],
      "actions": [
        {
          "name": "Garras",
          "text": "Tirada de ataque cuerpo a cuerpo: +3, alcance 5 pies. Acierto: 1 de daño cortante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "buho_gigante",
      "name": "Búho gigante",
      "size": "Grande",
      "type": "celestial",
      "alignment": "neutral",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 19,
        "formula": "3d10 + 3"
      },
      "speed": {
        "walk": "5 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 13,
        "dex": 15,
        "con": 12,
        "int": 10,
        "wis": 14,
        "cha": 10
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 6
        },
        {
          "name": "Sigilo",
          "bonus": 6
        }
      ],
      "damageResistances": [
        "necrótico",
        "radiante"
      ],
      "senses": [
        "visión en la oscuridad 120 pies",
        "Percepción pasiva 16"
      ],
      "languages": [
        "celestial",
        "entiende común, elfo y silvano, pero no puede hablarlos"
      ],
      "cr": "1/4",
      "xp": 50,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Pasar volando",
          "text": "El búho no provoca ataques de oportunidad cuando vuela para ponerse fuera del alcance de un enemigo."
        }
      ],
      "actions": [
        {
          "name": "Garras",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 7 (1d10 + 2) de daño cortante."
        },
        {
          "name": "Lanzamiento de conjuros",
          "text": "El búho lanza uno de los siguientes conjuros, que no requiere componentes y utiliza la Sabiduría como aptitud mágica: A voluntad: detectar el bien y el mal, detectar magia. 1/día: clarividencia."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "buitre",
      "name": "Buitre",
      "size": "Mediana",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 10,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 5,
        "formula": "1d8 + 1"
      },
      "speed": {
        "walk": "10 pies",
        "fly": "50 pies"
      },
      "abilities": {
        "str": 7,
        "dex": 10,
        "con": 13,
        "int": 2,
        "wis": 12,
        "cha": 4
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 3
        }
      ],
      "senses": [
        "Percepción pasiva 13"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "xp": 10,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Atacar en manada",
          "text": "El buitre tiene ventaja en una tirada de ataque contra una criatura si al menos uno de los aliados del buitre se encuentra a 5 pies o menos de la criatura y no tiene el estado de incapacitado."
        }
      ],
      "actions": [
        {
          "name": "Pico",
          "text": "Tirada de ataque cuerpo a cuerpo: +2, alcance 5 pies. Acierto: 2 (1d4) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "buitre_gigante",
      "name": "Buitre gigante",
      "size": "Grande",
      "type": "monstruosidad",
      "alignment": "neutral malvada",
      "ac": 10,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 25,
        "formula": "3d10 + 9"
      },
      "speed": {
        "walk": "10 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 15,
        "dex": 10,
        "con": 16,
        "int": 6,
        "wis": 12,
        "cha": 7
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 3
        }
      ],
      "damageResistances": [
        "necrótico"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 13"
      ],
      "languages": [
        "entiende común, pero no puede hablar"
      ],
      "cr": "1",
      "xp": 200,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Atacar en manada",
          "text": "El buitre tiene ventaja en una tirada de ataque contra una criatura si al menos uno de los aliados del buitre se encuentra a 5 pies o menos de la criatura y no tiene el estado de incapacitado."
        }
      ],
      "actions": [
        {
          "name": "Picotazo",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 9 (2d6 + 2) de daño perforante y el objetivo tendrá el estado de envenenado hasta el final de su siguiente turno."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "caballito_de_mar",
      "name": "Caballito de mar",
      "size": "Diminuta",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 1,
        "formula": "1d4 - 1"
      },
      "speed": {
        "walk": "5 pies",
        "swim": "20 pies"
      },
      "abilities": {
        "str": 1,
        "dex": 12,
        "con": 8,
        "int": 1,
        "wis": 10,
        "cha": 2
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 2
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "senses": [
        "Percepción pasiva 12"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "xp": 0,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Respirar en el agua",
          "text": "El caballito de mar solo puede respirar bajo el agua."
        }
      ],
      "actions": [
        {
          "name": "Carrera burbujeante",
          "text": "Mientras está bajo el agua, el caballito de mar se mueve hasta su velocidad nadando sin provocar ataques de oportunidad."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "caballito_de_mar_gigante",
      "name": "Caballito de mar gigante",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 14,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 16,
        "formula": "3d10"
      },
      "speed": {
        "walk": "5 pies",
        "swim": "40 pies"
      },
      "abilities": {
        "str": 15,
        "dex": 12,
        "con": 11,
        "int": 2,
        "wis": 12,
        "cha": 5
      },
      "skills": [],
      "senses": [
        "Percepción pasiva 11"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/2",
      "xp": 100,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Respirar en el agua",
          "text": "El caballito de mar solo puede respirar bajo el agua."
        }
      ],
      "actions": [
        {
          "name": "Embestir",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 9 (2d6 + 2) de daño contundente, u 11 (2d8 + 2) de daño contundente si el caballito de mar recorre al menos 20 pies en línea recta hacia el objetivo justo antes de acertarle."
        }
      ],
      "bonusActions": [
        {
          "name": "Carrera burbujeante",
          "text": "Mientras está bajo el agua, el caballito de mar se mueve hasta la mitad de su velocidad nadando sin provocar ataques de oportunidad."
        }
      ],
      "reactions": []
    },
    {
      "id": "caballo_de_guerra",
      "name": "Caballo de guerra",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 11,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 19,
        "formula": "3d10 + 3"
      },
      "speed": {
        "walk": "60 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 12,
        "con": 13,
        "int": 2,
        "wis": 12,
        "cha": 7
      },
      "skills": [],
      "senses": [
        "Percepción pasiva 11"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/2",
      "xp": 100,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Cascos",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 9 (2d4 + 4) de daño contundente. Si el objetivo es una criatura Grande o más pequeña y el caballo recorre al menos 20 pies en línea recta hacia ella justo antes de acertarle, esta recibirá 5 (2d4) de daño contundente adicional y tendrá el estado de derribada."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "caballo_de_monta",
      "name": "Caballo de monta",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 11,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 13,
        "formula": "2d10 + 2"
      },
      "speed": {
        "walk": "60 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 13,
        "con": 12,
        "int": 2,
        "wis": 11,
        "cha": 7
      },
      "skills": [],
      "senses": [
        "Percepción pasiva 10"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/4",
      "xp": 50,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Cascos",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 7 (1d8 + 3) de daño contundente."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "caballo_de_tiro",
      "name": "Caballo de tiro",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 10,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 15,
        "formula": "2d10 + 4"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 10,
        "con": 15,
        "int": 2,
        "wis": 11,
        "cha": 7
      },
      "skills": [],
      "senses": [
        "Percepción pasiva 10"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/4",
      "xp": 50,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Cascos",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 6 (1d4 + 4) de daño contundente."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "cabra",
      "name": "Cabra",
      "size": "Mediana",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 10,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 4,
        "formula": "1d8"
      },
      "speed": {
        "walk": "40 pies",
        "climb": "30 pies"
      },
      "abilities": {
        "str": 11,
        "dex": 10,
        "con": 11,
        "int": 2,
        "wis": 10,
        "cha": 5
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 2
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "xp": 10,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Embestir",
          "text": "Tirada de ataque cuerpo a cuerpo: +2, alcance 5 pies. Acierto: 1 de daño contundente o 2 (1d4) de daño contundente si la cabra recorre al menos 20 pies en línea recta hacia el objetivo justo antes de acertarle."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "cabra_gigante",
      "name": "Cabra gigante",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 11,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 19,
        "formula": "3d10 + 3"
      },
      "speed": {
        "walk": "40 pies",
        "climb": "30 pies"
      },
      "abilities": {
        "str": 17,
        "dex": 13,
        "con": 12,
        "int": 3,
        "wis": 12,
        "cha": 6
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 3
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 13"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/2",
      "xp": 100,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Embestir",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 6 (1d6 + 3) de daño contundente. Si el objetivo es una criatura Grande o más pequeña y la cabra recorre al menos 20 pies en línea recta hacia ella justo antes de acertarle, esta recibirá 5 (2d4) de daño contundente adicional y tendrá el estado de derribada."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "camello",
      "name": "Camello",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 10,
      "initiative": {
        "modifier": -1,
        "score": 9
      },
      "hp": {
        "average": 17,
        "formula": "2d10 + 6"
      },
      "speed": {
        "walk": "50 pies"
      },
      "abilities": {
        "str": 15,
        "dex": 8,
        "con": 17,
        "int": 2,
        "wis": 11,
        "cha": 5
      },
      "skills": [],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/8",
      "xp": 25,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 4 (1d4 + 2) de daño contundente."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "cangrejo",
      "name": "Cangrejo",
      "size": "Diminuta",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 11,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 3,
        "formula": "1d4 + 1"
      },
      "speed": {
        "walk": "20 pies",
        "swim": "20 pies"
      },
      "abilities": {
        "str": 6,
        "dex": 11,
        "con": 12,
        "int": 1,
        "wis": 8,
        "cha": 2
      },
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 2
        }
      ],
      "senses": [
        "visión ciega 30 pies",
        "Percepción pasiva 9"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "xp": 10,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Anfibio",
          "text": "El cangrejo puede respirar tanto dentro como fuera del agua."
        }
      ],
      "actions": [
        {
          "name": "Pinza",
          "text": "Tirada de ataque cuerpo a cuerpo: +2, alcance 5 pies. Acierto: 1 de daño contundente."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "cangrejo_gigante",
      "name": "Cangrejo gigante",
      "size": "Mediana",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 15,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 13,
        "formula": "3d8"
      },
      "speed": {
        "walk": "30 pies",
        "swim": "30 pies"
      },
      "abilities": {
        "str": 13,
        "dex": 13,
        "con": 11,
        "int": 1,
        "wis": 9,
        "cha": 3
      },
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 3
        }
      ],
      "senses": [
        "visión ciega 30 pies",
        "Percepción pasiva 9"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/8",
      "xp": 25,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Anfibio",
          "text": "El cangrejo puede respirar tanto dentro como fuera del agua."
        }
      ],
      "actions": [
        {
          "name": "Pinza",
          "text": "Tirada de ataque cuerpo a cuerpo: +3, alcance 5 pies. Acierto: 4 (1d6 + 1) de daño contundente. Si el objetivo es una criatura Mediana o más pequeña, tendrá el estado de agarrada (CD 11 para escapar) por una de las dos pinzas."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "chacal",
      "name": "Chacal",
      "size": "Pequeña",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 3,
        "formula": "1d6"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 8,
        "dex": 15,
        "con": 11,
        "int": 3,
        "wis": 12,
        "cha": 6
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 5
        },
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "senses": [
        "visión en la oscuridad 90 pies",
        "Percepción pasiva 15"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "xp": 10,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +1, alcance 5 pies. Acierto: 1 (1d4 - 1) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "ciempies_gigante",
      "name": "Ciempiés gigante",
      "size": "Pequeña",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 14,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 9,
        "formula": "2d6 + 2"
      },
      "speed": {
        "walk": "30 pies",
        "climb": "30 pies"
      },
      "abilities": {
        "str": 5,
        "dex": 14,
        "con": 12,
        "int": 1,
        "wis": 7,
        "cha": 3
      },
      "skills": [],
      "senses": [
        "visión ciega 30 pies",
        "Percepción pasiva 8"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/4",
      "xp": 50,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 4 (1d4 + 2) de daño perforante y el objetivo tendrá el estado de envenenado hasta el principio del siguiente turno del ciempiés."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "ciervo",
      "name": "Ciervo",
      "size": "Mediana",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 4,
        "formula": "1d8"
      },
      "speed": {
        "walk": "50 pies"
      },
      "abilities": {
        "str": 11,
        "dex": 16,
        "con": 11,
        "int": 2,
        "wis": 14,
        "cha": 5
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 4
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "xp": 10,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Ágil",
          "text": "El ciervo no provoca ataques de oportunidad cuando se mueve para ponerse fuera del alcance de un enemigo."
        }
      ],
      "actions": [
        {
          "name": "Embestir",
          "text": "Tirada de ataque cuerpo a cuerpo: +2, alcance 5 pies. Acierto: 2 (1d4) de daño contundente."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "cocodrilo",
      "name": "Cocodrilo",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 13,
        "formula": "2d10 + 2"
      },
      "speed": {
        "walk": "20 pies",
        "swim": "30 pies"
      },
      "abilities": {
        "str": 15,
        "dex": 10,
        "con": 13,
        "int": 2,
        "wis": 10,
        "cha": 5
      },
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 2
        }
      ],
      "senses": [
        "Percepción pasiva 10"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/2",
      "xp": 100,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Aguantar la respiración",
          "text": "El cocodrilo puede aguantar la respiración durante 1 hora."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 6 (1d8 + 2) de daño perforante. Si el objetivo es una criatura Mediana o más pequeña, tendrá el estado de agarrada (CD 12 para escapar). Mientras esté agarrada, tendrá el estado de apresada."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "cocodrilo_gigante",
      "name": "Cocodrilo gigante",
      "size": "Enorme",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 14,
      "initiative": {
        "modifier": -1,
        "score": 9
      },
      "hp": {
        "average": 85,
        "formula": "9d12 + 27"
      },
      "speed": {
        "walk": "30 pies",
        "swim": "50 pies"
      },
      "abilities": {
        "str": 21,
        "dex": 9,
        "con": 17,
        "int": 2,
        "wis": 10,
        "cha": 7
      },
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "senses": [
        "Percepción pasiva 10"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "5",
      "xp": 1800,
      "proficiencyBonus": 3,
      "traits": [
        {
          "name": "Aguantar la respiración",
          "text": "El cocodrilo puede aguantar la respiración durante 1 hora."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El cocodrilo realiza un ataque de mordisco y uno con su cola."
        },
        {
          "name": "Cola",
          "text": "Tirada de ataque cuerpo a cuerpo: +8, alcance 10 pies. Acierto: 18 (3d8 + 5) de daño contundente. Si el objetivo es una criatura Grande o más pequeña, tendrá el estado de derribada."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +8, alcance 5 pies. Acierto: 21 (3d10 + 5) de daño perforante. Si el objetivo es una criatura Grande o más pequeña, tendrá el estado de agarrada (CD 15 para escapar). Mientras esté agarrada, tendrá el estado de apresada y no podrá ser objetivo de la cola del cocodrilo."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "comadreja",
      "name": "Comadreja",
      "size": "Diminuta",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 1,
        "formula": "1d4 - 1"
      },
      "speed": {
        "walk": "30 pies",
        "climb": "30 pies"
      },
      "abilities": {
        "str": 3,
        "dex": 16,
        "con": 8,
        "int": 2,
        "wis": 12,
        "cha": 3
      },
      "skills": [
        {
          "name": "Acrobacias",
          "bonus": 5
        },
        {
          "name": "Percepción",
          "bonus": 3
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 13"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "xp": 10,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 1 de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "comadreja_gigante",
      "name": "Comadreja gigante",
      "size": "Mediana",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 9,
        "formula": "2d8"
      },
      "speed": {
        "walk": "40 pies",
        "climb": "30 pies"
      },
      "abilities": {
        "str": 11,
        "dex": 17,
        "con": 10,
        "int": 4,
        "wis": 12,
        "cha": 5
      },
      "skills": [
        {
          "name": "Acrobacias",
          "bonus": 5
        },
        {
          "name": "Percepción",
          "bonus": 3
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 13"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/8",
      "xp": 25,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 5 (1d4 + 3) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "corcel_sobrenatural",
      "name": "Corcel sobrenatural",
      "size": "Grande",
      "type": "celestial, feérico o infernal (a elección)",
      "alignment": "neutral",
      "ac": "10 + 1 por cada nivel del conjuro",
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": "5 + (10 × nivel del conjuro)",
        "formula": "d10 × nivel del conjuro + 5"
      },
      "speed": {
        "walk": "60 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 12,
        "con": 14,
        "int": 6,
        "wis": 12,
        "cha": 8
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "skills": [],
      "senses": [
        "Percepción pasiva 11"
      ],
      "languages": [
        "telepatía 5 pies (solo funciona contigo)"
      ],
      "cr": "variable",
      "xp": 0,
      "proficiencyBonus": "igual a tu bonificador por competencia",
      "traits": [
        {
          "name": "Vínculo vital",
          "text": "Cuando recuperas puntos de golpe mediante un conjuro de nivel 1 o superior, el corcel recupera la misma cantidad de puntos de golpe si estás a 5 pies o menos de él."
        }
      ],
      "actions": [
        {
          "name": "Golpetazo sobrenatural",
          "text": "Tirada de ataque cuerpo a cuerpo: bonificador igual a tu modificador de ataque de conjuros, alcance 5 pies. Acierto: 1d8 más el nivel del conjuro de daño radiante (celestial), psíquico (feérico) o necrótico (infernal)."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "specialActions": [
        {
          "name": "Mirada siniestra (solo infernal; recarga tras un descanso largo)",
          "text": "Tirada de salvación de Sabiduría CD igual a tu CD de salvación de conjuros, una criatura a 60 pies o menos que el corcel pueda ver. Fallo: el objetivo tendrá el estado de asustado hasta el final de tu siguiente turno."
        },
        {
          "name": "Paso feérico (solo feérico; recarga tras un descanso largo)",
          "text": "El corcel se teletransporta, junto con su jinete, a un espacio sin ocupar de tu elección a 60 pies o menos del corcel."
        },
        {
          "name": "Toque sanador (solo celestial; recarga tras un descanso largo)",
          "text": "Una criatura a 5 pies o menos del corcel recupera una cantidad de puntos de golpe igual a 2d8 más el nivel del conjuro."
        }
      ]
    },
    {
      "id": "cuervo",
      "name": "Cuervo",
      "size": "Diminuta",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 2,
        "formula": "1d4"
      },
      "speed": {
        "walk": "10 pies",
        "fly": "50 pies"
      },
      "abilities": {
        "str": 2,
        "dex": 14,
        "con": 10,
        "int": 5,
        "wis": 13,
        "cha": 6
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 3
        }
      ],
      "senses": [
        "Percepción pasiva 13"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "xp": 10,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Imitación",
          "text": "El cuervo puede imitar sonidos sencillos que haya escuchado, como un susurro o un trino. Alguien que lo escuche podrá darse cuenta de que son imitaciones si supera una prueba de Sabiduría (Perspicacia) con CD 10."
        }
      ],
      "actions": [
        {
          "name": "Pico",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 1 de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "defensor_de_acero",
      "name": "Defensor de acero",
      "size": "Mediana",
      "type": "constructo",
      "alignment": "neutral",
      "ac": "12 + tu modificador de Inteligencia",
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": "5 + (5 × nivel de artificiero)",
        "formula": "d8 × nivel de artificiero + modificador de Constitución por dado"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 14,
        "dex": 12,
        "con": 14,
        "int": 4,
        "wis": 10,
        "cha": 6
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 2
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": -3
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "skills": [],
      "damageResistances": [],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "hechizado",
        "cansancio",
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "entiende los idiomas que conoces"
      ],
      "cr": "variable",
      "xp": 0,
      "proficiencyBonus": "igual a tu bonificador por competencia",
      "traits": [
        {
          "name": "Vínculo de acero",
          "text": "Añade tu bonificador por competencia a cualquier prueba de característica o tirada de salvación que haga el defensor."
        }
      ],
      "actions": [
        {
          "name": "Desgarro potenciado por fuerza",
          "text": "Tirada de ataque cuerpo a cuerpo: bonificador igual a tu modificador de ataque de conjuros, alcance 5 pies. Acierto: 1d8 + 2 más tu modificador de Inteligencia de daño de fuerza."
        },
        {
          "name": "Reparar (3/día)",
          "text": "El defensor, o un constructo u objeto que pueda ver a 5 pies o menos de él, recupera una cantidad de puntos de golpe igual a 2d8 más tu modificador de Inteligencia."
        }
      ],
      "bonusActions": [],
      "reactions": [
        {
          "name": "Desviar ataque",
          "text": "Detonante: una criatura que el defensor puede ver a 5 pies o menos de él realiza una tirada de ataque contra una criatura distinta al defensor. Respuesta: la criatura que realiza el ataque lo hace con desventaja."
        }
      ]
    },
    {
      "id": "diablillo",
      "name": "Diablillo",
      "size": "Diminuto",
      "type": "infernal (diablo)",
      "alignment": "legal malvado",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 21,
        "formula": "6d4 + 6"
      },
      "speed": {
        "walk": "20 pies",
        "fly": "40 pies"
      },
      "abilities": {
        "str": 6,
        "dex": 17,
        "con": 13,
        "int": 11,
        "wis": 12,
        "cha": 14
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -2
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "skills": [
        {
          "name": "Engaño",
          "bonus": 4
        },
        {
          "name": "Perspicacia",
          "bonus": 3
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "damageResistances": [
        "frío"
      ],
      "damageImmunities": [
        "fuego",
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 120 pies (no afectada por la oscuridad mágica)",
        "Percepción pasiva 11"
      ],
      "languages": [
        "común",
        "infernal"
      ],
      "cr": "1",
      "xp": 200,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Resistencia mágica",
          "text": "El diablillo tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Aguijón",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 6 (1d6 + 3) de daño perforante más 7 (2d6) de daño de veneno."
        },
        {
          "name": "Cambio de forma",
          "text": "El diablillo cambia de forma para parecerse a una araña (velocidad de trepar 20 pies), un cuervo (vuelo 60 pies) o una rata (velocidad 20 pies), o recupera su auténtica forma. Su perfil es el mismo en todas las formas, excepto por su velocidad. Cualquier equipo que vista o lleve no se transformará."
        },
        {
          "name": "Invisibilidad",
          "text": "El diablillo lanza invisibilidad sobre sí mismo sin necesidad de componentes y utiliza el Carisma como aptitud mágica."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "duende",
      "name": "Duende",
      "size": "Diminuto",
      "type": "feérico",
      "alignment": "neutral bueno",
      "ac": 15,
      "initiative": {
        "modifier": 4,
        "score": 14
      },
      "hp": {
        "average": 10,
        "formula": "4d4"
      },
      "speed": {
        "walk": "10 pies",
        "fly": "40 pies"
      },
      "abilities": {
        "str": 3,
        "dex": 18,
        "con": 10,
        "int": 14,
        "wis": 13,
        "cha": 11
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -4
        },
        {
          "ability": "dex",
          "bonus": 4
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": 2
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 3
        },
        {
          "name": "Sigilo",
          "bonus": 8
        }
      ],
      "damageResistances": [],
      "damageImmunities": [],
      "conditionImmunities": [],
      "senses": [
        "Percepción pasiva 13"
      ],
      "languages": [
        "común",
        "élfico",
        "silvano"
      ],
      "cr": "1/4",
      "xp": 50,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Espada aguja",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 6 (1d4 + 4) de daño perforante."
        },
        {
          "name": "Arco encantador",
          "text": "Tirada de ataque a distancia: +6, alcance 40/160 pies. Acierto: 1 de daño perforante y el objetivo tendrá el estado de hechizado hasta el principio del siguiente turno del duende."
        },
        {
          "name": "Invisibilidad",
          "text": "El duende lanza invisibilidad sobre sí mismo sin necesidad de componentes y utiliza el Carisma como aptitud mágica."
        },
        {
          "name": "Visión del corazón",
          "text": "Tirada de salvación de Carisma: CD 10, una criatura que el duende pueda ver a 5 pies o menos (los celestiales, infernales y muertos vivientes fallan automáticamente la tirada). Fallo: el duende descubre las emociones y el alineamiento del objetivo."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "elefante",
      "name": "Elefante",
      "size": "Enorme",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": -1,
        "score": 9
      },
      "hp": {
        "average": 76,
        "formula": "8d12 + 24"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 22,
        "dex": 9,
        "con": 17,
        "int": 3,
        "wis": 11,
        "cha": 6
      },
      "skills": [],
      "senses": [
        "Percepción pasiva 10"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "4",
      "xp": 1100,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El elefante realiza dos ataques con sus colmillos."
        },
        {
          "name": "Colmillos",
          "text": "Tirada de ataque cuerpo a cuerpo: +8, alcance 5 pies. Acierto: 15 (2d8 + 6) de daño perforante. Si el objetivo es una criatura Enorme o más pequeña y el elefante recorre al menos 20 pies en línea recta hacia ella justo antes de acertarle, tendrá el estado de derribada."
        }
      ],
      "bonusActions": [
        {
          "name": "Arrollar",
          "text": "Tirada de salvación de Destreza: CD 16, una criatura a 5 pies o menos que tenga el estado de derribada. Fallo: 17 (2d10 + 6) de daño contundente. Éxito: la mitad del daño."
        }
      ],
      "reactions": []
    },
    {
      "id": "enjambre_de_cuervos",
      "name": "Enjambre de cuervos",
      "size": "Mediana",
      "type": "enjambre de bestias",
      "subtype": "diminutas",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 11,
        "formula": "2d8 + 2"
      },
      "speed": {
        "walk": "10 pies",
        "fly": "50 pies"
      },
      "abilities": {
        "str": 6,
        "dex": 14,
        "con": 12,
        "int": 5,
        "wis": 12,
        "cha": 6
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 5
        }
      ],
      "damageResistances": [
        "contundente",
        "cortante",
        "perforante"
      ],
      "conditionImmunities": [
        "agarrado",
        "apresado",
        "asustado",
        "aturdido",
        "derribado",
        "hechizado",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "Percepción pasiva 15"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/4",
      "xp": 50,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Enjambre",
          "text": "El enjambre puede ocupar el espacio de otra criatura y viceversa, y es capaz de atravesar cualquier abertura por la que quepa un cuervo Diminuto. El enjambre no puede recuperar puntos de golpe ni obtener puntos de golpe temporales."
        }
      ],
      "actions": [
        {
          "name": "Picos",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 5 (1d6 + 2) de daño perforante o 2 (1d4) de daño perforante si el enjambre está maltrecho."
        },
        {
          "name": "Cacofonía (recarga 6)",
          "text": "Tirada de salvación de Sabiduría: CD 10, una criatura en el espacio del enjambre. Fallo: el objetivo tendrá el estado de ensordecido hasta el principio del siguiente turno del enjambre. Mientras esté ensordecido, el objetivo también tendrá desventaja en las pruebas de característica y las tiradas de ataque."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "enjambre_de_insectos",
      "name": "Enjambre de insectos",
      "size": "Mediana",
      "type": "enjambre de bestias",
      "subtype": "diminutas",
      "alignment": "sin alineamiento",
      "ac": 11,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 19,
        "formula": "3d8 + 6"
      },
      "speed": {
        "walk": "20 pies",
        "climb": "20 pies",
        "fly": "20 pies"
      },
      "abilities": {
        "str": 3,
        "dex": 13,
        "con": 14,
        "int": 1,
        "wis": 7,
        "cha": 1
      },
      "skills": [],
      "damageResistances": [
        "contundente",
        "cortante",
        "perforante"
      ],
      "conditionImmunities": [
        "agarrado",
        "apresado",
        "asustado",
        "aturdido",
        "derribado",
        "hechizado",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión ciega 30 pies",
        "Percepción pasiva 8"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/2",
      "xp": 100,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Enjambre",
          "text": "El enjambre puede ocupar el espacio de otra criatura y viceversa, y es capaz de atravesar cualquier abertura por la que quepa un insecto Diminuto. El enjambre no puede recuperar puntos de golpe ni obtener puntos de golpe temporales."
        },
        {
          "name": "Trepar cual arácnido",
          "text": "Si el enjambre tiene una velocidad trepando, podrá trepar por superficies difíciles e incluso recorrer techos sin tener que realizar pruebas de característica."
        }
      ],
      "actions": [
        {
          "name": "Mordiscos",
          "text": "Tirada de ataque cuerpo a cuerpo: +3, alcance 5 pies. Acierto: 6 (2d4 + 1) de daño de veneno o 3 (1d4 + 1) de daño de veneno si el enjambre está maltrecho."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "enjambre_de_murcielagos",
      "name": "Enjambre de murciélagos",
      "size": "Grande",
      "type": "enjambre de bestias",
      "subtype": "diminutas",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 11,
        "formula": "2d10"
      },
      "speed": {
        "walk": "5 pies",
        "fly": "30 pies"
      },
      "abilities": {
        "str": 5,
        "dex": 15,
        "con": 10,
        "int": 2,
        "wis": 12,
        "cha": 4
      },
      "skills": [],
      "damageResistances": [
        "contundente",
        "cortante",
        "perforante"
      ],
      "conditionImmunities": [
        "agarrado",
        "apresado",
        "asustado",
        "aturdido",
        "derribado",
        "hechizado",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión ciega 60 pies",
        "Percepción pasiva 11"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/4",
      "xp": 50,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Enjambre",
          "text": "El enjambre puede ocupar el espacio de otra criatura y viceversa, y es capaz de atravesar cualquier abertura por la que quepa un murciélago Diminuto. El enjambre no puede recuperar puntos de golpe ni obtener puntos de golpe temporales."
        }
      ],
      "actions": [
        {
          "name": "Mordiscos",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 5 (2d4) de daño perforante o 2 (1d4) de daño perforante si el enjambre está maltrecho."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "enjambre_de_piranas",
      "name": "Enjambre de pirañas",
      "size": "Mediana",
      "type": "enjambre de bestias",
      "subtype": "diminutas",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 28,
        "formula": "8d8 - 8"
      },
      "speed": {
        "walk": "5 pies",
        "swim": "40 pies"
      },
      "abilities": {
        "str": 13,
        "dex": 16,
        "con": 9,
        "int": 1,
        "wis": 7,
        "cha": 2
      },
      "skills": [],
      "damageResistances": [
        "contundente",
        "cortante",
        "perforante"
      ],
      "conditionImmunities": [
        "agarrado",
        "apresado",
        "asustado",
        "aturdido",
        "derribado",
        "hechizado",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 8"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1",
      "xp": 200,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Enjambre",
          "text": "El enjambre puede ocupar el espacio de otra criatura y viceversa, y es capaz de atravesar cualquier abertura por la que quepa una piraña Diminuta. El enjambre no puede recuperar puntos de golpe ni obtener puntos de golpe temporales."
        },
        {
          "name": "Respirar en el agua",
          "text": "El enjambre solo puede respirar bajo el agua."
        }
      ],
      "actions": [
        {
          "name": "Mordiscos",
          "text": "Tirada de ataque cuerpo a cuerpo: +5 (con ventaja si el objetivo no tiene todos sus puntos de golpe), alcance 5 pies. Acierto: 8 (2d4 + 3) de daño perforante o 5 (1d4 + 3) de daño perforante si el enjambre está maltrecho."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "enjambre_de_ratas",
      "name": "Enjambre de ratas",
      "size": "Mediana",
      "type": "enjambre de bestias",
      "subtype": "diminutas",
      "alignment": "sin alineamiento",
      "ac": 10,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 14,
        "formula": "4d8 - 4"
      },
      "speed": {
        "walk": "30 pies",
        "climb": "30 pies"
      },
      "abilities": {
        "str": 9,
        "dex": 11,
        "con": 9,
        "int": 2,
        "wis": 10,
        "cha": 3
      },
      "skills": [],
      "damageResistances": [
        "contundente",
        "cortante",
        "perforante"
      ],
      "conditionImmunities": [
        "agarrado",
        "apresado",
        "asustado",
        "aturdido",
        "derribado",
        "hechizado",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión en la oscuridad 30 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/4",
      "xp": 50,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Enjambre",
          "text": "El enjambre puede ocupar el espacio de otra criatura y viceversa, y es capaz de atravesar cualquier abertura por la que quepa una rata Diminuta. El enjambre no puede recuperar puntos de golpe ni obtener puntos de golpe temporales."
        }
      ],
      "actions": [
        {
          "name": "Mordiscos",
          "text": "Tirada de ataque cuerpo a cuerpo: +2, alcance 5 pies. Acierto: 5 (2d4) de daño perforante o 2 (1d4) de daño perforante si el enjambre está maltrecho."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "enjambre_de_serpientes_venenosas",
      "name": "Enjambre de serpientes venenosas",
      "size": "Mediana",
      "type": "enjambre de bestias",
      "subtype": "diminutas",
      "alignment": "sin alineamiento",
      "ac": 14,
      "initiative": {
        "modifier": 4,
        "score": 14
      },
      "hp": {
        "average": 36,
        "formula": "8d8"
      },
      "speed": {
        "walk": "30 pies",
        "swim": "30 pies"
      },
      "abilities": {
        "str": 8,
        "dex": 18,
        "con": 11,
        "int": 1,
        "wis": 10,
        "cha": 3
      },
      "skills": [],
      "damageResistances": [
        "contundente",
        "cortante",
        "perforante"
      ],
      "conditionImmunities": [
        "agarrado",
        "apresado",
        "asustado",
        "aturdido",
        "derribado",
        "hechizado",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión ciega 10 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "2",
      "xp": 450,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Enjambre",
          "text": "El enjambre puede ocupar el espacio de otra criatura y viceversa, y es capaz de atravesar cualquier abertura por la que quepa una serpiente Diminuta. El enjambre no puede recuperar puntos de golpe ni obtener puntos de golpe temporales."
        }
      ],
      "actions": [
        {
          "name": "Mordiscos",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 8 (1d8 + 4) de daño perforante o 6 (1d4 + 4) de daño perforante si el enjambre está maltrecho, más 10 (3d6) de daño de veneno."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "escarabajo_de_fuego_gigante",
      "name": "Escarabajo de fuego gigante",
      "size": "Pequeña",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 4,
        "formula": "1d6 + 1"
      },
      "speed": {
        "walk": "30 pies",
        "climb": "30 pies"
      },
      "abilities": {
        "str": 8,
        "dex": 10,
        "con": 12,
        "int": 1,
        "wis": 7,
        "cha": 3
      },
      "skills": [],
      "damageResistances": [
        "fuego"
      ],
      "senses": [
        "visión ciega 30 pies",
        "Percepción pasiva 8"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "xp": 10,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Iluminación",
          "text": "El escarabajo emite luz brillante en un radio de 10 pies y luz tenue 10 pies más allá."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +1, alcance 5 pies. Acierto: 1 de daño de fuego."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "escorpion",
      "name": "Escorpión",
      "size": "Diminuta",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 11,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 1,
        "formula": "1d4 - 1"
      },
      "speed": {
        "walk": "10 pies"
      },
      "abilities": {
        "str": 2,
        "dex": 11,
        "con": 8,
        "int": 1,
        "wis": 8,
        "cha": 2
      },
      "skills": [],
      "senses": [
        "visión ciega 10 pies",
        "Percepción pasiva 9"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "xp": 10,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Aguijón",
          "text": "Tirada de ataque cuerpo a cuerpo: +2, alcance 5 pies. Acierto: 1 de daño perforante más 3 (1d6) de daño de veneno."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "escorpion_gigante",
      "name": "Escorpión gigante",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 15,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 52,
        "formula": "7d10 + 14"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 13,
        "con": 15,
        "int": 1,
        "wis": 9,
        "cha": 3
      },
      "skills": [],
      "senses": [
        "visión ciega 60 pies",
        "Percepción pasiva 9"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "3",
      "xp": 700,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El escorpión realiza dos ataques con sus pinzas y uno con su aguijón."
        },
        {
          "name": "Aguijón",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 7 (1d8 + 3) de daño perforante más 11 (2d10) de daño de veneno."
        },
        {
          "name": "Pinza",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 6 (1d6 + 3) de daño contundente. Si el objetivo es una criatura Grande o más pequeña, tendrá el estado de agarrada (CD 13 para escapar) por una de las dos pinzas."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "espiritu_aberrante",
      "name": "Espíritu aberrante",
      "size": "Mediana",
      "type": "aberración",
      "alignment": "neutral",
      "ac": "11 + el nivel del conjuro",
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": "40 + (10 × (nivel del conjuro - 4))",
        "formula": "base 40, +10 por nivel por encima de 4"
      },
      "speed": {
        "walk": "30 pies",
        "fly": "30 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 10,
        "con": 15,
        "int": 16,
        "wis": 10,
        "cha": 6
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": 3
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "skills": [],
      "damageImmunities": [
        "psíquico"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "habla profundo",
        "entiende los idiomas que conozcas"
      ],
      "cr": "variable",
      "xp": 0,
      "proficiencyBonus": "igual a tu bonificador por competencia",
      "traits": [
        {
          "name": "Aura susurrante (solo azotamentes)",
          "text": "Al comienzo de todos los turnos del espíritu, este emite energía psiónica si no tiene el estado de incapacitado. Tirada de salvación de Sabiduría CD igual a tu CD de salvación de conjuros, todas las criaturas (excepto tú) a 5 pies o menos del espíritu. Fallo: 2d6 de daño psíquico."
        },
        {
          "name": "Regeneración (solo slaad)",
          "text": "El espíritu recupera 5 puntos de golpe al principio de su turno si tiene al menos 1 punto de golpe."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El espíritu realiza una cantidad de ataques igual a la mitad del nivel de este conjuro (redondeado hacia abajo)."
        },
        {
          "name": "Garra (solo slaad)",
          "text": "Tirada de ataque cuerpo a cuerpo: bonificador igual a tu modificador de ataque de conjuros, alcance 5 pies. Acierto: 1d10 + 3 más el nivel del conjuro de daño cortante y el objetivo no podrá recuperar puntos de golpe hasta el principio del siguiente turno del espíritu."
        },
        {
          "name": "Golpe psíquico (solo azotamentes)",
          "text": "Tirada de ataque cuerpo a cuerpo: bonificador igual a tu modificador de ataque de conjuros, alcance 5 pies. Acierto: 1d8 + 3 más el nivel del conjuro de daño psíquico."
        },
        {
          "name": "Rayo ocular (solo contemplador)",
          "text": "Tirada de ataque a distancia: bonificador igual a tu modificador de ataque de conjuros, alcance 150 pies. Acierto: 1d8 + 3 más el nivel del conjuro de daño psíquico."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "espiritu_automata",
      "name": "Espíritu autómata",
      "size": "Mediana",
      "type": "constructo",
      "alignment": "neutral",
      "ac": "13 + el nivel del conjuro",
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": "40 + (15 × (nivel del conjuro - 4))",
        "formula": "base 40, +15 por nivel por encima de 4"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 10,
        "con": 18,
        "int": 14,
        "wis": 11,
        "cha": 5
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": 2
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -3
        }
      ],
      "skills": [],
      "damageResistances": [
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "cansancio",
        "envenenado",
        "hechizado",
        "paralizado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "entiende los idiomas que conoces"
      ],
      "cr": "variable",
      "xp": 0,
      "proficiencyBonus": "igual a tu bonificador por competencia",
      "traits": [
        {
          "name": "Cuerpo abrasador (solo metal)",
          "text": "Una criatura que acierta al espíritu con un ataque cuerpo a cuerpo o empieza su turno en un agarre con el espíritu sufre 1d10 de daño de fuego."
        },
        {
          "name": "Letargo pétreo (solo piedra)",
          "text": "Cuando una criatura empieza su turno a 10 pies o menos del espíritu, este puede hacerla objetivo con energía mágica si puede verla. Tirada de salvación de Sabiduría CD igual a tu CD de salvación de conjuros. Fallo: hasta el principio de su siguiente turno, el objetivo no puede realizar ataques de oportunidad y su velocidad se reduce a la mitad."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El espíritu realiza una cantidad de ataques con su golpe igual a la mitad del nivel de este conjuro (redondeado hacia abajo)."
        },
        {
          "name": "Golpe",
          "text": "Tirada de ataque cuerpo a cuerpo: bonificador igual a tu modificador de ataque de conjuros, alcance 5 pies. Acierto: 1d8 + 4 más el nivel del conjuro de daño contundente."
        }
      ],
      "bonusActions": [],
      "reactions": [
        {
          "name": "Azote berserk (solo arcilla)",
          "text": "Detonante: el espíritu recibe daño de una criatura. Respuesta: el espíritu realiza un ataque con su golpe contra esa criatura si es posible o se mueve hasta la mitad de su velocidad hacia esa criatura sin provocar ataques de oportunidad."
        }
      ]
    },
    {
      "id": "espiritu_bestial",
      "name": "Espíritu bestial",
      "size": "Pequeña",
      "type": "bestia",
      "alignment": "neutral",
      "ac": "11 + el nivel del conjuro",
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": "20 (solo aire) o 30 (solo mar y tierra) + (5 × nivel del conjuro)",
        "formula": "base 20/30 +5 por nivel"
      },
      "speed": {
        "walk": "30 pies",
        "swim": "30 pies",
        "climb": "30 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 11,
        "con": 16,
        "int": 4,
        "wis": 14,
        "cha": 5
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": -3
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": -3
        }
      ],
      "skills": [],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "entiende los idiomas que conoces"
      ],
      "cr": "variable",
      "xp": 0,
      "proficiencyBonus": "igual a tu bonificador por competencia",
      "traits": [
        {
          "name": "Atacar en manada (solo mar y tierra)",
          "text": "El espíritu tiene ventaja en una tirada de ataque contra una criatura si al menos uno de los aliados del espíritu se encuentra a 5 pies o menos de la criatura y no tiene el estado de incapacitado."
        },
        {
          "name": "Pasar volando (solo aire)",
          "text": "El espíritu no provoca ataques de oportunidad cuando vuela para ponerse fuera del alcance de un enemigo."
        },
        {
          "name": "Respirar en el agua (solo mar)",
          "text": "El espíritu solo puede respirar bajo el agua."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El espíritu realiza una cantidad de ataques de desgarro igual a la mitad del nivel de este conjuro (redondeado hacia abajo)."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: bonificador igual a tu modificador de ataque de conjuros, alcance 5 pies. Acierto: 1d8 + 4 más el nivel del conjuro de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "espiritu_celestial",
      "name": "Espíritu celestial",
      "size": "Grande",
      "type": "celestial",
      "alignment": "neutral",
      "ac": "11 + el nivel del conjuro + 2 (solo defensor)",
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": "40 + (10 × (nivel del conjuro - 5))",
        "formula": "base 40, +10 por nivel por encima de 5"
      },
      "speed": {
        "walk": "30 pies",
        "fly": "40 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 14,
        "con": 16,
        "int": 10,
        "wis": 14,
        "cha": 16
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 3
        }
      ],
      "skills": [],
      "damageResistances": [
        "radiante"
      ],
      "conditionImmunities": [
        "asustado",
        "hechizado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "celestial",
        "entiende los idiomas que conoces"
      ],
      "cr": "variable",
      "xp": 0,
      "proficiencyBonus": "igual a tu bonificador por competencia",
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El espíritu realiza una cantidad de ataques igual a la mitad del nivel de este conjuro (redondeado hacia abajo)."
        },
        {
          "name": "Maza radiante (solo defensor)",
          "text": "Tirada de ataque cuerpo a cuerpo: bonificador igual a tu modificador de ataque de conjuros, alcance 5 pies. Acierto: 1d10 + 3 más el nivel del conjuro de daño radiante, y el espíritu puede elegirse a sí mismo o a otra criatura que pueda ver a 10 pies o menos del objetivo. La criatura elegida gana 1d10 puntos de golpe temporales."
        },
        {
          "name": "Arco radiante (solo vengador)",
          "text": "Tirada de ataque a distancia: bonificador igual a tu modificador de ataque de conjuros, alcance 60 pies. Acierto: 2d6 + 2 más el nivel del conjuro de daño radiante."
        },
        {
          "name": "Toque sanador (1/día)",
          "text": "El espíritu toca a otra criatura. El objetivo recupera una cantidad de puntos de golpe igual a 2d8 más el nivel del conjuro."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "espiritu_draconico",
      "name": "Espíritu dracónico",
      "size": "Grande",
      "type": "dragón",
      "alignment": "neutral",
      "ac": "14 + el nivel del conjuro",
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": "50 + (10 × (nivel del conjuro - 5))",
        "formula": "base 50, +10 por nivel por encima de 5"
      },
      "speed": {
        "walk": "30 pies",
        "swim": "30 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 14,
        "con": 17,
        "int": 10,
        "wis": 14,
        "cha": 14
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": 2
        }
      ],
      "skills": [],
      "damageResistances": [
        "ácido",
        "frío",
        "fuego",
        "relámpago",
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "envenenado",
        "hechizado"
      ],
      "senses": [
        "visión ciega 30 pies",
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "dracónico",
        "entiende los idiomas que conoces"
      ],
      "cr": "variable",
      "xp": 0,
      "proficiencyBonus": "igual a tu bonificador por competencia",
      "traits": [
        {
          "name": "Resistencias compartidas",
          "text": "Cuando invocas al espíritu, eliges una de sus resistencias. Tienes resistencia a ese tipo de daño elegido hasta que el conjuro termine."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El espíritu realiza una cantidad de ataques de desgarro igual a la mitad del nivel del conjuro (redondeado hacia abajo) o utiliza su ataque de aliento."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: bonificador igual a tu modificador de ataque de conjuros, alcance 10 pies. Acierto: 1d6 + 4 más el nivel del conjuro de daño perforante."
        },
        {
          "name": "Aliento",
          "text": "Tirada de salvación de Destreza: CD igual a tu CD de salvación de conjuros, todas las criaturas en un cono de 30 pies. Fallo: 2d6 de daño de un tipo al que este espíritu tenga resistencia (a tu elección cuando lanzas el conjuro). Éxito: la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "espiritu_elemental",
      "name": "Espíritu elemental",
      "size": "Mediana",
      "type": "elemental",
      "alignment": "neutral",
      "ac": "11 + el nivel del conjuro",
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": "50 + (10 × (nivel del conjuro - 4))",
        "formula": "base 50, +10 por nivel por encima de 4"
      },
      "speed": {
        "walk": "40 pies",
        "burrow": "40 pies",
        "swim": "40 pies",
        "fly": "40 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 15,
        "con": 17,
        "int": 4,
        "wis": 10,
        "cha": 16
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": -3
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 3
        }
      ],
      "skills": [],
      "damageResistances": [
        "ácido (solo agua)",
        "cortante (solo tierra)",
        "perforante (solo tierra)",
        "relámpago (solo aire)",
        "trueno (solo aire)"
      ],
      "damageImmunities": [
        "fuego (solo fuego)",
        "veneno"
      ],
      "conditionImmunities": [
        "cansancio",
        "envenenado",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "primordial",
        "entiende los idiomas que conoces"
      ],
      "cr": "variable",
      "xp": 0,
      "proficiencyBonus": "igual a tu bonificador por competencia",
      "traits": [
        {
          "name": "Forma amorfa (solo agua, aire y fuego)",
          "text": "El espíritu puede moverse a través de un espacio de solo 1 pulgada de ancho sin que cuente como terreno difícil."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El espíritu realiza una cantidad de ataques con su golpe igual a la mitad del nivel de este conjuro (redondeado hacia abajo)."
        },
        {
          "name": "Golpe",
          "text": "Tirada de ataque cuerpo a cuerpo: bonificador igual a tu modificador de ataque de conjuros, alcance 5 pies. Acierto: 1d10 + 4 más el nivel del conjuro de daño contundente (solo tierra), de frío (solo agua), de fuego (solo fuego) o de relámpago (solo aire)."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "espiritu_feerico",
      "name": "Espíritu feérico",
      "size": "Pequeña",
      "type": "feérico",
      "alignment": "neutral",
      "ac": "12 + el nivel del conjuro",
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": "30 + (10 × (nivel del conjuro - 3))",
        "formula": "base 30, +10 por nivel por encima de 3"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 13,
        "dex": 16,
        "con": 14,
        "int": 14,
        "wis": 11,
        "cha": 16
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 1
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": 2
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 3
        }
      ],
      "skills": [],
      "damageResistances": [],
      "damageImmunities": [],
      "conditionImmunities": [
        "hechizado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "silvano",
        "entiende los idiomas que conoces"
      ],
      "cr": "variable",
      "xp": 0,
      "proficiencyBonus": "igual a tu bonificador por competencia",
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El espíritu realiza una cantidad de ataques con su filo feérico igual a la mitad del nivel de este conjuro (redondeado hacia abajo)."
        },
        {
          "name": "Filo feérico",
          "text": "Tirada de ataque cuerpo a cuerpo: bonificador igual a tu modificador de ataque de conjuros, alcance 5 pies. Acierto: 2d6 + 3 más el nivel del conjuro de daño de fuerza."
        }
      ],
      "bonusActions": [
        {
          "name": "Paso feérico",
          "text": "El espíritu se teletransporta mágicamente hasta 30 pies a un espacio sin ocupar que pueda ver. A continuación, se produce uno de los siguientes efectos, en función del ánimo elegido para el espíritu:\n\nAlegre: Tirada de salvación de Sabiduría: CD igual a tu CD de salvación de conjuros, una criatura que el espíritu pueda ver a 10 pies o menos de sí. Fallo: el objetivo queda hechizado por ti y el espíritu durante 1 minuto o hasta que sufra algún tipo de daño.\n\nBurlón: El espíritu llena de oscuridad mágica un cubo de 10 pies de lado a 5 pies o menos de él, que durará hasta el final de su siguiente turno.\n\nEnfurecido: El espíritu tiene ventaja en la siguiente tirada de ataque que realice antes del final de este turno."
        }
      ],
      "reactions": []
    },
    {
      "id": "espiritu_infernal",
      "name": "Espíritu infernal",
      "size": "Grande",
      "type": "infernal",
      "alignment": "neutral",
      "ac": "12 + el nivel del conjuro",
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": "50 (demonio) / 40 (diablo) / 60 (yugoloth) + (15 × (nivel del conjuro - 6))",
        "formula": "base según tipo, +15 por nivel por encima de 6"
      },
      "speed": {
        "walk": "40 pies",
        "climb": "40 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 13,
        "dex": 16,
        "con": 15,
        "int": 10,
        "wis": 10,
        "cha": 16
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 1
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 3
        }
      ],
      "skills": [],
      "damageResistances": [
        "fuego"
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "abisal",
        "infernal",
        "telepatía 60 pies"
      ],
      "cr": "variable",
      "xp": 0,
      "proficiencyBonus": "igual a tu bonificador por competencia",
      "traits": [
        {
          "name": "Resistencia mágica",
          "text": "El espíritu tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        },
        {
          "name": "Últimos estertores (solo demonio)",
          "text": "Cuando los puntos de golpe del espíritu se reducen a 0 o el conjuro termine, el espíritu explotará. Tirada de salvación de Destreza: CD igual a tu CD de salvación de conjuros, todas las criaturas en un radio de 10 pies desde el espíritu. Fallo: 2d10 más el nivel de este conjuro de daño de fuego. Éxito: la mitad del daño."
        },
        {
          "name": "Vista del diablo (solo diablo)",
          "text": "La oscuridad mágica no dificulta la visión en la oscuridad del espíritu."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El espíritu realiza una cantidad de ataques igual a la mitad del nivel de este conjuro (redondeado hacia abajo)."
        },
        {
          "name": "Garras (solo yugoloth)",
          "text": "Tirada de ataque cuerpo a cuerpo: bonificador igual a tu modificador de ataque de conjuros, alcance 5 pies. Acierto: 1d8 + 3 más el nivel del conjuro de daño cortante. Inmediatamente después de que el ataque acierte o falle, el espíritu puede teletransportarse hasta 30 pies a un espacio sin ocupar que pueda ver."
        },
        {
          "name": "Mordisco (solo demonio)",
          "text": "Tirada de ataque cuerpo a cuerpo: bonificador igual a tu modificador de ataque de conjuros, alcance 5 pies. Acierto: 1d12 + 3 más el nivel del conjuro de daño necrótico."
        },
        {
          "name": "Golpe ardiente (solo diablo)",
          "text": "Tirada de ataque cuerpo a cuerpo o a distancia: bonificador igual a tu modificador de ataque de conjuros, alcance 5 pies o 150 pies a distancia. Acierto: 2d6 + 3 más el nivel del conjuro de daño de fuego."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "espiritu_muerto_viviente",
      "name": "Espíritu muerto viviente",
      "size": "Mediana",
      "type": "muerto viviente",
      "alignment": "neutral",
      "ac": "11 + el nivel del conjuro",
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": "30 (fantasmal o pútrido) / 20 (esquelético) + (10 × (nivel del conjuro - 3))",
        "formula": "base según tipo, +10 por nivel por encima de 3"
      },
      "speed": {
        "walk": "30 pies",
        "fly": "40 pies"
      },
      "abilities": {
        "str": 12,
        "dex": 16,
        "con": 15,
        "int": 4,
        "wis": 10,
        "cha": 9
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 1
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": -3
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -1
        }
      ],
      "skills": [],
      "damageResistances": [],
      "damageImmunities": [
        "necrótico",
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "cansancio",
        "envenenado",
        "paralizado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "entiende los idiomas que conoces"
      ],
      "cr": "variable",
      "xp": 0,
      "proficiencyBonus": "igual a tu bonificador por competencia",
      "traits": [
        {
          "name": "Aura purulenta (solo pútrido)",
          "text": "Tirada de salvación de Constitución: CD igual a tu CD de salvación de conjuros, cualquier criatura (excepto tú) que empiece su turno en un radio de 5 pies desde el espíritu. Fallo: la criatura tiene el estado de envenenado hasta el principio de su siguiente turno."
        },
        {
          "name": "Pasaje incorpóreo (solo fantasmal)",
          "text": "El espíritu puede moverse a través de otras criaturas y objetos como si fueran terreno difícil. Si acaba su turno dentro de un objeto, se desplaza al espacio sin ocupar más cercano y recibe 1d10 de daño de fuerza por cada 5 pies recorridos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El espíritu realiza una cantidad de ataques igual a la mitad del nivel de este conjuro (redondeado hacia abajo)."
        },
        {
          "name": "Garra purulenta (solo pútrido)",
          "text": "Tirada de ataque cuerpo a cuerpo: bonificador igual a tu modificador de ataque de conjuros, alcance 5 pies. Acierto: 1d6 + 3 más el nivel del conjuro de daño cortante. Si el objetivo tiene el estado de envenenado, queda paralizado hasta el final de su siguiente turno."
        },
        {
          "name": "Toque mortal (solo fantasmal)",
          "text": "Tirada de ataque cuerpo a cuerpo: bonificador igual a tu modificador de ataque de conjuros, alcance 5 pies. Acierto: 1d8 + 3 más el nivel del conjuro de daño necrótico y el objetivo tiene el estado de asustado hasta el final de su siguiente turno."
        },
        {
          "name": "Rayo sepulcral (solo esquelético)",
          "text": "Tirada de ataque a distancia: bonificador igual a tu modificador de ataque de conjuros, alcance 150 pies. Acierto: 2d4 + 3 más el nivel del conjuro de daño necrótico."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "esqueleto",
      "name": "Esqueleto",
      "size": "Mediana",
      "type": "muerto viviente",
      "alignment": "legal malvado",
      "ac": 14,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 13,
        "formula": "2d8 + 4"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 10,
        "dex": 16,
        "con": 15,
        "int": 6,
        "wis": 8,
        "cha": 5
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 0
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": -1
        },
        {
          "ability": "cha",
          "bonus": -3
        }
      ],
      "skills": [],
      "damageVulnerabilities": [
        "contundente"
      ],
      "damageResistances": [],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "cansancio",
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 9"
      ],
      "languages": [
        "entiende común y otro idioma, pero no puede hablar"
      ],
      "cr": "1/4",
      "xp": 50,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Equipo",
          "text": "Arco corto, espada corta."
        }
      ],
      "actions": [
        {
          "name": "Espada corta",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 6 (1d6 + 3) de daño perforante."
        },
        {
          "name": "Arco corto",
          "text": "Tirada de ataque a distancia: +5, alcance 80/320 pies. Acierto: 6 (1d6 + 3) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "gato",
      "name": "Gato",
      "size": "Diminuta",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 2,
        "formula": "1d4"
      },
      "speed": {
        "walk": "40 pies",
        "climb": "40 pies"
      },
      "abilities": {
        "str": 3,
        "dex": 15,
        "con": 10,
        "int": 3,
        "wis": 12,
        "cha": 7
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 3
        },
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 13"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "xp": 10,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Saltador",
          "text": "La distancia de salto del gato se determina usando su Destreza en vez de su Fuerza."
        }
      ],
      "actions": [
        {
          "name": "Arañazo",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 1 de daño cortante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "golem_de_arcilla",
      "name": "Gólem de arcilla",
      "size": "Grande",
      "type": "constructo",
      "alignment": "sin alineamiento",
      "ac": 14,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 123,
        "formula": "13d10 + 52"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 20,
        "dex": 9,
        "con": 18,
        "int": 3,
        "wis": 8,
        "cha": 1
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 5
        },
        {
          "ability": "dex",
          "bonus": -1
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": -1
        },
        {
          "ability": "cha",
          "bonus": -5
        }
      ],
      "skills": [],
      "damageVulnerabilities": [],
      "damageResistances": [
        "contundente",
        "cortante",
        "perforante"
      ],
      "damageImmunities": [
        "ácido",
        "psíquico",
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "cansancio",
        "envenenado",
        "hechizado",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 9"
      ],
      "languages": [
        "común y otro cualquiera"
      ],
      "cr": "9",
      "xp": 5000,
      "proficiencyBonus": 4,
      "traits": [
        {
          "name": "Absorción de ácido",
          "text": "Siempre que fuese a recibir daño de ácido, el gólem no sufre ese daño y recupera una cantidad de puntos de golpe igual al daño de ácido infligido."
        },
        {
          "name": "Berserk",
          "text": "Siempre que el gólem comience su turno maltrecho, tira 1d6. Si sacas un 6, el gólem se ve poseído por una furia berserk. En cada uno de los turnos que pase en este estado, el gólem atacará a la criatura más cercana que pueda ver. Si no hay ninguna criatura lo bastante próxima como para que se mueva hasta ella y la ataque, el gólem atacará a un objeto. Una vez que el gólem se ve poseído por la furia berserk, continuará así hasta que sea destruido o deje de estar maltrecho."
        },
        {
          "name": "Forma inmutable",
          "text": "El gólem no puede cambiar de forma."
        },
        {
          "name": "Resistencia mágica",
          "text": "El gólem tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El gólem realiza dos ataques con su golpe o tres si ha utilizado la acción adicional de prisa en este turno."
        },
        {
          "name": "Golpe",
          "text": "Tirada de ataque cuerpo a cuerpo: +9, alcance 5 pies. Acierto: 10 (1d10 + 5) de daño contundente más 6 (1d12) de daño de ácido y los puntos de golpe máximos del objetivo se reducen en una cantidad igual al daño de ácido sufrido."
        }
      ],
      "bonusActions": [
        {
          "name": "Prisa (recarga 5–6)",
          "text": "El gólem realiza las acciones de correr y destrabarse."
        }
      ],
      "reactions": []
    },
    {
      "id": "golem_de_carne",
      "name": "Gólem de carne",
      "size": "Mediano",
      "type": "constructo",
      "alignment": "neutral",
      "ac": 9,
      "initiative": {
        "modifier": -1,
        "score": 9
      },
      "hp": {
        "average": 127,
        "formula": "15d8 + 60"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 9,
        "con": 18,
        "int": 6,
        "wis": 10,
        "cha": 5
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": -1
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -3
        }
      ],
      "skills": [],
      "damageResistances": [],
      "damageImmunities": [
        "relámpago",
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "cansancio",
        "envenenado",
        "hechizado",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "entiende común y otro idioma, pero no puede hablar"
      ],
      "cr": "5",
      "xp": 1800,
      "proficiencyBonus": 3,
      "traits": [
        {
          "name": "Absorción de relámpago",
          "text": "Siempre que fuese a recibir daño de relámpago, el gólem recupera una cantidad de puntos de golpe igual al daño de relámpago infligido."
        },
        {
          "name": "Aversión al fuego",
          "text": "Si el gólem recibe daño de fuego, tendrá desventaja en las tiradas de ataque y las pruebas de característica hasta el final de su siguiente turno."
        },
        {
          "name": "Berserk",
          "text": "Siempre que el gólem comience su turno maltrecho, tira 1d6. Si sacas un 6, el gólem se ve poseído por una furia berserk. En cada uno de los turnos que pase en este estado, el gólem atacará a la criatura más cercana que pueda ver. Si no hay ninguna criatura lo bastante próxima como para que se mueva hasta ella y la ataque, el gólem atacará a un objeto. Una vez que el gólem se ve poseído por la furia berserk, continuará así hasta que sea destruido o deje de estar maltrecho. Si el creador del gólem está a 60 pies o menos de este, podrá intentar calmarlo empleando una acción para realizar una prueba de Carisma (Persuasión) con CD 15; el gólem deberá ser capaz de oír a su creador. Si supera la prueba, el gólem dejará de estar en estado berserk hasta el principio de su siguiente turno. En ese momento, volverá a tirar según su atributo Berserk si sigue maltrecho."
        },
        {
          "name": "Forma inmutable",
          "text": "El gólem no puede cambiar de forma."
        },
        {
          "name": "Resistencia mágica",
          "text": "El gólem tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El gólem realiza dos ataques con su golpe."
        },
        {
          "name": "Golpe",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 13 (2d8 + 4) de daño contundente más 4 (1d8) de daño de relámpago."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "golem_de_hierro",
      "name": "Gólem de hierro",
      "size": "Grande",
      "type": "constructo",
      "alignment": "sin alineamiento",
      "ac": 20,
      "initiative": {
        "modifier": 9,
        "score": 19
      },
      "hp": {
        "average": 252,
        "formula": "24d10 + 120"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 24,
        "dex": 9,
        "con": 20,
        "int": 3,
        "wis": 11,
        "cha": 1
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 7
        },
        {
          "ability": "dex",
          "bonus": -1
        },
        {
          "ability": "con",
          "bonus": 5
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -5
        }
      ],
      "skills": [],
      "damageResistances": [],
      "damageImmunities": [
        "fuego",
        "psíquico",
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "cansancio",
        "envenenado",
        "hechizado",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión en la oscuridad 120 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "entiende común y otros dos idiomas, pero no puede hablar"
      ],
      "cr": "16",
      "xp": 15000,
      "proficiencyBonus": 5,
      "traits": [
        {
          "name": "Absorción de fuego",
          "text": "Siempre que fuese a recibir daño de fuego, el gólem recupera una cantidad de puntos de golpe igual al daño de fuego infligido."
        },
        {
          "name": "Forma inmutable",
          "text": "El gólem no puede cambiar de forma."
        },
        {
          "name": "Resistencia mágica",
          "text": "El gólem tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El gólem realiza dos ataques con su brazo cuchilla o su rayo ardiente en cualquier combinación."
        },
        {
          "name": "Brazo cuchilla",
          "text": "Tirada de ataque cuerpo a cuerpo: +12, alcance 10 pies. Acierto: 20 (3d8 + 7) de daño cortante más 10 (3d6) de daño de fuego."
        },
        {
          "name": "Rayo ardiente",
          "text": "Tirada de ataque a distancia: +10, alcance 120 pies. Acierto: 36 (8d8) de daño de fuego."
        },
        {
          "name": "Aliento venenoso (recarga 6)",
          "text": "Tirada de salvación de Constitución: CD 18, todas las criaturas en un cono de 60 pies. Fallo: 55 (10d10) de daño de veneno. Éxito: la mitad del daño."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "golem_de_piedra",
      "name": "Gólem de piedra",
      "size": "Grande",
      "type": "constructo",
      "alignment": "sin alineamiento",
      "ac": 18,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 220,
        "formula": "21d10 + 105"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 22,
        "dex": 9,
        "con": 20,
        "int": 3,
        "wis": 11,
        "cha": 1
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 6
        },
        {
          "ability": "dex",
          "bonus": -1
        },
        {
          "ability": "con",
          "bonus": 5
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -5
        }
      ],
      "skills": [],
      "damageResistances": [],
      "damageImmunities": [
        "psíquico",
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "cansancio",
        "envenenado",
        "hechizado",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión en la oscuridad 120 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "entiende común y otros dos idiomas, pero no puede hablar"
      ],
      "cr": "10",
      "xp": 5900,
      "proficiencyBonus": 4,
      "traits": [
        {
          "name": "Forma inmutable",
          "text": "El gólem no puede cambiar de forma."
        },
        {
          "name": "Resistencia mágica",
          "text": "El gólem tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El gólem realiza dos ataques con su golpe o su rayo de fuerza en cualquier combinación."
        },
        {
          "name": "Golpe",
          "text": "Tirada de ataque cuerpo a cuerpo: +10, alcance 5 pies. Acierto: 15 (2d8 + 6) de daño contundente más 9 (2d8) de daño de fuerza."
        },
        {
          "name": "Rayo de fuerza",
          "text": "Tirada de ataque a distancia: +9, alcance 120 pies. Acierto: 22 (4d10) de daño de fuerza."
        }
      ],
      "bonusActions": [
        {
          "name": "Ralentizar (recarga 5–6)",
          "text": "El gólem lanza el conjuro ralentizar, que no requiere componentes y utiliza la Constitución como aptitud mágica (CD de salvación de conjuros 17)."
        }
      ],
      "reactions": []
    },
    {
      "id": "guardian_escudo",
      "name": "Guardián escudo",
      "size": "Grande",
      "type": "constructo",
      "alignment": "sin alineamiento",
      "ac": 17,
      "initiative": {
        "modifier": -1,
        "score": 9
      },
      "hp": {
        "average": 142,
        "formula": "15d10 + 60"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 8,
        "con": 18,
        "int": 7,
        "wis": 10,
        "cha": 3
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 4
        },
        {
          "ability": "dex",
          "bonus": -1
        },
        {
          "ability": "con",
          "bonus": 4
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -4
        }
      ],
      "skills": [],
      "damageResistances": [],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "cansancio",
        "envenenado",
        "hechizado",
        "paralizado",
        "petrificado"
      ],
      "senses": [
        "visión ciega 10 pies",
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "entiende las órdenes recibidas en cualquier idioma, pero no puede hablar"
      ],
      "cr": "7",
      "xp": 2900,
      "proficiencyBonus": 3,
      "traits": [
        {
          "name": "Almacenar conjuros",
          "text": "El lanzador de conjuros que porte el amuleto del guardián podrá hacer que el guardián almacene un conjuro de nivel 4 o menos. Para ello, el portador deberá lanzar el conjuro sobre el guardián estando a 5 pies o menos. Este conjuro, en vez de tener efecto, se almacenará en él. Cualquier conjuro almacenado anteriormente se perderá cuando se almacene uno nuevo. El guardián puede lanzar el conjuro almacenado siguiendo los parámetros definidos por el lanzador original sin necesidad de componentes y empleará la aptitud mágica del lanzador. Luego, el conjuro almacenado se perderá."
        },
        {
          "name": "Regeneración",
          "text": "El guardián recupera 10 puntos de golpe al principio de cada uno de sus turnos si tiene al menos 1 punto de golpe."
        },
        {
          "name": "Vínculo",
          "text": "El guardián está vinculado mágicamente a un amuleto. Mientras ambos se encuentren en el mismo plano de existencia, el portador del amuleto podrá llamar telepáticamente al guardián para que acuda a su lado, y el guardián conocerá la distancia que le separa del amuleto y en qué dirección se halla. Si el guardián está situado a 60 pies o menos del portador del amuleto, la mitad del daño que reciba este (redondeado hacia arriba) será transferido al guardián."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El guardián realiza dos ataques de puñetazo."
        },
        {
          "name": "Puñetazo",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 10 pies. Acierto: 11 (2d6 + 4) de daño contundente más 7 (2d6) de daño de fuerza."
        }
      ],
      "bonusActions": [],
      "reactions": [
        {
          "name": "Protección",
          "text": "Detonante: una tirada de ataque acierta al portador del amuleto del guardián mientras está a 5 pies o menos de él. Respuesta: hasta el principio del siguiente turno del guardián, el portador obtiene un bonificador de +5 a la CA, incluido contra el ataque al que reacciona, lo que puede hacer que falle."
        }
      ]
    },
    {
      "id": "halcon",
      "name": "Halcón",
      "size": "Diminuta",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 1,
        "formula": "1d4 - 1"
      },
      "speed": {
        "walk": "10 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 5,
        "dex": 16,
        "con": 8,
        "int": 2,
        "wis": 14,
        "cha": 6
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 6
        }
      ],
      "senses": [
        "Percepción pasiva 16"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "xp": 10,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Garras",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 1 de daño cortante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "halcon_sangriento",
      "name": "Halcón sangriento",
      "size": "Pequeña",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 7,
        "formula": "2d6"
      },
      "speed": {
        "walk": "10 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 6,
        "dex": 14,
        "con": 10,
        "int": 3,
        "wis": 14,
        "cha": 5
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 6
        }
      ],
      "senses": [
        "Percepción pasiva 16"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/8",
      "xp": 25,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Atacar en manada",
          "text": "El halcón tiene ventaja en una tirada de ataque contra una criatura si al menos uno de los aliados del halcón se encuentra a 5 pies o menos de la criatura y no tiene el estado de incapacitado."
        }
      ],
      "actions": [
        {
          "name": "Pico",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 4 (1d4 + 2) de daño perforante o 6 (1d8 + 2) de daño perforante si el objetivo está maltrecho."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "hiena",
      "name": "Hiena",
      "size": "Mediana",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 11,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 5,
        "formula": "1d8 + 1"
      },
      "speed": {
        "walk": "50 pies"
      },
      "abilities": {
        "str": 11,
        "dex": 13,
        "con": 12,
        "int": 2,
        "wis": 12,
        "cha": 5
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 3
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 13"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "xp": 10,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Atacar en manada",
          "text": "La hiena tiene ventaja en una tirada de ataque contra una criatura si al menos uno de los aliados de la hiena se encuentra a 5 pies o menos de la criatura y no tiene el estado de incapacitado."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +2, alcance 5 pies. Acierto: 3 (1d6) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "hiena_gigante",
      "name": "Hiena gigante",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 45,
        "formula": "6d10 + 12"
      },
      "speed": {
        "walk": "50 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 14,
        "con": 14,
        "int": 2,
        "wis": 12,
        "cha": 7
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 3
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 13"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1",
      "xp": 200,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 10 (2d6 + 3) de daño perforante."
        }
      ],
      "bonusActions": [
        {
          "name": "Rabia (1/día)",
          "text": "Inmediatamente después de hacer daño a una criatura que ya estuviera maltrecha, la hiena se podrá mover hasta la mitad de su velocidad y realizará un ataque de mordisco."
        }
      ],
      "reactions": []
    },
    {
      "id": "hipopotamo",
      "name": "Hipopótamo",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 14,
      "initiative": {
        "modifier": -2,
        "score": 8
      },
      "hp": {
        "average": 82,
        "formula": "11d10 + 22"
      },
      "speed": {
        "walk": "30 pies",
        "swim": "30 pies"
      },
      "abilities": {
        "str": 21,
        "dex": 7,
        "con": 15,
        "int": 2,
        "wis": 12,
        "cha": 4
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 3
        }
      ],
      "senses": [
        "Percepción pasiva 13"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "4",
      "xp": 1100,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Aguantar la respiración",
          "text": "El hipopótamo puede aguantar la respiración durante 10 minutos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El hipopótamo realiza dos ataques de mordisco."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 16 (2d10 + 5) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "insecto_gigante",
      "name": "Insecto gigante",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": "11 + el nivel del conjuro",
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": "30 + (10 × (nivel del conjuro - 4))",
        "formula": "base 30, +10 por nivel por encima de 4"
      },
      "speed": {
        "walk": "40 pies",
        "climb": "40 pies",
        "fly": "40 pies"
      },
      "abilities": {
        "str": 17,
        "dex": 13,
        "con": 15,
        "int": 4,
        "wis": 14,
        "cha": 3
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 1
        },
        {
          "ability": "con",
          "bonus": 2
        },
        {
          "ability": "int",
          "bonus": -3
        },
        {
          "ability": "wis",
          "bonus": 2
        },
        {
          "ability": "cha",
          "bonus": -4
        }
      ],
      "skills": [],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "entiende los idiomas que conoces"
      ],
      "cr": "variable",
      "xp": 0,
      "proficiencyBonus": "igual a tu bonificador por competencia",
      "traits": [
        {
          "name": "Trepar cual arácnido",
          "text": "El insecto puede trepar por superficies difíciles e incluso recorrer techos sin tener que realizar pruebas de característica."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El insecto realiza una cantidad de ataques igual a la mitad del nivel de este conjuro (redondeado hacia abajo)."
        },
        {
          "name": "Punzada venenosa",
          "text": "Tirada de ataque cuerpo a cuerpo: bonificador igual a tu modificador de ataque de conjuros, alcance 10 pies. Acierto: 1d6 + 3 más el nivel del conjuro de daño perforante más 1d4 de daño de veneno."
        },
        {
          "name": "Proyectil de telarañas (solo araña)",
          "text": "Tirada de ataque a distancia: bonificador igual a tu modificador de ataque de conjuros, alcance 60 pies. Acierto: 1d10 + 3 más el nivel del conjuro de daño contundente y la velocidad del objetivo se reduce a 0 hasta el principio de su siguiente turno."
        }
      ],
      "bonusActions": [],
      "reactions": [],
      "specialActions": [
        {
          "name": "Escupitajo venenoso (solo ciempiés)",
          "text": "Tirada de salvación de Constitución: CD igual a tu CD de salvación de conjuros, una criatura a 10 pies o menos. Fallo: el objetivo tendrá el estado de envenenado hasta el principio del siguiente turno del insecto."
        }
      ]
    },
    {
      "id": "jabali",
      "name": "Jabalí",
      "size": "Mediana",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 11,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 13,
        "formula": "2d8 + 4"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 13,
        "dex": 11,
        "con": 14,
        "int": 2,
        "wis": 9,
        "cha": 5
      },
      "skills": [],
      "senses": [
        "Percepción pasiva 9"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/4",
      "xp": 50,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Furia maltrecha",
          "text": "Mientras esté maltrecho, el jabalí tiene ventaja en las tiradas de ataque."
        }
      ],
      "actions": [
        {
          "name": "Colmillos",
          "text": "Tirada de ataque cuerpo a cuerpo: +3, alcance 5 pies. Acierto: 4 (1d6 + 1) de daño perforante. Si el objetivo es una criatura Mediana o más pequeña y el jabalí recorre al menos 20 pies en línea recta hacia ella justo antes de acertarle, esta recibirá 3 (1d6) de daño perforante adicional y tendrá el estado de derribada."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "jabali_gigante",
      "name": "Jabalí gigante",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 42,
        "formula": "5d10 + 15"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 17,
        "dex": 10,
        "con": 16,
        "int": 2,
        "wis": 7,
        "cha": 5
      },
      "skills": [],
      "senses": [
        "Percepción pasiva 8"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "2",
      "xp": 450,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Furia maltrecha",
          "text": "El jabalí tendrá ventaja en las tiradas de ataque cuerpo a cuerpo mientras esté maltrecho."
        }
      ],
      "actions": [
        {
          "name": "Colmillos",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 10 (2d6 + 3) de daño perforante. Si el objetivo es una criatura Grande o más pequeña y el jabalí recorre al menos 20 pies en línea recta hacia ella justo antes de acertarle, esta recibirá 7 (2d6) de daño perforante adicional y tendrá el estado de derribada."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "lagarto",
      "name": "Lagarto",
      "size": "Diminuta",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 10,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 2,
        "formula": "1d4"
      },
      "speed": {
        "walk": "20 pies",
        "climb": "20 pies"
      },
      "abilities": {
        "str": 2,
        "dex": 11,
        "con": 10,
        "int": 1,
        "wis": 8,
        "cha": 3
      },
      "skills": [],
      "senses": [
        "visión en la oscuridad 30 pies",
        "Percepción pasiva 9"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "xp": 10,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Trepar cual arácnido",
          "text": "El lagarto puede trepar por superficies difíciles e incluso recorrer techos sin tener que realizar pruebas de característica."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +2, alcance 5 pies. Acierto: 1 de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "lagarto_gigante",
      "name": "Lagarto gigante",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 19,
        "formula": "3d10 + 3"
      },
      "speed": {
        "walk": "40 pies",
        "climb": "40 pies"
      },
      "abilities": {
        "str": 15,
        "dex": 12,
        "con": 13,
        "int": 2,
        "wis": 10,
        "cha": 5
      },
      "skills": [],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/4",
      "xp": 50,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Trepar cual arácnido",
          "text": "El lagarto puede trepar por superficies difíciles e incluso recorrer techos sin tener que realizar pruebas de característica."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 6 (1d8 + 2) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "leon",
      "name": "León",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 22,
        "formula": "4d10"
      },
      "speed": {
        "walk": "50 pies"
      },
      "abilities": {
        "str": 17,
        "dex": 15,
        "con": 11,
        "int": 3,
        "wis": 12,
        "cha": 8
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 3
        },
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 13"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1",
      "xp": 200,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Atacar en manada",
          "text": "El león tiene ventaja en una tirada de ataque contra una criatura si al menos uno de los aliados del león se encuentra a 5 pies o menos de la criatura y no tiene el estado de incapacitado."
        },
        {
          "name": "Saltar con carrera",
          "text": "Si se ha movido al menos 10 pies justo antes, el león puede realizar un salto de longitud de hasta 25 pies."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El león realiza dos ataques de desgarro. Puede sustituir un ataque por un rugido."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 7 (1d8 + 3) de daño cortante."
        },
        {
          "name": "Rugido",
          "text": "Tirada de salvación de Sabiduría: CD 11, una criatura a 15 pies o menos. Fallo: el objetivo tendrá el estado de asustado hasta el principio del siguiente turno del león."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "lobo",
      "name": "Lobo",
      "size": "Mediana",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 11,
        "formula": "2d8 + 2"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 14,
        "dex": 15,
        "con": 12,
        "int": 3,
        "wis": 12,
        "cha": 6
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 5
        },
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 15"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/4",
      "xp": 50,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Atacar en manada",
          "text": "El lobo tiene ventaja en las tiradas de ataque contra una criatura si al menos uno de los aliados del lobo se encuentra a 5 pies o menos de la criatura y no tiene el estado de incapacitado."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 5 (1d6 + 2) de daño perforante. Si el objetivo es una criatura Mediana o más pequeña, tendrá el estado de derribada."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "lobo_terrible",
      "name": "Lobo terrible",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 14,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 22,
        "formula": "3d10 + 6"
      },
      "speed": {
        "walk": "50 pies"
      },
      "abilities": {
        "str": 17,
        "dex": 15,
        "con": 15,
        "int": 3,
        "wis": 12,
        "cha": 7
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 5
        },
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 15"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1",
      "xp": 200,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Atacar en manada",
          "text": "El lobo tiene ventaja en una tirada de ataque contra una criatura si al menos uno de los aliados del lobo se encuentra a 5 pies o menos de la criatura y no tiene el estado de incapacitado."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 8 (1d10 + 3) de daño perforante. Si el objetivo es una criatura Grande o más pequeña, tendrá el estado de derribada."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "mamut",
      "name": "Mamut",
      "size": "Enorme",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 126,
        "formula": "11d12 + 55"
      },
      "speed": {
        "walk": "50 pies"
      },
      "abilities": {
        "str": 24,
        "dex": 9,
        "con": 21,
        "int": 3,
        "wis": 11,
        "cha": 6
      },
      "skills": [],
      "senses": [
        "Percepción pasiva 10"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "6",
      "xp": 2300,
      "proficiencyBonus": 3,
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El mamut realiza dos ataques con sus colmillos."
        },
        {
          "name": "Colmillos",
          "text": "Tirada de ataque cuerpo a cuerpo: +10, alcance 10 pies. Acierto: 18 (2d10 + 7) de daño perforante. Si el objetivo es una criatura Enorme o más pequeña y el mamut recorre al menos 20 pies en línea recta hacia ella justo antes de acertarle, tendrá el estado de derribada."
        }
      ],
      "bonusActions": [
        {
          "name": "Arrollar",
          "text": "Tirada de salvación de Destreza: CD 18, una criatura a 5 pies o menos que tenga el estado de derribada. Fallo: 29 (4d10 + 7) de daño contundente. Éxito: la mitad del daño."
        }
      ],
      "reactions": []
    },
    {
      "id": "mastin",
      "name": "Mastín",
      "size": "Mediana",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 5,
        "formula": "1d8 + 1"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 13,
        "dex": 14,
        "con": 12,
        "int": 3,
        "wis": 12,
        "cha": 7
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 5
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 15"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/8",
      "xp": 25,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +3, alcance 5 pies. Acierto: 4 (1d6 + 1) de daño perforante. Si el objetivo es una criatura Mediana o más pequeña, tendrá el estado de derribada."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "mula",
      "name": "Mula",
      "size": "Mediana",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 10,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 11,
        "formula": "2d8 + 2"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 14,
        "dex": 10,
        "con": 13,
        "int": 2,
        "wis": 10,
        "cha": 5
      },
      "skills": [],
      "senses": [
        "Percepción pasiva 10"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/8",
      "xp": 25,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Bestia de carga",
          "text": "La mula se considera de un tamaño mayor para determinar su capacidad de carga."
        }
      ],
      "actions": [
        {
          "name": "Cascos",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 4 (1d4 + 2) de daño contundente."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "murcielago",
      "name": "Murciélago",
      "size": "Diminuta",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 1,
        "formula": "1d4 - 1"
      },
      "speed": {
        "walk": "5 pies",
        "fly": "30 pies"
      },
      "abilities": {
        "str": 2,
        "dex": 15,
        "con": 8,
        "int": 2,
        "wis": 12,
        "cha": 4
      },
      "skills": [],
      "senses": [
        "visión ciega 60 pies",
        "Percepción pasiva 11"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "xp": 10,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 1 de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "murcielago_gigante",
      "name": "Murciélago gigante",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 22,
        "formula": "4d10"
      },
      "speed": {
        "walk": "10 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 15,
        "dex": 16,
        "con": 11,
        "int": 2,
        "wis": 12,
        "cha": 6
      },
      "skills": [],
      "senses": [
        "visión ciega 120 pies",
        "Percepción pasiva 11"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/4",
      "xp": 50,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 6 (1d6 + 3) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "objeto_animado",
      "name": "Objeto animado",
      "size": "Variable (Enorme o menor)",
      "type": "constructo",
      "alignment": "sin alineamiento",
      "ac": 15,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": "10 (Mediano o menor), 20 (Grande), 40 (Enorme)",
        "formula": "variable según tamaño"
      },
      "speed": {
        "walk": "30 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 10,
        "con": 10,
        "int": 3,
        "wis": 3,
        "cha": 1
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 3
        },
        {
          "ability": "dex",
          "bonus": 0
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": -4
        },
        {
          "ability": "cha",
          "bonus": -5
        }
      ],
      "skills": [],
      "damageImmunities": [
        "psíquico",
        "veneno"
      ],
      "conditionImmunities": [
        "asustado",
        "cansancio",
        "envenenado",
        "hechizado",
        "paralizado"
      ],
      "senses": [
        "visión ciega 30 pies",
        "Percepción pasiva 6"
      ],
      "languages": [
        "entiende los idiomas que conoces"
      ],
      "cr": "variable",
      "xp": 0,
      "proficiencyBonus": "igual a tu bonificador por competencia",
      "traits": [],
      "actions": [
        {
          "name": "Golpe",
          "text": "Tirada de ataque cuerpo a cuerpo: bonificador igual a tu modificador de ataque de conjuros, alcance 5 pies. Acierto: daño de fuerza igual a 1d4 + 3 más tu modificador por aptitud mágica (Mediano o más pequeño), 2d6 + 3 más tu modificador por aptitud mágica (Grande) o 2d12 + 3 más tu modificador por aptitud mágica (Enorme)."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "orca",
      "name": "Orca",
      "size": "Enorme",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 90,
        "formula": "12d12 + 12"
      },
      "speed": {
        "walk": "5 pies",
        "swim": "60 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 14,
        "con": 13,
        "int": 3,
        "wis": 12,
        "cha": 7
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 3
        },
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "senses": [
        "visión ciega 120 pies",
        "Percepción pasiva 13"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "3",
      "xp": 700,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Aguantar la respiración",
          "text": "La orca puede aguantar la respiración durante 30 minutos."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 21 (5d6 + 4) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "oso_lechuza",
      "name": "Oso lechuza",
      "size": "Grande",
      "type": "monstruosidad",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 59,
        "formula": "7d10 + 21"
      },
      "speed": {
        "walk": "40 pies",
        "climb": "40 pies"
      },
      "abilities": {
        "str": 20,
        "dex": 12,
        "con": 17,
        "int": 3,
        "wis": 12,
        "cha": 7
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 5
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 15"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "3",
      "xp": 700,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El oso lechuza realiza dos ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 14 (2d8 + 5) de daño cortante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "oso_negro",
      "name": "Oso negro",
      "size": "Mediana",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 11,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 19,
        "formula": "3d8 + 6"
      },
      "speed": {
        "walk": "30 pies",
        "swim": "30 pies",
        "climb": "30 pies"
      },
      "abilities": {
        "str": 15,
        "dex": 12,
        "con": 14,
        "int": 2,
        "wis": 12,
        "cha": 7
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 5
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 15"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/2",
      "xp": 100,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El oso realiza dos ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 5 (1d6 + 2) de daño cortante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "oso_pardo",
      "name": "Oso pardo",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 11,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 22,
        "formula": "3d10 + 6"
      },
      "speed": {
        "walk": "40 pies",
        "climb": "30 pies"
      },
      "abilities": {
        "str": 17,
        "dex": 12,
        "con": 15,
        "int": 2,
        "wis": 13,
        "cha": 7
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 3
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 13"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1",
      "xp": 200,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El oso realiza un ataque de mordisco y uno con sus garras."
        },
        {
          "name": "Garra",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 5 (1d4 + 3) de daño cortante. Si el objetivo es una criatura Grande o más pequeña, tendrá el estado de derribada."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 7 (1d8 + 3) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "oso_polar",
      "name": "Oso polar",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 42,
        "formula": "5d10 + 15"
      },
      "speed": {
        "walk": "40 pies",
        "swim": "40 pies"
      },
      "abilities": {
        "str": 20,
        "dex": 14,
        "con": 16,
        "int": 2,
        "wis": 13,
        "cha": 7
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 5
        },
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 15"
      ],
      "languages": [
        "ninguno"
      ],
      "damageResistances": [
        "frío"
      ],
      "cr": "2",
      "xp": 450,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El oso realiza dos ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 9 (1d8 + 5) de daño cortante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "pantera",
      "name": "Pantera",
      "size": "Mediana",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 13,
        "formula": "3d8"
      },
      "speed": {
        "walk": "50 pies",
        "climb": "40 pies"
      },
      "abilities": {
        "str": 14,
        "dex": 16,
        "con": 10,
        "int": 3,
        "wis": 14,
        "cha": 7
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 4
        },
        {
          "name": "Sigilo",
          "bonus": 7
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/4",
      "xp": 50,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 6 (1d6 + 3) de daño cortante."
        }
      ],
      "bonusActions": [
        {
          "name": "Huida veloz",
          "text": "La pantera realiza las acciones de destrabarse o esconderse."
        }
      ],
      "reactions": []
    },
    {
      "id": "pirana",
      "name": "Piraña",
      "size": "Diminuta",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 1,
        "formula": "1d4 - 1"
      },
      "speed": {
        "walk": "5 pies",
        "swim": "40 pies"
      },
      "abilities": {
        "str": 2,
        "dex": 16,
        "con": 9,
        "int": 1,
        "wis": 7,
        "cha": 2
      },
      "skills": [],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 8"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "xp": 10,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Respirar en el agua",
          "text": "La piraña solo puede respirar bajo el agua."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +5 (con ventaja si el objetivo no tiene todos sus puntos de golpe), alcance 5 pies. Acierto: 1 de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "plesiosaurio",
      "name": "Plesiosaurio",
      "size": "Grande",
      "type": "bestia",
      "subtype": "dinosaurio",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 68,
        "formula": "8d10 + 24"
      },
      "speed": {
        "walk": "20 pies",
        "swim": "40 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 15,
        "con": 16,
        "int": 2,
        "wis": 12,
        "cha": 5
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 3
        },
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "senses": [
        "Percepción pasiva 13"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "2",
      "xp": 450,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Aguantar la respiración",
          "text": "El plesiosaurio puede aguantar la respiración durante 1 hora."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 10 pies. Acierto: 11 (2d6 + 4) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "poni",
      "name": "Poni",
      "size": "Mediana",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 10,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 11,
        "formula": "2d8 + 2"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 15,
        "dex": 10,
        "con": 13,
        "int": 2,
        "wis": 11,
        "cha": 7
      },
      "skills": [],
      "senses": [
        "Percepción pasiva 10"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/8",
      "xp": 25,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Cascos",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 4 (1d4 + 2) de daño contundente."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "pseudodragon",
      "name": "Pseudodragón",
      "size": "Diminuta",
      "type": "dragón",
      "alignment": "neutral bueno",
      "ac": 14,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 10,
        "formula": "3d4 + 3"
      },
      "speed": {
        "walk": "15 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 6,
        "dex": 15,
        "con": 13,
        "int": 10,
        "wis": 12,
        "cha": 10
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -2
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 1
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "skills": [
        {
          "name": "Percepción",
          "bonus": 5
        },
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "senses": [
        "visión ciega 10 pies",
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 15"
      ],
      "languages": [
        "entiende común y dracónico, pero no puede hablar"
      ],
      "cr": "1/4",
      "xp": 50,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Resistencia mágica",
          "text": "El pseudodragón tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El pseudodragón realiza dos ataques de mordisco."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 4 (1d4 + 2) de daño perforante."
        },
        {
          "name": "Aguijón",
          "text": "Tirada de salvación de Constitución: CD 12, una criatura que el pseudodragón pueda ver a 5 pies o menos. Fallo: 5 (2d4) de daño de veneno y el objetivo tendrá el estado de envenenado durante 1 hora. Fallo por 5 o más: mientras esté envenenado, el objetivo también tendrá el estado de inconsciente, que terminará antes si recibe daño o una criatura a 5 pies o menos de él utiliza una acción para despertarlo."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "pteranodon",
      "name": "Pteranodon",
      "size": "Mediana",
      "type": "bestia",
      "subtype": "dinosaurio",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 13,
        "formula": "3d8"
      },
      "speed": {
        "walk": "10 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 12,
        "dex": 15,
        "con": 10,
        "int": 2,
        "wis": 9,
        "cha": 5
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 1
        }
      ],
      "senses": [
        "Percepción pasiva 11"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/4",
      "xp": 50,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Pasar volando",
          "text": "El pteranodon no provoca ataques de oportunidad cuando vuela para ponerse fuera del alcance de un enemigo."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 6 (1d8 + 2) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "pulpo",
      "name": "Pulpo",
      "size": "Pequeña",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 3,
        "formula": "1d6"
      },
      "speed": {
        "walk": "5 pies",
        "swim": "30 pies"
      },
      "abilities": {
        "str": 4,
        "dex": 15,
        "con": 11,
        "int": 3,
        "wis": 10,
        "cha": 4
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 2
        },
        {
          "name": "Sigilo",
          "bonus": 6
        }
      ],
      "senses": [
        "visión en la oscuridad 30 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "xp": 10,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Compresión",
          "text": "El pulpo puede moverse a través de un espacio de solo 1 pulgada de ancho sin gastar movimiento adicional para hacerlo."
        },
        {
          "name": "Respirar en el agua",
          "text": "El pulpo solo puede respirar bajo el agua."
        }
      ],
      "actions": [
        {
          "name": "Tentáculos",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 1 de daño contundente."
        }
      ],
      "bonusActions": [],
      "reactions": [
        {
          "name": "Nube de tinta (1/día)",
          "text": "Detonante: una criatura termina su turno a 5 pies o menos del pulpo mientras está bajo el agua. Respuesta: el pulpo suelta tinta que llena un cubo de 5 pies de lado centrado en él y se mueve hasta su velocidad nadando. El cubo está muy oscuro durante 1 minuto o hasta que una corriente fuerte o un efecto similar disperse la tinta."
        }
      ]
    },
    {
      "id": "pulpo_gigante",
      "name": "Pulpo gigante",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 11,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 45,
        "formula": "7d10 + 7"
      },
      "speed": {
        "walk": "10 pies",
        "swim": "60 pies"
      },
      "abilities": {
        "str": 17,
        "dex": 13,
        "con": 13,
        "int": 5,
        "wis": 10,
        "cha": 4
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 4
        },
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 14"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1",
      "xp": 200,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Respirar en el agua",
          "text": "El pulpo solo puede respirar bajo el agua. Puede aguantar la respiración durante 1 hora fuera del agua."
        }
      ],
      "actions": [
        {
          "name": "Tentáculos",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 10 pies. Acierto: 10 (2d6 + 3) de daño contundente. Si el objetivo es una criatura Mediana o más pequeña, tendrá el estado de agarrada (CD 13 para escapar) por los ocho tentáculos. Mientras esté agarrada, tendrá el estado de apresada."
        }
      ],
      "bonusActions": [],
      "reactions": [
        {
          "name": "Nube de tinta (1/día)",
          "text": "Detonante: el pulpo recibe daño mientras está bajo el agua. Respuesta: el pulpo suelta tinta que llena un cubo de 10 pies de lado centrado en él y se mueve hasta su velocidad nadando. El cubo está muy oscuro durante 1 minuto o hasta que una corriente fuerte o un efecto similar disperse la tinta."
        }
      ]
    },
    {
      "id": "quasit",
      "name": "Quasit",
      "size": "Diminuto",
      "type": "infernal (demonio)",
      "alignment": "caótico malvado",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 25,
        "formula": "10d4"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 5,
        "dex": 17,
        "con": 10,
        "int": 7,
        "wis": 10,
        "cha": 10
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -3
        },
        {
          "ability": "dex",
          "bonus": 3
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": -2
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": 0
        }
      ],
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 5
        }
      ],
      "damageResistances": [
        "frío",
        "fuego",
        "relámpago"
      ],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 120 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "abisal",
        "común"
      ],
      "cr": "1",
      "xp": 200,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Resistencia mágica",
          "text": "El quasit tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 5 (1d4 + 3) de daño cortante y el objetivo tendrá el estado de envenenado hasta el principio del siguiente turno del quasit."
        },
        {
          "name": "Asustar (1/día)",
          "text": "Tirada de salvación de Sabiduría: CD 10, una criatura a 20 pies o menos. Fallo: el objetivo tendrá el estado de asustado. Al final de cada uno de sus turnos, el objetivo repetirá la tirada de salvación y, si tiene éxito, se librará del efecto. Tras 1 minuto, tendrá éxito automáticamente."
        },
        {
          "name": "Cambio de forma",
          "text": "El quasit cambia de forma para parecerse a un ciempiés (velocidad 40 pies, trepar 40 pies), un murciélago (10 pies, volar 40 pies) o un sapo (40 pies, nadar 40 pies), o recupera su auténtica forma. Su perfil es el mismo en todas las formas, excepto por su velocidad. Cualquier equipo que vista o lleve no se transformará."
        },
        {
          "name": "Invisibilidad",
          "text": "El quasit lanza invisibilidad sobre sí mismo sin necesidad de componentes y utiliza el Carisma como aptitud mágica."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "rana",
      "name": "Rana",
      "size": "Diminuta",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 11,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 1,
        "formula": "1d4 - 1"
      },
      "speed": {
        "walk": "20 pies",
        "swim": "20 pies"
      },
      "abilities": {
        "str": 1,
        "dex": 13,
        "con": 8,
        "int": 1,
        "wis": 8,
        "cha": 3
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 1
        },
        {
          "name": "Sigilo",
          "bonus": 3
        }
      ],
      "senses": [
        "visión en la oscuridad 30 pies",
        "Percepción pasiva 11"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "xp": 10,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Anfibia",
          "text": "La rana puede respirar tanto dentro como fuera del agua."
        },
        {
          "name": "Saltar sin carrera",
          "text": "La rana puede hacer un salto de longitud de hasta 10 pies o un salto de altura de hasta 5 pies, tanto si ha cogido carrerilla como si no."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +3, alcance 5 pies. Acierto: 1 de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "rana_gigante",
      "name": "Rana gigante",
      "size": "Mediana",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 11,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 18,
        "formula": "4d8"
      },
      "speed": {
        "walk": "30 pies",
        "swim": "30 pies"
      },
      "abilities": {
        "str": 12,
        "dex": 13,
        "con": 11,
        "int": 2,
        "wis": 10,
        "cha": 3
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 2
        },
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "senses": [
        "visión en la oscuridad 30 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/4",
      "xp": 50,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Anfibia",
          "text": "La rana puede respirar tanto dentro como fuera del agua."
        },
        {
          "name": "Saltar sin carrera",
          "text": "La rana puede hacer un salto de longitud de hasta 20 pies o un salto de altura de hasta 10 pies, tanto si ha cogido carrerilla como si no."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +3, alcance 5 pies. Acierto: 5 (1d6 + 2) de daño perforante. Si el objetivo es una criatura Mediana o más pequeña, tendrá el estado de agarrada (CD 11 para escapar)."
        },
        {
          "name": "Engullir",
          "text": "La rana engulle a un objetivo Pequeño o de menor tamaño al que esté agarrando. Mientras esté engullido, el objetivo no estará agarrado, sino que tendrá los estados de apresado y cegado, y tendrá cobertura completa contra los ataques y otros efectos fuera de la rana. Mientras esté engullendo al objetivo, la rana no podrá usar su mordisco y, si muere, el objetivo engullido dejará de estar apresado y podrá gastar 5 pies de movimiento para escapar del cadáver, del que saldrá con el estado de derribado. Al final del siguiente turno de la rana, el objetivo engullido recibirá 5 (2d4) de daño de ácido. Si ese daño no lo mata, la rana lo regurgitará y el objetivo saldrá de ella con el estado de derribado."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "rata",
      "name": "Rata",
      "size": "Diminuta",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 10,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 1,
        "formula": "1d4 - 1"
      },
      "speed": {
        "walk": "20 pies",
        "climb": "20 pies"
      },
      "abilities": {
        "str": 2,
        "dex": 11,
        "con": 9,
        "int": 2,
        "wis": 10,
        "cha": 4
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 2
        }
      ],
      "senses": [
        "visión en la oscuridad 30 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "xp": 10,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Ágil",
          "text": "La rata no provoca ataques de oportunidad cuando se mueve para ponerse fuera del alcance de un enemigo."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +2, alcance 5 pies. Acierto: 1 de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "rata_gigante",
      "name": "Rata gigante",
      "size": "Pequeña",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 7,
        "formula": "2d6"
      },
      "speed": {
        "walk": "30 pies",
        "climb": "30 pies"
      },
      "abilities": {
        "str": 7,
        "dex": 16,
        "con": 11,
        "int": 2,
        "wis": 10,
        "cha": 4
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 2
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/8",
      "xp": 25,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Atacar en manada",
          "text": "La rata tiene ventaja en una tirada de ataque contra una criatura si al menos uno de los aliados de la rata se encuentra a 5 pies o menos de la criatura y no tiene el estado de incapacitado."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 5 (1d4 + 3) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "renacuajo_slaad",
      "name": "Renacuajo slaad",
      "size": "Diminuto",
      "type": "aberración",
      "alignment": "caótica neutral",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 7,
        "formula": "3d4"
      },
      "speed": {
        "walk": "30 pies",
        "burrow": "10 pies"
      },
      "abilities": {
        "str": 7,
        "dex": 15,
        "con": 10,
        "int": 3,
        "wis": 5,
        "cha": 3
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -2
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 0
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": -3
        },
        {
          "ability": "cha",
          "bonus": -4
        }
      ],
      "skills": [
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "damageResistances": [
        "ácido",
        "frío",
        "fuego",
        "relámpago",
        "trueno"
      ],
      "damageImmunities": [],
      "conditionImmunities": [],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 7"
      ],
      "languages": [
        "entiende slaad, pero no puede hablar"
      ],
      "cr": "1/3",
      "xp": 25,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Resistencia mágica",
          "text": "El slaad tiene ventaja en las tiradas de salvación contra conjuros y otros efectos mágicos."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 5 (1d6 + 2) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "rinoceronte",
      "name": "Rinoceronte",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": -1,
        "score": 9
      },
      "hp": {
        "average": 45,
        "formula": "6d10 + 12"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 21,
        "dex": 8,
        "con": 15,
        "int": 2,
        "wis": 12,
        "cha": 6
      },
      "skills": [],
      "senses": [
        "Percepción pasiva 11"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "2",
      "xp": 450,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Cornada",
          "text": "Tirada de ataque cuerpo a cuerpo: +7, alcance 5 pies. Acierto: 14 (2d8 + 5) de daño perforante. Si el objetivo es una criatura Grande o más pequeña y el rinoceronte recorre al menos 20 pies en línea recta hacia ella justo antes de acertarle, esta recibirá 9 (2d8) de daño perforante adicional y tendrá el estado de derribada."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "sapo_gigante",
      "name": "Sapo gigante",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 11,
      "initiative": {
        "modifier": 1,
        "score": 11
      },
      "hp": {
        "average": 39,
        "formula": "6d10 + 6"
      },
      "speed": {
        "walk": "30 pies",
        "swim": "30 pies"
      },
      "abilities": {
        "str": 15,
        "dex": 13,
        "con": 13,
        "int": 2,
        "wis": 10,
        "cha": 3
      },
      "skills": [],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1",
      "xp": 200,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Anfibio",
          "text": "El sapo puede respirar tanto dentro como fuera del agua."
        },
        {
          "name": "Saltar sin carrera",
          "text": "El sapo puede hacer un salto de longitud de hasta 20 pies o un salto de altura de hasta 10 pies, tanto si ha cogido carrerilla como si no."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 5 (1d6 + 2) de daño perforante más 5 (2d4) de daño de veneno. Si el objetivo es una criatura Mediana o más pequeña, tendrá el estado de agarrada (CD 12 para escapar)."
        },
        {
          "name": "Engullir",
          "text": "El sapo engulle a un objetivo Mediano o más pequeño al que esté agarrando. Mientras esté engullido, el objetivo no estará agarrado, sino que tendrá los estados de apresado y cegado, y tendrá cobertura completa contra los ataques y otros efectos fuera del sapo. Además, el objetivo recibirá 10 (3d6) de daño de ácido al final de cada turno del sapo. El sapo solo puede engullir a un objetivo a la vez y no podrá usar su mordisco mientras tenga a un objetivo engullido. Si el sapo muere, una criatura engullida dejará de estar apresada por él y podrá gastar 5 pies de movimiento para escapar del cadáver, del que saldrá con el estado de derribada."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "serpiente_constrictora",
      "name": "Serpiente constrictora",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 13,
        "formula": "2d10 + 2"
      },
      "speed": {
        "walk": "30 pies",
        "swim": "30 pies"
      },
      "abilities": {
        "str": 15,
        "dex": 14,
        "con": 12,
        "int": 1,
        "wis": 10,
        "cha": 3
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 2
        },
        {
          "name": "Sigilo",
          "bonus": 4
        }
      ],
      "senses": [
        "visión ciega 10 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/4",
      "xp": 50,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 6 (1d8 + 2) de daño perforante."
        },
        {
          "name": "Constreñir",
          "text": "Tirada de salvación de Fuerza: CD 12, una criatura Mediana o más pequeña que la serpiente pueda ver a 5 pies o menos. Fallo: 7 (3d4) de daño contundente y el objetivo tendrá el estado de agarrado (CD 12 para escapar)."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "serpiente_constrictora_gigante",
      "name": "Serpiente constrictora gigante",
      "size": "Enorme",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 60,
        "formula": "8d12 + 8"
      },
      "speed": {
        "walk": "30 pies",
        "swim": "30 pies"
      },
      "abilities": {
        "str": 19,
        "dex": 14,
        "con": 12,
        "int": 1,
        "wis": 10,
        "cha": 3
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 2
        }
      ],
      "senses": [
        "visión ciega 10 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "2",
      "xp": 450,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "La serpiente realiza un ataque de mordisco y emplea su acción de constreñir."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 10 pies. Acierto: 11 (2d6 + 4) de daño perforante."
        },
        {
          "name": "Constreñir",
          "text": "Tirada de salvación de Fuerza: CD 14, una criatura Grande o más pequeña que la serpiente pueda ver a 10 pies o menos. Fallo: 13 (2d8 + 4) de daño contundente y el objetivo tendrá el estado de agarrado (CD 14 para escapar)."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "serpiente_venenosa",
      "name": "Serpiente venenosa",
      "size": "Diminuta",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 5,
        "formula": "2d4"
      },
      "speed": {
        "walk": "30 pies",
        "swim": "30 pies"
      },
      "abilities": {
        "str": 2,
        "dex": 15,
        "con": 11,
        "int": 1,
        "wis": 10,
        "cha": 3
      },
      "skills": [],
      "senses": [
        "visión ciega 10 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/8",
      "xp": 25,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 4 (1d4 + 2) de daño perforante más 3 (1d6) de daño de veneno."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "serpiente_venenosa_gigante",
      "name": "Serpiente venenosa gigante",
      "size": "Mediana",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 14,
      "initiative": {
        "modifier": 4,
        "score": 14
      },
      "hp": {
        "average": 11,
        "formula": "2d8 + 2"
      },
      "speed": {
        "walk": "40 pies",
        "swim": "40 pies"
      },
      "abilities": {
        "str": 10,
        "dex": 18,
        "con": 13,
        "int": 2,
        "wis": 10,
        "cha": 3
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 2
        }
      ],
      "senses": [
        "visión ciega 10 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/4",
      "xp": 50,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 10 pies. Acierto: 6 (1d4 + 4) de daño perforante más 4 (1d8) de daño de veneno."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "serpiente_voladora",
      "name": "Serpiente voladora",
      "size": "Diminuta",
      "type": "monstruosidad",
      "alignment": "sin alineamiento",
      "ac": 14,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 5,
        "formula": "2d4"
      },
      "speed": {
        "walk": "30 pies",
        "swim": "30 pies",
        "fly": "60 pies"
      },
      "abilities": {
        "str": 4,
        "dex": 15,
        "con": 11,
        "int": 2,
        "wis": 12,
        "cha": 5
      },
      "skills": [],
      "senses": [
        "visión ciega 10 pies",
        "Percepción pasiva 11"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/8",
      "xp": 25,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Pasar volando",
          "text": "La serpiente no provoca ataques de oportunidad cuando vuela para ponerse fuera del alcance de un enemigo."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 1 de daño perforante más 5 (2d4) de daño de veneno."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "simio",
      "name": "Simio",
      "size": "Mediana",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 19,
        "formula": "3d8 + 6"
      },
      "speed": {
        "walk": "30 pies",
        "climb": "30 pies"
      },
      "abilities": {
        "str": 16,
        "dex": 14,
        "con": 14,
        "int": 6,
        "wis": 12,
        "cha": 7
      },
      "skills": [
        {
          "name": "Atletismo",
          "bonus": 5
        },
        {
          "name": "Percepción",
          "bonus": 3
        }
      ],
      "senses": [
        "Percepción pasiva 13"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/2",
      "xp": 100,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El simio realiza dos ataques de puñetazo."
        },
        {
          "name": "Puñetazo",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 5 (1d4 + 3) de daño contundente."
        },
        {
          "name": "Piedra (recarga 6)",
          "text": "Tirada de ataque a distancia: +5, alcance 25/50 pies. Acierto: 10 (2d6 + 3) de daño contundente."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "simio_gigante",
      "name": "Simio gigante",
      "size": "Enorme",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 5,
        "score": 15
      },
      "hp": {
        "average": 168,
        "formula": "16d12 + 64"
      },
      "speed": {
        "walk": "40 pies",
        "climb": "40 pies"
      },
      "abilities": {
        "str": 23,
        "dex": 14,
        "con": 18,
        "int": 5,
        "wis": 12,
        "cha": 7
      },
      "skills": [
        {
          "name": "Atletismo",
          "bonus": 9
        },
        {
          "name": "Percepción",
          "bonus": 4
        },
        {
          "name": "Supervivencia",
          "bonus": 4
        }
      ],
      "senses": [
        "Percepción pasiva 14"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "7",
      "xp": 2900,
      "proficiencyBonus": 3,
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El simio realiza dos ataques de puñetazo."
        },
        {
          "name": "Puñetazo",
          "text": "Tirada de ataque cuerpo a cuerpo: +9, alcance 10 pies. Acierto: 22 (3d10 + 6) de daño contundente."
        },
        {
          "name": "Lanzamiento de pedrusco (recarga 6)",
          "text": "El simio arroja un pedrusco a un punto que pueda ver a 90 pies o menos. Tirada de salvación de Destreza: CD 17, todas las criaturas en una esfera de 5 pies de radio centrada en ese punto. Fallo: 24 (7d6) de daño contundente. Si el objetivo es una criatura Grande o más pequeña, tendrá el estado de derribada. Éxito: solo la mitad del daño."
        }
      ],
      "bonusActions": [
        {
          "name": "Salto",
          "text": "El simio gasta 10 pies de movimiento para saltar hasta 30 pies."
        }
      ],
      "reactions": []
    },
    {
      "id": "sirviente_homunculo",
      "name": "Sirviente homúnculo",
      "size": "Diminuta",
      "type": "constructo",
      "alignment": "neutral",
      "ac": 13,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": "5 + (5 × nivel del conjuro)",
        "formula": "dados de golpe d4 iguales al nivel del conjuro"
      },
      "speed": {
        "walk": "20 pies",
        "fly": "30 pies"
      },
      "abilities": {
        "str": 4,
        "dex": 15,
        "con": 12,
        "int": 10,
        "wis": 10,
        "cha": 7
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": -3
        },
        {
          "ability": "dex",
          "bonus": 2
        },
        {
          "ability": "con",
          "bonus": 1
        },
        {
          "ability": "int",
          "bonus": 0
        },
        {
          "ability": "wis",
          "bonus": 0
        },
        {
          "ability": "cha",
          "bonus": -2
        }
      ],
      "skills": [],
      "damageResistances": [],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "cansancio",
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 10"
      ],
      "languages": [
        "telepatía 1 milla (solo funciona contigo)"
      ],
      "cr": "variable",
      "xp": 0,
      "proficiencyBonus": "igual a tu bonificador por competencia",
      "traits": [
        {
          "name": "Evasión",
          "text": "Si el homúnculo está sujeto a un efecto que le permita hacer una tirada de salvación de Destreza para recibir solo la mitad del daño, en vez de ello no recibe daño si supera la salvación y solo recibe la mitad si falla. No puede usar este atributo si tiene el estado de incapacitado."
        },
        {
          "name": "Vínculo mágico",
          "text": "Añade el nivel del conjuro a cualquier prueba de característica o tirada de salvación que haga el homúnculo."
        }
      ],
      "actions": [
        {
          "name": "Golpe de fuerza",
          "text": "Tirada de ataque cuerpo a cuerpo o a distancia: bonificador igual a tu modificador de ataque de conjuros, alcance 5 pies o alcance 30 pies. Acierto: 1d6 más el nivel del conjuro de daño de fuerza."
        }
      ],
      "bonusActions": [],
      "reactions": [
        {
          "name": "Canalizar magia",
          "text": "Detonante: lanzas un conjuro con alcance de toque mientras el homúnculo está a 120 pies o menos de ti. Respuesta: el homúnculo entrega el conjuro mediante su toque."
        }
      ]
    },
    {
      "id": "tarantula_gigante",
      "name": "Tarántula gigante",
      "size": "Mediana",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 11,
        "formula": "2d8 + 2"
      },
      "speed": {
        "walk": "40 pies",
        "climb": "40 pies"
      },
      "abilities": {
        "str": 12,
        "dex": 16,
        "con": 13,
        "int": 3,
        "wis": 12,
        "cha": 4
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 3
        },
        {
          "name": "Sigilo",
          "bonus": 7
        }
      ],
      "senses": [
        "visión ciega 10 pies",
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 13"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/4",
      "xp": 50,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Trepar cual arácnido",
          "text": "La araña puede trepar por superficies difíciles e incluso recorrer techos sin tener que realizar pruebas de característica."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 5 (1d4 + 3) de daño perforante más 5 (2d4) de daño de veneno."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "tejon",
      "name": "Tejón",
      "size": "Diminuta",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 11,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 5,
        "formula": "1d4 + 3"
      },
      "speed": {
        "walk": "20 pies",
        "burrow": "5 pies"
      },
      "abilities": {
        "str": 10,
        "dex": 11,
        "con": 16,
        "int": 2,
        "wis": 12,
        "cha": 5
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 3
        }
      ],
      "damageResistances": [
        "veneno"
      ],
      "senses": [
        "visión en la oscuridad 30 pies",
        "Percepción pasiva 13"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "0",
      "xp": 10,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +2, alcance 5 pies. Acierto: 1 de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "tejon_gigante",
      "name": "Tejón gigante",
      "size": "Mediana",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 0,
        "score": 10
      },
      "hp": {
        "average": 15,
        "formula": "2d8 + 6"
      },
      "speed": {
        "walk": "30 pies",
        "burrow": "10 pies"
      },
      "abilities": {
        "str": 13,
        "dex": 10,
        "con": 17,
        "int": 2,
        "wis": 12,
        "cha": 5
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 3
        }
      ],
      "damageResistances": [
        "veneno"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 13"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/4",
      "xp": 50,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +3, alcance 5 pies. Acierto: 6 (2d4 + 1) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "tiburon_cazador",
      "name": "Tiburón cazador",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 45,
        "formula": "6d10 + 12"
      },
      "speed": {
        "walk": "5 pies",
        "swim": "40 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 14,
        "con": 15,
        "int": 1,
        "wis": 10,
        "cha": 4
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 2
        }
      ],
      "senses": [
        "visión ciega 60 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "2",
      "xp": 450,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Respirar en el agua",
          "text": "El tiburón solo puede respirar bajo el agua."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +6 (con ventaja si el objetivo no tiene todos sus puntos de golpe), alcance 5 pies. Acierto: 14 (3d6 + 4) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "tiburon_arrecife",
      "name": "Tiburón de arrecife",
      "size": "Mediana",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 12,
      "initiative": {
        "modifier": 2,
        "score": 12
      },
      "hp": {
        "average": 22,
        "formula": "4d8 + 4"
      },
      "speed": {
        "walk": "5 pies",
        "swim": "30 pies"
      },
      "abilities": {
        "str": 14,
        "dex": 15,
        "con": 13,
        "int": 1,
        "wis": 10,
        "cha": 4
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 2
        }
      ],
      "senses": [
        "visión ciega 30 pies",
        "Percepción pasiva 12"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1/2",
      "xp": 100,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Atacar en manada",
          "text": "El tiburón tiene ventaja en una tirada de ataque contra una criatura si al menos uno de los aliados del tiburón se encuentra a 5 pies o menos de la criatura y no tiene el estado de incapacitado."
        },
        {
          "name": "Respirar en el agua",
          "text": "El tiburón solo puede respirar bajo el agua."
        }
      ],
      "actions": [
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +4, alcance 5 pies. Acierto: 7 (2d4 + 2) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "tiburon_gigante",
      "name": "Tiburón gigante",
      "size": "Enorme",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 92,
        "formula": "8d12 + 40"
      },
      "speed": {
        "walk": "5 pies",
        "swim": "60 pies"
      },
      "abilities": {
        "str": 23,
        "dex": 11,
        "con": 21,
        "int": 1,
        "wis": 10,
        "cha": 5
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 3
        }
      ],
      "senses": [
        "visión ciega 60 pies",
        "Percepción pasiva 13"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "5",
      "xp": 1800,
      "proficiencyBonus": 3,
      "traits": [
        {
          "name": "Respirar en el agua",
          "text": "El tiburón solo puede respirar bajo el agua."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El tiburón realiza dos ataques de mordisco."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +9 (con ventaja si el objetivo no tiene todos sus puntos de golpe), alcance 5 pies. Acierto: 22 (3d10 + 6) de daño perforante."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "tigre",
      "name": "Tigre",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 30,
        "formula": "4d10 + 8"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 17,
        "dex": 16,
        "con": 14,
        "int": 3,
        "wis": 12,
        "cha": 8
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 3
        },
        {
          "name": "Sigilo",
          "bonus": 7
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 13"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "1",
      "xp": 200,
      "proficiencyBonus": 2,
      "traits": [],
      "actions": [
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +5, alcance 5 pies. Acierto: 10 (2d6 + 3) de daño cortante. Si el objetivo es una criatura Grande o más pequeña, tendrá el estado de derribada."
        }
      ],
      "bonusActions": [
        {
          "name": "Huida veloz",
          "text": "El tigre realiza las acciones de destrabarse o esconderse."
        }
      ],
      "reactions": []
    },
    {
      "id": "tigre_dientes_de_sable",
      "name": "Tigre dientes de sable",
      "size": "Grande",
      "type": "bestia",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 52,
        "formula": "7d10 + 14"
      },
      "speed": {
        "walk": "40 pies"
      },
      "abilities": {
        "str": 18,
        "dex": 17,
        "con": 15,
        "int": 3,
        "wis": 12,
        "cha": 8
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 5
        },
        {
          "name": "Sigilo",
          "bonus": 7
        }
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 15"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "2",
      "xp": 450,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Saltar con carrera",
          "text": "Si se ha movido al menos 10 pies justo antes, el tigre puede realizar un salto de longitud de hasta 25 pies."
        }
      ],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El tigre realiza dos ataques de desgarro."
        },
        {
          "name": "Desgarro",
          "text": "Tirada de ataque cuerpo a cuerpo: +6, alcance 5 pies. Acierto: 11 (2d6 + 4) de daño cortante."
        }
      ],
      "bonusActions": [
        {
          "name": "Huida veloz",
          "text": "El tigre realiza las acciones de destrabarse o esconderse."
        }
      ],
      "reactions": []
    },
    {
      "id": "tiranosaurio_rex",
      "name": "Tiranosaurio rex",
      "size": "Enorme",
      "type": "bestia",
      "subtype": "dinosaurio",
      "alignment": "sin alineamiento",
      "ac": 13,
      "initiative": {
        "modifier": 3,
        "score": 13
      },
      "hp": {
        "average": 136,
        "formula": "13d12 + 52"
      },
      "speed": {
        "walk": "50 pies"
      },
      "abilities": {
        "str": 25,
        "dex": 10,
        "con": 19,
        "int": 2,
        "wis": 12,
        "cha": 9
      },
      "skills": [
        {
          "name": "Percepción",
          "bonus": 4
        }
      ],
      "senses": [
        "Percepción pasiva 14"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "8",
      "xp": 3900,
      "proficiencyBonus": 3,
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El tiranosaurio realiza un ataque de mordisco y uno con su cola."
        },
        {
          "name": "Cola",
          "text": "Tirada de ataque cuerpo a cuerpo: +10, alcance 15 pies. Acierto: 25 (4d8 + 7) de daño contundente. Si el objetivo es una criatura Enorme o más pequeña, tendrá el estado de derribada."
        },
        {
          "name": "Mordisco",
          "text": "Tirada de ataque cuerpo a cuerpo: +10, alcance 10 pies. Acierto: 33 (4d12 + 7) de daño perforante. Si el objetivo es una criatura Grande o más pequeña, tendrá el estado de agarrada (CD 17 para escapar). Mientras esté agarrada, tendrá el estado de apresada y no podrá ser objetivo de la cola del tiranosaurio."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "triceratops",
      "name": "Triceratops",
      "size": "Enorme",
      "type": "bestia",
      "subtype": "dinosaurio",
      "alignment": "sin alineamiento",
      "ac": 14,
      "initiative": {
        "modifier": -1,
        "score": 9
      },
      "hp": {
        "average": 114,
        "formula": "12d12 + 36"
      },
      "speed": {
        "walk": "50 pies"
      },
      "abilities": {
        "str": 22,
        "dex": 9,
        "con": 17,
        "int": 2,
        "wis": 11,
        "cha": 5
      },
      "skills": [],
      "senses": [
        "Percepción pasiva 10"
      ],
      "languages": [
        "ninguno"
      ],
      "cr": "5",
      "xp": 1800,
      "proficiencyBonus": 3,
      "traits": [],
      "actions": [
        {
          "name": "Ataque múltiple",
          "text": "El triceratops realiza dos ataques de cornada."
        },
        {
          "name": "Cornada",
          "text": "Tirada de ataque cuerpo a cuerpo: +9, alcance 5 pies. Acierto: 19 (2d12 + 6) de daño perforante. Si el objetivo es una criatura Enorme o más pequeña y el triceratops recorre al menos 20 pies en línea recta hacia ella justo antes de acertarle, esta recibirá 9 (2d8) de daño perforante adicional y tendrá el estado de derribada."
        }
      ],
      "bonusActions": [],
      "reactions": []
    },
    {
      "id": "zombi",
      "name": "Zombi",
      "size": "Mediana",
      "type": "muerto viviente",
      "alignment": "neutral malvado",
      "ac": 8,
      "initiative": {
        "modifier": -2,
        "score": 8
      },
      "hp": {
        "average": 15,
        "formula": "2d8 + 6"
      },
      "speed": {
        "walk": "20 pies"
      },
      "abilities": {
        "str": 13,
        "dex": 6,
        "con": 16,
        "int": 3,
        "wis": 6,
        "cha": 5
      },
      "savingThrows": [
        {
          "ability": "str",
          "bonus": 1
        },
        {
          "ability": "dex",
          "bonus": -2
        },
        {
          "ability": "con",
          "bonus": 3
        },
        {
          "ability": "int",
          "bonus": -4
        },
        {
          "ability": "wis",
          "bonus": -2
        },
        {
          "ability": "cha",
          "bonus": -3
        }
      ],
      "skills": [],
      "damageVulnerabilities": [],
      "damageResistances": [],
      "damageImmunities": [
        "veneno"
      ],
      "conditionImmunities": [
        "cansancio",
        "envenenado"
      ],
      "senses": [
        "visión en la oscuridad 60 pies",
        "Percepción pasiva 8"
      ],
      "languages": [
        "entiende común y otro idioma, pero no puede hablar"
      ],
      "cr": "1/4",
      "xp": 50,
      "proficiencyBonus": 2,
      "traits": [
        {
          "name": "Fortaleza de muerto viviente",
          "text": "Si el daño reduce a 0 los puntos de golpe del zombi, hará una tirada de salvación de Constitución (CD 5 más el daño sufrido), siempre que el daño no sea radiante o proceda de un crítico. Si la supera, el zombi se queda con 1 punto de golpe."
        }
      ],
      "actions": [
        {
          "name": "Golpe",
          "text": "Tirada de ataque cuerpo a cuerpo: +3, alcance 5 pies. Acierto: 5 (1d8 + 1) de daño contundente."
        }
      ],
      "bonusActions": [],
      "reactions": []
    }
  ]
};
