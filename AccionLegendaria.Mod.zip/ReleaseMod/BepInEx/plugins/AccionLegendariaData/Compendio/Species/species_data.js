window.SPECIES_DATA = {
  "species": [
    {
      "id": "aasimar",
      "name": "Aasimar",
      "size": [
        "Mediano",
        "Pequeño"
      ],
      "type": "humanoide",
      "alignment": "variable",
      "speed": {
        "walk": 30
      },
      "languages": [
        "común",
        "celestial"
      ],
      "darkvision": {
        "range": 60
      },
      "resistances": [
        "necrótico",
        "radiante"
      ],
      "traits": [
        {
          "name": "Manos curativas",
          "description": "Como acción de magia, tocas a una criatura y tiras una cantidad de d4 igual a tu bonificador por competencia. La criatura recupera una cantidad de puntos de golpe igual al resultado total de la tirada. Cuando uses este atributo, no podrás volver a hacerlo hasta que finalices un descanso largo."
        },
        {
          "name": "Portador de luz",
          "description": "Conoces el truco luz. El Carisma es tu aptitud mágica para lanzarlo."
        },
        {
          "name": "Resistencia celestial",
          "description": "Tienes resistencia al daño necrótico y al radiante."
        },
        {
          "name": "Visión en la oscuridad",
          "description": "Tienes visión en la oscuridad hasta 60 pies."
        },
        {
          "name": "Revelación celestial",
          "description": "Cuando alcanzas el nivel 3 de personaje, puedes transformarte como acción adicional y usar una de las opciones que aparecen a continuación (elige la opción cada vez que te transformes). La transformación dura 1 minuto o hasta que le pongas fin (no requiere acción). Cuando te transformes, no podrás volver a hacerlo hasta que finalices un descanso largo.\n\nUna vez en cada uno de tus turnos hasta que finalice la transformación, puedes infligir daño adicional a un objetivo cuando le hagas daño con un ataque o un conjuro. El daño adicional es igual a tu bonificador por competencia y el tipo es necrótico para Mortaja necrótica o radiante para Alas celestiales y Fulgor interior.\n\nEstas son las opciones de transformación:\n\nAlas celestiales. Dos alas espectrales brotan temporalmente de tu espalda. Hasta que la transformación termine, tienes una velocidad volando igual a tu velocidad.\n\nFulgor interior. De tus ojos y tu boca surge temporalmente una luz abrasadora. Durante este tiempo, emites luz brillante en un radio de 10 pies y luz tenue 10 pies más allá y, al final de cada uno de tus turnos, cada criatura a 10 pies o menos de ti recibirá una cantidad de daño radiante igual a tu bonificador por competencia.\n\nMortaja necrótica. Tus ojos se vuelven brevemente pozos de oscuridad y unas alas que no te permiten volar brotan temporalmente de tu espalda. Las criaturas que no sean tus aliados y estén a 10 pies o menos de ti deberán superar una tirada de salvación de Carisma (CD 8 más tu modificador por Carisma y tu bonificador por competencia) o tendrán el estado de asustadas hasta el final de tu siguiente turno."
        }
      ]
    },
    {
      "id": "draconido",
      "name": "Dracónido",
      "size": [
        "Mediano"
      ],
      "type": "humanoide",
      "alignment": "variable",
      "speed": {
        "walk": 30
      },
      "languages": [
        "común",
        "dracónico"
      ],
      "darkvision": {
        "range": 60
      },
      "traits": [
        {
          "name": "Linaje dracónico",
          "description": "Tu linaje proviene de un progenitor dragón. Elige el tipo de dragón en la siguiente tabla. Tu elección afectará a tus atributos Ataque de aliento y Resistencia al daño además de a tu aspecto.",
          "table": {
            "headers": [
              "Dragón",
              "Tipo de daño"
            ],
            "rows": [
              [
                "Azul",
                "Relámpago"
              ],
              [
                "Blanco",
                "Frío"
              ],
              [
                "Bronce",
                "Relámpago"
              ],
              [
                "Cobre",
                "Ácido"
              ],
              [
                "Negro",
                "Ácido"
              ],
              [
                "Oro",
                "Fuego"
              ],
              [
                "Oropel",
                "Fuego"
              ],
              [
                "Plata",
                "Frío"
              ],
              [
                "Rojo",
                "Fuego"
              ],
              [
                "Verde",
                "Veneno"
              ]
            ]
          }
        },
        {
          "name": "Ataque de aliento",
          "description": "Cuando lleves a cabo la acción de atacar en tu turno, puedes sustituir uno de tus ataques por una exhalación de energía mágica en un cono de 15 pies o en una línea de 30 pies de largo y 5 pies de ancho (elige la forma cada vez). Todas las criaturas situadas en esa zona deberán hacer una tirada de salvación de Destreza (CD 8 más tu modificador por Constitución y tu bonificador por competencia). Si la fallan, sufrirán 1d10 de daño del tipo determinado por tu atributo Linaje dracónico. Si la superan, recibirán la mitad de ese daño. El daño aumenta en 1d10 cuando alcanzas los niveles 5 (2d10), 11 (3d10) y 17 (4d10) de personaje.\n\nPuedes utilizar este ataque de aliento una cantidad de veces igual a tu bonificador por competencia y recuperas todos los usos tras finalizar un descanso largo."
        },
        {
          "name": "Resistencia al daño",
          "description": "Tienes resistencia al tipo de daño determinado por tu atributo Linaje dracónico."
        },
        {
          "name": "Visión en la oscuridad",
          "description": "Tienes visión en la oscuridad hasta 60 pies."
        },
        {
          "name": "Vuelo dracónico",
          "description": "Cuando alcanzas el nivel 5 de personaje, puedes canalizar la magia dracónica para volar de forma temporal. Como acción adicional, haces que en la espalda te broten unas alas espectrales que duran 10 minutos o hasta que las repliegues (no requiere acción) o tengas el estado de incapacitado. Durante ese tiempo, tendrás una velocidad volando igual a tu velocidad. Tus alas parecen hechas de la misma energía que tu ataque de aliento.\n\nCuando uses este atributo, no podrás volver a hacerlo hasta que finalices un descanso largo."
        }
      ]
    },
    {
      "id": "elfo",
      "name": "Elfo",
      "size": [
        "Mediano"
      ],
      "type": "humanoide",
      "alignment": "variable",
      "speed": {
        "walk": 30
      },
      "languages": [
        "común",
        "élfico"
      ],
      "darkvision": {
        "range": 60
      },
      "traits": [
        {
          "name": "Linaje élfico",
          "description": "Formas parte de un linaje que te otorga capacidades sobrenaturales. Elige un linaje de la tabla “Linajes élficos”. Obtienes el beneficio de nivel 1 de ese linaje.\n\nCuando alcanzas los niveles 3 y 5 de personaje, aprendes un conjuro de nivel superior, como se muestra en la tabla. Siempre tienes ese conjuro preparado. Puedes lanzarlo una vez sin gastar un espacio de conjuro y recuperas la capacidad de hacerlo de esta forma tras finalizar un descanso largo. También puedes lanzar el conjuro usando cualquier espacio de conjuro que tengas del nivel apropiado.\n\nLa Inteligencia, la Sabiduría o el Carisma es tu aptitud mágica para los conjuros que lances con este atributo (elige la característica al seleccionar el linaje).",
          "table": {
            "headers": [
              "Linaje",
              "Nivel 1",
              "Nivel 3",
              "Nivel 5"
            ],
            "rows": [
              [
                "Alto elfo",
                "Conoces el truco prestidigitación. Tras finalizar un descanso largo, puedes sustituir este truco por otro truco diferente de la lista de conjuros de mago.",
                "Detectar magia",
                "Paso brumoso"
              ],
              [
                "Drow",
                "El alcance de tu visión en la oscuridad aumenta a 120 pies. También conoces el truco luces danzantes.",
                "Fuego feérico",
                "Oscuridad"
              ],
              [
                "Elfo de los bosques",
                "Tu velocidad aumenta a 35 pies. También conoces el truco saber druídico.",
                "Zancada prodigiosa",
                "Pasar sin rastro"
              ]
            ]
          }
        },
        {
          "name": "Linaje feérico",
          "description": "Tienes ventaja en las tiradas de salvación para evitar o poner fin al estado de hechizado."
        },
        {
          "name": "Sentidos agudos",
          "description": "Tienes competencia en la habilidad de Percepción, Perspicacia o Supervivencia."
        },
        {
          "name": "Trance",
          "description": "No necesitas dormir y la magia no puede dormirte. Puedes finalizar un descanso largo en 4 horas si las pasas en una meditación similar a un trance, tiempo durante el cual conservas la consciencia."
        },
        {
          "name": "Visión en la oscuridad",
          "description": "Tienes visión en la oscuridad hasta 60 pies."
        }
      ]
    },
    {
      "id": "enano",
      "name": "Enano",
      "size": [
        "Mediano"
      ],
      "type": "humanoide",
      "alignment": "variable",
      "speed": {
        "walk": 30
      },
      "languages": [
        "común",
        "enano"
      ],
      "darkvision": {
        "range": 120
      },
      "resistances": [
        "veneno"
      ],
      "traits": [
        {
          "name": "Afinidad con la piedra",
          "description": "Como acción adicional, ganas la capacidad de sentir vibraciones con un alcance de 60 pies durante 10 minutos. Debes encontrarte sobre una superficie de piedra o en contacto con una superficie de piedra para usar esta capacidad. La piedra puede ser natural o labrada.\n\nPuedes usar esta acción adicional una cantidad de veces igual a tu bonificador por competencia y recuperas todos los usos tras finalizar un descanso largo."
        },
        {
          "name": "Aguante enano",
          "description": "Tus puntos de golpe máximos se incrementan en 1 y aumentarán en 1 más cada vez que subas un nivel."
        },
        {
          "name": "Resistencia enana",
          "description": "Tienes resistencia al daño de veneno. También tienes ventaja en las tiradas de salvación para evitar o poner fin al estado de envenenado."
        },
        {
          "name": "Visión en la oscuridad",
          "description": "Tienes visión en la oscuridad hasta 120 pies."
        }
      ]
    },
    {
      "id": "gnomo",
      "name": "Gnomo",
      "size": [
        "Pequeño"
      ],
      "type": "humanoide",
      "alignment": "variable",
      "speed": {
        "walk": 30
      },
      "languages": [
        "común",
        "gnómico"
      ],
      "darkvision": {
        "range": 60
      },
      "traits": [
        {
          "name": "Astucia gnoma",
          "description": "Tienes ventaja en las tiradas de salvación de Inteligencia, Sabiduría y Carisma."
        },
        {
          "name": "Linaje gnomo",
          "description": "Formas parte de un linaje que te otorga capacidades sobrenaturales. Escoge una de las siguientes opciones; elijas la que elijas, la Inteligencia, la Sabiduría o el Carisma es tu aptitud mágica para los conjuros que lances con este atributo (elige la característica al seleccionar el linaje).",
          "subtraits": [
            {
              "name": "Gnomo de las rocas",
              "description": "Conoces los trucos prestidigitación y reparar. Además, puedes pasar 10 minutos lanzando prestidigitación para crear un dispositivo mecánico Diminuto (CA 5, 1 pg), como un juguete, un encendedor o una caja de música. Cuando crees el dispositivo, determinarás su función eligiendo un efecto de prestidigitación. El dispositivo producirá ese efecto cada vez que otra criatura o tú empleéis una acción adicional para activarlo con un toque. Si el efecto elegido tiene varias opciones, escoges una de ellas para el dispositivo cuando lo crees. Por ejemplo, si eliges el efecto de encender o apagar del conjuro, determinas si el dispositivo enciende o apaga los fuegos: el dispositivo no hace ambas cosas. Puedes tener tres de estos dispositivos activos al mismo tiempo y se desarman 8 horas después de crearlos o cuando los desmontes con un toque como acción de utilizar."
            },
            {
              "name": "Gnomo de los bosques",
              "description": "Conoces el truco ilusión menor. Además, siempre tienes el conjuro hablar con los animales preparado. Puedes lanzarlo sin gastar un espacio de conjuro una cantidad de veces igual a tu bonificador por competencia y recuperas todos los usos tras finalizar un descanso largo. También puedes usar cualquier espacio de conjuro que tengas para lanzarlo."
            }
          ]
        },
        {
          "name": "Visión en la oscuridad",
          "description": "Tienes visión en la oscuridad hasta 60 pies."
        }
      ]
    },
    {
      "id": "goliat",
      "name": "Goliat",
      "size": [
        "Mediano"
      ],
      "type": "humanoide",
      "alignment": "variable",
      "speed": {
        "walk": 35
      },
      "languages": [
        "común",
        "gigante"
      ],
      "traits": [
        {
          "name": "Constitución poderosa",
          "description": "Tienes ventaja en cualquier prueba de característica que hagas para poner fin al estado de agarrado. Además, al determinar tu capacidad de carga, cuentas como si tuvieras un tamaño una categoría superior."
        },
        {
          "name": "Forma grande",
          "description": "A partir del nivel 5 de personaje, puedes cambiar de tamaño a Grande como acción adicional si estás en un lugar lo bastante espacioso. Esta transformación dura 10 minutos o hasta que le pongas fin (no requiere acción). Durante ese tiempo, tendrás ventaja en las pruebas de Fuerza y tu velocidad aumentará en 10 pies. Cuando uses este atributo, no podrás volver a hacerlo hasta que finalices un descanso largo."
        },
        {
          "name": "Linaje gigante",
          "description": "Desciendes de los gigantes. Elige uno de los siguientes beneficios sobrenaturales que te concede tu linaje; podrás usar el beneficio elegido una cantidad de veces igual a tu bonificador por competencia y recuperas todos los usos tras finalizar un descanso largo.",
          "subtraits": [
            {
              "name": "Abrasión del fuego (gigante de fuego)",
              "description": "Cuando aciertes a un objetivo con una tirada de ataque y le causes daño, también puedes causarle 1d10 de daño de fuego."
            },
            {
              "name": "Caída de las colinas (gigante de las colinas)",
              "description": "Cuando aciertes a una criatura Grande o más pequeña con una tirada de ataque y le causes daño, también puedes infligirle el estado de derribada."
            },
            {
              "name": "Excursión de las nubes (gigante de las nubes)",
              "description": "Como acción adicional, te teletransportas mágicamente hasta 30 pies a un espacio sin ocupar que puedas ver."
            },
            {
              "name": "Frío de la escarcha (gigante de escarcha)",
              "description": "Cuando aciertes a un objetivo con una tirada de ataque y le causes daño, también puedes causarle 1d6 de daño de frío y reducir su velocidad en 10 pies hasta el principio de tu siguiente turno."
            },
            {
              "name": "Resistencia de la piedra (gigante de piedra)",
              "description": "Cuando recibas daño, puedes usar una reacción para tirar 1d12. Suma tu modificador por Constitución al resultado y reduce el daño en ese total."
            },
            {
              "name": "Trueno de la tormenta (gigante de las tormentas)",
              "description": "Cuando una criatura que esté a 60 pies o menos de ti te cause daño, puedes usar una reacción para infligirle 1d8 de daño de trueno."
            }
          ]
        }
      ]
    },
    {
      "id": "humano",
      "name": "Humano",
      "size": [
        "Mediano",
        "Pequeño"
      ],
      "type": "humanoide",
      "alignment": "variable",
      "speed": {
        "walk": 30
      },
      "languages": [
        "común"
      ],
      "traits": [
        {
          "name": "Diestro",
          "description": "Ganas competencia en una habilidad de tu elección."
        },
        {
          "name": "Ingenioso",
          "description": "Obtienes inspiración heroica tras finalizar un descanso largo."
        },
        {
          "name": "Versátil",
          "description": "Obtienes una dote de origen de tu elección."
        }
      ]
    },
    {
      "id": "mediano",
      "name": "Mediano",
      "size": [
        "Pequeño"
      ],
      "type": "humanoide",
      "alignment": "variable",
      "speed": {
        "walk": 30
      },
      "languages": [
        "común",
        "mediano"
      ],
      "traits": [
        {
          "name": "Agilidad de mediano",
          "description": "Puedes moverte a través del espacio ocupado por cualquier criatura de tamaño superior al tuyo, pero no puedes detenerte en el mismo espacio."
        },
        {
          "name": "Fortuna",
          "description": "Cuando saques un 1 en una prueba con d20, podrás repetir la tirada y deberás utilizar el nuevo resultado."
        },
        {
          "name": "Sigiloso por naturaleza",
          "description": "Puedes llevar a cabo la acción de esconderte incluso tras una criatura cuyo tamaño sea, al menos, una categoría superior al tuyo."
        },
        {
          "name": "Valiente",
          "description": "Tienes ventaja en las tiradas de salvación que hagas para evitar o poner fin al estado de asustado."
        }
      ]
    },
    {
      "id": "orco",
      "name": "Orco",
      "size": [
        "Mediano"
      ],
      "type": "humanoide",
      "alignment": "variable",
      "speed": {
        "walk": 30
      },
      "languages": [
        "común",
        "orco"
      ],
      "darkvision": {
        "range": 120
      },
      "traits": [
        {
          "name": "Aguante incansable",
          "description": "Cuando tus puntos de golpe se reducen a 0 pero no mueres inmediatamente, puedes recuperar 1 punto de golpe. Cuando uses este atributo, no podrás volver a hacerlo hasta que finalices un descanso largo."
        },
        {
          "name": "Descarga de adrenalina",
          "description": "Puedes llevar a cabo la acción de correr como acción adicional. Cuando lo hagas, obtendrás una cantidad de puntos de golpe temporales igual a tu bonificador por competencia.\n\nPuedes usar este atributo una cantidad de veces igual a tu bonificador por competencia y recuperas todos los usos tras finalizar un descanso corto o largo."
        },
        {
          "name": "Visión en la oscuridad",
          "description": "Tienes visión en la oscuridad hasta 120 pies."
        }
      ]
    },
    {
      "id": "tiefling",
      "name": "Tiefling",
      "size": [
        "Mediano",
        "Pequeño"
      ],
      "type": "humanoide",
      "alignment": "variable",
      "speed": {
        "walk": 30
      },
      "languages": [
        "común",
        "infernal"
      ],
      "darkvision": {
        "range": 60
      },
      "traits": [
        {
          "name": "Legado infernal",
          "description": "Eres el destinatario de un legado que te otorga capacidades sobrenaturales. Elige un legado de la tabla “Legados infernales”. Obtienes el beneficio de nivel 1 del legado elegido.\n\nCuando alcanzas los niveles 3 y 5 de personaje, aprendes un conjuro de nivel superior, como se muestra en la tabla. Siempre tienes ese conjuro preparado. Puedes lanzarlo una vez sin gastar un espacio de conjuro y recuperas la capacidad de hacerlo de esta forma tras finalizar un descanso largo. También puedes lanzar el conjuro usando cualquier espacio de conjuro que tengas del nivel apropiado.\n\nLa Inteligencia, la Sabiduría o el Carisma es tu aptitud mágica para los conjuros que lances con este atributo (elige la característica al seleccionar el legado).",
          "table": {
            "headers": [
              "Legado",
              "Nivel 1",
              "Nivel 3",
              "Nivel 5"
            ],
            "rows": [
              [
                "Abisal",
                "Tienes resistencia al daño de veneno. También conoces el truco rociada venenosa.",
                "Rayo nauseabundo",
                "Inmovilizar persona"
              ],
              [
                "Ctónico",
                "Tienes resistencia al daño necrótico. También conoces el truco toque helado.",
                "Falsa vida",
                "Rayo debilitador"
              ],
              [
                "Infernal",
                "Tienes resistencia al daño de fuego. También conoces el truco descarga de fuego.",
                "Represión infernal",
                "Oscuridad"
              ]
            ]
          }
        },
        {
          "name": "Presencia sobrenatural",
          "description": "Conoces el truco taumaturgia. Cuando lo lances con este atributo, el conjuro utiliza la misma aptitud mágica que la de tu atributo Legado infernal."
        },
        {
          "name": "Visión en la oscuridad",
          "description": "Tienes visión en la oscuridad hasta 60 pies."
        }
      ]
    },
    {
      "id": "dhampir",
      "name": "Dhampir",
      "size": [
        "Mediano",
        "Pequeño"
      ],
      "type": "humanoide",
      "alignment": "variable",
      "speed": {
        "walk": 35,
        "climb": 35
      },
      "darkvision": {
        "range": 60
      },
      "resistances": [
        "necrótico"
      ],
      "traits": [
        {
          "name": "Visión en la oscuridad",
          "description": "Tienes visión en la oscuridad con un alcance de 60 pies."
        },
        {
          "name": "Trepar como araña",
          "description": "Tienes una velocidad de trepar igual a tu velocidad. Cuando alcanzas el nivel 3 de personaje, puedes moverte hacia arriba, abajo y a través de superficies verticales y por techos sin necesidad de usar las manos."
        },
        {
          "name": "Rastro de no-muerte",
          "description": "Tienes resistencia al daño necrótico."
        },
        {
          "name": "Mordedura vampírica",
          "description": "Cuando realizas un ataque sin armas y causas daño, puedes elegir morder con tus colmillos. Infliges daño perforante igual a 1d4 + tu modificador de Constitución en lugar del daño normal de un ataque sin armas.\n\nAdemás, cuando infliges este daño a una criatura que no sea un constructo ni un no muerto, puedes potenciarte de una de las siguientes formas:",
          "subtraits": [
            {
              "name": "Drenar",
              "description": "Recuperas puntos de golpe iguales al daño perforante infligido."
            },
            {
              "name": "Fortalecer",
              "description": "Obtienes un bonificador a la siguiente prueba de característica o tirada de ataque que realices antes de que transcurra 1 minuto; el bonificador es igual al daño perforante infligido."
            }
          ],
          "uses": {
            "count": "PB",
            "recharge": "descanso largo"
          }
        }
      ],
      "languages": [
        "común",
        "otro idioma"
      ]
    },
    {
      "id": "cambiante",
      "name": "Cambiante",
      "size": [
        "Mediano",
        "Pequeño"
      ],
      "type": "feérico",
      "alignment": "variable",
      "speed": {
        "walk": 30
      },
      "traits": [
        {
          "name": "Instintos cambiantes",
          "description": "Obtienes competencia en dos de las siguientes habilidades a tu elección: Engaño, Perspicacia, Intimidación, Interpretación o Persuasión."
        },
        {
          "name": "Cambiaformas",
          "description": "Como acción, puedes cambiar tu apariencia y tu voz. Puedes modificar tu coloración, longitud del cabello, sexo, altura y peso, y cambiar tu tamaño entre Mediano y Pequeño.\n\nPuedes parecer de otra especie jugable, pero tus estadísticas no cambian. No puedes copiar a alguien que no hayas visto y debes mantener la misma estructura corporal. Este rasgo no cambia tu equipo.\n\nMientras estés transformado, tienes ventaja en las pruebas de Carisma.\n\nPermaneces en esta forma hasta que uses una acción para volver a tu forma original."
        }
      ],
      "languages": [
        "común",
        "otro idioma"
      ]
    },
    {
      "id": "kalashtar",
      "name": "Kalashtar",
      "size": [
        "Mediano"
      ],
      "type": "aberración",
      "alignment": "variable",
      "speed": {
        "walk": 30
      },
      "resistances": [
        "psíquico"
      ],
      "traits": [
        {
          "name": "Mente dual",
          "description": "Tienes ventaja en las tiradas de salvación de Sabiduría y Carisma."
        },
        {
          "name": "Disciplina mental",
          "description": "Tienes resistencia al daño psíquico."
        },
        {
          "name": "Vínculo mental",
          "description": "Tienes telepatía con un alcance en pies igual a 10 veces tu nivel.\n\nPuedes usar una acción de magia para permitir que una criatura con la que te comuniques pueda responderte telepáticamente durante 1 hora."
        },
        {
          "name": "Separado de los sueños",
          "description": "No puedes ser objetivo del conjuro sueño.\n\nAl finalizar un descanso largo, obtienes competencia en una habilidad a tu elección hasta que finalices otro descanso largo."
        }
      ],
      "languages": [
        "común"
      ]
    },
    {
      "id": "khoravar",
      "name": "Semielfo (Khoravar)",
      "size": [
        "Mediano",
        "Pequeño"
      ],
      "type": "humanoide",
      "alignment": "variable",
      "speed": {
        "walk": 30
      },
      "darkvision": {
        "range": 60
      },
      "traits": [
        {
          "name": "Ascendencia feérica",
          "description": "Tienes ventaja en las tiradas de salvación para evitar o finalizar el estado de encantado."
        },
        {
          "name": "Don feérico",
          "description": "Conoces el truco amistad.\n\nTras finalizar un descanso largo, puedes sustituirlo por un truco de clérigo, druida o mago. La Inteligencia, Sabiduría o Carisma es tu aptitud mágica."
        },
        {
          "name": "Resistencia al letargo",
          "description": "Cuando fallas una tirada de salvación para evitar o finalizar el estado de inconsciente, puedes tener éxito en su lugar.\n\nNo puedes volver a usar este rasgo hasta finalizar 1d4 descansos largos."
        },
        {
          "name": "Versatilidad",
          "description": "Obtienes competencia en una habilidad o herramienta.\n\nTras finalizar un descanso largo, puedes cambiarla por otra."
        }
      ],
      "languages": [
        "común",
        "élfico"
      ]
    },
    {
      "id": "cambiante_salvaje",
      "name": "Cambiaformas",
      "size": [
        "Mediano",
        "Pequeño"
      ],
      "type": "humanoide",
      "alignment": "variable",
      "speed": {
        "walk": 30
      },
      "darkvision": {
        "range": 60
      },
      "traits": [
        {
          "name": "Instintos bestiales",
          "description": "Obtienes competencia en una de las siguientes habilidades: Acrobacias, Atletismo, Intimidación o Supervivencia."
        },
        {
          "name": "Transformación",
          "description": "Como acción adicional, puedes adoptar una forma bestial durante 1 minuto.\n\nObtienes puntos de golpe temporales iguales a 2 × tu bonificador por competencia.\n\nPuedes usar este rasgo un número de veces igual a tu bonificador por competencia y recuperas todos los usos tras un descanso largo.",
          "subtraits": [
            {
              "name": "Piel bestial",
              "description": "Obtienes 1d6 puntos de golpe temporales adicionales y +1 a la CA."
            },
            {
              "name": "Colmillo alargado",
              "description": "Puedes realizar ataques sin armas que infligen 1d6 + Fuerza de daño perforante."
            },
            {
              "name": "Zancada veloz",
              "description": "Tu velocidad aumenta en 10 pies y puedes moverte 10 pies como reacción sin provocar ataques de oportunidad."
            },
            {
              "name": "Caza salvaje",
              "description": "Tienes ventaja en pruebas de Sabiduría y los enemigos no obtienen ventaja contra ti."
            }
          ]
        }
      ],
      "languages": [
        "común"
      ]
    },
    {
      "id": "forjado",
      "name": "Forjado",
      "size": [
        "Mediano",
        "Pequeño"
      ],
      "type": "constructo",
      "alignment": "variable",
      "speed": {
        "walk": 30
      },
      "resistances": [
        "veneno"
      ],
      "traits": [
        {
          "name": "Resistencia de constructo",
          "description": "Tienes resistencia al daño de veneno y ventaja en tiradas de salvación contra el estado envenenado."
        },
        {
          "name": "Protección integrada",
          "description": "Obtienes +1 a la CA. Tu armadura no puede ser retirada contra tu voluntad."
        },
        {
          "name": "Descanso de centinela",
          "description": "No necesitas dormir y puedes completar un descanso largo en 6 horas permaneciendo inmóvil."
        },
        {
          "name": "Diseño especializado",
          "description": "Obtienes competencia en una habilidad y una herramienta."
        },
        {
          "name": "Incansable",
          "description": "No sufres agotamiento por deshidratación, hambre o asfixia."
        }
      ],
      "languages": [
        "común"
      ]
    }
  ]
}